# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------

import bpy
from .bmesh_utils import BmeshEdit as bmed
from math import pi, sin, cos
from mathutils import Vector
from bpy.props import PointerProperty
from bpy.types import Object
import logging
logger = logging.getLogger(__package__)


def update_handle(self, context):
    self.update(context, childs_only=True)
    self.cleanup_user_defined_objects(context, bpy.data.objects)


class ArchipackHandle:

    user_defined_handle: PointerProperty(
        name="Inside",
        type=Object,
        update=update_handle
    )
    user_defined_handle_outside: PointerProperty(
        name="Outside",
        type=Object,
        update=update_handle
    )

    def _handle_geom(self, _verts, _faces, faces, verts, side=0, direction=0, depth=0):
        offset = len(verts)
        if side != direction:
            faces.extend([tuple([i + offset for i in reversed(f)]) for f in _faces])
        else:
            faces.extend([tuple(i + offset for i in f) for f in _faces])
        x, y = 1, 1
        if direction == 1:
            x = -1
        if side == 1:
            y = -1
        verts.extend([tuple([x * v[0], y * v[1] - depth, v[2]]) for v in _verts])

    def _door_handle_1(self, verts, faces, side, direction, depth):
        """
            side 1 -> inside
        """
        _verts = [(0.015, -0.003, -0.107), (0.008, -0.002, -0.007), (0.015, -0.002, -0.107),
                 (0.019, -0.002, -0.026), (-0.015, -0.003, -0.107), (-0.007, -0.002, -0.007),
                 (-0.015, -0.002, -0.107), (-0.018, -0.002, -0.026), (0.008, -0.002, 0.007),
                 (0.019, -0.002, 0.034), (-0.018, -0.002, 0.034), (-0.007, -0.002, 0.007),
                 (-0.018, -0.003, -0.026), (0.019, -0.003, -0.026), (-0.018, -0.003, 0.034),
                 (0.019, -0.003, 0.034), (-0.007, -0.042, -0.007), (0.008, -0.042, -0.007),
                 (-0.007, -0.042, 0.007), (0.008, -0.042, 0.007), (-0.007, -0.047, -0.016),
                 (0.008, -0.048, -0.018), (-0.007, -0.047, 0.016), (0.008, -0.048, 0.018),
                 (-0.025, -0.041, 0.013), (-0.025, -0.041, -0.012), (-0.025, -0.048, 0.013),
                 (-0.025, -0.048, -0.012), (0.019, -0.0, -0.026), (0.015, -0.0, -0.107),
                 (-0.015, -0.0, -0.107), (-0.018, -0.0, -0.026), (0.019, 0.0, 0.034),
                 (-0.018, 0.0, 0.034), (-0.107, -0.041, 0.013), (-0.107, -0.041, -0.012),
                 (-0.107, -0.048, 0.013), (-0.107, -0.048, -0.012), (-0.12, -0.041, 0.013),
                 (-0.12, -0.041, -0.012), (-0.12, -0.048, 0.013), (-0.12, -0.048, -0.012),
                 (0.008, -0.005, -0.007), (0.008, -0.005, 0.007), (-0.007, -0.005, 0.007),
                 (-0.007, -0.005, -0.007), (0.008, -0.041, -0.007), (0.008, -0.041, 0.007),
                 (-0.007, -0.041, 0.007), (-0.007, -0.041, -0.007), (0.015, -0.003, -0.091),
                 (0.015, -0.002, -0.091), (-0.015, -0.002, -0.091), (-0.015, -0.003, -0.091),
                 (0.015, -0.0, -0.091), (-0.015, -0.0, -0.091), (0.015, -0.003, 0.044),
                 (0.015, -0.002, 0.044), (-0.015, -0.002, 0.044), (-0.015, -0.003, 0.044),
                 (0.015, 0.0, 0.044), (-0.015, 0.0, 0.044)]

        _faces = [(50, 51, 3, 13), (52, 55, 30, 6), (52, 53, 12, 7), (53, 50, 13, 12),
                 (2, 0, 4, 6), (10, 33, 31, 7), (15, 56, 59, 14), (12, 14, 10, 7),
                 (3, 9, 15, 13), (47, 19, 17, 46), (5, 12, 13, 1), (8, 15, 14, 11),
                 (11, 14, 12, 5), (1, 13, 15, 8), (22, 26, 27, 20), (48, 18, 19, 47),
                 (49, 16, 18, 48), (46, 17, 16, 49), (21, 23, 22, 20), (17, 21, 20, 16),
                 (19, 23, 21, 17), (18, 22, 23, 19), (24, 34, 36, 26), (16, 25, 24, 18),
                 (20, 27, 25, 16), (18, 24, 26, 22), (4, 0, 50, 53), (2, 29, 54, 51),
                 (6, 30, 29, 2), (10, 58, 61, 33), (3, 28, 32, 9), (51, 54, 28, 3),
                 (34, 38, 40, 36), (25, 35, 34, 24), (27, 37, 35, 25), (26, 36, 37, 27),
                 (39, 41, 40, 38), (35, 39, 38, 34), (37, 41, 39, 35), (36, 40, 41, 37),
                 (1, 42, 45, 5), (5, 45, 44, 11), (11, 44, 43, 8), (8, 43, 42, 1),
                 (42, 46, 49, 45), (45, 49, 48, 44), (44, 48, 47, 43), (43, 47, 46, 42),
                 (6, 4, 53, 52), (7, 31, 55, 52), (0, 2, 51, 50), (58, 59, 56, 57),
                 (57, 60, 61, 58), (32, 60, 57, 9), (14, 59, 58, 10), (9, 57, 56, 15)]

        self._handle_geom(_verts, _faces, faces, verts, side, direction, depth)

    def _door_handle_15(self, verts, faces, side, direction, depth, profil, s):
        # Buttons like, elliptic, round
        s1 = len(profil) - 1
        _verts = []
        da = 2 * pi / s
        for x, y in profil:
            a = pi / 4
            for k in range(s):
                a -= da
                _verts.append(tuple([cos(a) * x, -y, sin(a) * x]))
        _faces = [(
            j * s + i + 1,
            j * s + i,
            (j + 1) * s + i,
            (j + 1) * s + i + 1
            ) for i in range(s - 1)
            for j in range(s1)
        ]
        _faces.extend([(
            j * s,
            (j + 1) * s - 1,
            (j + 2) * s - 1,
            (j + 1) * s
        ) for j in range(s1)])
        f = s * (s1 + 1) - 1
        _faces.append(tuple([f - i for i in range(s)]))
        self._handle_geom(_verts, _faces, faces, verts, side, direction, depth)

    def _window_handle_0s(self, verts, faces, side, direction, depth):
        """
            side 1 -> inside
            short handle for flat window
        """
        _verts = [(-0.01, 0.003, 0.011), (-0.013, 0.0, -0.042), (-0.018, 0.003, 0.03), (-0.01, 0.003, -0.01),
                 (-0.018, 0.003, -0.038), (0.01, 0.003, 0.011), (0.018, 0.003, 0.03), (0.018, 0.003, -0.038),
                 (0.01, 0.003, -0.01), (-0.018, 0.004, -0.038), (-0.018, 0.004, 0.03), (0.018, 0.004, -0.038),
                 (0.018, 0.004, 0.03), (-0.01, 0.039, -0.01), (-0.01, 0.025, 0.011), (0.01, 0.036, -0.01),
                 (0.01, 0.025, 0.011), (-0.017, 0.049, -0.01), (-0.01, 0.034, 0.011), (0.017, 0.049, -0.01),
                 (0.01, 0.034, 0.011), (0.0, 0.041, -0.048), (0.013, 0.003, 0.033), (0.019, 0.057, -0.048),
                 (-0.019, 0.057, -0.048), (-0.018, 0.0, 0.03), (0.013, 0.0, -0.042), (0.013, 0.004, -0.042),
                 (-0.018, 0.0, -0.038), (0.018, 0.0, 0.03), (0.018, 0.0, -0.038), (0.001, 0.041, -0.126),
                 (-0.013, 0.004, 0.033), (0.019, 0.056, -0.126), (-0.019, 0.056, -0.126), (0.001, 0.036, -0.16),
                 (-0.013, 0.003, 0.033), (0.019, 0.051, -0.16), (-0.019, 0.051, -0.16), (-0.01, 0.006, 0.011),
                 (0.01, 0.006, 0.011), (0.01, 0.006, -0.01), (-0.01, 0.006, -0.01), (-0.01, 0.025, 0.011),
                 (0.01, 0.025, 0.011), (0.01, 0.035, -0.01), (-0.01, 0.038, -0.01), (0.013, 0.003, -0.042),
                 (-0.013, 0.0, 0.033), (-0.013, 0.004, -0.042), (-0.013, 0.003, -0.042), (0.013, 0.004, 0.033),
                 (0.013, 0.0, 0.033)]

        _faces = [(4, 2, 10, 9), (6, 12, 51, 22), (10, 2, 36, 32), (2, 25, 48, 36),
                 (27, 47, 50, 49), (7, 30, 26, 47), (28, 4, 50, 1), (12, 10, 32, 51),
                 (16, 14, 43, 44), (9, 10, 0, 3), (12, 11, 8, 5), (11, 9, 3, 8),
                 (10, 12, 5, 0), (23, 24, 17, 19), (15, 16, 44, 45), (13, 15, 45, 46),
                 (14, 13, 46, 43), (20, 19, 17, 18), (18, 17, 13, 14), (20, 18, 14, 16),
                 (19, 20, 16, 15), (31, 33, 23, 21), (21, 15, 13), (24, 21, 13, 17),
                 (21, 23, 19, 15), (9, 11, 27, 49), (26, 1, 50, 47), (4, 9, 49, 50),
                 (29, 6, 22, 52), (35, 37, 33, 31), (48, 52, 22, 36), (34, 31, 21, 24),
                 (33, 34, 24, 23), (38, 37, 35), (22, 51, 32, 36), (38, 35, 31, 34),
                 (37, 38, 34, 33), (39, 42, 3, 0), (42, 41, 8, 3), (41, 40, 5, 8),
                 (40, 39, 0, 5), (43, 46, 42, 39), (46, 45, 41, 42), (45, 44, 40, 41),
                 (44, 43, 39, 40), (28, 25, 2, 4), (12, 6, 7, 11), (7, 6, 29, 30),
                 (11, 7, 47, 27)]
        self._handle_geom(_verts, _faces, faces, verts, side=side, depth=depth)

    def _window_handle_0l(self, verts, faces, side, direction, depth):
        """
            side 1 -> inside
            long handle for rail windows
        """
        _verts = [(-0.01, 0.003, 0.011), (-0.013, 0.0, -0.042), (-0.018, 0.003, 0.03), (-0.01, 0.003, -0.01),
                 (-0.018, 0.003, -0.038), (0.01, 0.003, 0.011), (0.018, 0.003, 0.03), (0.018, 0.003, -0.038),
                 (0.01, 0.003, -0.01), (-0.018, 0.004, -0.038), (-0.018, 0.004, 0.03), (0.018, 0.004, -0.038),
                 (0.018, 0.004, 0.03), (-0.01, 0.041, -0.01), (-0.01, 0.027, 0.011), (0.01, 0.038, -0.01),
                 (0.01, 0.027, 0.011), (-0.017, 0.054, -0.01), (-0.01, 0.039, 0.011), (0.017, 0.054, -0.01),
                 (0.01, 0.039, 0.011), (0.0, 0.041, -0.048), (0.013, 0.003, 0.033), (0.019, 0.059, -0.048),
                 (-0.019, 0.059, -0.048), (-0.018, 0.0, 0.03), (0.013, 0.0, -0.042), (0.013, 0.004, -0.042),
                 (-0.018, 0.0, -0.038), (0.018, 0.0, 0.03), (0.018, 0.0, -0.038), (0.001, 0.041, -0.322),
                 (-0.013, 0.004, 0.033), (0.019, 0.058, -0.322), (-0.019, 0.058, -0.322), (0.001, 0.036, -0.356),
                 (-0.013, 0.003, 0.033), (0.019, 0.053, -0.356), (-0.019, 0.053, -0.356), (-0.01, 0.006, 0.011),
                 (0.01, 0.006, 0.011), (0.01, 0.006, -0.01), (-0.01, 0.006, -0.01), (-0.01, 0.027, 0.011),
                 (0.01, 0.027, 0.011), (0.01, 0.037, -0.01), (-0.01, 0.04, -0.01), (0.013, 0.003, -0.042),
                 (-0.013, 0.0, 0.033), (-0.013, 0.004, -0.042), (-0.013, 0.003, -0.042), (0.013, 0.004, 0.033),
                 (0.013, 0.0, 0.033)]

        _faces = [(4, 2, 10, 9), (6, 12, 51, 22), (10, 2, 36, 32), (2, 25, 48, 36),
                 (27, 47, 50, 49), (7, 30, 26, 47), (28, 4, 50, 1), (12, 10, 32, 51),
                 (16, 14, 43, 44), (9, 10, 0, 3), (12, 11, 8, 5), (11, 9, 3, 8),
                 (10, 12, 5, 0), (23, 24, 17, 19), (15, 16, 44, 45), (13, 15, 45, 46),
                 (14, 13, 46, 43), (20, 19, 17, 18), (18, 17, 13, 14), (20, 18, 14, 16),
                 (19, 20, 16, 15), (31, 33, 23, 21), (21, 15, 13), (24, 21, 13, 17),
                 (21, 23, 19, 15), (9, 11, 27, 49), (26, 1, 50, 47), (4, 9, 49, 50),
                 (29, 6, 22, 52), (35, 37, 33, 31), (48, 52, 22, 36), (34, 31, 21, 24),
                 (33, 34, 24, 23), (38, 37, 35), (22, 51, 32, 36), (38, 35, 31, 34),
                 (37, 38, 34, 33), (39, 42, 3, 0), (42, 41, 8, 3), (41, 40, 5, 8),
                 (40, 39, 0, 5), (43, 46, 42, 39), (46, 45, 41, 42), (45, 44, 40, 41),
                 (44, 43, 39, 40), (28, 25, 2, 4), (12, 6, 7, 11), (7, 6, 29, 30),
                 (11, 7, 47, 27)]
        self._handle_geom(_verts, _faces, faces, verts, side=side, depth=depth)

    def find_handle(self, o):
        return [
            self.find_one_by_flag(o, ("handle", "handle_inside")),
            self.find_one_by_flag(o, "handle_outside")
        ]

    def _update_handle_mesh(self, context, o, handle_type, id_mat, direction, sides, depth):
        verts, faces = [], []

        if "WINDOW" in handle_type:

            logger.debug("%s", handle_type)

            if handle_type == "WINDOW_0000":
                # short models
                if (sides & 1) > 0:
                    self._window_handle_0s(verts, faces, 0, direction, 0)
                if (sides & 2) > 0:
                    self._window_handle_0s(verts, faces, 1, direction, depth)
            elif handle_type == "WINDOW_0001":
                # long models
                if (sides & 1) > 0:
                    self._window_handle_0l(verts, faces, 0, direction, 0)
                if (sides & 2) > 0:
                    self._window_handle_0l(verts, faces, 1, direction, depth)
        else:
            if handle_type == "DOOR_1":
                if (sides & 1) > 0:
                    self._door_handle_1(verts, faces, 1, direction, 0)
                if (sides & 2) > 0:
                    self._door_handle_1(verts, faces, 0, direction, depth)

            elif handle_type == "DOOR_15":
                # 152 Spherical handle
                s = 12
                r, y = 0.03, 0.08
                y = max(2 * r, y)
                da = pi / s
                a = -pi / 2
                r0 = r * cos(a + da)
                profil = [(3.5 * r0, 0), (3.5 * r0, 0.03 * y), (r0, 0.03 * y)]
                z = 1.5 * r + 0.03 * y
                for i in range(s - 1):
                    a += da
                    profil.append((cos(a) * r, z + sin(a) * r))
                if (sides & 1) > 0:
                    self._door_handle_15(verts, faces, 1, direction, 0, profil, s)
                if (sides & 2) > 0:
                    self._door_handle_15(verts, faces, 0, direction, depth, profil, s)

        if len(verts) > 0:
            bmed.buildmesh(o, verts, faces, [id_mat] * len(faces), ensure_uvs=True)
            self.shade_smooth(context, o, 0.20944)
        else:
            bmed.emptymesh(o)
        return None

    def _mirror_custom_object(self, o, flip, axis="X"):
        if flip and not self.has_flag(o.data, "mirror"):
            sel = []
            self.rec_get_childrens(o, sel)
            _axis = axis.lower()
            for c in sel:
                bm = bmed._start(c)
                bmed.mirror(bm, axis=axis)
                bmed._end(bm, c)
                if c.name != o.name:
                    for _a in _axis:
                        setattr(c.location, _a, -getattr(c.location, _a))
        self.set_flag(o.data, "mirror", flip)

    def update_handle(
            self, context, parent, handle_type, handle_location, id_mat, sides=0, direction=0, y=0
    ):

        i, o = self.find_handle(parent)

        mirror = not bool(direction)

        if i is not None and (
            ("USER" in handle_type and (self.has_flag(i, "handle") or self.user_defined_handle is None)) or
            ("USER" not in handle_type and self.has_flag(i, "handle_inside")) or
            (sides == 0) or handle_type == 'NONE' or
            (mirror != self.has_flag(i.data, "mirror", write=False))
        ):
            self.delete_object(context, i)
            i = None

        if o is not None and (
            ("USER" in handle_type and self.user_defined_handle_outside is None) or
            ("USER" not in handle_type and  self.has_flag(o, "handle_outside")) or
            (sides == 0) or handle_type == 'NONE' or
            (mirror == self.has_flag(o.data, "mirror", write=False))
        ):
            self.delete_object(context, o)
            o = None

        if sides == 0 or handle_type == 'NONE':
            return None

        elif "USER" not in handle_type:
            if i is None:
                i, m = self.create_mesh("Handle")
                self.set_flag(i, "handle", True)
                self.link_object_to_scene(context, i)
                self.link_collections(i, parent)
                i.color = (0, 1, 0, 1)
                modif = i.modifiers.new('Subsurf', 'SUBSURF')
                modif.render_levels = 3
                modif.levels = 2

                i.parent = parent
                i.matrix_world = parent.matrix_world.copy()
                # XXX my best guess here is that parent_inverse play a role in flipping rotation ..
                i.rotation_euler.z = 0
                self.safe_scale(i)

            self._update_handle_mesh(context, i, handle_type, id_mat, direction, sides, y)
            self.link_materials(context, parent, i)
            i.location = handle_location

            return i
        else:

            # Custom based handles
            if self.user_defined_handle is not None and (sides & 1) > 0:
                # Duplicate custom handle
                if i is None:
                    i = self.duplicate_object(context, self.user_defined_handle, not mirror, layer_name="Openings")
                    self.link_collections(i, parent)
                    self.set_flag(i, "handle_inside", True)
                    # when reuse standard handle, the flag may remains
                    self.set_flag(i, 'handle', False)
                    i.parent = parent
                    i.matrix_world = parent.matrix_world.copy()
                    i.rotation_euler.z = 0
                    self.safe_scale(i)

                i.location = handle_location
                self._mirror_custom_object(i, mirror)

            if self.user_defined_handle_outside is not None and (sides & 2) > 0:
                if o is None:
                    o = self.duplicate_object(context, self.user_defined_handle_outside, mirror, layer_name="Openings")
                    self.link_collections(o, parent)
                    self.set_flag(o, "handle_outside", True)
                    # when reuse standard handle, the flag may remains
                    self.set_flag(o, 'handle', False)

                    o.parent = parent
                    o.matrix_world = parent.matrix_world.copy()
                    o.rotation_euler.z = pi
                    self.safe_scale(o)

                x, _y, z = handle_location
                o.location = (x, _y - y, z)
                self._mirror_custom_object(o, not mirror)

            return o
