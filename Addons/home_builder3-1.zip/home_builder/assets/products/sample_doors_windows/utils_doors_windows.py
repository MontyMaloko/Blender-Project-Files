
def get_scene_props(scene):
    return scene.hb_doors_windows