'''-*- coding:utf-8 -*-

Easyref Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

import bpy
from bpy.types import Operator
from bpy.props import (StringProperty,
                       BoolProperty, EnumProperty,
                       IntProperty, FloatProperty
                       )

from .all_operators import Freezer
from .properties import *
import math
from math import radians
from mathutils import Matrix, Vector
import blf
import numpy as np
from math import sqrt

def area_of_type(type_name):
    for area in bpy.context.screen.areas:
        if area.type == type_name:
            return area

def get_3d_view():
    return area_of_type('VIEW_3D')

def angle(pt1, pt2):
    return math.atan2(pt2[1] - pt1[1], pt2[0] - pt1[0])

def distance_2d(pt1, pt2):
    dist = math.sqrt((pt1[0]-pt2[0])**2 + (pt1[1]-pt2[1])**2)
    return dist

font_info = {
    "font_id": 0,
    "handler": None,
}

def easyref_draw_callback_px(self, context, cam):
    # Define colors
    color_orange = (1, 0.522, 0, 1)  # RGBA
    color_white = (1.0, 1.0, 1.0, 1.0)  # RGBA
    
    # Define font sizes based on DPI
    font_size = 30
    
    # Calculate height and width
    height = context.area.height
    
    # Check T panel overlap
    overlap = context.preferences.system.use_region_overlap
    t_panel_width = 0
    if overlap:
        for region in context.area.regions:
            if region.type == 'TOOLS':
                t_panel_width = region.width

    # Calculate position
    y = height / 2 + 200  # Position at 75% of screen height
    x = t_panel_width + 20  # Left margin

    # Setup font
    font_id = font_info["font_id"]
    blf.size(font_id, int(font_size))

    # Draw camera info
    label = "CAMERA LENS: "
    value = str(round(cam.data.lens, 2))

    # Draw label in orange
    blf.position(font_id, x, y, 0)
    blf.color(font_id, *color_orange)
    blf.draw(font_id, label)

    # Calculate width of label for value position
    text_width, text_height = blf.dimensions(font_id, label)

    # Draw value in white
    blf.position(font_id, x + text_width, y, 0)
    blf.color(font_id, *color_white)
    blf.draw(font_id, value)

def dist_3d(pt1, pt2):
    dist = sqrt((pt1[0]-pt2[0])**2 + (pt1[1]-pt2[1])**2 + (pt1[2]-pt2[2])**2)
    return dist

def translate(pt1, pt2, factor):
    pt1, pt2 = np.array(pt1), np.array(pt2)
    return (pt1 + factor*(pt2 - pt1)).tolist()

def get_axis(obj):
    mat = obj.matrix_world
    localX = Vector((mat[0][0],mat[1][0],mat[2][0]))
    localY = Vector((mat[0][1],mat[1][1],mat[2][1]))
    localZ = Vector((mat[0][2],mat[1][2],mat[2][2]))
    return [list(localX), list(localY), list(localZ)]

class EASYREF_OT_modal_focal(Freezer, bpy.types.Operator):
    """Move focal with mouse Y"""
    bl_idname = "easyref.modal_focal"
    bl_label = "Modal Focal"

    def modal(self, context, event):
        # context.area.header_text_set("MODAL ON >>> Move your Mouse Left and Right to change the focus of the camera")
        if event.type == 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x
            speed = 0.01 if event.shift else 0.1
            modal_speed = self.prefs.focus_modal_speed
            if delta>0:
                delta_mul = 2.**(delta/100 * speed * modal_speed)
            else:
                delta_mul = 1./(2.**(-delta/100 * speed * modal_speed))
            self.cam.data.lens = self.first_lens * delta_mul
            self.cam.location = translate(self.first_center, list(self.first_pos), delta_mul)

        elif event.type == 'LEFTMOUSE':
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler, 'WINDOW')
            # context.area.header_text_set(None)

            if self.has_selection:
                for obj in self.sel:
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.cam.data.lens = self.first_lens
            self.cam.location = self.first_pos
            bpy.types.SpaceView3D.draw_handler_remove(self.drawHandler, 'WINDOW')

            if self.has_selection:
                for obj in self.sel:
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.prefs = get_addon_preferences()

        self.has_selection = False
        if context.selected_objects:
            self.has_selection = True
            self.act_obj = context.active_object
            self.sel = [obj for obj in context.selected_objects]

        # Mouse
        self.first_mouse_y = event.mouse_y
        self.first_mouse_x = event.mouse_x
        self.cam = context.scene.camera
        self.first_pos = list(self.cam.location)
        self.first_axis = get_axis(self.cam)
        self.first_lens = self.cam.data.lens
        # Cursor
        self.first_cursor_pos = context.scene.cursor.location
        self.first_distance = dist_3d(list(self.first_cursor_pos), self.first_pos)
        self.first_center = np.array(list(self.first_pos)) - self.first_distance*np.array(self.first_axis[2])
        self.drawHandler = bpy.types.SpaceView3D.draw_handler_add(easyref_draw_callback_px, (self, context, self.cam), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class EASYREF_OT_modal(Freezer, Operator):
    """ EDIT IMAGE REFERENCE

    - Move: G, Rotate: R, Scale: S
    - Opacity: W
    - Flip X: X, Flip Y: C
    - Valid: SPACE/ENTER
    - Delete Reference: DEL
    - EXIT: ECHAP"""
    bl_idname = "easyref.modal"
    bl_label = "Edit References"

    def tagRedrawAreas(self):
        for window in bpy.context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                area.tag_redraw()

    first_mouse_x : IntProperty() # type: ignore
    first_mouse_y : IntProperty() # type: ignore
    first_value : FloatProperty() # type: ignore

    image_opacity : FloatProperty(
        default=0.3,
        min=0.2, max=1,
        precision=3
    ) # type: ignore

    image_scale : FloatProperty(
        default=1,
        min=0.2, max=100,
        precision=3
    ) # type: ignore

    image_offset_x : FloatProperty(
        default=0.5,
        min=-1, max=1,
        precision=3
    ) # type: ignore

    image_offset_y : FloatProperty(
        default=0.5,
        min=-1, max=1,
        precision=3
    ) # type: ignore

    action : EnumProperty(
        items=(("scale", "", ""),
               ("rotate","",""),
               ("opacity", "", ""),
               ("move", "", ""),
               ("offset_x", "",""),
               ("offset_y","",""),
               ("offset_xy", "", ""),
               ("dof", "", ""),
               ("modal_focal", "", ""),
               ("sensor_width", "", ""),
               ("clip_start", "", ""),
               ("clip_end", "", ""),
               ("ortho_zoom", "", ""),
               ("ortho_pan", "", ""),
               ("ortho_pan_x", "", ""),
               ("ortho_pan_y", "", ""),
               ("free_mode", "", ""),
               ("image_flip_x", "", ""),
               ("image_flip_y", "", ""),),
        default="free_mode") # type: ignore

    camref : StringProperty() # type: ignore
    new_empty : StringProperty() # type: ignore
    juste_empty : BoolProperty(default=False) # type: ignore
    juste_modal : BoolProperty(default=False) # type: ignore
    index : IntProperty() # type: ignore

    _timer = None

    def modal(self, context, event):
        wm = context.window_manager
        # context.area.header_text_set(
        #     "MODAL ON >>> Move: G, Rotate: R, Scale: S, Opacity: W, Flip X/Y: X/Y, Focus: Q, Front/Back: C, LOCK: L, Next/Previous Image: L/R Arrow, Offset X: A, Offset Y: Z, Valid: RMB/SPACE, EXIT:ESC")

        if event.type == 'MIDDLEMOUSE' :
            return {'PASS_THROUGH'}

        elif event.type in {"SLASH", "NUMPAD_PERIOD", "NUMPAD_0"} :
            self.action = "free_mode"
            return {'PASS_THROUGH'}

        elif event.type == "LEFTMOUSE":
            self.action = "free_mode"
            return {'PASS_THROUGH'}

        elif event.shift and event.type == "RIGHTMOUSE":
            self.action = "free_mode"
            return {'PASS_THROUGH'}

        # actions si on bouge la souris
        elif event.type == 'MOUSEMOVE':
            last_mouse = (self.first_mouse_x, self.first_mouse_y)
            current_mouse = (event.mouse_x, event.mouse_y)
            current_offset = (self.bg.offset[0], self.bg.offset[1])

            # Linear delta with reduced sensitivity
            # delta_x = (event.mouse_x - self.first_mouse_x) / 2000 if event.shift else (event.mouse_x - self.first_mouse_x) / 500
            # delta_y = (event.mouse_y - self.first_mouse_y) / 2000 if event.shift else (event.mouse_y - self.first_mouse_y) / 500
            delta_x = (event.mouse_x - self.first_mouse_x)
            delta_y = (event.mouse_y - self.first_mouse_y)
            speed = 0.01 if event.shift else 0.1
            modal_speed = self.prefs.refs_modal_speed

            # --------------------------------
            # IMAGES
            # --------------------------------
            if self.action == "opacity":
                self.bg.alpha = min(100, max(0.01, self.image_opacity + delta_x * speed / 100 * modal_speed))

            elif self.action == "scale":
                x = self.v3d.x + self.v3d.width/2 + current_offset[0]*self.v3d.width
                y = self.v3d.y + self.v3d.height/2 + current_offset[1]*self.v3d.height
                current_pos = (x,y)
                d1 = distance_2d(current_pos, last_mouse)
                d2 = distance_2d(current_pos, current_mouse)
                ns = self.last_size*(d2/d1)
                self.bg.scale = ns

            elif self.action == "rotate":
                # Rotate based on horizontal mouse movement
                delta_rotation = (event.mouse_x - self.first_mouse_x) / 500  # Reduced rotation speed by 5x
                if event.shift:
                    delta_rotation *= 0.1  # Even slower rotation when holding shift
                self.bg.rotation = self.last_rot + delta_rotation

            elif self.action == "offset_x":
                # Linear offset directly mapped to mouse movement
                self.bg.offset[0] = self.image_offset_x + delta_x * 0.001 * modal_speed

            elif self.action == "offset_y":
                # Linear offset directly mapped to mouse movement
                self.bg.offset[1] = self.image_offset_y + delta_y * 0.001 * modal_speed

            elif self.action == "offset_xy":
                # Linear offset for both axes
                value = 0.001
                self.bg.offset[0] = self.image_offset_x + delta_x * value * modal_speed
                self.bg.offset[1] = self.image_offset_y + delta_y * value * modal_speed
               
            # --------------------------------
            # CAMERA
            # --------------------------------

            elif self.action == "dof":
                if self.cam.data.type == 'ORTHO':
                    self.cam.data.ortho_scale = self.ortho_scale - delta_x * 0.05
                else:
                    self.cam.data.lens = self.dof - delta_x * 0.05

            elif self.action == "sensor_width":
                self.cam.data.sensor_width = self.sensor_width + delta_x * 0.05

            elif self.action == "ortho_zoom":
                self.cam.data.ortho_scale = self.ortho_zoom + delta_x 

            elif self.action == "ortho_pan":
                self.cam.data.shift_x, self.cam.data.shift_y = self.ortho_pan_x + delta_x / 4 , self.ortho_pan_y + delta_y / 4

        # --------------------------------
        # CAMERA SETTINGS
        # --------------------------------
        if event.type == 'Q' and event.value == 'PRESS':
            bpy.ops.easyref.modal_focal('INVOKE_DEFAULT')
            self.action = "modal_focal"

        # Offset XY
        if event.shift and event.type == 'MIDDLEMOUSE' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.first_mouse_y = event.mouse_y
            self.ortho_pan_x, self.ortho_pan_y = self.cam.data.shift_x, self.cam.data.shift_y

            self.action = "ortho_pan"

        # Ortho zoom
        if event.ctrl and event.type == 'MIDDLEMOUSE' and event.value == 'PRESS':
            if self.cam.data.type == 'ORTHO':
                self.first_mouse_x = event.mouse_x
                self.first_mouse_y = event.mouse_y
                self.ortho_zoom = self.cam.data.ortho_scale
                self.action = "ortho_zoom"
            else:
                return {'PASS_THROUGH'}

        # dof
        if event.type == 'D' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.ortho_scale = self.cam.data.ortho_scale
            self.dof = self.cam.data.lens
            self.action = "dof"

        # Sensor Width
        if event.type == 'F' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.sensor_width = self.cam.data.sensor_width
            self.action = "sensor_width"

        # Clip Start
        if event.type == 'V' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.clip_start = self.cam.data.clip_start
            self.action = "clip_start"

        # Clip End
        if event.type == 'B' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.clip_end = self.cam.data.clip_end
            self.action = "clip_end"

        #---------------------------------
        # IMAGES SETTINGS
        # --------------------------------
        # Opacity
        if event.type == 'W' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.image_opacity = self.bg.alpha
            self.action = "opacity"

        # Rotate
        if event.type == 'R' and event.value == 'PRESS':
            self.v3d = get_3d_view()
            self.last_rot = float(self.bg.rotation)
            self.first_mouse_x = event.mouse_x
            self.first_mouse_y = event.mouse_y
            self.image_rotate = self.bg.rotation
            self.action = "rotate"

        # Scale
        if event.type == 'S' and event.value == 'PRESS':
            self.v3d = get_3d_view()
            self.last_size = float(self.bg.scale)
            self.first_mouse_x = int(event.mouse_x)
            self.first_mouse_y = int(event.mouse_y)
            self.image_scale = self.bg.scale
            self.action = "scale"

        # Offset X
        elif event.type == 'A' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.image_offset_x = self.bg.offset[0]
            self.action = "offset_x"

        # Offset Y
        elif event.type == 'Z' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.image_offset_y = self.bg.offset[1]
            self.action = "offset_y"

        # Offset XY
        elif event.type == 'G' and event.value == 'PRESS':
            self.first_mouse_x = event.mouse_x
            self.first_mouse_y = event.mouse_y
            self.image_offset_x, self.image_offset_y = self.bg.offset[0:2]
            self.action = "offset_xy"

        # Flip X
        elif event.type == 'X' and event.value == 'PRESS':
            self.bg.use_flip_x = not self.bg.use_flip_x
            self.action = "free_mode"

        # Flip Y
        elif event.type == 'Y' and event.value == 'PRESS':
            self.bg.use_flip_y = not self.bg.use_flip_y
            self.action = "free_mode"

        # ---------------------------------------------------------
        # Switch Between images
        # ---------------------------------------------------------
        if event.type in {'GRLESS', 'LEFT_ARROW', 'RIGHT_ARROW'} and event.value == 'PRESS':
            index = self.cam.data.easyref_image_active
            if event.type == 'GRLESS' and event.shift or event.type == 'RIGHT_ARROW':
                index = index + 1 if index +1 <= len(self.cam.data.background_images) -1 else 0
            else:
                index = index - 1 if index -1 >= 0 else len(self.cam.data.background_images) -1

            self.cam.data.easyref_image_active = index
            self.bg = self.cam.data.background_images[index]

            self.current_value = self.bg.alpha

            # Launch Timer
            if self._timer is None:
                self.bg.alpha = 0.05
                self._timer = wm.event_timer_add(0.07, window=context.window)

        if event.type == 'TIMER' and self._timer is not None:
            self.bg.alpha += 0.1
            if self.bg.alpha == 1:
                wm.event_timer_remove(self._timer)
                self._timer = None
                self.bg.alpha = self.current_value

        # Clear Rotation
        elif event.alt and event.type == 'R' and event.value == 'PRESS':
            self.bg.rotation = 0
            self.action = "free_mode"

        # Depth Front/Back
        elif event.type == 'C' and event.value == 'PRESS':
            if self.bg.display_depth == 'BACK':
                self.bg.display_depth = 'FRONT'
            else:
                self.bg.display_depth = 'BACK'
            self.action = "free_mode"

        # Depth Front/Back
        elif event.type == 'H' and event.value == 'PRESS':
            self.bg.show_background_image = not self.bg.show_background_image
            self.action = "free_mode"

        # lock Camera
        elif event.type == 'L' and event.value == 'PRESS':

            status = self.cam.lock_rotation[0]
            for i in range(3):
                self.cam.lock_rotation[i] = self.cam.lock_location[i] = self.cam.lock_scale[i] = not status
                context.space_data.lock_camera = not context.space_data.lock_camera

                self.cam["Cam Lock"] = not self.cam["Cam Lock"]
                self.action = "free_mode"

        if event.type == 'NUMPAD_5' and event.value == 'PRESS':

            if self.cam.data.type == 'ORTHO':
                self.cam_prop.ortho_view = False
                self.cam.data.type = 'PERSP'

            elif self.cam.data.type == 'PERSP':
                self.cam_prop.ortho_view = True
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # Front view NUMPAD_1
        if event.type == 'NUMPAD_1' and event.value == 'PRESS':
            self.cam_prop.ortho_view = True
            context.object.location[1] = 0
            T = Matrix.Translation(Vector((0, -60, 0)))
            R = Matrix.Rotation(radians(90), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))

            self.cam.matrix_world = T @ R @ S

            if self.cam.data.type == 'PERSP':
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # Back view
        if event.type == 'NUMPAD_1' and event.ctrl and event.value == 'PRESS':
            self.cam_prop.ortho_view = True
            context.object.location[1] = 0
            T = Matrix.Translation(Vector((0, 60, 0)))
            R = Matrix.Rotation(radians(180), 4, Vector((0, -1, -1)))
            S = Matrix.Scale(1, 4, (1, 1, 1))

            self.cam.matrix_world = T @ R @ S
            if self.cam.data.type == 'PERSP':
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # Rigth view
        if event.type == 'NUMPAD_3' and event.value == 'PRESS':
            self.cam_prop.ortho_view = True
            context.object.location[0] = 0
            T = Matrix.Translation(Vector((60, 0, 0)))
            R = Matrix.Rotation(radians(90), 4, Vector((0, 0, 1)))
            R = R @ Matrix.Rotation(radians(90), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))

            self.cam.matrix_world = T @ R @ S

            if self.cam.data.type == 'PERSP':
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # left view
        if event.type == 'NUMPAD_3' and event.ctrl and event.value == 'PRESS':
            self.cam_prop.ortho_view = True
            context.object.location[0] = 0
            T = Matrix.Translation(Vector((-60, 0, 0)))
            R = Matrix.Rotation(radians(90), 4, Vector((0, 0, -1)))
            R = R @ Matrix.Rotation(radians(90), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))

            self.cam.matrix_world = T @ R @ S

            if self.cam.data.type == 'PERSP':
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # Top view
        if event.type == 'NUMPAD_7' and event.value == 'PRESS':
            self.cam_prop.ortho_view = True
            context.object.location[2] = 0
            T = Matrix.Translation(Vector((0, 0, 60)))
            R = Matrix.Rotation(radians(0), 4, Vector((0, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))

            self.cam.matrix_world = T @ R @ S

            if self.cam.data.type == 'PERSP':
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # Bottom view
        if event.type == 'NUMPAD_7' and event.ctrl and event.value == 'PRESS':
            self.cam_prop.ortho_view = True
            context.object.location[2] = 0
            T = Matrix.Translation(Vector((0, 0, -60)))
            R = Matrix.Rotation(radians(180), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))

            self.cam.matrix_world = T @ R @ S

            if self.cam.data.type == 'PERSP':
                self.cam.data.type = 'ORTHO'
                self.cam.data.ortho_scale = 70

        # Accept
        if event.type in {'SPACE', 'RIGHTMOUSE'}:

            if self._timer is not None:
                wm.event_timer_remove(self._timer)
                self._timer = None
            if self.has_selection:
                for obj in self.sel:
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            WM = context.window_manager
            WM.modal_ON = False
            # context.area.header_text_set(text ="")
            # context.area.header_text_set(None)
            EasyRef_Update_UI()
            # context.area.ui_type = 'VIEW'
            context.area.ui_type = 'VIEW_3D'

            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, 'WINDOW')
            return {'FINISHED'}

        # Cancel
        if event.type  == 'ESC':

            if self._timer is not None:
                wm.event_timer_remove(self._timer)
                self._timer = None


            # Restore Ortho/Persp Mode and cam to view
            self.cam.data.type = self.view_mode
            context.space_data.lock_camera = self.cam_to_view
            if self.has_selection :
                for obj in self.sel:
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            WM = context.window_manager
            WM.modal_ON = False

            # context.area.header_text_set(None)

            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler, 'WINDOW')

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    @classmethod
    def poll(cls, context):
        return context.area.type == 'VIEW_3D'

    # ---INVOKE ------------------------------------------------------------------------------------
    def invoke(self, context, event):
        WM = context.window_manager
        WM.modal_ON = True
        self.action = "free_mode"
        self.prefs = get_addon_preferences()
        self.has_selection = False
        if context.selected_objects and context.selected_objects[0].type != 'EMPTY':
            self.has_selection = True
            self.act_obj = context.active_object
            self.sel = [obj for obj in context.selected_objects]


        self.cam = bpy.data.objects[self.camref]
        context.space_data.camera = self.cam
        context.view_layer.objects.active = self.cam
        context.scene.camera = self.cam
        bpy.ops.view3d.object_as_camera()
        self.cam_prop = self.cam.easyref[0]

        if self.has_selection:
            self.act_obj.select_set(state=True)
            context.view_layer.objects.active = self.act_obj

        # Check modes
        self.view_mode = self.cam.data.type
        self.cam_to_view = context.space_data.lock_camera
        self.cam_is_locked = self.cam["Cam Lock"]

        # self.self.cam.data.easyref_image_active = 0
        self.bg = self.cam.data.background_images[self.cam.data.easyref_image_active]

        # Modal start and Info text
        context.window_manager.modal_handler_add(self)
        self.draw_handler = bpy.types.SpaceView3D.draw_handler_add(
        self.draw_reference_controls, (context,), 'WINDOW', 'POST_PIXEL')
        # self.drawHandler = bpy.types.SpaceView3D.draw_handler_add(drawCallback, (self, context), 'WINDOW', 'POST_PIXEL')

        # Redraw right from the start, or else it only happens after user input.
        self.tagRedrawAreas()

        return {'RUNNING_MODAL'}
    
    def draw_reference_controls(self, context):
        # Define colors
        color_orange = (1, 0.522, 0, 1)  # RGBA
        color_white = (1.0, 1.0, 1.0, 1.0)  # RGBA

        # Define font sizes
        font_size_title = 30
        font_size_text = 20

        font_id = 0
        blf.size(font_id, font_size_title)

        # Calculate height and width
        height = context.area.height
        
        # Check T panel overlap
        overlap = context.preferences.system.use_region_overlap
        t_panel_width = 0
        if overlap:
            for region in context.area.regions:
                if region.type == 'TOOLS':
                    t_panel_width = region.width

        # Starting position
        y = height / 2 + 100
        x = t_panel_width + 20

        # # Draw camera lens info
        # # Draw label in orange
        # blf.position(font_id, x, y + 40, 0)  # Position above title
        # blf.color(font_id, *color_orange)
        # blf.draw(font_id, "CAMERA LENS: ")

        # # Calculate width of label for value position
        # text_width, text_height = blf.dimensions(font_id, "CAMERA LENS: ")

        # # Draw value in white
        # blf.position(font_id, x + text_width, y + 40, 0)
        # blf.color(font_id, *color_white)
        # blf.draw(font_id, str(round(self.cam.data.lens, 2)))
        
        # Draw title
        title_text = "IMAGES CONTROLS"
        blf.position(font_id, x, y, 0)
        blf.color(font_id, *color_white)
        blf.draw(font_id, title_text)

        y -= 40  # Space below title

        # Set font size for instructions
        blf.size(font_id, font_size_text)

        # Draw instructions
        instructions = {
            "": "",
            "BASIC SETTINGS": "",
            "": "",
            "G:": "Move Reference", 
            "R:": "Rotate Reference",
            "S:": "Scale Reference",
            "W:": "Adjust Opacity",
            "Q:": "Edit Focal",
            "X/Y:": "Flip X/Y",
            "L/R ARROWS:": "Switch Images",
            "L:": "Lock Camera",
            "": "",
            "OTHER SETTINGS": "",
            "": "",
            "A/Z:": "Offset X/Y",
            "C:": "Front/Back Display",
            "D:": "Focal Length", 
            "F:": "Sensor Width",
            "H:": "Show Background",
            "Numpad 1,3,7:": "Ortho Views",
            "": "",
            "SPACE/RMB:": "Valid",
            "ESC:": "Cancel"
        }

        for key, description in instructions.items():
            # Draw key in orange
            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, key)

            # Draw description in white
            blf.position(font_id, x + 150, y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, description)

            y -= font_size_text + 5  # Space between lines

CLASSES =  [EASYREF_OT_modal,
            EASYREF_OT_modal_focal]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass