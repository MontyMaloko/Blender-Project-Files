# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
import bmesh
from mathutils import Vector, Matrix
import logging

USE_SLOTS = False

logger = logging.getLogger(__package__)

X_AXIS = Vector((1, 0, 0))
Y_AXIS = Vector((0, 1, 0))
Z_AXIS = Vector((0, 0, 1))
ZERO = Vector((0, 0, 0))
IDENTITY = Vector((1, 1, 1))

# Geometry nodes autogoolean
NODE_WIDTH = 290
NODE_SPACE_X = 50
NODE_SPACE_Y = 40
NODE_START_Y = -100


# Register "handlers" func to call with (datablock, context, obj) signature
# for blenderbim / external addon integration
class Callbacks:
    create = []  # create / callback
    copy = []  # duplicate / callback
    delete = []
    update = []  # update
    unique = []  # make unique

    enabled = True

    @classmethod
    def disable(cls):
        cls.enabled = False

    @classmethod
    def enable(cls):
        cls.enabled = True

    @classmethod
    def call(cls, category, context, o, d):
        if cls.enabled and hasattr(cls, category):
            for fun in getattr(cls, category, []):
                fun(context, o, d)

    @classmethod
    def add(cls, category, fun):
        if hasattr(cls, category):
            cat = getattr(cls, category)
            if fun not in cat:
                cat.append(fun)


"""
 Layer (layer Management) / collection names by class
"""
layer_names = {
    "All": "All",
    "reference_point": "Reference",
    "wall": "Walls",
    "custom_wall": "Walls",
    "wall2": "Walls",
    "slab": "Slabs",
    "floor": "Floors",
    "molding": "Moldings",
    "fence": "Furnitures",
    "stair": "Stairs",
    "truss": "Furnitures",
    "kitchen": "Kitchen",
    "kitchen_module": "Kitchen",
    "kitchen_cabinet": "Kitchen",
    "handle": "Openings",
    "handle_inside": "Openings",
    "handle_outside": "Openings",
    "window": "Openings",
    "window_panel": "Openings",
    "glass": "Openings",
    "window_shutter": "Openings",
    "blind": "Openings",
    "door": "Openings",
    "door_panel": "Openings",
    "custom": "Custom",
    "custom_part": "Custom",
    "roof": "Roofs",
    "beam": "Beams",
    "slab_cutter": "Slabs",
    "floor_cutter": "Floors",
    "roof_cutter": "Roofs",
    "dimension_auto": "2d",
    "section": "2d",
    "section_target": "2d",
    "area": "2d",
    "assembly": "Assembly",
    "furniture": "Furnitures",
    "area_cutter": "2d",
    "layout": "2d",
    "profile": "Profile",
    "hole": "Holes",
    "hybridhole": "Holes",
    "custom_hole": "Holes",
    "terrain": "Terrain"
}


class ArchipackContextAbstraction:

    @classmethod
    def get_active_object(cls, context):
        for attr in ("object", "active_object"):
            res = cls.get_context_value(context, attr)
            if res is not None:
                return res
        # logger.debug("get_active_object no object found, context %s %s" % (context, traceback.print_stack()))

    @classmethod
    def get_scene_object(cls, context, name):
        return cls.get_context_value(context, "scene").objects.get(name.strip())

    @classmethod
    def get_scene_objects(cls, context):
        return cls.get_context_value(context, "scene").objects

    @staticmethod
    def get_context_value(ctx, attr):
        """
        :param ctx: context either pointer or dict for context override
        :param attr: path of attr in context
        :return: value
        """
        res = ctx
        keys = attr.split(".")
        try:
            # context is a dict
            iter(ctx)
            for key in keys:
                res = res[key]
            return res
        except TypeError:
            pass
        except Exception as e:
            print(e)
            pass
        try:
            for key in keys:
                res = getattr(res, key)
            return res
        except Exception as e:
            print(e)
            pass
        return None


class context_override(ArchipackContextAbstraction):
    """ Override context in object mode
    """

    @staticmethod
    def area(context, ctx, area_type):
        # take care of context switching
        # when call from outside of 3d view
        # on subsequent calls those vars are set
        try:
            if context.space_data is None or context.space_data.type != area_type:
                for window in context.window_manager.windows:
                    screen = window.screen
                    for area in screen.areas:
                        if area.type == area_type:
                            ctx['area'] = area
                            for region in area.regions:
                                if region.type == 'WINDOW':
                                    ctx['region'] = region
                            break
        except:
            pass

    def id_data(self, context, ctx, act, sel, filter_cb):
        """ Set id data based context variables
        :param context:
        :param ctx:
        :param act:
        :param sel:
        :param filter_cb:
        :return:
        """

        sel_id_data = [o.id_data for o in sel]
        all_id_data = self.get_scene_objects(context)
        if filter_cb is not None:
            sel_id_data = list(filter(filter_cb, sel_id_data))
            all_id_data = list(filter(filter_cb, all_id_data))

        ctx['selected_objects'] = sel_id_data
        ctx['selectable_objects'] = all_id_data
        ctx['visible_objects'] = all_id_data
        if act is not None:
            act_id_data = act.id_data
            ctx['objects_in_mode'] = [act_id_data]
            ctx['objects_in_mode_unique_data'] = [act_id_data]
        # parent child relationship operators
        ctx['editable_objects'] = sel_id_data
        ctx['selected_editable_objects'] = sel_id_data

        # looks like snap use editable bases.. no more exposed in context ???
        # view_layer->basact;
        # for (Base * base = view_layer->object_bases.first ...

    def __init__(self, context, act, sel, filter_cb=None, mode="OBJECT", area_type="VIEW_3D"):
        ctx = context.copy()
        self.context = context
        # area override
        self.area(context, ctx, area_type)

        self._mode = mode
        self._act = None

        ctx['object'] = act
        ctx['active_object'] = act

        if area_type == "VIEW_3D":

            if act is not None and act not in sel:
                sel.append(act)

            # view_layer <bpy_struct, ViewLayer("View Layer")>
            # active_operator  <bpy_struct, Operator>
            # collection  <bpy_struct, Collection()>
            # layer_collection <bpy_struct, LayerCollection()>
            # <Struct Object()>

            # bpy.data objects
            self.id_data(context, ctx, act, sel, filter_cb)
            self.id_data(context, ctx, act, sel, filter_cb)

            if mode == "EDIT":
                self._act = ctx['view_layer'].objects.active
                ctx['view_layer'].objects.active = act
                if bpy.app.version[0] > 3:
                    with context.temp_override(**ctx):
                        bpy.ops.object.mode_set(mode="EDIT")
                else:
                    bpy.ops.object.mode_set(ctx, mode="EDIT")
                if act is not None:
                    ctx['edit_object'] = act.id_data
                ctx['mode'] = 'EDIT_MESH'
        self._ctx = ctx

    def __enter__(self):
        return self._ctx

    def __exit__(self, exc_type, exc_val, exc_tb):

        if self._mode == "EDIT":
            if bpy.app.version[0] > 3:
                with self.context.temp_override(**self._ctx):
                    bpy.ops.object.mode_set(mode="OBJECT")
            else:
                bpy.ops.object.mode_set(self._ctx, mode='OBJECT')

        if self._act is not None:
            self._ctx['view_layer'].objects.active = self._act

        return False


class ensure_select_and_restore(ArchipackContextAbstraction):
    """Context Manager
    For use bpy.ops like transform.translate or any op working on selection

    Usage:

    with ensure_select_and_restore(context, obj, sel, object_mode='EDIT'):
        .. obj is selected and active
        bpy.ops.transform.translate ...

    with ensure_select_and_restore(context, obj, sel, object_mode='OBJECT') as (new_act, new_sel):
        .. new_act is selected and active and in object_mode if set
        .. old_sel objects are no more selected (if different of obj)
        .. old_act is no more active (if different of obj)
        bpy.ops.transform.translate ...

    .. obj is not active nor selected unless it was selected or active before
    .. old_sel are selected
    .. old_act is active
    :param context: blender context
    :param obj: blender object
    :param sel: a new selection
    :param object_mode: object mode to switch in ['EDIT', 'OBJECT', ..]
    """

    def _collection_hierarchy(self, coll, hierarchy, childrens):
        """ Flatten collection hierarchy under 2.80x
        :param coll:
        :param hierarchy:
        :param childrens:
        :return:
        """
        childrens[coll.name] = coll
        for c in coll.children:
            hierarchy[c.name] = coll.name
            self._collection_hierarchy(c, hierarchy, childrens)

    def get_view_layer(self, context):
        return self.get_context_value(context, "view_layer")

    def collection_hierarchy(self, context):
        self._coll_childrens = {}
        self._coll_hierarchy = {}
        coll = self.get_view_layer(context).layer_collection
        self._collection_hierarchy(coll, self._coll_hierarchy, self._coll_childrens)

    def unhide_collections(self, layers):
        hide_viewport = set()
        hide_global = set()
        coll_exclude = set()
        for coll_name in layers:
            while coll_name in self._coll_hierarchy:
                if self._coll_childrens[coll_name].hide_viewport is True:
                    hide_viewport.add(coll_name)
                    self._coll_childrens[coll_name].hide_viewport = False
                if self._coll_childrens[coll_name].collection.hide_viewport is True:
                    hide_global.add(coll_name)
                    self._coll_childrens[coll_name].collection.hide_viewport = False
                if self._coll_childrens[coll_name].exclude is True:
                    coll_exclude.add(coll_name)
                    self._coll_childrens[coll_name].exclude = False
                coll_name = self._coll_hierarchy[coll_name]
        self._coll_hide_global = hide_global
        self._coll_hide_viewport = hide_viewport
        self._coll_exclude = coll_exclude

    def hide_collections(self):
        for coll_name in self._coll_hide_viewport:
            self._coll_childrens[coll_name].hide_viewport = True
        for coll_name in self._coll_hide_global:
            self._coll_childrens[coll_name].collection.hide_viewport = True
        for coll_name in self._coll_exclude:
            self._coll_childrens[coll_name].exclude = True

    def ensure_select(self, o):
        if o is not None:
            if o.hide_get():
                o.hide_set(False)
                self._hide_viewport.add(o.name)
            if o.hide_select:
                o.hide_select = False
                self._hide_select.add(o.name)
            o.select_set(state=True)

    def restore_vis_sel(self):
        for name in self._vis_sel_state:
            o = self.get_scene_object(self._ctx, name)
            if o is not None:
                o.hide_select = name in self._hide_select
                o.hide_set(name in self._hide_viewport)

    def __init__(self, context, obj, sel, object_mode=None):
        act = None
        try:
            act = self.get_active_object(context)
        except:
            pass

        self._ctx = context
        self._act_mode = None
        self._act = ""
        try:
            self._previous_sel = set([o.name for o in self.get_context_value(context, "selected_objects")])
        except:
            self._previous_sel = set()
            pass
        self._obj = obj
        self._sel = sel
        # Unhide collections
        layers = set([o.users_collection[0].name for o in sel if o.visible_get() is False])
        self._coll_hide_global = set()
        self._coll_hide_viewport = set()
        self._coll_exclude = set()
        self._coll_childrens = {}
        self._coll_hierarchy = {}

        if len(layers) > 0:
            self.collection_hierarchy(context)
            self.unhide_collections(layers)

        self._vis_sel_state = set([o.name for o in sel])

        self._vis_sel_state.add(obj.name)
        obj_mode = obj.mode

        self._hide_viewport = set()
        self._hide_select = set()

        # ensure act.mode allow deselect all
        # other objects are all in 'OBJECT' mode
        if act is not None:
            self._act = act.name
            self._act_mode = act.mode
            if act.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')

        # deselect require object mode
        bpy.ops.object.select_all(action="DESELECT")

        # with stop_auto_manipulate(context):
        # hide_select and hide_viewport prevent selection
        self.ensure_select(obj)
        self.get_view_layer(context).objects.active = obj

        for o in sel:
            self.ensure_select(o)

        if object_mode is not None:
            # obj == act -> obj was in _act_mode, exit set obj mode back to _act_mode
            # obj != act -> obj was in 'OBJECT' mode, exit set obj mode back to 'OBJECT'
            if obj_mode != object_mode:
                bpy.ops.object.mode_set(mode=object_mode)

    def __enter__(self):
        return self._ctx, self._obj, self._sel

    def __exit__(self, exc_type, exc_val, exc_tb):

        # deselect require object mode
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action="DESELECT")

        # restore hide_viewport and hide_select
        self.restore_vis_sel()
        self.hide_collections()

        # with stop_auto_manipulate(self._ctx):
        # restore previous selection, use names so deleted objects wont crash blender
        for name in self._previous_sel:
            o = self.get_scene_object(self._ctx, name)
            if o is not None:
                o.select_set(state=True)

        # restore previous active, use names so deleted objects wont crash blender
        act = self.get_scene_object(self._ctx, self._act)
        if act is not None:
            self.get_view_layer(self._ctx).objects.active = act

            # restore act mode
            if self._act_mode is not None and act.mode != self._act_mode:
                bpy.ops.object.mode_set(mode=self._act_mode)

        # false let raise exception if any
        return False


class ArchipackLayerManager(ArchipackContextAbstraction):
    """
     Layer manager for use in 2.8+ series
    """

    @staticmethod
    def collection_by_name(context, collection_name):
        if collection_name in layer_names:
            return layer_names[collection_name].capitalize()
        return collection_name.capitalize()

    @staticmethod
    def get_collection_by_name(main, name, unique=False):
        """
        Return any collection starting by name, provide support to .000x
        on multiple scenes
        :param main: Main collection to seek to
        :param name: Collection name to seek
        :param unique: Seek exact name
        """
        coll = None
        if unique:
            for sub in main.children:
                if name == sub.name:
                    coll = sub
                    break
        else:
            for sub in main.children:
                if name in sub.name:
                    coll = sub
                    break

        return coll

    @classmethod
    def link_to_collection(cls, o, coll):
        """Link object to collection coll
        """
        if coll.objects.get(o.name) is None:
            coll.objects.link(o)

    @classmethod
    def create_collection(cls, main, name, separator="/", unique=False):
        """ Create nested collections
        :param main: main collection
        :param name: target collection path including separator for hierarchy
        :param separator: separator for path parts
        :param unique: use exact same name without .xxx
        :return:
        """
        _name = name.split(separator)
        curr = _name.pop(0)

        coll = cls.get_collection_by_name(main, curr, unique=unique)

        # coll = main.children.get(curr)

        if coll is None:
            coll = bpy.data.collections.new(name=curr)
            main.children.link(coll)

        # create nested collections if any
        if len(_name) > 0:
            if len(_name) > 1:
                nest = separator.join(_name)
            else:
                nest = _name[0]
            return cls.create_collection(coll, nest, separator=separator, unique=unique)

        return coll

    @classmethod
    def get_collection(cls, context, o, layer_name, default_layer):

        if layer_name is not None:
            collection_name = cls.collection_by_name(context, layer_name)
        else:
            collection_name = None
            # Use data class
            is_not_hole = not cls.has_flag(o, "custom_hole", "hole")

            if o.data is not None and is_not_hole:
                for key in o.data.keys():
                    if "archipack_" in key:
                        collection_name = cls.collection_by_name(context, key[10:])
                        break
            # Use Object class
            if collection_name is None and is_not_hole:
                for key in o.keys():
                    if "archipack_" in key:
                        collection_name = cls.collection_by_name(context, key[10:])
                        break
            # Use flags when nothing else is found
            if collection_name is None:
                if "archipack" in o:
                    for key in o['archipack'].keys():
                        if key in layer_names:
                            collection_name = cls.collection_by_name(context, key)
                        break

        sc = cls.get_context_value(context, "scene")
        coll_main = cls.get_collection_by_name(sc.collection, "Archipack")
        if coll_main is None:
            coll_main = bpy.data.collections.new(name="Archipack")
            sc.collection.children.link(coll_main)
        else:
            # fallback to parent collection if it is an archipack collection
            # by definition, archipack collection must pre-exist
            if collection_name is None and o.parent is not None and o.parent.users_collection:
                coll = cls.get_collection_by_name(coll_main, o.parent.users_collection[0].name, unique=True)
                if coll is not None:
                    return coll

        if collection_name is None:
            return sc.collection

        coll = cls.create_collection(coll_main, collection_name)

        return coll

    @classmethod
    def link_collections(cls, source, o):
        """Link o to each collections source belong to
        """
        for coll in source.users_collection:
            cls.link_to_collection(o, coll)


class ArchipackObjectsManagerBase:

    @classmethod
    def is_valid(cls, o):
        """ Invalid object no more return None
        :param o:
        :return:
        """
        try:
            o.id_data
            res = True
        except:
            res = False
            pass
        return res

    @classmethod
    def get_valid_object(cls, o):
        if cls.is_valid(o):
            return o
        return None

    @staticmethod
    def _cleanup_datablock(d, typ):
        if d and d.users < 1:
            if typ == 'MESH':
                bpy.data.meshes.remove(d)
            elif typ == 'CURVE':
                bpy.data.curves.remove(d)
            elif typ == 'LAMP':
                bpy.data.lamps.remove(d)

    @staticmethod
    def fix_luxcore_material_pointer(o):
        # FIX crash with luxcore, node tree pointer issue
        if hasattr(o, "material_slots"):
            for i, slot in enumerate(o.material_slots):
                if slot.material is None:
                    continue
                if slot.material.users < 2:
                    if hasattr(slot.material, "luxcore"):
                        if slot.material.luxcore is not None and slot.material.luxcore.node_tree is not None:
                            slot.material.luxcore.node_tree.nodes.clear()
                            slot.material = None

    def clear_modifier_stack(self, o):
        o.modifiers.clear()

    def copy_modifier_stack(self, src, dst):
        for mod in src.modifiers:
            m = dst.modifiers.get(mod.name)
            if m is None:
                m = dst.modifiers.new(name=mod.name, type=mod.type)
                for attr in dir(mod):
                    if attr.startswith("_") or attr in {"type", 'bl_rna', 'rna_type'}:
                        continue
                    try:
                        setattr(m, attr, getattr(mod, attr))
                    except:
                        pass

    @classmethod
    def rec_get_childrens(cls, o, sel, filter=None):
        if filter is None or filter(o):
            sel.append(o)
        for c in o.children:
            cls.rec_get_childrens(c, sel, filter)

    @classmethod
    def _delete_object(cls, context, o):
        Callbacks.call("delete", context, o, None)
        o.select_set(state=False)
        # remove parent so next reload will remove all
        o.parent = None
        d = o.data
        typ = o.type
        cls.unlink_object_from_scene(context, o)
        cls.fix_luxcore_material_pointer(o)
        # with context_override(context, o, [o]) as ctx:
        #    cls.call_operator(context, ctx, bpy.ops.object.delete)
        bpy.data.objects.remove(o, do_unlink=True)
        cls._cleanup_datablock(d, typ)

    @classmethod
    def _delete_childs(cls, context, o):
        if o and o.children:
            for c in o.children:
                cls._delete_childs(context, c)
        cls._delete_object(context, o)

    @classmethod
    def delete_object(cls, context, o):
        """
          Recursively delete object and childs
          Cleanup datablock when needed
          @o: object to delete
        """
        if cls.is_valid(o):
            cls._delete_childs(context, o)

    @classmethod
    def _duplicate_object(cls, context, o, linked, layer_name=None):
        new_o = o.copy()
        if o.data:
            if linked:
                new_o.data = o.data
            else:
                new_o.data = o.data.copy()

        cls.link_object_to_scene(context, new_o, layer_name=layer_name)

        Callbacks.call("copy", context, new_o, None)
        return new_o

    @classmethod
    def call_operator(cls, context, ctx, operator, kwargs=None, ctx_exec='EXEC_DEFAULT'):
        if bpy.app.version[0] > 3:
            if isinstance(context, dict):
                _ctx = bpy.context
            else:
                _ctx = context
            with _ctx.temp_override(**ctx):
                if operator.poll():
                    if kwargs is None:
                        operator(ctx_exec)
                    else:
                        operator(ctx_exec, **kwargs)
        else:
            if operator.poll(ctx):
                if kwargs is None:
                    operator(ctx, ctx_exec)
                else:
                    operator(ctx, ctx_exec, **kwargs)

    @classmethod
    def set_parent(cls, context, parent, child, keep_transform=True):

        childs = [parent]
        try:
            childs.extend(child)
        except TypeError:
            childs.append(child)
            pass

        with context_override(context, parent, childs) as ctx:
            cls.call_operator(context, ctx, bpy.ops.object.parent_set, {
                "type": 'OBJECT',
                "keep_transform": keep_transform
            })
            # bpy.ops.object.parent_set(ctx, type='OBJECT', keep_transform=keep_transform)
        for c in childs:
            cls.safe_scale(c)

    @classmethod
    def safe_scale(cls, o):
        if o.scale == ZERO:
            o.scale = IDENTITY

    @classmethod
    def _duplicate_childs(cls, context, o, linked, layer_name=None):
        p = cls._duplicate_object(context, o, linked, layer_name=layer_name)
        for child in o.children:
            c = cls._duplicate_childs(context, child, linked, layer_name=layer_name)
            # cls.set_parent(context, p, c)
            c.parent = p
            c.matrix_local = child.matrix_local.copy()
            # keep parent inverse as objects are not supposed to move while duplicating
            c.matrix_parent_inverse = child.matrix_parent_inverse.copy()
            cls.safe_scale(c)
        return p

    @classmethod
    def duplicate_object(cls, context, o, linked, layer_name=None):
        """
          Recursively duplicate object and childs
          @o: object to duplicate
          @linked : boolean linked duplicate
          return parent on success
        """
        if cls.is_valid(o):
            return cls._duplicate_childs(context, o, linked, layer_name=layer_name)
        return None

    @staticmethod
    def create_mesh(name, mesh=None):
        if mesh is not None:
            m = mesh
        else:
            m = bpy.data.meshes.new(name)
        o = bpy.data.objects.new(name, m)
        return o, m

    @staticmethod
    def ifc_name_context(o, ifc_class, ifc_context):
        if ifc_class not in o.name:
            o.name = "%s/%s" % (ifc_class, o.name)
        if o.data and ifc_context not in o.data.name:
            o.data.name = "%s/%s" % (ifc_context, o.data.name)

    @classmethod
    def _link_object(cls, src, o):
        if src.data:
            d = o.data
            typ = o.type
            o.data = src.data
            cls._cleanup_datablock(d, typ)

    @classmethod
    def _link_child(cls, src, o):
        cls._link_object(src, o)
        if len(src.children) == len(o.children):
            for child, o_child in zip(src.children, o.children):
                cls._link_child(child, o_child)

    @classmethod
    def link_object(cls, src, o):
        """
         Recursievely link datablock
         @src: object source
         @o: object destination
         src and o parent child relationship must match
         !!! disable manipulate before !!!
        """
        if src is not None:
            cls._link_child(src, o)

    @classmethod
    def rec_get_parent(cls, o, filter=None):
        if not cls.is_valid(o):
            return None
        if filter is not None and filter(o):
            return o
        elif o.parent:
            return cls.rec_get_parent(o.parent, filter)
        elif filter is None:
            return o
        return None

    @classmethod
    def get_topmost_parent(cls, o):
        return cls.rec_get_parent(o)

    @classmethod
    def get_reference_point(cls, o):
        def _filter(c):
            return "archipack_reference_point" in c

        return cls.rec_get_parent(o, _filter)


class ArchipackFlagsManager:
    """
    Set object's flags for archipack
    Mesh data are shared by instances, where flags at Object level are not
    """
    @classmethod
    def find_one_by_flag(cls, o, flag):
        for c in o.children:
            if cls.has_flag(c, flag, write=False):
                return c
        return None

    @classmethod
    def find_all_by_flag(cls, o, flag):
        return [c for c in o.children if cls.has_flag(c, flag, write=False)]

    @classmethod
    def _setup_flags(cls, o):
        """Setup flags, update from previous system
        :param o: Blender Object
        :return: void
        """
        o["archipack"] = {}
        # convert from previous system to new one
        for key in {
            'hole',
            'skip_material',
            # Door / custom orientation
            'flip',
            # Window
            'glass',
            # window / door handles
            'handle',
            # Custom objects
            'custom_wall', 'custom_hole',
            # Terrain
            'earthwork_border', 'earthwork_area', 'earthwork_wrap',
            'lake_border', 'lake_area', 'lake_wrap',
            'road_axis', 'raod_wrap'
        }:
            old_key = "archipack_%s" % key
            if old_key in o:
                cls.set_flag(o, key, True)
                del o[old_key]

    @classmethod
    def set_flag(cls, o, flag, state):
        """Add / remove flag to an object
        :param o: Blender Object
        :param flag: string
        :param state: bool set or remove flag
        :return: void
        """
        if "archipack" not in o:
            cls._setup_flags(o)
        if state:
            o["archipack"][flag] = True
        elif flag in o['archipack']:
            del o['archipack'][flag]
            if len(o['archipack']) < 1:
                del o['archipack']

    @classmethod
    def has_flag(cls, o, flags, write=True):
        """ Check if an object has a flag
        :param o: Blender Object
        :param flags: mixed string / iterable
        :param write: do not write on id data (eg in poll functions)
        :return: bool
        """
        if type(flags).__name__ == 'str':
            # str are iterable ..
            _flags = [flags]
        else:
            _flags = flags
        if "archipack" not in o:
            if write:
                cls._setup_flags(o)
            else:
                # handle old flag system in read only context like in poll functions
                return any(["archipack_%s" % f in o for f in _flags])
        return any([f in o["archipack"] for f in _flags])


class ArchipackObjectsManager(ArchipackLayerManager, ArchipackObjectsManagerBase, ArchipackFlagsManager):
    """
      Provide objects and datablock utility
      Support meshes curves and lamps
      - recursive delete objects and datablocks
      - recursive clone linked
      - recursive copy

     Provide abstraction layer for blender 2.8 / 2.9 / 3.x series

    """

    @staticmethod
    def minimum_blender_version(major, minor, rev):
        return bpy.app.version >= (major, minor, rev)

    @staticmethod
    def hide_sockets(socks):
        for sock in socks:
            sock.hide = len(sock.links) < 1

    @classmethod
    def hide_unlinked_sockets(cls, node):
        cls.hide_sockets(node.outputs)
        cls.hide_sockets(node.inputs)

    @staticmethod
    def node_by_type(mod, typ):
        """
        :param mod: nodes based modifier
        :param typ:
        :return: First node of type found in node group or None
        """
        for node in mod.node_group.nodes:
            if typ == node.type:
                return node
        return None

    @staticmethod
    def nodes_by_type(mod, typ):
        """
        :param mod: nodes based modifier
        :param typ:
        :return: All nodes by type in node group
        """
        return [node for node in mod.node_group.nodes if typ == node.type]

    @staticmethod
    def align_nodes(nodes, location_y, spacing_y):
        for i, node in enumerate(nodes):
            node.location.y = location_y + i * spacing_y

    @staticmethod
    def add_node_boolean_modifier(wall, name="AutoMixedBoolean"):
        """
        add a node based boolean modifier
        :param wall:
        :return: modifier
        """
        m = wall.modifiers.new(type="NODES", name=name)
        m.show_expanded = False
        m.node_group.name = wall.name
        return m

    @classmethod
    def add_node_boolean_hole(cls, m, hole):
        """
        Add a hole in a node based boolean setup
        :param m:
        :param hole:
        :return:
        """
        node = cls.node_by_type(m, "BOOLEAN")
        hole_node = m.node_group.nodes.new(type="GeometryNodeObjectInfo")
        hole_node.transform_space = 'RELATIVE'
        m.node_group.links.new(hole_node.outputs[3], node.inputs[1])
        hole_node.inputs[0].default_value = hole
        # Display options
        hole_node.label = hole.name
        cls.hide_unlinked_sockets(hole_node)
        # hole_node.inputs[0].hide = False
        # hole_node.show_options = False
        hole_node.hide = True
        hole_node.width = NODE_WIDTH

    @classmethod
    def ensure_node_boolean_setup(cls, wall, m):
        """
        Add node based modifier boolean node if needed
        :param wall:
        :param m:
        :return: boolean node
        """
        node = cls.node_by_type(m, "BOOLEAN")
        if node is None:
            node = m.node_group.nodes.new(type='GeometryNodeBoolean')
            node.inputs[2].default_value = True
            group_in_node = cls.node_by_type(m, "GROUP_INPUT")
            group_in_node.label = wall.name
            group_out_node = cls.node_by_type(m, "GROUP_OUTPUT")
            group_out_node.label = "Result"
            links = m.node_group.links
            links.new(group_in_node.outputs[0], node.inputs[0])
            links.new(group_out_node.inputs[0], node.outputs[0])
            links.new(group_in_node.outputs[1], node.inputs[2])

        return node

    def bmesh_bevel(
            self,
            bm,
            geom,
            offset,
            offset_type='OFFSET',
            segments=1,
            profile=0.5,
            affect='EDGES',
            clamp_overlap=False,
            material=-1,
            loop_slide=True,
            mark_seam=False,
            mark_sharp=False
    ):
        if self.minimum_blender_version(2, 90, 0):
            bmesh.ops.bevel(
                bm,
                geom=geom,
                offset=offset,
                offset_type=offset_type,
                segments=segments,  # d.bevel_res
                profile=profile,
                affect=affect,
                clamp_overlap=clamp_overlap,
                material=material,
                loop_slide=loop_slide,
                mark_seam=mark_seam,
                mark_sharp=mark_sharp
            )
        else:
            bmesh.ops.bevel(
                bm,
                geom=geom,
                offset=offset,
                offset_type=offset_type,
                segments=segments,  # d.bevel_res
                profile=profile,
                vertex_only=affect == 'VERTEX',
                clamp_overlap=clamp_overlap,
                material=material,
                loop_slide=loop_slide,
                mark_seam=mark_seam,
                mark_sharp=mark_sharp
            )

    @property
    def user_defined_objects(self):
        return []

    def _tag_user_defined_objects(self):
        # Users are likely not to be up to date at update time
        for o in self.user_defined_objects:
            # do never tag scene objects !
            if o is not None and not o.users_collection:
                # Tag so we are able to remove when no more in use
                self.set_flag(o, "preset_object", True)

    def cleanup_user_defined_objects(self, context, objs=None):
        """
        Cleanup user defined objects datablock
        when deleting object, there is basically at least 1 user, as pointer still hold one
        IMPORTANT NOTE:
        custom objects fields update must call and pass bpy.data.objects as objs in order to handle
        removal of hidden data when picking another object
        :param context: blender's context
        :param objs: optional bpy.data.objects in order to remove references when picking new object
        """
        if objs is None:
            objs = self.user_defined_objects
            add_tags = False
            def _filter(c):
                return c is not None and c.users < 2 and not c.users_collection
        else:
            add_tags = True
            def _filter(c):
                return \
                    c.users < 1 and \
                    not c.users_collection and \
                    self.has_flag(c, "preset_object", write=False)

        _objs =  [o for o in objs if _filter(o)]

        for o in _objs:
            print("cleanup_user_defined_objects remove", o.name, o.users)
            self.delete_object(context, o)

        if add_tags:
            # tag after so objects are kept when loading preset as users are likely not set at that time !
            self._tag_user_defined_objects()

    @classmethod
    def modifier_apply(cls, context, ctx, modifier="", apply_as='DATA'):
        if bpy.app.version >= (2, 90, 0):
            if apply_as == 'SHAPE':
                cls.call_operator(context, ctx, bpy.ops.object.modifier_apply_as_shapekey, {
                    "modifier": modifier
                })
            else:
                cls.call_operator(context, ctx, bpy.ops.object.modifier_apply, {
                    "modifier": modifier
                })
        else:
            cls.call_operator(context, ctx, bpy.ops.object.modifier_apply, {
                "modifier": modifier,
                "apply_as": apply_as
            })

    @classmethod
    def modifiers_apply(cls, context, o):
        ctx = context.copy()
        ctx['object'] = o
        for mod in o.modifiers[:]:
            ctx['modifier'] = mod
            try:
                cls.modifier_apply(context, ctx, apply_as='DATA', modifier=mod.name)
            except:
                pass

    @staticmethod
    def scene_ray_cast(context, orig, vec):
        if bpy.app.version >= (2, 91, 0):
            return context.scene.ray_cast(
                depsgraph=context.view_layer.depsgraph,
                origin=orig,
                direction=vec)
        else:
            return context.scene.ray_cast(
                view_layer=context.view_layer,
                origin=orig,
                direction=vec)

    @staticmethod
    def get_cursor_location(context):
        res = Vector()
        try:
            # before 28.02.2019
            res = context.scene.cursor_location.copy()
        except:
            pass

        try:
            # after 28.02.2019
            res = context.scene.cursor.location.copy()
        except:
            pass
        return res

    @staticmethod
    def set_cursor_location(context, location):
        try:
            # after 28.02.2019
            context.scene.cursor.location = location
        except:
            pass
        try:
            # before 28.02.2019
            context.scene.cursor_location = location
        except:
            pass

    @classmethod
    def get_linked_objects(cls, context, o):
        """Collect linked objects on scene
        Regardless visibility
        :param context: blender context
        :param o: blender object
        :return: list of all linked objects
        """
        _d = o.data
        if _d is not None:
            _objs = cls.get_scene_objects(context)
            return [c for c in _objs if c.data and c.data is _d]
        return []

    @staticmethod
    def hide_for_render_engines(o):
        # Viewport display
        o.display_type = 'WIRE'
        o.display.show_shadows = False

        # Eevee
        o.hide_render = True

        # Cycles-x
        for attr in (
                'visible_camera',
                'visible_diffuse',
                'visible_glossy',
                'visible_transmission',
                'visible_volume_scatter',
                'visible_shadow'
        ):
            if hasattr(o, attr):
                setattr(o, attr, False)

        # Cycles / E-Cycles
        if hasattr(o, "cycles_visibility"):
            for attr in ('camera', 'diffuse', 'glossy', 'shadow', 'scatter', 'transmission'):
                if hasattr(o.cycles_visibility, attr):
                    setattr(o.cycles_visibility, attr, False)

        # Luxcore
        if hasattr(o, "luxcore"):
            try:
                o.luxcore.visible_to_camera = False
                o.luxcore.exclude_from_render = True
            except AttributeError:
                pass

        # Radeon Pro render
        if hasattr(o, "rpr"):
            try:
                o.rpr.visibility_in_primary_rays = False
                o.rpr.reflection_visibility = False
                o.rpr.refraction_visibility = False
                o.rpr.diffuse_visibility = False
                o.rpr.shadows = False
            except AttributeError:
                pass

    @classmethod
    def select_object(cls, context, o, active=False):
        """
         Select object and make active
        """
        if cls.is_valid(o):
            o.select_set(state=True)

            if active:
                vl = cls.get_context_value(context, "view_layer")
                if vl is not None:
                    vl.objects.active = o

    @classmethod
    def link_materials(cls, context, source, dest):
        if USE_SLOTS:
            # adding to slots doesnt work on newly created objects
            # also require object to be visible
            _mats = source.material_slots
            _slots = dest.material_slots
            n_mats = len(_mats)
            n_slots = len(_slots)
            delta = n_mats - n_slots
            if delta != 0:
                with context_override(context, dest, [dest]) as ctx:
                    # with ensure_select_and_restore(context, dest, [dest]):
                    # print("link_materials :", n_mats, n_slots)
                    if delta < 0:
                        for i in range(-delta):
                            cls.call_operator(context, ctx, bpy.ops.object.material_slot_remove)
                            # bpy.ops.object.material_slot_remove(ctx)
                    else:
                        for i in range(delta):
                            cls.call_operator(context, ctx, bpy.ops.object.material_slot_add)
                            # bpy.ops.object.material_slot_add(ctx)

            dest.material_slots.update()

            _slots = dest.material_slots
            for src, dst in zip(_mats, _slots):
                dst.material = src.material
        else:
            src_mats = source.data.materials
            dest_mats = dest.data.materials
            n_mats = len(src_mats)
            n_dest = len(dest_mats)
            delta = n_mats - n_dest
            for i in range(-delta):
                dest_mats.pop(index=-1)
            for i, mat in enumerate(src_mats):
                if i + 1 > n_dest:
                    dest_mats.append(mat)
                else:
                    dest_mats[i] = mat
            # dest.update_tag()
            # dest.data.update_tag()
            dest_mats.update()

    @classmethod
    def unselect_object(cls, context, o):
        if cls.is_valid(o):
            o.select_set(state=False)

    def _collection_hierarchy(self, coll, hierarchy, childrens):
        """ Flatten collection hierarchy under 2.80x
        :param coll: layer_collection
        :param hierarchy: dict  child: parent name
        :param childrens: dict  child: LayerCollection
        :return:
        """
        childrens[coll.name] = coll
        for c in coll.children:
            hierarchy[c.name] = coll.name
            self._collection_hierarchy(c, hierarchy, childrens)

    @staticmethod
    def unhide_collections(coll_names, hierarchy, childrens):
        hide_viewport = set()
        hide_global = set()
        coll_exclude = set()
        for coll_name in coll_names:
            while coll_name in hierarchy:
                if childrens[coll_name].hide_viewport is True:
                    hide_viewport.add(coll_name)
                childrens[coll_name].hide_viewport = False
                if childrens[coll_name].collection.hide_viewport is True:
                    hide_global.add(coll_name)
                if childrens[coll_name].exclude is True:
                    coll_exclude.add(coll_name)
                childrens[coll_name].collection.hide_viewport = False
                coll_name = hierarchy[coll_name]
        return hide_viewport, hide_global, coll_exclude

    @staticmethod
    def hide_collections(childrens, hide_viewport, hide_global, coll_exclude):
        for coll_name in hide_viewport:
            childrens[coll_name].hide_viewport = True
        for coll_name in coll_exclude:
            childrens[coll_name].exclude = True
        for coll_name in hide_global:
            childrens[coll_name].collection.hide_viewport = True

    @classmethod
    def link_object_to_scene(cls, context, o, layer_name=None, default_layer=False):
        coll = cls.get_collection(context, o, layer_name, default_layer)
        cls.link_to_collection(o, coll)

    @staticmethod
    def unlink_object_from_scene(context, o):
        for coll in o.users_collection:
            if coll.objects.get(o.name) is not None:
                coll.objects.unlink(o)

    @staticmethod
    def is_visible(o):
        return not o.hide_get()

    @staticmethod
    def is_selected(o):
        return o.select_get()

    @staticmethod
    def hide_object(o):
        o.hide_set(True)

    @staticmethod
    def show_object(o):
        o.hide_set(False)

    @staticmethod
    def find_modifier_by_type(o, mod_type):
        for mod in o.modifiers:
            if mod.type == mod_type:
                return mod
        return None

    @staticmethod
    def find_modifiers_by_type(o, mod_type):
        return [m for m in o.modifiers if m.type == mod_type]

    @classmethod
    def get_archipack_bool_modifier(cls, o):
        """
        :param o: wall
        :return: boolean / nodes modifier for archipack holes
        """
        for mod in o.modifiers:
            if mod.type == "BOOLEAN":
                if mod.object is not None and cls.has_flag(mod.object, "hybridhole"):
                    return mod
            elif mod.type == "NODES":
                nodes = mod.node_group.nodes
                if (
                        len(nodes) > 3 and
                        any([n.type == "BOOLEAN" for n in nodes]) and
                        any([n.type == "OBJECT_INFO" and n.inputs[0].default_value is not None and
                             (
                                     not cls.has_flag(n.inputs[0].default_value, ["custom_hole", "hole"])
                             )
                             for n in nodes])
                ):
                    return mod
        return None

    @staticmethod
    def get_transform_orientation(context):
        return context.scene.transform_orientation_slots[0].type

    @staticmethod
    def set_transform_orientation(context, _type):
        context.scene.transform_orientation_slots[0].type = _type

    @classmethod
    def archipack_filter(cls, o):
        if cls.is_valid(o):
            if o.data is not None:
                for key in o.data.keys():
                    if "archipack_" in key:
                        return True
            for key in o.keys():
                if "archipack_" in key:
                    return True
        return False

    @classmethod
    def archipack_datablock(cls, o, filter=None):
        """
         Return archipack datablock from object
        """
        d = None
        if cls.is_valid(o):
            if o.data is not None:
                try:
                    for key in o.data.keys():
                        if "archipack_" in key and (filter is None or filter(o, key)):
                            d = getattr(o.data, key)[0]
                            break
                except:
                    pass
            if d is None:
                try:
                    for key in o.keys():
                        if "archipack_" in key and (filter is None or filter(o, key)):
                            d = getattr(o, key)[0]
                            break
                except:
                    pass
        return d

    @classmethod
    def filter_selection(cls, sel):
        res = {}
        for o in sel:
            d = cls.archipack_datablock(o)
            if d is not None:
                key = d.__class__.__name__
                if key not in res:
                    res[key] = set()
                res[key].add(o.name)
        return res

    @classmethod
    def filter_selection_loose(cls, sel):
        """Filter archipack datablock and custom props tagged
        :param sel:
        :return:
        """
        res = {}
        for o in sel:
            d = cls.archipack_datablock(o)
            if d is None:
                for key in o.keys():
                    if "archipack_" in key:
                        if key not in res:
                            res[key] = set()
                        res[key].add(o.name)
            else:
                key = d.__class__.__name__
                if key not in res:
                    res[key] = set()
                res[key].add(o.name)
        return res

    @classmethod
    def filter_polygons(cls, _geoms, geoms=None):
        """ filter Polygons in a collection of geometry
        :param _geoms: Single / Collection of geometry
        :param geoms: and array to fill
        :return: array of Polygons
        """
        if geoms is None:
            geoms = []

        try:
            iter(_geoms)
        except:
            _geoms = [_geoms]
            pass

        for geom in _geoms:
            if geom.type_id == 6:
                # Multipolygon
                geoms.extend(geom.geoms)
            elif geom.type_id == 3:
                # Polygon
                geoms.append(geom)
            elif geom.type_id == 7:
                # GeometryCollection components may be Polygon and Multipolygon
                cls.filter_polygons(geom.geoms, geoms)
        return geoms


class stop_auto_manipulate:
    """Context Manager

    Usage:

    with stop_auto_manipulate(context):
        bpy.ops.archipack ...
    :param context: blender context
    """

    def __init__(self, context):
        self._ctx = context
        self._state = True
        wm = ArchipackContextAbstraction.get_context_value(context, "window_manager")
        if wm and hasattr(wm, "archipack"):
            self._state = wm.archipack.auto_manipulate
            wm.archipack.auto_manipulate = False

    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc_val, exc_tb):
        wm = ArchipackContextAbstraction.get_context_value(self._ctx, "window_manager")
        if wm and hasattr(wm, "archipack"):
            wm.archipack.auto_manipulate = self._state

        # false let raise exception if any
        return None
