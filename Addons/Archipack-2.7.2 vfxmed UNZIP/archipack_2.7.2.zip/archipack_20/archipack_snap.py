# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
# Inspired by Okavango's np_point_move
# ----------------------------------------------------------
"""
    Usage:
        from .archipack_snap import snap_point

        snap_point(context, takeloc, draw_callback, action_callback, constraint_axis)

        arguments:

        takeloc Vector3d location of point to snap

        constraint_axis boolean tuple for each axis
              eg: (True, True, False) to constrtaint to xy plane

        draw_callback(context, sp)
            sp.takeloc
            sp.placeloc
            sp.delta

        action_callback(context, event, state, sp)
            state in {FREEMOVE, SUCCESS, CANCEL}
            sp.takeloc
            sp.placeloc
            sp.delta

        with 3d Vectors
        - delta     = placeloc - takeloc
        - takeloc
        - placeloc


        NOTE:
            may change grid size to 0.1 round feature (SHIFT)
            see https://blenderartists.org/forum/showthread.php?205158-Blender-2-5-Snap-mode-increment
            then use a SHIFT use grid snap

"""

import bpy
# noinspection PyUnresolvedReferences
from bpy.types import Operator
from mathutils import Vector, Matrix
from .archipack_abstraction import context_override
from .archipack_prefs import get_prefs
from .archipack_logging import logger


def dumb_callback(context, event, state, sp):
    return


def dumb_draw(sp, context):
    return


# States
SUCCESS = 1
CANCEL = 2
FREEMOVE = 4
CREATE = 8
MANIPULATE = 16
STARTING = 32
RESTART = 64


def debug_state(state):
    return {
        SUCCESS: "SUCCESS",
        CANCEL: "CANCEL",
        FREEMOVE: "FREEMOVE",
        CREATE: "CREATE",
        MANIPULATE: "MANIPULATE",
        STARTING: "STARTING",
        RESTART: "RESTART"
    }[state]



USE_SLCADSNAP = False
if not bpy.app.background:

    try:

        from sl_ct.snapi.preferences import Prefs
        Prefs.get(bpy.context)
        USE_SLCADSNAP = True
        print("CAD Transform found")

    except ImportError:
        print("CAD Transform not found, fallback to blender's native snap")
        pass

    except KeyError:
        print("You must enable CAD Transform, fallback to blender's native snap")
        pass


if USE_SLCADSNAP:

    from sl_ct.operators import (
        SLCT_main, ModalAction
    )
    from sl_ct.snapi.selection import (
        Selection
    )
    from sl_ct.snapi.snapitem import (
        SnapItems
    )
    from sl_ct.snapi.transform import (
        Transform, Space
    )
    from sl_ct.snapi.types import (
        TransformType,
        ConstraintType,
        SnapItemType
    )
    from sl_ct.snapi.geom import (
        View,
        Geom3d
    )
    from sl_ct.snapi.widgets import (
        Handles,
        SnapHelpers
    )

    class ARCHIPACK_OT_snap(SLCT_main, Operator):
        bl_idname = "archipack.snap"
        bl_label = 'CAD Transform'

        _transform_type = TransformType.MOVE
        _confirm_exit = True
        _release_confirm = True

        _trs = Matrix()

        # Store from outside before call
        constraint_matrix = None
        takeloc = None
        placeloc = None
        callback = None
        _draw_op = None
        constraint = 0
        allow_disable_snap = False
        allow_rotation = False
        _auto_manipulate = False

        def _draw(self, context):

            # setup pers matrix and window size
            View.prepare_to_draw(context)

            # Preview of transformed objects
            Transform.draw()

            # at top so if anything goes wrong after at least cursor is drawn
            self._cursor.draw()

            # if DEBUG:
            #    self._preview_widget.draw()

            # draw in reverse order so last is top
            self._grid.draw(context)

            # tripod widget
            self._pivot.draw(context)

            # virtual snap points + snap buffer debug
            self._detector.draw(context)

            # draw tooltip under widgets
            self._tooltip.update(self._cursor.pixel)
            self._tooltip.draw(context)

            # Transform widgets
            self._rotation.draw()
            # self._move.draw(context)
            # self._scale.draw(context)

            # self._debug.draw(context, Vector((50, 50)))

            SnapHelpers.draw()
            Selection.draw()
            Handles.draw()

            # Selection area for helpers
            # self._selection_area.draw(context)

            # Preview and average
            self._context_preview_point.draw()
            self._context_preview_line.draw()

            self._average.draw()

            # snap circle
            self._snap.draw()

        def draw_handler(self, context):

            if self._draw_op is not None:
                self._draw_op(self, context)

            self._draw(context)

        def cancelled(self, context):
            context.window_manager.archipack.auto_manipulate = self._auto_manipulate
            self.exit(context)
            return {'CANCELLED'}

        def finished(self, context):
            context.window_manager.archipack.auto_manipulate = self._auto_manipulate
            self.exit(context)
            return {'FINISHED'}

        @classmethod
        def is_snapping(cls):
            return Selection.has_hover()

        @classmethod
        def get_active_snapitem(cls):
            return SnapItems.active

        @classmethod
        def get_matrix(cls):
            return Transform.matrix

        @classmethod
        def get_placeloc(cls):
            return Transform.pos

        @classmethod
        def apply_constraint(cls, origin, delta):

            pt = None
            if cls.is_snapping():
                snapitem = cls.get_active_snapitem()
                # print("ARCHIPACK_OT_snap.apply_constraint snapitem : %s" % snapitem)

                if snapitem.type == SnapItemType.LINE:
                    pt = Geom3d.intersect_line_line(origin, origin + delta, *snapitem.coords[0:2])
                elif snapitem.type == SnapItemType.TRI:
                    pt = Geom3d.intersect_ray_plane(origin, delta, snapitem.coord, snapitem.normal)
                else:
                    pt = Geom3d.neareast_point_on_line(snapitem.coord, origin, origin + delta)

            # print("ARCHIPACK_OT_snap.apply_constraint pt: %s" % pt)

            if pt is not None:
                return pt - origin

            return delta

        def keyboard_event(self, context, event):
            trs = Transform.get_action()
            nk = self.allow_rotation and event.value == "PRESS" and not (trs.transformtype & TransformType.KEYBOARD)

            if nk and event.type == "R":

                trs.transformtype = TransformType.ROTATE
                ModalAction.set(ModalAction.FREEMOVE)

                return self.running_modal(context, event)

            return self.keyboard_event_handler(context, event)

        def set_mouse_cursor(self, context, event):
            self._cursor.hide()
            context.window.cursor_set("DEFAULT")

        def init(self, context, event):
            self._waiting = False

            # override by .init_handler()
            release_confirm = self._release_confirm
            logger.debug("ARCHIPACK_OT_snap.init(context)")

            try:
                self.init_handler(context, event)
            except KeyError:
                global USE_SLCADSNAP
                USE_SLCADSNAP = False
                print("You must enable CAD Transform addon in blender preferences and restart !")
                return

            self._release_confirm = release_confirm

            self._auto_manipulate = context.window_manager.archipack.auto_manipulate
            context.window_manager.archipack.auto_manipulate = False

            Space.set_user(self.constraint_matrix)
            self._pivot.matrix_world[:] = Space.get_user()
            self._pivot.matrix_world.translation[:] = self.takeloc
            self._pivot.show()
            Transform.push(context, [self._pivot], self._transform_type, Space.get_user())
            Transform.pop(0)
            trs = Transform.get_action()

            trs.constraint = self.constraint

            ModalAction.set(ModalAction.TRANSFORM)
            Transform.start(context, event, self.takeloc.copy())

        def tooltips(self, context, state) -> list:

            return {
                "Pick start point": [
                    (["MOUSE_LMB"], "Confirm and start"),
                    (["MOUSE_RMB", "EVENT_ESC"], "Exit"),
                    (["EVENT_SHIFT", "MOUSE_LMB"], "Select / edit")
                ],
                "Pick destination": [
                    (["MOUSE_LMB", "EVENT_RETURN"], "Confirm"),
                    (["MOUSE_RMB", "EVENT_ESC"], "Cancel"),
                    (["ZERO"], "Enter distance"),
                    (["EVENT_CTRL", "MOUSE_WHEEL", "UP_ARROW", "DOWN_ARROW"], "Copy"),
                    (["MOUSE_MMB_DRAG"], "Automatic Constraint"),
                    (["EVENT_SHIFT", "MOUSE_MMB_DRAG"], "Automatic Constraint Plane")
                ]
            }[state]

        @property
        def delta(self):
            return self.placeloc - self.takeloc

        @property
        def matrix(self):
            # in world space
            return Transform.matrix

        def pass_through(self, context, event):
            return self.running_modal(context, event)

        def mouse_move(self, context, event):

            self.mouse_move_handler(context, event)

            if event.ctrl:
                self._detector.snapitem = None
                self.placeloc[:] = self._detector.pos
                self._snap.hide()
            else:
                self.placeloc[:] = self.get_placeloc()
                self._snap.pos = self._detector.pos
                self._snap.show()

            if ModalAction.has(ModalAction.TRANSFORM):

                trs = Transform.get_action()
                if trs.has(TransformType.ROTATE):
                    self._rotation.show()

                # print("ARCHIPACK_OT_snap.mouse_move() callback FREEMOVE")
                self.callback(context, event, FREEMOVE, self)

        def confirm(self, context, event, confirm: bool = True):
            trs = Transform.get_action()
            has_transform = ModalAction.has(ModalAction.TRANSFORM)
            has_keyboard = trs.has(TransformType.KEYBOARD)
            can_exit = self.confirm_handler(context, event, confirm)
            cancel = not confirm

            if event.ctrl:
                self.placeloc[:] = self._detector.pos
            else:
                self.placeloc[:] = self.get_placeloc()

            # Exit on cancel / or if confirm_exit
            if has_transform and (
                    # can_exit and (
                    (confirm) or # and self._confirm_exit) or
                    (cancel and not has_keyboard)
                    # )
            ):
                if confirm:
                    # print("ARCHIPACK_OT_snap.mouse_move() callback SUCCESS")
                    self.callback(context, event, SUCCESS, self)
                    return self.finished(context)
                else:
                    # print("ARCHIPACK_OT_snap.mouse_move() callback CANCEL")
                    self.callback(context, event, CANCEL, self)
                    return self.cancelled(context)

            return self.running_modal(context, event)

    # from slcad_transform.slcad_transform import (
    #     SLCAD_main, SlCadConstraint, slcadsnap,
    #     X, Y, Z, AXIS,
    #     MOVE, FREEMOVE, KEYBOARD, ROTATE, SCALE, PIVOT,
    #     C_USER, DRAW_CONSTRAINT
    # )
    #
    # class ARCHIPACK_OT_snap(SLCAD_main, Operator):
    #     bl_idname = "archipack.snap"
    #     bl_label = 'CAD Transform'
    #
    #     _default_action = MOVE | FREEMOVE
    #     _confirm_exit = True
    #     _release_confirm = True
    #
    #     _draw_handler = None
    #     _trs = Matrix()
    #
    #     # Store from outside before call
    #     constraint_matrix = None
    #     takeloc = None
    #     placeloc = None
    #     callback = None
    #     _draw = None
    #
    #     @classmethod
    #     def is_snapping(cls):
    #         return slcadsnap.is_snapping
    #
    #     def gl_draw(self, context):
    #
    #         loc = self.apply_constraint(self.takeloc)
    #         self._preview_widget.c = slcadsnap._screen_location_from_3d(loc)
    #         self._preview_widget.draw(context)
    #         loc = self.apply_constraint(self.placeloc)
    #         self._preview_widget.c = slcadsnap._screen_location_from_3d(loc)
    #         self._preview_widget.draw(context)
    #
    #         SLCAD_main.gl_draw(self, context)
    #
    #     def keyboard_event(self, context, event):
    #
    #         nk = event.value == "PRESS" and not (self._action & KEYBOARD)
    #
    #         # if event.value == "PRESS" and "CTRL" in event.type:
    #         #    self._disable_snap = not self._disable_snap
    #         #    print("disable_snap", self._disable_snap)
    #
    #         if nk and event.type == "R":
    #             print("Action ROTATE")
    #             self._action = ROTATE | FREEMOVE
    #             return True
    #         # elif nk and event.type == "S":
    #         #     # Note: scale issue is
    #         #     print("Action SCALE")
    #         #     self._action = SCALE | PIVOT
    #         #     return True
    #         # elif nk and event.type == "G":
    #         #     print("Action MOVE")
    #         #     self._action = MOVE | FREEMOVE
    #         #     return True
    #         # else:
    #         return SLCAD_main.keyboard_event(self, context, event)
    #
    #     @classmethod
    #     def poll(cls, context):
    #         return True
    #
    #     def exit(self, context, event):
    #         if self._draw_handler is not None:
    #             bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
    #         logger.debug("snap exit")
    #         SLCAD_main.exit(self, context, event)
    #
    #     def init(self, context):
    #         global slcadsnap
    #         self._waiting = False
    #         logger.debug("slcadsnap.start(context)")
    #         slcadsnap.start(context, True)
    #         # Allow rotate and move action change
    #         self._keyboard_type.add("R")
    #         # self._keyboard_type.add("G")
    #         # self._keyboard_type.add("S")
    #         # self._keyboard_type.add("LEFT_CTRL")
    #         # self._keyboard_type.add("RIGHT_CTRL")
    #
    #         local = context.active_object.matrix_world.normalized()
    #         world = Matrix.Translation(self.takeloc.copy())
    #         self._constraint_global = SlCadConstraint(world)
    #         self._constraint_local = SlCadConstraint(self.constraint_matrix.copy())
    #         self._constraint_user = SlCadConstraint(self.constraint_matrix.copy())
    #         self._constraint_flag = C_USER
    #         self._draw_handler = None
    #         self._draw_flags |= DRAW_CONSTRAINT
    #         if self._draw is not None:
    #             args = (self, context)
    #             self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(self._draw, args, 'WINDOW', 'POST_PIXEL')
    #
    #         self.snap_from = self.takeloc.copy()
    #
    #         self.update_constraint(context)
    #         self.store_matrix_world(context)
    #         self.clear_average()
    #
    #     @property
    #     def delta(self):
    #         return self.placeloc - self.takeloc
    #
    #     @property
    #     def matrix(self):
    #         # in world space
    #         return self._trs
    #
    #     def undo(self, context, event):
    #         logger.debug("end callback CANCEL")
    #         self.callback(context, event, CANCEL, self)
    #
    #     def _transform(self, context, event, o, tm, confirm):
    #
    #         # tm is absolute about constraint
    #         space = self.constraint.project_matrix
    #         # world space
    #         self._trs = space @ tm @ space.inverted()
    #         if self._action & MOVE:
    #             self.placeloc = space @ tm.translation.copy()
    #         else:
    #             self.placeloc = space @ tm @ Vector((1,0,0))
    #
    #         if self._waiting and not confirm:
    #             print("XXXXXXXXXX  _transform waiting")
    #             return
    #
    #         if confirm and self._waiting:
    #             print("XXXXXXXXXX  _transform confirm")
    #
    #         self._waiting = True
    #
    #         if confirm:
    #             if self.delta.length == 0:
    #                 print("callback CANCEL")
    #                 self.callback(context, event, CANCEL, self)
    #             else:
    #                 print("callback SUCCESS")
    #                 self.callback(context, event, SUCCESS, self)
    #         else:
    #             print("callback RUNNING")
    #             self.callback(context, event, FREEMOVE, self)
    #
    #         self._waiting = False

else:

    from .archipack_abstraction import ArchipackObjectsManager, stop_auto_manipulate


    class SnapStore:
        """
            Global store
        """
        callback = None
        draw = None
        helper = None
        takeloc = Vector()
        placeloc = Vector()
        constraint_axis = (True, True, False)
        helper_matrix = Matrix()
        transform_orientation = 'GLOBAL'
        release_confirm = True
        skip_children = False
        instances_running = 0
        # store available tool_settings
        tool_settings = {}
        # context related
        use_snap = False
        snap_elements = None
        snap_target = None
        pivot_point = None
        trans_orientation = None
        filter_cb = None


    def store_ts(ts):
        res = {}
        keys = dir(ts)
        for k in keys:
            if not k.startswith("_") and k not in {"bl_rna"}:
                v = getattr(ts, k, None)
                if v.__class__.__name__ in {'str', 'bool'} and v != "":
                    res[k] = v
        return res

    def revert_ts(ts, store):
        for k, v in store.items():
            setattr(ts, k, v)


    class ArchipackSnapBase(ArchipackObjectsManager):
        """
            Helper class for snap Operators
            store and restore context
            create and destroy helper
            install and remove a draw_callback working while snapping

            store and provide access to 3d Vectors
            in draw_callback and action_callback
            - delta     = placeloc - takeloc
            - takeloc
            - placeloc
        """

        def __init__(self):
            self._draw_handler = None
            self._timer = None

        def init(self, context, event):
            # Store context data
            ts = context.tool_settings
            # SnapStore.tool_settings = store_ts(ts)
            SnapStore.trans_orientation = self.get_transform_orientation(context)
            self.create_helper(context)

            if SnapStore.draw is not None:
                args = (self, context)
                self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(SnapStore.draw, args, 'WINDOW',
                                                                            'POST_PIXEL')

        def remove_timer(self, context):
            if self._timer is not None:
                context.window_manager.event_timer_remove(self._timer)

        def exit(self, context):

            self.remove_timer(context)

            if self._draw_handler is not None:
                bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')

            # Restore original context
            if hasattr(context, "tool_settings"):
                ts = context.tool_settings
                revert_ts(ts, SnapStore.tool_settings)

            self.set_transform_orientation(context, SnapStore.trans_orientation)

            self.destroy_helper(context)
            # logger.debug("ArchipackSnapBase.exit() act: %s", context.object.name)

        def create_helper(self, context):
            """
                Create a helper with fake user
                or find older one in bpy data and relink to scene
                currently only support OBJECT mode

                Do target helper be linked to scene in order to work ?

            """
            helper = bpy.data.objects.get('Archipack_snap_helper')
            if helper is not None:
                logger.debug("ArchipackSnapBase.create_helper() helper found")
                if self.get_scene_object(context, 'Archipack_snap_helper') is None:
                    logger.debug("ArchipackSnapBase.create_helper() link helper")
                    self.link_object_to_scene(context, helper)
                    # context.scene.collection.objects.link(helper)
            else:
                logger.debug("ArchipackSnapBase.create_helper() create helper")
                helper = bpy.data.objects.new(name="Archipack_snap_helper", object_data=None)
                helper.empty_display_type = "ARROWS"  # "PLAIN_AXES"
                helper.empty_display_size = 0.2
                # m = bpy.data.meshes.new("Archipack_snap_helper")
                # m.vertices.add(count=1)
                # helper = bpy.data.objects.new("Archipack_snap_helper", m)
                self.link_object_to_scene(context, helper)
                # context.scene.collection.objects.link(helper)

            helper.matrix_world = SnapStore.helper_matrix
            SnapStore.helper = helper

        def destroy_helper(self, context):
            """
                Unlink helper
                currently only support OBJECT mode
            """
            if SnapStore.helper is not None:
                self.unlink_object_from_scene(context, SnapStore.helper)
            SnapStore.helper = None

        @property
        def delta(self):
            return self.placeloc - self.takeloc

        @property
        def takeloc(self):
            return SnapStore.takeloc

        @property
        def placeloc(self):
            # take from helper when there so the delta
            # is working even while modal is running
            if SnapStore.helper is not None:
                return SnapStore.helper.location
            else:
                return SnapStore.placeloc


    class ARCHIPACK_OT_snap(ArchipackSnapBase, Operator):
        bl_idname = 'archipack.snap'
        bl_label = 'Archipack snap'
        bl_options = {'INTERNAL', 'UNDO'}  #
        is_updating = False

        def _sp_callback(self, context, event, state, sp):
            # skip on free move in order to consume events
            if (state != FREEMOVE or not self.is_updating):
                self.is_updating = True
                SnapStore.callback(context, event, state, sp)
                self.is_updating = False

        @classmethod
        def is_snapping(cls):
            return False

        def modal(self, context, event):

            if SnapStore.helper is None:
                logger.debug("Snap.modal() helper is none !!  event %s %s",
                             event.type,
                             event.value)
                self.exit(context)
                return {'FINISHED'}

            logger.debug("Snap.modal event %s %s location:%s",
                         event.type,
                         event.value,
                         SnapStore.helper.location)

            if context.area is not None:
                context.area.tag_redraw()

            if event.type in 'TIMER':

                self._sp_callback(context, event, FREEMOVE, self)

                return {'PASS_THROUGH'}

            if event.type not in ('ESC', 'RIGHTMOUSE', 'LEFTMOUSE', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'):
                return {'PASS_THROUGH'}

            # right click while moving may either return RIGHTMOUSE or MOUSEMOVE + PRESS
            # anyway, a mouse + press event here means cancel
            if event.type in ('ESC', 'RIGHTMOUSE'):  # or (event.type == 'MOUSEMOVE' and event.value == 'PRESS'):
                SnapStore.callback(context, event, CANCEL, self)
            else:
                SnapStore.placeloc = SnapStore.helper.location
                # on tt modal exit with right click, the delta is 0 so exit
                # XXX this prevent RET to create wall's segments
                if self.delta.length == 0:
                    SnapStore.callback(context, event, CANCEL, self)
                else:
                    SnapStore.callback(context, event, SUCCESS, self)

            self.exit(context)
            # self.report({'INFO'}, "ARCHIPACK_OT_snap exit")
            return {'FINISHED'}

        def invoke(self, context, event):
            if context.area.type == 'VIEW_3D':

                if event.type in ('ESC', 'RIGHTMOUSE'):
                    return {'FINISHED'}

                self.is_updating = False

                with stop_auto_manipulate(context):

                    self.init(context, event)

                    logger.debug("Snap.invoke event %s %s location:%s",
                                 event.type,
                                 event.value,
                                 SnapStore.helper.location)

                    wm = context.window_manager
                    wm.modal_handler_add(self)
                    # Use a timer to broadcast a TIMER event while transform.translate is running
                    self._timer = wm.event_timer_add(0.05, window=context.window)
                    with context_override(context, SnapStore.helper, [SnapStore.helper], SnapStore.filter_cb) as ctx:
                        self.call_operator(context, ctx, bpy.ops.transform.translate, {
                            "constraint_axis": SnapStore.constraint_axis,
                            "orient_type": SnapStore.transform_orientation,
                            "release_confirm": SnapStore.release_confirm
                        }, 'INVOKE_DEFAULT')

                    # with ensure_select_and_restore(context, SnapStore.helper, [SnapStore.helper]):
                    #     if "orient_type" in bpy.ops.transform.translate.get_rna_type().bl_rna.properties.keys():
                    #         # after 28.02.2019
                    #         bpy.ops.transform.translate('INVOKE_DEFAULT',
                    #             constraint_axis=SnapStore.constraint_axis,
                    #             orient_type=SnapStore.transform_orientation,
                    #             release_confirm=SnapStore.release_confirm)
                    #     else:
                    #         # before 28.02.2019
                    #         bpy.ops.transform.translate('INVOKE_DEFAULT',
                    #             constraint_axis=SnapStore.constraint_axis,
                    #             constraint_orientation=SnapStore.transform_orientation,
                    #             release_confirm=SnapStore.release_confirm)

                    logger.debug("Snap.invoke transform.translate done")

                return {'RUNNING_MODAL'}
            else:
                self.report({'WARNING'}, "View3D not found, cannot run operator")
                return {'FINISHED'}




def snap_point(context,
                takeloc=None,
                draw=None,
                callback=dumb_callback,
                takemat=None,
                constraint_axis=(True, True, False),
                transform_orientation='GLOBAL',
                mode='OBJECT',
                release_confirm=True,
                skip_children=False,
                allow_rotation=False
               ):
    """
        Invoke op from outside world
        in a convenient importable function

        transform_orientation in [‘GLOBAL’, ‘LOCAL’, ‘NORMAL’, ‘GIMBAL’, ‘VIEW’]

        draw(sp, context) a draw callback
        callback(context, event, state, sp) action callback

        Use either :
        takeloc Vector, unconstraint or system axis constraints
        takemat Matrix, constaint to this matrix as 'LOCAL' coordsys
            The snap source helper use it as world matrix
            so it is possible to constraint to user defined coordsys.
    """
    prefs = get_prefs(context)
    if USE_SLCADSNAP:

        if takemat is not None:
            takeloc = takemat.translation.copy()
        elif takeloc is not None:
            takemat = Matrix.Translation(takeloc)

        ARCHIPACK_OT_snap.constraint_matrix = takemat
        ARCHIPACK_OT_snap.callback = callback
        ARCHIPACK_OT_snap._draw_op = draw
        ARCHIPACK_OT_snap._release_confirm = prefs.release_confirm
        ARCHIPACK_OT_snap.takeloc = takeloc
        ARCHIPACK_OT_snap.placeloc = takeloc.copy()
        ARCHIPACK_OT_snap.allow_rotation = allow_rotation
        constraint = ConstraintType.NONE
        dimension = sum(map(lambda x: 1 if x else 0, constraint_axis))

        if dimension > 1:
            constraint = ConstraintType.PLANE
            constraint_axis = [not x for x in constraint_axis]

        elif dimension == 1:
            constraint = ConstraintType.AXIS

        for axis, flag in zip(constraint_axis, [ConstraintType.X, ConstraintType.Y, ConstraintType.Z]):
            if axis:
                constraint |= flag

        ARCHIPACK_OT_snap.constraint = constraint

        # print("bpy.ops.archipack.snap()")
        logger.debug("bpy.ops.archipack.snap('INVOKE_DEFAULT')")
        bpy.ops.archipack.snap('INVOKE_DEFAULT')
        return None

    else:

        SnapStore.draw = draw
        SnapStore.callback = callback
        SnapStore.constraint_axis = constraint_axis
        SnapStore.release_confirm = prefs.release_confirm
        # SnapStore.skip_children = skip_children
        # Prevent snap to reference point
        SnapStore.filter_cb = lambda x: "archipack_reference_point" not in x

        if takemat is not None:
            SnapStore.helper_matrix = takemat
            takeloc = takemat.translation.copy()
            transform_orientation = 'LOCAL'
        elif takeloc is not None:
            SnapStore.helper_matrix = Matrix.Translation(takeloc)
        else:
            raise ValueError("ArchipackSnap: Either takeloc or takemat must be defined")

        SnapStore.takeloc = takeloc
        SnapStore.placeloc = takeloc.copy()

        SnapStore.transform_orientation = transform_orientation

        # @NOTE: unused mode var to switch between OBJECT and EDIT mode
        # for ArchipackSnapBase to be able to handle both modes
        # must implements corresponding helper create and delete actions
        SnapStore.mode = mode
        logger.debug("bpy.ops.archipack.snap('INVOKE_DEFAULT')")

        bpy.ops.archipack.snap('INVOKE_DEFAULT')
        # return helper so we are able to move it "live"
        return SnapStore.helper


def register():
    bpy.utils.register_class(ARCHIPACK_OT_snap)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_OT_snap)
