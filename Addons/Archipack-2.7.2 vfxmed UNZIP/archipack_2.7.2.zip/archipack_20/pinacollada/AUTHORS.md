Authors (Ordered by date of first contribution)
===============================================

* Alejandro Conty Estevez (aconty AT gmail.com)
* Conrad Wong
* Jeff Terrace (jterrace AT gmail.com)
* Rehno Lindeque
* Dusan Maliarik
* Ewen Cheslack-Postava
* Ole Laursen
* Andrey Nechypurenko (andreynech AT gmail.com)
* Guohui Xiao (xiao AT kr.tuwien.ac.at)
* Hannes Gräuler (graeuler AT geoplex.de)
* Thomas Holder (speleo3)

