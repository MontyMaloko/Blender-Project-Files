# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# support routines for render measures in final image
# Author: Antonio Vazquez (antonioya)
# Archipack adaptation by : Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from shutil import copyfile
from os import path, remove, listdir
from sys import exc_info
import subprocess
# noinspection PyUnresolvedReferences
import bpy_extras.image_utils as img_utils
# noinspection PyUnresolvedReferences
from math import ceil

from .archipack_iconmanager import icons

from bpy.types import Operator
from bl_ui import properties_render


class ARCHIPACK_OT_render_thumbs(Operator):
    bl_idname = "archipack.render_thumbs"
    bl_label = "Render presets thumbs"
    bl_description = "Setup default presets and update thumbs (may take one or 2 minits)"
    bl_options = {'REGISTER', 'INTERNAL'}

    @classmethod
    def poll(cls, context):
        # Ensure BLENDER_EEVEE engine is available
        return 'BLENDER_EEVEE' in context.scene.render.engine

    def background_render(self, context, cls, preset):
        generator = path.dirname(path.realpath(__file__)) + path.sep + "archipack_thumbs.py"
        matlib_path = context.preferences.addons[__package__].preferences.matlib_path
        # Run external instance of blender like the original thumbnail generator.
        cmd = [
            bpy.app.binary_path,
            "--background",
            "--factory-startup",
            "-noaudio",
            "--python", generator,
            "--",
            "addon:" + __package__,
            "matlib:" + matlib_path,
            "cls:" + cls,
            "preset:" + preset
            ]
        popen = subprocess.Popen(cmd, stdout=subprocess.PIPE, universal_newlines=True)
        for stdout_line in iter(popen.stdout.readline, ""):
            yield stdout_line
        popen.stdout.close()
        popen.wait()

    def copy_to_user_path(self, category):
        """
        Copy factory presets to writeable presets folder
        Two cases here:
        1 there is not presets thumbs found (official version)
        2 thumbs allready are there (unofficial)
        """
        file_list = []
        # load default presets
        dir_path = path.dirname(path.realpath(__file__))
        # sub_path = "presets" + path.sep + category
        source_path = path.join(dir_path, "presets", category)
        if path.exists(source_path):
            file_list.extend([
                f
                for f in listdir(source_path)
                if f.endswith('.json') and
                not f.startswith('.')
        ])

        presets_path = icons.create_preset_folder(category)

        # files from factory not found in user doesnt require a recompute
        skipfiles = []
        for f in file_list:
            # copy python/txt preset
            if not path.exists(path.join(presets_path, f)):
                copyfile(path.join(source_path , f), path.join(presets_path ,f))

            # skip txt files (material presets)
            # if f.endswith(".txt"):
            #    skipfiles.append(f)

            # when thumbs allready are in factory folder but not found in user one
            # simply copy them, and add preset to skip list
            thumb_filename = f[:-4] + ".png"
            if path.exists(path.join(source_path, thumb_filename)):
                if not path.exists(path.join(presets_path, thumb_filename)):
                    copyfile(path.join(source_path, thumb_filename), path.join(presets_path, thumb_filename))
                    skipfiles.append(f)

        return skipfiles

    def scan_files(self, category):
        file_list = []

        # copy from factory to user writeable folder
        skipfiles = self.copy_to_user_path(category)

        # load user def presets
        preset_paths = bpy.utils.script_paths("presets")

        for preset in reversed(preset_paths):
            presets_path = path.join(preset, category)
            if path.exists(presets_path):
                file_list += [
                    path.join(presets_path, f[:-4])
                    for f in listdir(presets_path)
                    if f.endswith('.json') and
                    not f.startswith('.') and
                    f not in skipfiles
                ]

        file_list.sort()
        return file_list

    def rebuild_thumbs(self, context):
        file_list = []
        dir_path = path.dirname(path.realpath(__file__))
        sub_path = "presets"
        presets_path = path.join(dir_path, sub_path)
        # print(presets_path)
        if path.exists(presets_path):
            dirs = listdir(presets_path)
            for dir in dirs:
                abs_dir = path.join(presets_path, dir)
                if path.isdir(abs_dir):
                    files = self.scan_files(dir)
                    file_list.extend([(dir, file) for file in files])

        ttl = len(file_list)
        for i, preset in enumerate(file_list):
            dir, file = preset
            cls = dir[10:]
            if cls in {'curves', 'materials'}:
                continue
            # context.scene.archipack_progress = (100 * i / ttl)
            log_all = False
            for l in self.background_render(context, cls, file + ".json"):
                if "[log]" in l:
                    print(l[5:].strip())
                elif "blender.crash" in l:
                    print("Unexpected error")
                    log_all = True
                if log_all:
                    print(l.strip())

    def invoke(self, context, event):
        addon_name = __name__.split('.')[0]
        matlib_path = context.preferences.addons[addon_name].preferences.matlib_path

        if matlib_path == '':
            self.report({'WARNING'}, "You should setup a default material library path in addon preferences")
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # context.scene.archipack_progress_text = 'Generating thumbs'
        # context.scene.archipack_progress = 0
        self.rebuild_thumbs(context)
        # context.scene.archipack_progress = -1
        return {'FINISHED'}


def register():
    bpy.utils.register_class(ARCHIPACK_OT_render_thumbs)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_OT_render_thumbs)
