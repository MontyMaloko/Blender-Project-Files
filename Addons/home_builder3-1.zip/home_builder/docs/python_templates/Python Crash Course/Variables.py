#PYTHON VARIABLES

my_variable = "Hello, World"

#Types of Variables
#----Integers
#----Floats
#----Booleans
#----Strings
#----Lists
#----Dictionary

#Define an Integer like this
my_int = 1

#Define a Float like this
my_float = 1.2

#Define a Boolean like this
my_true_value = True
my_false_value = False

#Define a String like this
my_string = "Text Info"

#Define a List like this
my_list = ["Item 1","Item 2","Item 3"]
my_tuple = ("Item 1","Item 2","Item 3")

#Define a Dictionary like this
my_dict = {"Item One":1,"Item Two":2}