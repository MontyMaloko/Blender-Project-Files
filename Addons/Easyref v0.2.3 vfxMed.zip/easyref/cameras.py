'''-*- coding:utf-8 -*-

Easyref Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

from bpy.types import Operator
import bpy, os
from bpy.props import (StringProperty,
                       BoolProperty,
                       PointerProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       BoolVectorProperty,
                       CollectionProperty)

from .all_operators import Freezer
from .properties import *
from mathutils import Matrix, Vector
from math import radians

def create_camera(context, D):

    bpy.ops.object.camera_add(enter_editmode=False, align='VIEW')
    cam = context.active_object
    cam.name = cam.data.name = "Cam Ref"

    cam.easyref.add()
    cam.data.lens = 75
    cam.data.sensor_width = 40
    cam.data.clip_start = 0.1
    cam.data.clip_end = 100000
    cam.data.show_passepartout = False
    cam.lock_scale = (True, True, True)
    context.scene.render.use_border = False
    context.space_data.lock_camera = True
    if bpy.app.version >= (4, 2, 0):
        context.space_data.overlay.show_camera_guides = False
    cam.hide_select = True

    # Add custom properties
    cam["Cam Lock"] = False
    cam["Lock cam to view"] = True
    cam["Visible"] = True

    context.scene.camera = cam

    return cam

class ImportFilesCollection(bpy.types.PropertyGroup):
    name : StringProperty(
        name = "File Path",
        description = "Filepath used for importing the file",
        maxlen = 1024,
        subtype = 'FILE_PATH',
    ) # type: ignore

class EASYREF_OT_images_refs_actions(Freezer, bpy.types.Operator):
    bl_idname = "easyref.images_refs_actions"
    bl_label = "Camera and References Actions"
    bl_options = {"REGISTER"}

    add_cam_and_ref : BoolProperty(default=False) # type: ignore
    add_ref : BoolProperty(default=False) # type: ignore
    launch_modal : BoolProperty(default=False) # type: ignore
    camref : StringProperty() # type: ignore

    @classmethod
    def description(cls, context, properties):
        if properties.add_cam_and_ref:  
            return f"Add a new camera with references images\n\nYou will be able to edit the settings and add/Remove references images\nYou can add as many references images as you want"
        elif not properties.add_cam_and_ref and properties.add_ref:
            return f"Add a new reference image to the selected camera"
        else:
            return f"Edit the selected camera and its reference image in the Modal Operator\n\nYou will be able to edit the Reference Image (Alpha, location, rotation, scale, etc...)"

    def invoke(self, context, event):

        # Add Cam and Ref
        if self.add_cam_and_ref:
            bpy.ops.easyref.create_cam_and_reference('INVOKE_DEFAULT')

        # Add ref
        if self.add_ref:
            bpy.ops.easyref.add_reference('INVOKE_DEFAULT', camref=self.camref)


        # Launch Modal
        if self.launch_modal:
            bpy.ops.easyref.modal('INVOKE_DEFAULT', camref=self.camref)

            return {"FINISHED"}

        return {"FINISHED"}


class EASYREF_OT_create_image_reference(Freezer, Operator):
    bl_idname = "easyref.create_cam_and_reference"
    bl_label = "Create Camera from Reference"
    bl_options = {'REGISTER', 'UNDO'}

    files : CollectionProperty(type=ImportFilesCollection) # type: ignore
    filepath : StringProperty(subtype="FILE_PATH") # type: ignore
    filter_glob : StringProperty(
        default="*.exr;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.tga;*.bmp;*.webp;*.gif;*.psd;*.psb;*.hdr;*.svg",
        options={'HIDDEN'},
    ) # type: ignore

    camref : StringProperty() # type: ignore

    def invoke(self, context, event):
        # Recherche les objets sélectionnés ayant la custom property "easyref_empty_ref_view"
        selected_refs = [obj for obj in context.selected_objects if obj.get("easyref_empty_ref_view")]
        if selected_refs:
            return self.execute(context)
        else:
            # Aucun objet adéquat sélectionné : on lance le navigateur de fichiers
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

    def move_to_collection(self, context, cam):
        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)
            # Create CAMERAS_REFERENCES collection inside REFERENCES
            ref_ortho_views_collection = bpy.data.collections.new("CAMERAS_REFERENCES")
            ref_collection.children.link(ref_ortho_views_collection)
        else:
            # Get or create CAMERAS_REFERENCES collection
            ref_ortho_views_collection = bpy.data.collections.get("CAMERAS_REFERENCES")
            if not ref_ortho_views_collection:
                ref_ortho_views_collection = bpy.data.collections.new("CAMERAS_REFERENCES")
                ref_collection.children.link(ref_ortho_views_collection)
        # Move reference to collection
        for col in cam.users_collection:
            col.objects.unlink(cam)
        ref_ortho_views_collection.objects.link(cam)

    def execute(self, context):
        # Capture la sélection immédiatement
        active_obj = context.active_object
        selected_objects = [obj for obj in context.selected_objects]

        # Save Selection
        self.save_selection(context)
        self.freeze(context)

        # Exit Cam view
        CamRef_Check_Cam_Statut()
        
        # Créer une liste qui inclut l'objet actif et les objets sélectionnés
        objects_to_check = []
        if active_obj:
            objects_to_check.append(active_obj)
        # Ajouter tous les objets sélectionnés qui ne sont pas l'objet actif
        for obj in selected_objects:
            if obj != active_obj and obj not in objects_to_check:
                objects_to_check.append(obj)
        
        # On vérifie à nouveau si un objet avec la custom property est sélectionné
        selected_refs = []
        for obj in objects_to_check:
            if "easyref_empty_ref_view" in obj:
                selected_refs.append(obj)
        
        if selected_refs:
            # Create camera
            cam = create_camera(context, bpy.data)
            self.camref = cam.name
            context.space_data.camera = cam

            bpy.ops.view3d.camera_to_view()
            context.scene.camera = cam
            cam.data.show_background_images = True
            context.space_data.use_local_camera = True

            # Add background images from selected references
            for i, ref in enumerate(selected_refs):
                if ref.type == 'EMPTY' and ref.empty_display_type == 'IMAGE':
                    bg = cam.data.background_images.new()
                    bg.image = ref.data
                    bg.alpha = 0.8
                    bg.frame_method = 'FIT'
                    bg.scale = 0.5
                    bg.display_depth = 'FRONT'
                    bg.show_expanded = False

            # Ne définir l'index actif que s'il y a des images
            if len(cam.data.background_images) > 0:
                cam.data.easyref_image_active = 0

        else:
            # Comportement normal avec le navigateur de fichiers
            path = os.path.dirname(self.filepath)
            
            # Create camera
            cam = create_camera(context, bpy.data)
            self.camref = cam.name
            context.space_data.camera = cam
            bpy.ops.view3d.camera_to_view()
            context.scene.camera = cam
            context.object.data.show_background_images = True
            context.space_data.use_local_camera = True

            # Add background images from files
            for i, file in enumerate(self.files):
                new_image = bpy.data.images.load(filepath=os.path.join(path, file.name), check_existing=True)
                cam.data.show_background_images = True
                bg = cam.data.background_images.new()
                bg.image = new_image
                bg.alpha = 0.8
                bg.frame_method = 'FIT'
                bg.scale = 0.5
                bg.display_depth = 'FRONT'
                bg.show_expanded = False

            # Ne définir l'index actif que s'il y a des images
            if len(self.files) > 0:
                cam.data.easyref_image_active = 0  # Toujours commencer par la première image

        # Common setup
        context.scene.tool_settings.annotation_stroke_placement_view3d = 'CURSOR'
        self.move_to_collection(context, cam)
        cam.select_set(state=False)

        # Make visible object selectable again
        self.unfreeze()

        # Restore Selection
        self.restore_selection(context)

        self.camref = cam.name
        
        # Ne lancer le modal que s'il y a des images
        if len(cam.data.background_images) > 0:
            bpy.ops.easyref.modal('INVOKE_DEFAULT', camref=self.camref)

        return {'FINISHED'}
    
# class EASYREF_OT_create_image_reference( Freezer, bpy.types.Operator):
#     bl_idname = "easyref.create_cam_and_reference"
#     bl_label = "Create Image Reference"
#     bl_options = {"REGISTER"}

#     files : CollectionProperty(type=ImportFilesCollection) # type: ignore
#     filepath : StringProperty(subtype="FILE_PATH") # type: ignore
#     filter_glob : StringProperty(
#         default="*.exr;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.tga;*.bmp;*.avi;*.mkv;*.mov;*.mp4;*.webm;*.webp;*.gif;*.psd;*.psb;*.hdr;*.svg",
#         options={'HIDDEN'},
#     ) # type: ignore

#     camref : StringProperty() # type: ignore

#     def invoke(self, context, event):
        
#         context.window_manager.fileselect_add(self)
#         return {'RUNNING_MODAL'}
    
#     def execute(self, context):

#         if context.object and context.object.type in {'MESH','CURVE','FONT','ARMATURE'}:
#             bpy.ops.object.mode_set(mode='OBJECT')

#         # Save Selection
#         self.save_selection(context)
#         self.freeze(context)

#         D = bpy.data
#         path = os.path.dirname(self.filepath)

#         # Exit Cam view
#         CamRef_Check_Cam_Statut()

#         # Create & Edit Camera settings
#         cam = create_camera(context, D)
#         self.camref = cam.name
#         context.space_data.camera = cam
#         bpy.ops.view3d.camera_to_view()
#         context.scene.camera = cam
#         context.object.data.show_background_images = True
#         context.space_data.use_local_camera = True
        
#         for file in self.files:
#             new_image = bpy.data.images.load(filepath=os.path.join(path, file.name), check_existing=True)
#             cam.data.show_background_images = True
#             bg = cam.data.background_images.new()
#             bg.image = new_image
#             bg.alpha = 0.8
#             bg.frame_method = 'FIT'
#             bg.scale = 0.5
#             bg.display_depth = 'FRONT'
#             bg.show_expanded = False

#         cam.data.easyref_image_active = len(self.files) -1
#         context.scene.tool_settings.annotation_stroke_placement_view3d = 'CURSOR'

#         #COLLECTION
#         # Get or create REFERENCES collection
#         ref_collection = bpy.data.collections.get("REFERENCES")
#         if not ref_collection:
#             # Create REFERENCES collection if it doesn't exist
#             ref_collection = bpy.data.collections.new("REFERENCES")
#             context.scene.collection.children.link(ref_collection)
            
#             # Create CAMERAS_REFERENCES collection inside REFERENCES
#             ref_cameras_collection = bpy.data.collections.new("CAMERAS_REFERENCES") 
#             ref_collection.children.link(ref_cameras_collection)
#         else:
#             # Get or create CAMERAS_REFERENCES collection inside REFERENCES
#             ref_cameras_collection = bpy.data.collections.get("CAMERAS_REFERENCES")
#             if not ref_cameras_collection:
#                 ref_cameras_collection = bpy.data.collections.new("CAMERAS_REFERENCES")
#                 ref_collection.children.link(ref_cameras_collection)
            
#         # Move the reference object to the CAMERAS_REFERENCES collection
#         cam_name = cam.name
#         if cam_name in bpy.data.objects:
#             empty = bpy.data.objects[cam_name]
#             # Unlink from current collection
#             context.collection.objects.unlink(empty)
#             # Link to CAMERAS_REFERENCES collection
#             ref_cameras_collection.objects.link(empty)

#         cam.select_set(state=False)

#         # Make visible object selectable again
#         self.unfreeze()

#         # Restore Selection
#         self.restore_selection(context)

#         self.camref = cam.name
#         bpy.ops.easyref.modal('INVOKE_DEFAULT', camref=self.camref)

#         return {"FINISHED"}

    

class EASYREF_OT_add_reference(Freezer, bpy.types.Operator):
    bl_idname = "easyref.add_reference"
    bl_label = "Create Image Reference"
    bl_description = "Create Image Reference\n\nSelect one or several images\nYou will be able to move, rotate, scale them, etc..."
    bl_options = {"REGISTER"}

    files : CollectionProperty(type=ImportFilesCollection) # type: ignore
    filepath : StringProperty(subtype="FILE_PATH") # type: ignore
    filter_glob : StringProperty(
        default="*.exr;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.tga;*.bmp;*.webp;*.gif;*.psd;*.psb;*.hdr;*.svg",
        options={'HIDDEN'},
    ) # type: ignore

    camref : StringProperty() # type: ignore

    def execute(self, context):

        path = os.path.dirname(self.filepath)

        # Set Cam Active, visible, and look trough
        cam = bpy.data.objects[self.camref]

        bpy.ops.view3d.object_as_camera()

        context.space_data.camera = cam

        for file in self.files:
            new_image = bpy.data.images.load(filepath=os.path.join(path, file.name), check_existing=True)
            cam.data.show_background_images = True
            bg = cam.data.background_images.new()
            bg.image = new_image
            bg.alpha = 0.8
            bg.frame_method = 'FIT'
            bg.scale = 0.5
            bg.display_depth = 'FRONT'
            bg.show_expanded = False

        cam.data.easyref_image_active = len(cam.data.background_images) - 1

        self.camref = cam.name
        bpy.ops.easyref.modal('INVOKE_DEFAULT', camref=self.camref)

        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class EASYREF_OT_easyref_rename_camera(Freezer, bpy.types.Operator):
    bl_idname = 'easyref.select_camref'
    bl_label = "Set Camera as Active"
    bl_description = "Set the selected camera as active\n\nSHIFT + CLICK: Rename the Camera"
    bl_options = {'REGISTER'}

    camref : StringProperty() # type: ignore
    new_name : StringProperty() # type: ignore

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "new_name", text="Name")

    def execute(self, context):
        cam = bpy.data.objects[self.camref]
        cam.name = cam.data.name = self.new_name
        return {'FINISHED'}

    def invoke(self, context, event):
        cam = bpy.data.objects[self.camref]

        self.obj = getattr(context, 'active_object')
        self.selection = context.selected_objects

        if event.shift:
            self.new_name = cam.name
            dpi_value = context.preferences.view.ui_scale
            return context.window_manager.invoke_props_dialog(self, width=int(dpi_value * 200))

        else:
            # save selection
            self.save_selection(context)

            context.space_data.camera = cam
            context.view_layer.objects.active = cam
            context.scene.camera = cam
            bpy.ops.view3d.object_as_camera()

            # Show children
            self.restore_selection(context)

            # Update UI
            EasyRef_Update_UI()

            context.space_data.lock_camera = not cam["Cam Lock"]

            return {'FINISHED'}

class EASYREF_OT_easyref_lock_cam_to_view(bpy.types.Operator):
    bl_idname = "easyref.lock_cam_to_view"
    bl_label = "Lock Camera To View"
    bl_description = "This will lock the camera transforms to the view"
    bl_options = {"REGISTER"}

    camref : StringProperty() # type: ignore

    def execute(self, context):
        cam = context.scene.objects.get(self.camref)
        context.space_data.lock_camera = not context.space_data.lock_camera

        cam["Lock cam to view"] = not cam["Lock cam to view"]
        return {"FINISHED"}

class EASYREF_OT_easyref_lock_camera_transforms(Freezer, bpy.types.Operator):
    bl_idname = "easyref.lock_camera_transforms"
    bl_label = "Lock Camera Transforms"
    bl_description = "This will lock the camera transforms to the view"
    bl_options = {"REGISTER"}

    camref : StringProperty() # type: ignore

    def execute(self, context):

        # Save Selection
        ob = getattr(bpy.context, 'active_object')
        self.save_selection(context)

        cam = context.scene.objects.get(self.camref)

        # Set Cam Active, visible, and look trough
        context.view_layer.objects.active = cam

        status = cam.lock_rotation[0]
        for i in range(3):
            cam.lock_rotation[i] = cam.lock_location[i] = cam.lock_scale[i] = not status
            context.space_data.lock_camera = not context.space_data.lock_camera


        cam["Cam Lock"] = not cam["Cam Lock"]

        # Make Text selectable
        for child in cam.children:
            if child.type == 'FONT':
                child.hide_select = status

        # Restore Selection
        self.restore_selection(context)


        return {"FINISHED"}

class EASYREF_OT_delete_camref( Freezer, bpy.types.Operator):
    bl_idname = "easyref.delete_camref"
    bl_label = "Delete Camera and References"
    bl_description = "This will delete the selected camera and all its references"
    bl_options = {"REGISTER"}

    camref : StringProperty() # type: ignore
    juste_empty : BoolProperty(default=False) # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        cam = context.scene.objects.get(self.camref)

        # Remove Empty
        for child in cam.children:
            bpy.data.objects.remove(child, do_unlink=True)

        bpy.data.objects.remove(cam, do_unlink=True)

        # Update UI
        EasyRef_Update_UI()
        return {"FINISHED"}

class EASYREF_OT_easyref_remove_all_camref(bpy.types.Operator):
    bl_idname = "easyref.remove_all_cam_ref"
    bl_label = "Delete All Cameras and References"
    bl_description = "This will delete all cameras and references from the scene"
    bl_options = {"REGISTER"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):

        camref_list = [cam for cam in context.scene.objects if "easyref" in cam]
        for cam in camref_list:
            for child in cam.children:
                bpy.data.objects.remove(child, do_unlink=True)

            # del cam
            bpy.data.objects.remove(cam, do_unlink=True)

        # Update UI
        EasyRef_Update_UI()

        bpy.ops.view3d.view_selected()
        return {"FINISHED"}

class EASYREF_OT_setup_for_focus(Freezer, bpy.types.Operator):
    bl_idname = "easyref.setup_for_focus"
    bl_label = "Camera Focus"
    bl_description = "Edit the focal of the view depending of the cursor position\n\nThis tool is made to fit the camera to the Reference"
    bl_options = {"REGISTER"}

    camref : StringProperty() # type: ignore

    def execute(self, context):
        cam = bpy.data.objects[self.camref]

        # save selection
        self.save_selection(context)

        context.space_data.camera = cam
        context.view_layer.objects.active = cam
        context.scene.camera = cam
        bpy.ops.view3d.object_as_camera()

        # Update UI
        EasyRef_Update_UI()

        bpy.context.space_data.lock_camera = not cam["Cam Lock"]

        bpy.ops.easyref.modal_focal('INVOKE_DEFAULT')

        return {"FINISHED"}

class EASYREF_OT_ortho_views(Operator):
    bl_idname = 'easyref.ortho_views'
    bl_label = ""
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    ortho_views : EnumProperty(
        items=(('front', "Front", ""),
               ('back', "Back", ""),
               ('left', "Left", ""),
               ('right', "Right", ""),
               ('top', "Top", ""),
               ('bottom', "Bottom", "")),
        default='front'
    ) # type: ignore

    camref : StringProperty() # type: ignore

    def execute(self, context):
        cam = context.scene.camera

        # Reset Cam transforms
        T = Matrix.Translation(Vector((0, 0, 0)))
        R = Matrix.Rotation(radians(0), 4, Vector((1, 0, 0)))
        S = Matrix.Scale(1, 4, (1, 1, 1))
        cam.matrix_world = T * R * S

        if self.ortho_views == 'front':

            # Front view
            T = Matrix.Translation(Vector((0, -10, 0)))
            R = Matrix.Rotation(radians(90), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))
            cam.matrix_world = T * R * S

        elif self.ortho_views == 'back':

            # Back view
            T = Matrix.Translation(Vector((0, 10, 0)))
            R = Matrix.Rotation(radians(180), 4, Vector((0, -1, -1)))
            S = Matrix.Scale(1, 4, (1, 1, 1))
            cam.matrix_world = T * R * S


        elif self.ortho_views == 'left':

            # left view
            T = Matrix.Translation(Vector((-10, 0, 0)))
            R = Matrix.Rotation(radians(90), 4, Vector((0, 0, -1)))
            R = R * Matrix.Rotation(radians(90), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))
            cam.matrix_world = T * R * S


        elif self.ortho_views == 'right':

            # Rigth view
            T = Matrix.Translation(Vector((10, 0, 0)))
            R = Matrix.Rotation(radians(90), 4, Vector((0, 0, 1)))
            R = R * Matrix.Rotation(radians(90), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))
            cam.matrix_world = T * R * S


        elif self.ortho_views == 'top':

            T = Matrix.Translation(Vector((0, 0, 10)))
            R = Matrix.Rotation(radians(0), 4, Vector((0, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))
            cam.matrix_world = T * R * S


        elif self.ortho_views == 'bottom':

            # Back view
            T = Matrix.Translation(Vector((0, 0, -10)))
            R = Matrix.Rotation(radians(180), 4, Vector((1, 0, 0)))
            S = Matrix.Scale(1, 4, (1, 1, 1))
            cam.matrix_world = T * R * S

        return {'FINISHED'}

class EASYREF_OT_delete_all_ref(Operator):
    bl_idname = "easyref.delete_all_refs"
    bl_label = "Delete All References"
    bl_description = "This will delete all references from the selected camera"
    bl_options = {"REGISTER"}

    camref : StringProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        WM = context.window_manager
        WM.modal_ON = False
        WM.annotations_ON = False

        cam = bpy.data.objects[self.camref]
        bg = cam.data.background_images
        for i in range(len(cam.data.background_images) -1, -1, -1):
            bg.remove(bg[i])

        cam.data.show_background_images = False
        cam.data.show_background_images = True
        EasyRef_Update_UI()

        return {"FINISHED"}

class EASYREF_OT_delete_ref(Operator):
    bl_idname = "easyref.delete_ref"
    bl_label = "Delete Reference"
    bl_description = "This will delete the selected reference from the selected camera"
    bl_options = {"REGISTER"}

    camref: StringProperty() # type: ignore
    index : IntProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        WM = context.window_manager
        WM.modal_ON = False
        WM.annotations_ON = False

        cam = bpy.data.objects[self.camref]

        bg = cam.data.background_images
        bg.remove(bg[self.index])

        cam.data.show_background_images = False
        cam.data.show_background_images = True
        EasyRef_Update_UI()
        return {"FINISHED"}

class EASYREF_OT_show_hide_background_images(Operator):
    bl_idname = "easyref.show_hide_background_images"
    bl_label = "Show/Hide Refererences"
    bl_description = "This will show/hide the selected reference from the selected camera"
    bl_options = {"REGISTER"}

    camref : StringProperty() # type: ignore

    def execute(self, context):
        cam = bpy.data.objects[self.camref]
        cam_prop = cam.easyref[0]

        cam.data.show_background_images = not cam.data.show_background_images
        cam_prop.showhide_background_images = not cam_prop.showhide_background_images

        EasyRef_Update_UI()
        return {"FINISHED"}
    
CLASSES =  [ImportFilesCollection,
            EASYREF_OT_images_refs_actions,
            EASYREF_OT_create_image_reference,
            EASYREF_OT_add_reference,
            EASYREF_OT_easyref_rename_camera,
            EASYREF_OT_easyref_lock_cam_to_view,
            EASYREF_OT_easyref_lock_camera_transforms,
            EASYREF_OT_delete_camref,
            EASYREF_OT_easyref_remove_all_camref,
            EASYREF_OT_setup_for_focus,
            EASYREF_OT_show_hide_background_images,
            EASYREF_OT_delete_all_ref,
            EASYREF_OT_delete_ref,
            EASYREF_OT_ortho_views,]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES:
    #     bpy.utils.unregister_class(cls)