# SPDX-FileCopyrightText: © 2022-2024 Wojciech Trybus <wojtryb@gmail.com>
# SPDX-License-Identifier: GPL-3.0-or-later

from .offset_grid_layout import OffsetGridLayout

__all__ = ["OffsetGridLayout"]
