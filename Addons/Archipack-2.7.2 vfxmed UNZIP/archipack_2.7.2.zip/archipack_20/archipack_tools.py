# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import Operator
from bpy.props import FloatProperty, BoolProperty, IntProperty
from math import sin, cos, pow, pi
from .bmesh_utils import BmeshEdit as bmed
from .archipack_abstraction import ensure_select_and_restore, context_override
from .archipack_object import ArchipackObjectsManager, ArchipackGenericOperator
from mathutils import Vector
from .archipack_polylines import Polygonizer

import logging
logger = logging.getLogger(__package__)


class ARCHIPACK_OT_center_to_world(Operator, ArchipackGenericOperator):
    bl_description = "Center selected objects to world"
    bl_idname = "archipack.center_to_world"
    bl_label = "Center to world"

    @classmethod
    def poll(cls, context):
        return context.selected_objects

    def bound_box(self, sel):
        x, y, z = list(zip(*[c.matrix_world @ Vector(p) for c in sel for p in c.bound_box]))
        mini, maxi = Vector((min(x), min(y), min(z))), Vector((max(x), max(y), max(z)))
        size = maxi - mini
        center = 0.5 * (mini + maxi)
        return mini, maxi, size, center

    def execute(self, context):
        sel = [c for c in context.selected_objects if c.parent is None]
        mini, maxi, size, center = self.bound_box(sel)
        x, y, z = -center
        for c in sel:
            c.matrix_world.translation += Vector((x, y, 0))
        return {'FINISHED'}


class ARCHIPACK_OT_merge_and_dissolve(Operator, ArchipackGenericOperator):
    bl_description = "Merge vertex by distance and limited dissolve"
    bl_idname = "archipack.merge_and_dissolve"
    bl_label = "Merge and dissolve"
    bl_options={'REGISTER', 'UNDO'}

    angle_limit: FloatProperty(
        name="Angle limit",
        description="Limited Dissolve angle limit",
        min=0.00001, max=pi,
        default=0.00174533,
        unit='ROTATION',
        subtype='ANGLE'
    )

    @classmethod
    def poll(cls, context):
        return context.selected_objects

    def execute(self, context):
        last_mode = context.mode
        if last_mode != "EDIT_MESH":
            bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.remove_doubles()
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.mesh.select_interior_faces()
        bpy.ops.mesh.delete(type='ONLY_FACE')
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.tris_convert_to_quads()
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.dissolve_limited(angle_limit=self.angle_limit, delimit={'NORMAL', 'MATERIAL'})
        if last_mode != "EDIT_MESH":
            bpy.ops.object.mode_set(mode="OBJECT")
        return {'FINISHED'}


class ARCHIPACK_OT_convert_all_to_tris(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.convert_all_to_tris"
    bl_label = "Triangulate"
    bl_description = "Triangulate mesh for visible objects"
    bl_options = {"REGISTER"}

    def execute(self, context):
        objects = self.get_scene_objects(context)
        for o in objects:
            if o.type == 'MESH' and o.visible_get():
                with ensure_select_and_restore(context, o, [o], object_mode='EDIT'):
                    bpy.ops.mesh.select_all(action="SELECT")
                    bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')

        return {'FINISHED'}


class ARCHIPACK_OT_symbol_2d(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.symbol_2d"
    bl_label = "2d symbol"
    bl_description = "Create 2d symbol for selected objects"
    bl_options = {"REGISTER"}

    evaluate: BoolProperty(name="Use modifiers", description="Evaluate modifiers", default=True)
    outlines: BoolProperty(
        name="Outlines (slow)",
        description="Output outlines only (for objects with less than 10k faces)",
        default=False
    )
    split: BoolProperty(
        name="Split (slow)",
        description="Split intersecting edges and optimize result (for objects with less than 10k faces)",
        default=False
    )
    sharp: BoolProperty(name="Sharp edges", description="Use only sharp edges of mesh", default=False)
    sharpness: FloatProperty(
        name="Angle",
        description="Min angle between faces for an edge to be considered",
        min=0, max=pi, default=0.523599,
        subtype='ANGLE', unit='ROTATION'
    )
    resolution: IntProperty(name="Resolution", description="Bezier curve evaluation steps", default=12, min=0, max=128)
    hierarchy: BoolProperty(name="Hierarchy", description="Include children objects")
    join: BoolProperty(name="Join", description="Generate a single symbol from many object", default=True)
    skip_backfaces: BoolProperty(
        name="Skip backfaces",
        description="Skip bakfaces edges, require correct normals",
        default=True
    )

    @classmethod
    def poll(cls, context):
        return context.selected_objects

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Input")
        box.prop(self, "evaluate")
        box.prop(self, "skip_backfaces")
        box.prop(self, "sharp")
        box.prop(self, "sharpness")
        box.prop(self, "resolution")
        box.prop(self, "hierarchy")

        box = layout.box()
        box.label(text="Output")
        box.prop(self, "join")
        box.prop(self, "outlines")
        box.prop(self, "split")

    def create(self, context, objects):
        o = objects[0]
        sharpness = 0
        if self.sharp:
            sharpness = self.sharpness
        io, geom = Polygonizer.object_to_symbol2d(
            context,
            objects,
            split=self.split,
            sharpness=sharpness,
            outlines=self.outlines,
            resolution=self.resolution,
            evaluate=self.evaluate,
            skip_backfaces=self.skip_backfaces,
        )
        curve_obj = io._to_curve(geom, "Symbol-{}".format(o.name), "2D")
        curve_obj.data.dimensions = '3D'
        self.link_object_to_scene(context, curve_obj, layer_name="2d")
        with context_override(context, o, [o, curve_obj]) as ctx:
            self.call_operator(context, ctx, bpy.ops.object.parent_set, {"keep_transform":True})

        self.select_object(context, curve_obj, True)

    def execute(self, context):
        objects = [o for o in context.selected_objects if o.type in {'MESH', 'CURVE'}]

        if self.hierarchy:
            names = set()
            def _filter(c):
                res = c.name not in names and c.type in {'MESH', 'CURVE'}
                names.add(c.name)
                return res
            sel = []
            for o in objects:
                self.rec_get_childrens(o, sel, filter=_filter)

            objects = sel


        if len(objects) < 1:
            self.report({'ERROR'}, "Select at least one mesh or curve object")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action="DESELECT")

        if self.join:
            self.create(context, objects)
        else:
            for o in objects:
                self.create(context, [o])

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class ARCHIPACK_OT_remove_vertex_colors(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.remove_vertex_colors"
    bl_label = "Remove vertex colors"
    bl_description = "Remove vertex colors for visible objects"
    bl_options = {"REGISTER"}

    def execute(self, context):
        objects = self.get_scene_objects(context)
        for o in objects:
            if o.type == 'MESH' and o.visible_get():
                vg = o.data.vertex_colors.get("Archipack")
                if vg:
                    o.data.vertex_colors.remove(vg)
        return {'FINISHED'}


class ARCHIPACK_OT_fix_hole_visibility(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.fix_hole_visibility"
    bl_label = "Hide holes"
    bl_description = "Hide holes from render engines"
    bl_options = {"REGISTER"}

    def execute(self, context):
        objects = self.get_scene_objects(context)
        for o in objects:
            if o.type == 'MESH':
                if self.has_flag(o, ('hole', 'custom_hole', 'hybridhole')):
                    self.hide_for_render_engines(o)
        return {'FINISHED'}


class ARCHIPACK_OT_apply_random_uv(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.apply_random_uv"
    bl_label = "Apply random uv"
    bl_description = "Apply random vertex colors to mesh uvs for visible objects"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def rotate_uv(a, u, v):
        ca = cos(a)
        sa = sin(a)
        return (ca * u) + (sa * v), (ca * v) - (sa * u)

    @staticmethod
    def translate_uv(u, v, du, dv):
        return u + du, v + dv

    @staticmethod
    def scale_uv(u, v, su, sv):
        return u * su, v * sv

    @staticmethod
    def has_random_uvs(o):
        for matid, slot in enumerate(o.material_slots):
            mat = slot.material
            if mat is not None and mat.use_nodes:
                nodes = mat.node_tree.nodes
                for node in nodes:
                    if node.type == "GROUP" and "Archipack Random UV" in node.node_tree.name:
                        return True
        return False

    def gamma_correct(self, gamma, r, g, b):
        rc = pow(r, gamma)
        gc = pow(g, gamma)
        bc = pow(b, gamma)
        return rc, gc, bc

    def apply(self, o):
        if self.has_random_uvs(o):
            bm = bmed._start(o)
            for matid, slot in enumerate(o.material_slots):
                mat = slot.material
                if mat is not None and mat.use_nodes:
                    tree = mat.node_tree
                    nodes = tree.nodes
                    n = None
                    # flag vertex colors output not linear due to internal gamma curve
                    is_not_linear = True
                    for node in nodes:
                        if node.type == "GROUP" and "Archipack Random UV" in node.node_tree.name:
                            n = node
                            for sub in n.node_tree.nodes:
                                if sub.type == 'GAMMA':
                                    is_not_linear = False
                                    break
                            break
                    if n is not None:
                        scale_u = n.inputs[0].default_value
                        scale_v = n.inputs[1].default_value
                        # use same factor than in node (approx 2 * pi)
                        rotation_uv = n.inputs[2].default_value / 360.0 * 6.28
                        random_rotation = n.inputs[3].default_value / 100.0 * 6.28
                        # disconnect uv output
                        for link in n.outputs[3].links:
                            tree.links.remove(link)
                        n.inputs[0].default_value = scale_u
                        vlay = bm.loops.layers.color.get("Archipack")
                        # Mimic Archipack Random UV group effect
                        if vlay is not None:
                            layer = bm.loops.layers.uv.verify()
                            for face in bm.faces:
                                if face.material_index == matid:
                                    for loop in face.loops:
                                        u, v = loop[layer].uv
                                        r, g, b, a = loop[vlay]
                                        # Vertex colors are gamma corrected in shader to get linear result
                                        if is_not_linear:
                                            r, g, b = self.gamma_correct(2.2, r, g, b)
                                        u, v = self.rotate_uv(rotation_uv, u, v)
                                        u, v = self.translate_uv(u, v, g / scale_u, b / scale_v)
                                        u, v = u * scale_u, v * scale_v
                                        u, v = self.rotate_uv(random_rotation * r, u, v)
                                        # print("rotate_uv", u, v, random_rotation * r)
                                        loop[layer].uv = (u, v)
                                        # keep vertex colors
                                        # loop[vlay] = (r, 0, 0, 1)
            bmed._end(bm, o)

    def execute(self, context):

        objects = self.get_scene_objects(context)
        for o in objects:
            if o.type == 'MESH' and o.visible_get():
                self.apply(o)

        return {'FINISHED'}


import blf
from bpy_extras import view3d_utils
from mathutils import Vector
from math import atan, degrees


class ARCHIPACK_OT_slope_overlay(Operator):

    bl_idname = "archipack.slope_overlay"
    bl_label = "Slope"
    bl_description = "Display edges slopes as overlay"
    bl_options = {'REGISTER'}

    _draw_handler = None
    colour = (0, 0, 0, 1)
    font_size = 16

    def position_2d_from_coord(self, context, coord):
        """ coord given in local input coordsys
        """
        region = context.region
        rv3d = context.region_data
        if bpy.app.version >= (3, 0, 0):
            loc = view3d_utils.location_3d_to_region_2d(region, rv3d, coord)
        else:
            loc = view3d_utils.location_3d_to_region_2d(region, rv3d, coord, None)
        return loc

    def draw_text(self, context, slopes):
        for loc, angle in slopes.items():
            p = self.position_2d_from_coord(context, Vector(loc))
            if p is None:
                return
            p = Vector(p)
            # dirty fast assignment
            dpi, font_id = context.preferences.system.dpi, 0
            blf.color(0, *self.colour)
            blf.size(font_id, self.font_size, dpi)
            blf.position(font_id, p.x, p.y, 0)
            blf.draw(font_id, angle)

    def modal(self, context, event):
        if event.type in ('ESC', 'RIGHTMOUSE'):
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
            return {'FINISHED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':

            o = context.active_object
            if o.type != "MESH":
                self.report({'WARNING'}, "Active object must be a mesh")
                return {'CANCELLED'}

            slopes = {}
            bm = bmed._start(o)
            tM = o.matrix_world
            for ed in bm.edges:
                if ed.calc_length() > 0.0001:
                    dp = ed.verts[1].co - ed.verts[0].co
                    percent = abs(dp.z) / dp.to_2d().length
                    angle = degrees(atan(percent))
                    slopes[tuple(tM @ (ed.verts[0].co + 0.5 * dp))] =\
                        "%s° - %s%%" % (round(angle, 1), round(100.0 * percent, 1))

            bm.free()

            args = (context, slopes,)
            self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(self.draw_text, args, 'WINDOW',
                                                                            'POST_PIXEL')
            wm = context.window_manager
            wm.modal_handler_add(self)

            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'FINISHED'}


def register():
    bpy.utils.register_class(ARCHIPACK_OT_apply_random_uv)
    bpy.utils.register_class(ARCHIPACK_OT_convert_all_to_tris)
    bpy.utils.register_class(ARCHIPACK_OT_remove_vertex_colors)
    bpy.utils.register_class(ARCHIPACK_OT_slope_overlay)
    bpy.utils.register_class(ARCHIPACK_OT_center_to_world)
    bpy.utils.register_class(ARCHIPACK_OT_symbol_2d)
    bpy.utils.register_class(ARCHIPACK_OT_merge_and_dissolve)
    bpy.utils.register_class(ARCHIPACK_OT_fix_hole_visibility)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_OT_apply_random_uv)
    bpy.utils.unregister_class(ARCHIPACK_OT_convert_all_to_tris)
    bpy.utils.unregister_class(ARCHIPACK_OT_remove_vertex_colors)
    bpy.utils.unregister_class(ARCHIPACK_OT_slope_overlay)
    bpy.utils.unregister_class(ARCHIPACK_OT_symbol_2d)
    bpy.utils.unregister_class(ARCHIPACK_OT_center_to_world)
    bpy.utils.unregister_class(ARCHIPACK_OT_merge_and_dissolve)
    bpy.utils.unregister_class(ARCHIPACK_OT_fix_hole_visibility)