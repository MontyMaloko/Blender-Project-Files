# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, UIList
from bpy.props import (
    FloatProperty, BoolProperty, IntProperty, CollectionProperty,
    StringProperty, EnumProperty, FloatVectorProperty, IntVectorProperty, BoolVectorProperty,
    PointerProperty
)
from bpy.app.handlers import persistent, save_pre
from .bmesh_utils import BmeshEdit as bmed

from .panel import Panel as Lofter
from mathutils import Vector, Matrix
from math import sin, cos, pi, acos, asin, floor, ceil, sqrt, degrees, tan, atan, atan2
from random import uniform, sample, seed, choice
from .archipack_manipulator import (
    Manipulable, archipack_manipulator, FeedbackPanel
)
from .archipack_abstraction import context_override, X_AXIS
from .archipack_generator import Generator, Line, Arc
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackCreateTool,
    ArchipackObject,
    ArchipackPanel,
    ArchipackDrawTool
)
from .archipack_dimension import DimensionProvider
from .archipack_curveman import ArchipackProfile, ArchipackUserDefinedPath
from .archipack_segments2 import ArchipackSegment
from .archipack_material import build_mat_enum
from .archipack_prefs import get_prefs
from .archipack_keymaps import Keymaps
from .archipack_jsonio import to_dict
from .archipack_iconmanager import icons
# from .archipack_throttle import throttle

from .archipack_snap import (
    snap_point,
    SUCCESS,
    CANCEL,
    FREEMOVE,
    CREATE,
    STARTING,
    RESTART,
    MANIPULATE
)


from time import time
import logging

logger = logging.getLogger(__package__)


MAT_RAIL = 0

material_enums = []
mat_enum, mat_index_getter, mat_index_setter= build_mat_enum('idmat', material_enums)


def build_geometry_enum(attr, geometry_enums):

    def build_enum(self, context):

        # Ui only show for active object so this is OK
        if context is None:
            return geometry_enums

        o = context.active_object
        d = archipack_array.datablock(o)

        if d is None:
            return geometry_enums

        # print("build_enum", o.name, id(self))

        geometry_enums.clear()
        geometry_enums.extend([
            (str(i), slot.name, slot.name)
            for i, slot in enumerate(d.geometrys)
        ])

        defined = {i for i, j, k in geometry_enums}
        # provide "Missing material" Enum for missing slots
        n_mats = len(geometry_enums) - 1

        if hasattr(self, attr):
            prop = getattr(self, attr)
            for index in prop:
                if str(index) not in defined and index > n_mats:
                    defined.add(str(index))
                    geometry_enums.append((str(index), "Missing", "Missing geometry"))

        return geometry_enums

    def geometry_getter(index):
        def getter(self):
            val = getattr(self, attr)[index]
            if val < len(geometry_enums):
                return val
            return 0

        return getter

    def geometry_setter(index):
        def setter(self, value):
            getattr(self, attr)[index] = value
            return None

        return setter

    return build_enum, geometry_getter, geometry_setter


geometry_enums = []
gen_enums, geometry_getter, geometry_setter = build_geometry_enum('geometry_id', geometry_enums)


"""
def convert(d):
    d.auto_update = False
    for i, p in enumerate(d.rules):
        print(i, p.rule_uid, p.parent, p.index)
    tree = {p.rule_uid: [c for c in d.rules if c.parent == p.index] for p in d.rules}
    print({p.rule_uid: [c.rule_uid for c in d.rules if c.parent == p.index] for p in d.rules})
    for uid, childs in tree.items():
        for c in childs: 
            c.parent = uid
    print({p.rule_uid: [c.parent for c in d.rules if c.parent == p.rule_uid] for p in d.rules})
    d.auto_update = True

d = C.object.data.archipack_array[0]
convert(d)


"""

adaptive_width_enums = []
def adaptive_width_enum(self, context):
    global adaptive_width_enums
    _icons = icons["main"]
    if len(adaptive_width_enums) < 1:
        adaptive_width_enums.extend([
            ('NONE', 'Disabled', '', 'NONE', 0),
            ('X', 'x', 'Scale on x axis', _icons["adapt_x"].icon_id, 1),
            ('XY', 'x and y', 'Scale on xy axis', _icons["adapt_xy"].icon_id, 2),
            ('XYZ', 'xyz', 'Scale in 3d', _icons["adapt_xyz"].icon_id, 3)
        ])
    return adaptive_width_enums



X_AXIS = Vector((1, 0, 0))
Y_AXIS = Vector((0, 1, 0))
Z_AXIS = Vector((0, 0, 1))

# curves indexes
CURVE_PATH = 0
CURVE_GROT = 1
CURVE_GSCA = 2
CURVE_GMOV = 3
CURVE_LERP = 0


class _IntervalNode(object):

    __slots__ = ('index', 'mini', 'maxi')

    def __str__(self):
        return "{} - {} {}".format(self.index, self.mini, self.maxi)

    def __init__(self, index, mini, maxi):
        self.index = index
        self.mini = mini
        self.maxi = maxi


tree_fmt = """depth: {}
nodes: 
{}
children: 
{}"""


class _IntervalTree(object):
    """
    Internal backend version of the index.
    The index being used behind the scenes. Has all the same methods as the user
    index, but requires more technical arguments when initiating it than the
    user-friendly version.
    """
    __slots__ = ('nodes', 'children', 'center', 'size', 'max_items', 'max_depth', '_depth')

    def __str__(self):
        return tree_fmt.format(
            self._depth,
            "\n".join([str(n) for n in self.nodes]),
            "\n".join([str(n) for n in self.children])
        )

    def __init__(self, center, size, max_items, max_depth, _depth=0):
        self.nodes = []
        self.children = []
        self.center = center
        self.size = size
        self.max_items = max_items
        self.max_depth = max_depth
        self._depth = _depth

    def insert(self, index, mini, maxi):
        if len(self.children) == 0:
            node = _IntervalNode(index, mini, maxi)
            self.nodes.append(node)
            if len(self.nodes) > self.max_items and self._depth < self.max_depth:
                self._split()
        else:
            self._insert_into_children(index, mini, maxi)

    def intersect(self, x):
        """Intersect, when 0 use current segment
        :param x:
        :param last: last segment
        :return:
        """
        # search children
        if self.children:
            if x <= self.center:
                res = self.children[0].intersect(x)
                if res > -1:
                    return res
            if x >= self.center:
                res = self.children[1].intersect(x)
                if res > -1:
                    return res

        # search node at this level
        for node in self.nodes:
            if node.mini <= x < node.maxi:
                return node.index

        return -1

    def intersect_inclusive(self, x):
        """Intersect, when 0 or x_max use current segment
        :param x:
        :param last: last segment
        :return:
        """
        # search children
        if self.children:
            if x <= self.center:
                res = self.children[0].intersect_inclusive(x)
                if res > -1:
                    return res
            if x >= self.center:
                res = self.children[1].intersect_inclusive(x)
                if res > -1:
                    return res

        # search node at this level
        for node in self.nodes:
            if x >= node.mini and x <= node.maxi:
                return node.index

        return -1

    def intersect_last(self, x):
        """Intersect, when 0 use last segment
        :param x:
        :param last: last segment
        :return:
        """
        # search children
        if self.children:
            if x <= self.center:
                res = self.children[0].intersect_last(x)
                if res > -1:
                    return res
            if x >= self.center:
                res = self.children[1].intersect_last(x)
                if res > -1:
                    return res

        for node in self.nodes:
            if x > node.mini and x <= node.maxi:
                return node.index

        return -1

    def _insert_into_children(self, index, mini, maxi):
        # if interval spans center then insert here
        if mini < self.center and maxi > self.center:
            node = _IntervalNode(index, mini, maxi)
            self.nodes.append(node)
        else:
            # try to insert into children
            if maxi <= self.center:
                self.children[0].insert(index, mini, maxi)
            else:
                self.children[1].insert(index, mini, maxi)

    def _split(self):
        quartsize = self.size / 4.0
        halfsize = self.size / 2.0
        x1 = self.center - quartsize
        x2 = self.center + quartsize
        new_depth = self._depth + 1
        self.children = [
            _IntervalTree(x1, halfsize, self.max_items, self.max_depth, new_depth),
            _IntervalTree(x2, halfsize, self.max_items, self.max_depth, new_depth)
        ]
        nodes = self.nodes[:]
        self.nodes.clear()
        for node in nodes:
            self._insert_into_children(node.index, node.mini, node.maxi)


class Rule:

    def curve(self, p):
        c = p.curves[CURVE_PATH]
        return c.use_curve, c

    def eval_curve(self, p, d, ds, di, dj, nr):
        use_curve, c = self.curve(p)
        if use_curve:
            res = [ds + c.eval_curve(3, d, x) for x in
                   [di * i for i in range(nr)]]
        else:
            res = [ds + di * i for i in range(nr)]
        return res
    
    def is_cyclic(self, it, d):
        return it.closed and (d[-1][-1] - d[0][0]) == it.d_max

    def clamp(self, res, d0, d1):
        return [max(d0, min(d1, _d)) for _d in res]

    def compute(self, it, d, p):
        raise NotImplementedError


class SelectRule(Rule):
    """Select spaces / axis
    """
    def __init__(self):
        Rule.__init__(self)

    def select_sub(self, p, sub, res0, res1):
        """ Select subs
        :param p: 
        :param sub: 
        :param res0: 
        :param res1: 
        :return: void
        """
        print(self.__class__.__name__)
        raise NotImplementedError


class SelectRandomSpace(SelectRule):
    def __init__(self):
        SelectRule.__init__(self)
        
    def compute(self, it, d, p):
        # select spaces
        n = len(d)
        selected = set(sample(range(n), k=floor(n * p.percent / 100)))
        res0 = [sub for i, sub in enumerate(d) if i in selected]
        res1 = [sub for i, sub in enumerate(d) if i not in selected]
        return res0, res1


class SelectRandomAxis(SelectRule):
    def __init__(self):
        SelectRule.__init__(self)

    def select_sub(self, p, sub, res0, res1):
        n = len(sub)
        r_n = range(n)
        selected = set(sample(r_n, k=floor(n * p.percent / 100)))
        res0.append([sub[i] for i in r_n if i in selected])
        res1.append([sub[i] for i in r_n if i not in selected])
        
    def compute(self, it, d, p):
        res0, res1 = [], []
        for sub in d:
            self.select_sub(p, sub, res0, res1)
        return res0, res1


class SelectFirstLastSpace(SelectRule):
    def __init__(self):
        SelectRule.__init__(self)

    def compute(self, it, d, p):
        res0, res1 = [], []
        # select spaces
        if len(d) < 3:
            res0 = d
        else:
            n = len(d)
            start = min(n, p.n_start)
            end = max(start, n - p.n_end)
            res0 = [d[i] for i in range(start)] + [d[i] for i in range(end, n)]
            res1 = [sub for i, sub in enumerate(d[start:end])]
        return res0, res1


class SelectFirstLastAxis(SelectRule):
    def __init__(self):
        SelectRule.__init__(self)

    def select_sub(self, p, sub, res0, res1):
        n = len(sub)
        if n < 3:
            res0.append(sub)
        else:
            start = min(n, p.n_start)
            end = max(start, n - p.n_end)
            r_n = range(start, end)
            res0.append([sub[i] for i in range(start)])
            res0.append([sub[i] for i in range(end, n)])
            res1.append([sub[i] for i in r_n])
            
    def compute(self, it, d, p):
        res0, res1 = [], []
        for sub in d:
            self.select_sub(p, sub, res0, res1)
        return res0, res1


class SelectEverySpace(SelectRule):

    def __init__(self):
        SelectRule.__init__(self)

    def compute(self, it, d, p):
        offset = -p.n_offset
        res0 = [sub for i, sub in enumerate(d) if ((i + offset) % p.every) == 0]
        res1 = [sub for i, sub in enumerate(d) if ((i + offset) % p.every) != 0]
        return res0, res1


class SelectEveryAxis(SelectRule):

    def __init__(self):
        SelectRule.__init__(self)

    def compute(self, it, d, p):
        offset = -p.n_offset

        # sub axis
        res0 = [[sub[i] for sub in d for i in range(len(sub)) if ((i + offset) % p.every) == 0]]
        res1 = [[sub[i] for sub in d for i in range(len(sub)) if ((i + offset) % p.every) != 0]]

        # select when axis cross end point
        if self.is_cyclic(it, d) and len(res0[0]) > 0:
            res0[0].append(it.d_max + res0[0][0])

        return res0, res1


class SplitRule(SelectRule):
    """Generate sub spaces
    """
    def __init__(self):
        SelectRule.__init__(self)
    
    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        print(self.__class__.__name__)
        raise NotImplementedError

    def pattern(self, p, d, d0, d1, ds, di, dj, nr):
        print(self.__class__.__name__)
        raise NotImplementedError
    
    def compute_space(self, p, d0, d1):
        offset, start, end, space = p.sides, p.start, p.end, p.space
        ds, de = d0 + offset + start, d1 - offset - end
        d = de - ds
        n = floor(d / space)
        nr = n + 1
        return self.compute_pattern(p, d0, d1, ds, de, d, n, nr, start, end, space, offset)

    def eval_curve(self, p, d, ds, di, dj, nr):
        use_curve, c = self.curve(p)
        if use_curve:
            res = [
                ds + c.eval_curve(3, d, x) for x in [
                    di * i + dj * j 
                    for i in range(nr) 
                    for j in range(-1, 2, 2)
                ]
            ]
        else:
            res = [
                ds + di * i + dj * j 
                for i in range(nr) 
                for j in range(-1, 2, 2)
            ]
        return res

    def filter(self, res, d0, d1):

        if len(res) > 1:
            # even gap / odd space
            res.pop(0)
            res.pop()

        # clamp to limits ???
        res.sort()
        return self.clamp(res, d0, d1)


class SplitSideRule(SplitRule):
    def __init__(self):
        SplitRule.__init__(self)
    
    def select_sub(self, p, sub, res0, res1):
        # side -> select even / odd
        if len(sub) > 0:
            for i, _d in enumerate(sub[1:]):
                _r = self.compute_space(p, sub[i], _d)
                res0.extend([_r[i:i + 2] for i in range(0, len(_r) - 1, 2)])
                res1.extend([_r[i:i + 2] for i in range(1, len(_r) - 1, 2)])
    
    def pattern(self, p, d, d0, d1, ds, di, dj, nr):
        """Generate pattern
        :return:
        """
        res = self.eval_curve(p, d, ds, di, dj, nr)
        res = self.filter(res, d0, d1)
        return self.add_sides(res, d0, d1)
    
    def add_sides(self, res, d0, d1):
        # Add start and end for sides
        res.insert(0, d0)
        res.append(d1)
        return res
    
    def compute(self, it, d, p):
        res0, res1 = [], []
        for sub in d:
            self.select_sub(p, sub, res0, res1)
        return res0, res1


class SplitCornerRule(SplitRule):
    def __init__(self):
        SplitRule.__init__(self)
    
    def add_corners(self, it, d, p, res):
        # add start and end on first and last
        for sub in d:
            if len(sub) > 0:
                res.insert(0, sub[0])
                break
        for sub in reversed(d):
            if len(sub) > 0:
                res.append(sub[-1])
                break

    def close(self, it, d, p, res):
        return

    def select(self, res):
        # even odd rule
        return \
            [res[i:i + 2] for i in range(0, len(res) - 1, 2)], \
            [res[i:i + 2] for i in range(1, len(res) - 1, 2)]

    def pattern(self, p, d, d0, d1, ds, di, dj, nr):
        res = self.eval_curve(p, d, ds, di, dj, nr)
        return self.filter(res, d0, d1)
    
    def compute(self, it, d, p):
        # corners only
        res = []
        for sub in d:
            if len(sub) > 0:
                for i, _d in enumerate(sub[1:]):
                    res.extend(self.compute_space(p, sub[i], _d))
        
        # single gap use different rule than multiple gaps
        self.add_corners(it, d, p, res)
        self.close(it, d, p, res)
        return self.select(res)
        

class GapFixed:
    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        if ds > de:
            return [d0, d1]
        #
        di = d + 2 * offset
        dj = offset
        nr = 2
        ds = d0 + start
        return self.pattern(p, d, d0, d1, ds, di, dj, nr)


class SplitSideGapFixed(GapFixed, SplitSideRule):

    def __init__(self):
        SplitSideRule.__init__(self)


class SplitCornerGapFixed(GapFixed, SplitCornerRule):

    def __init__(self):
        SplitCornerRule.__init__(self)

    def close(self, it, d, p, res):
        # only apply on single space between corners
        # add start and end on first and last
        if it.closed and len(res) > 0:
            # res is a flat array
            # print("res before", res)
            last = res.pop()
            res.insert(0, last)
            # print("res after", res)


class GapAdaptive:
    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        if n < 1:
            return [d0, d1]
        di = space - (start + end)
        offset = min(0.5 * di, offset)
        dj = offset
        nr = 2
        ds = d0 + 0.5 * (d1 - d0 - space) + start
        return self.pattern(p, d, d0, d1, ds, di, dj, nr)


class SplitSideGapAdaptive(GapAdaptive, SplitSideRule):

    def __init__(self):
        SplitSideRule.__init__(self)


class SplitCornerGapAdaptive(GapAdaptive, SplitCornerRule):

    def __init__(self):
        SplitCornerRule.__init__(self)

    def close(self, it, d, p, res):
        # only apply on single space between corners
        # add start and end on first and last
        if it.closed and len(res) > 0:
            # res is a flat array
            # print("res before", res)
            last = res.pop()
            res.insert(0, last)
            # print("res after", res)


class GapsFixed:

    def compute_space(self, p, d0, d1):
        offset, start, end, space = p.sides, p.start, p.end, p.space
        ds, de = d0 + start, d1 - end
        d = de - ds
        n = floor(d / space)
        nr = n + 1
        return self.compute_pattern(p, d0, d1, ds, de, d, n, nr, start, end, space, offset)

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        # fixed border (until 0) fixed items adaptive gaps
        if n < 0:
            return [d0, d1]

        n = max(0, n)
        nr = n + 1
        if n > 1:
            dt = (d - n * space) / (n - 1)
        else:
            ds += 0.5 * (d - space)
            dt = 0
        di = space + dt
        offset = max(-0.5 * dt, min(0.5 * space, offset))
        dj = 0.5 * dt + offset
        ds -= dj - offset
        return self.pattern(p, d, d0, d1, ds, di, dj, nr)


class SplitSideGapsFixed(GapsFixed, SplitSideRule):
    # (Split) gaps adaptive / spaces absolute
    def __init__(self):
        SplitSideRule.__init__(self)


class SplitCornerGapsFixed(GapsFixed, SplitCornerRule):

    def __init__(self):
        SplitCornerRule.__init__(self)


class GapsAdaptive:

    def compute_space(self, p, d0, d1):
        offset, start, end, space = p.sides, p.start, p.end, p.space
        ds, de = d0 + start, d1 - end
        d = de - ds
        n = floor(d / space)
        nr = n + 1
        return self.compute_pattern(p, d0, d1, ds, de, d, n, nr, start, end, space, offset)

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        if n < 1:
            return [d0, d1]

        offset = min(0.5 * space, offset)
        # limit space
        space = min(d / n, space - 2 * offset)
        dt = (d - n * space) / (n + 1)
        di = space + dt
        dj = 0.5 * dt
        ds += 0.5 * dt
        return self.pattern(p, d, d0, d1, ds, di, dj, nr)


class SplitSideGapsAdaptive(GapsAdaptive, SplitSideRule):
    # (Split) sides and gaps adaptive / spaces absolute
    def __init__(self):
        SplitSideRule.__init__(self)


class SplitCornerGapsAdaptive(GapsAdaptive, SplitCornerRule):
    # (Split) corner and gaps adaptive / spaces absolute
    def __init__(self):
        SplitCornerRule.__init__(self)


class GapsFlexible:
    def compute_space(self, p, d0, d1):
        offset, start, end, space = p.sides, p.start, p.end, p.space
        ds, de = d0 + start, d1 - end
        d = de - ds
        n = floor(d / space)
        nr = n + 1
        return self.compute_pattern(p, d0, d1, ds, de, d, n, nr, start, end, space, offset)

    # def pattern(self, p, d, d0, d1, ds, di, dj, nr):
    #     """Generate pattern
    #     :return:
    #     """
    #     res = self.eval_curve(p, d, ds, di, dj, nr)
    #     res = self.filter(res, d0, d1)
    #     return self.add_sides(res, d0, d1)

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        if n > 0:
            di = d / n
            return self.pattern(p, d, d0, d1, ds, di, 0, nr)
        else:
            return []

    def eval_curve(self, p, d, ds, di, dj, nr):
        use_curve, c = self.curve(p)
        if use_curve:
            res = [
                ds + c.eval_curve(3, d, x) for x in
                [di * i for i in range(nr)]
            ]
        else:
            res = [ds + di * i for i in range(nr)]
        return res


class SplitCornerGapsFlexible(GapsFlexible, SplitCornerRule):
    
    def __init__(self):
        SplitCornerRule.__init__(self)

    def select(self, res):
        # corners / spaces
        res0, res1 = [], []
        n = len(res)
        if n > 2:
            res0, res1 = \
                [res[0:2], res[-2:n]], \
                [res[i:i + 2] for i in range(1, n - 2)]
        elif n > 1:
            res0, res1 = \
                [res[0:2], res[-2:n]], \
                []
        return res0, res1


class SplitSideGapsFlexible(GapsFlexible, SplitSideRule):

    def __init__(self):
        SplitSideRule.__init__(self)

    def select_sub(self, p, sub, res0, res1):
        if len(sub) > 0:
            for i, _d in enumerate(sub[1:]):
                _r = self.compute_space(p, sub[i], _d)
                n = len(_r)
                if n > 2:
                    res0.extend([_r[0:2], _r[-2:n]])
                    res1.extend([_r[i:i + 2] for i in range(1, n - 2)])
                elif n > 1:
                    res0.extend([_r[0:2]])


class SpaceBetweenAxis(Rule):
    
    def compute(self, it, d, p):
        res = [
            [sub[i], _d]
            for sub in d
            for i, _d in enumerate(sub[1:])
            if len(sub) > 1
        ]
        return res, res


class SplitByAngle(SplitRule):
    
    def compute(self, it, d, p):
        res = it.by_angle(d, p.angle_limit)
        return res, res
    
    
class SubdivideSpace(Rule):
    
    def compute(self, it, d, p):
        n = p.n_sub
        res = []
        for i, _d in enumerate(d[1:]):
            d0 = d[i]
            dj = (_d - d0) / n
            for j in range(n + 1):
                res.append(d0 + dj * j)
        return res, res


class InterpolateRule(Rule):

    def filter_input(self, it, d, p):
        return d

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        raise NotImplementedError

    def compute_space(self, p, d0, d1):
        offset, start, end, space = p.sides, p.start, p.end, p.space
        ds, de = d0 + offset + start, d1 - offset - end
        d = de - ds
        n = floor(d / space)
        nr = n + 1
        return self.compute_pattern(p, d0, d1, ds, de, d, n, nr, start, end, space, offset)

    def pattern(self, p, d, d0, d1, ds, di, dj, nr):
        if nr < 1:
            return []
        res = self.eval_curve(p, d, ds, di, dj, nr)
        if p.clamp:
            return self.clamp(res, d0, d1)
        return res

    def compute(self, it, d, p):
        # input filtering eg to remove empty spaces
        df = self.filter_input(it, d, p)

        res = [[]]
        if len(df) > 0:
            res = [
                self.clamp(
                    self.compute_space(p, sub[i], _d),
                    0,
                    it.d_max
                )
                for sub in df
                for i, _d in enumerate(sub[1:])
                if len(sub) > 0
            ]
        return res, res


class AxisBlueNoise(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        if n > 0:
            return self.pattern(p, d, d0, d1, ds, 0, 0, nr)
        else:
            return []

    def eval_curve(self, p, d, ds, di, dj, nr):
        use_curve, c = self.curve(p)
        res = []
        p0 = 0
        while p0 < d:
            res.append(p0)
            p0 += uniform(1, 2) * p.space

        if len(res) > 0:
            ds += 0.5 * (d - res[-1])
            if use_curve:
                res = [ds + c.eval_curve(3, d, x) for x in res]
            else:
                res = [ds + x for x in res]

        return res


class AxisSubdivide(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        di = d / p.n_sub
        nr = p.n_sub + 1
        return self.pattern(p, d, d0, d1, ds, di, 0, nr)


class AxisItemsOnBothSides(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        nr = 2
        di = d
        if d > 0:
            return self.pattern(p, d, d0, d1, ds, di, 0, nr)
        else:
            return []


class AxisAdaptiveSpace(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        # Adaptive space with items at start and end when possible
        if n > 0:
            nr = max(2, n + 1)
            di = d / n
            return self.pattern(p, d, d0, d1, ds, di, 0, nr)
        else:
            return []


class AxisAdaptiveSpaceSideHalf(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        # Adaptive space with half space at start and end
        # when n=1 ->  |   1   |
        # when n=2 ->  | 1   2 |
        if n > 0:
            nr = n
            di = d / n
            ds += 0.5 * di
            return self.pattern(p, d, d0, d1, ds, di, 0, nr)
        else:
            return []


class AxisAdaptiveSpaceSideSpace(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        # Adaptive space with space at start and end
        # when n=2 ->  |     1     |
        # when n=3 ->  |   1   2   |
        if n > 1:
            nr = n - 1
            di = d / n
            ds += di
            return self.pattern(p, d, d0, d1, ds, di, 0, nr)
        else:
            return []


class AxisFixedSpaceSideAdaptive(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        # Fixed space with adaptive space at start and end
        # when n=1 ->   | x   x |
        # when n=2 ->   | x x x |
        if n > 0:
            nr = n + 1
            dd = d - n * p.space
            di = (d - dd) / n
            ds += 0.5 * dd
            return self.pattern(p, d, d0, d1, ds, di, 0, nr)
        else:
            return []


class AxisCenteredItem(InterpolateRule):

    def compute_pattern(self, p, d0, d1, ds, de, d, n, nr, start, end, space, offset):
        # Centered item
        nr = 1
        di = d
        ds += 0.5 * d
        return self.pattern(p, d, d0, d1, ds, di, 0, nr)

    def filter_input(self, it, d, p):
        return it.filter_empty_space(d)


class Interpolator:
    def __init__(self, g, dimension="2D"):
        self.closed = g.closed
        self.s = list(range(len(g.line.segs)))
        pos3d = [_k.p3d for _k in g.line.segs]
        if dimension == "3D":
            pos = pos3d
        else:
            pos = [_k._p0 for _k in g.line.segs]

        if g.closed:
            self.s.append(0)
            pos.append(pos[0])
            pos3d.append(pos3d[0])

        d = [0]
        l = [(p - pos[i]).length for i, p in enumerate(pos[1:])]
        for i, _l in enumerate(l):
            d.append(d[i] + _l)
        l.append(1)
        # binary search of segment index based on d
        # as numpy does unwanted sorting on interpolate and unique
        self.tree = _IntervalTree(0.5 * d[-1], d[-1], 2, 50, _depth=0)
        for i, _d in enumerate(d[1:]):
            self.tree.insert(self.s[i], d[i], _d)
        # print(self.tree)
        self.d_max = d[-1]
        self.l = l
        self.d = d
        self.p = pos3d   # np.array(pos3d)

    def set_pos(self, segs):
        # self.p = np.array([_k.p3d for _k in segs])
        self.p = [_k.p3d for _k in segs]

    def _split_by_angle(self, p, d, angle_limit):
        v = [(p[i] - _p).normalized() for i, _p in enumerate(p[1:])]
        da = [acos(min(1, max(0, v[i].dot(_v)))) for i, _v in enumerate(v[1:])]
        # v = p[1:] - p[:-1]
        # v_norm = (v.T / np.linalg.norm(v, axis=1)).T
        # da = np.arccos(np.clip(np.sum(v_norm[:-1] * v_norm[1:], axis=1), -1.0, 1.0))
        return [d[0]] + [d[i + 1] for i, a in enumerate(da) if a > angle_limit] + [d[-1]]

    def split_by_angle(self, angle_limit):
        return [self._split_by_angle(self.p, self.d, angle_limit)]

    def by_angle(self, d, angle_limit):
        return [self._split_by_angle(self.pts(_d), _d, angle_limit) for _d in self.intersect(d)]

    def _interpolate(self, d0: float, d1: float, p):
        # default to adaptive space with items at start and end when possible
        offset, start, end = p.sides, p.start, p.end
        ds, de = d0 + offset + start, d1 - offset - end
        d = de - ds
        # how much full spaces are available
        # | 1 | 2 |
        n = floor(d / p.space)
        nr = 0
        # at this point n could be 0, this is fine for axis
        if "blue_noise" in p.rule:
            if n > 5000:
                return []
            c = p.curves[CURVE_PATH]
            pts = []

            if c.use_curve:
                p0 = ds
                while p0 < d:
                    pts.append(p0)
                    p0 += uniform(1, 2) * p.space
                pts.pop()
                pts.append(d)
                return [ds + c.eval_curve(3, d, x) for x in pts]
            else:
                p0 = ds
                while p0 < de:
                    pts.append(p0)
                    p0 += uniform(1, 2) * p.space
                pts.pop()
                pts.append(de)
                return pts

        elif "subdivide" in p.rule:
            dt = d / p.n_sub
            nr = p.n_sub + 1

        elif "space" in p.rule:
            # Adaptive space with items at start and end
            # always ->  |1     2|
            nr = 2
            dt = d
        elif "boundary" in p.rule:
            # Adaptive space with items at start and end
            # when n=0 ->  |1     2|
            # when n=1 ->  |1     2|
            # when n=2 ->  |1  2  3|
            nr = max(2, n + 1)
            if n > 0:
                dt = d / n
            else:
                dt = d
        elif "border" in p.rule:
            # Adaptive space with items at start and end when possible
            # when n=1 ->  |1     2|
            # when n=2 ->  |1  2  3|
            if n > 0:
                nr = max(2, n + 1)
                dt = d / n
        elif "half_axis" in p.rule:
            # Adaptive space with half space at start and end
            # when n=1 ->  |   1   |
            # when n=2 ->  | 1   2 |
            if n > 0:
                nr = n
                dt = d / n
                ds += 0.5 * dt
        elif "centered_item" in p.rule:
            # Single item on axis
            nr = 1
            dt = d
            ds += 0.5 * d
        elif "axis" in p.rule:
            # Adaptive space with space at start and end
            # when n=2 ->  |     1     |
            # when n=3 ->  |   1   2   |
            if n > 1:
                nr = n - 1
                dt = d / n
                ds += dt
        elif "fixed" in p.rule:
            # Fixed space with adaptive space at start and end
            # when n=1 ->   | x   x |
            # when n=2 ->   | x x x |
            if n > 0:
                nr = n + 1
                dd = d - n * p.space
                dt = (d - dd) / n
                ds += 0.5 * dd
        elif "end" in p.rule:
            # Fixed space with adaptive space at start and item at end
            # when n=0 ->   |   x
            # when n=1 ->   | x x
            ds = de - n * p.space
            n += 1
        elif "start" in p.rule:
            # Fixed space with adaptive space at end and item at start
            # when n=0 ->   x   |
            # when n=1 ->   x x |
            de = ds + n * p.space
            n += 1
        if nr < 1:
            return []
        # dt = (de - ds) / ns
        # 4x faster than np.linspace
        c = p.curves[CURVE_PATH]
        if c.use_curve:
            return [ds + c.eval_curve(3, d, x) for x in [dt * i for i in range(nr)]]
        else:
            return [ds + dt * i for i in range(nr)]
        
    def reverse(self, d):
        if len(d) > 0:
            return [[_d[-1], d[i][0]] for i, _d in enumerate(d[:-1])]
        return [[]]

    # def space_between_axis(self, d):
    #     spaces = [
    #         [sub[i], _d]
    #         for sub in d
    #         for i, _d in enumerate(sub[1:])
    #         if len(sub) > 1
    #     ]
    #     return spaces

    def interpolate(self, d, p):
        if len(d) > 0:
            return [
                self._interpolate(sub[i], _d, p)
                for sub in d
                for i, _d in enumerate(sub[1:])
                if len(sub) > 0
            ]
        return [[]]

    # def _split(self, d0: float, d1: float, space: float, p):
    #     offset, start, end = p.sides, p.start, p.end
    #     ds, de = d0 + offset + start, d1 - offset - end
    #     d = de - ds
    #     half = 0.5 * offset
    #     di = ds + 0.5 * d
    #     if "split_left" in p.rule:
    #         # Split fixed left and space is absolute
    #         di = ds + space + half
    #     elif "split_right" in p.rule:
    #         # Split and return right part, space is absolute
    #         di = de - space - half
    #     elif "split" in p.rule:
    #         # Split and return left part, space is a factor
    #         di = ds + d * space + half
    #     # elif "split_right" in method:
    #         # Split and return right part, space is a factor
    #     #   di = de - d * space - half
    #     return (ds, di - half), (di + half, de)

    # def _select(self, d0, d1, space, p):
    #     offset, start, end = p.sides, p.start, p.end
    #     c = p.curves[CURVE_PATH]
    #
    #     ds, de = d0 + offset + start, d1 - offset - end
    #     d = de - ds
    #     n = floor(d / space)
    #     di, dj = 0, 0
    #     nr = n + 1
    #
    #     if "split_gap_f" in p.rule:
    #         # sides absolute / middle adaptive
    #         if ds > de:
    #             return []
    #         di = d + 2 * offset
    #         dj = offset
    #         nr = 2
    #         ds = d0 + start
    #
    #     elif "split_gap_a" in p.rule:
    #         # sides adaptive / middle absolute
    #         if n < 1:
    #             return []
    #         di = space - (start + end)
    #         dj = offset
    #         nr = 2
    #         ds = d0 + 0.5 * (d1 - d0 - space) + start
    #
    #     elif "split_gaps_a" in p.rule:
    #         # adaptive border fixed items adaptive gaps
    #         if n < 0:
    #             return []
    #         dt = (d - n * space) / (n + 1)
    #         di = space + dt
    #         dj = 0.5 * dt + offset
    #         ds += 0.5 * dt
    #
    #     elif "split_gaps_r" in p.rule:
    #         # fixed border items adaptive
    #         if n < 1:
    #             gap = []
    #         else:
    #             di = (d / n)
    #             if c.use_curve:
    #                 gap = [ds + c.eval_curve(3, d, x) for x in
    #                        [di * i for i in range(nr)]]
    #             else:
    #                 gap = [ds + di * i for i in range(nr)]
    #
    #         if "side" in p.rule:
    #             gap.insert(0, d0)
    #             gap.append(d1)
    #
    #         return gap
    #
    #     elif "split_gaps_f" in p.rule:
    #         # fixed border (until 0) fixed items adaptive gaps
    #         # ds, de = d0 + start, d1 - end
    #         # d = de - ds
    #         if n < 0:
    #             return []
    #
    #         n = max(0, n)
    #         nr = n + 1
    #         if n > 1:
    #             dt = (d - n * space) / (n - 1)
    #         else:
    #             ds += 0.5 * (d - space)
    #             dt = 0
    #         di = space + dt
    #         dj = 0.5 * dt - offset
    #         ds -= dj + offset
    #
    #     elif "split_gaps_x" in p.rule:
    #
    #         # EXPERIMENTAL NOT IN USE
    #
    #         # fixed border (until 0) fixed gaps adaptive items
    #         # ds, de = d0 + start, d1 - end
    #         # d = de - ds
    #         n = floor(d / space)
    #         n = max(0, n)
    #         r = n + 1
    #         if n > 1:
    #             dt = (d - n * space) / (n - 1)
    #         else:
    #             ds += 0.5 * (d - space)
    #             dt = 0
    #         #s     |               |
    #         #di  |sp + dt  |sp + dt  |
    #         #dj|   |sp+2o|   |sp+2o|   |
    #         #  |sp+dt+2o |
    #         di = space + dt
    #         dj = 0.5 * dt - offset
    #         ds -= 0.5 * dt
    #
    #     # elif p.rule == "split_gap_f_corner":
    #     #     return [ds, de]
    #
    #
    #     if c.use_curve:
    #         gap = [ds + c.eval_curve(3, d, x) for x in
    #                       [di * i + dj * j for i in range(nr) for j in range(-1, 2, 2)]]
    #     else:
    #         gap = [ds + di * i + dj * j for i in range(nr) for j in range(-1, 2, 2)]
    #
    #     # ensure > order
    #     # gap.sort()
    #
    #     if len(gap) > 1:
    #         # even gap / odd space
    #         gap.pop(0)
    #         gap.pop()
    #
    #     # clamp to limits
    #     gap.sort()
    #     gap = [max(d0, min(d1, _d)) for _d in gap]
    #
    #     # Add start and end for sides
    #     if "side" in p.rule:
    #         gap.insert(0, d0)
    #         gap.append(d1)
    #
    #     return gap

    def number_of_axis(self, d):
        return sum([len(sub) for sub in d])

    def number_of_spaces(self, d):
        return sum([len(sub)-1 for sub in d])

    # def select(self, d, space: float, p, closed: False):
    #
    #     if "random" in p.rule:
    #
    #         if "sub" in p.rule:
    #             # select axis into subs
    #             res0 = []
    #             res1 = []
    #             for sub in d:
    #                 n = len(sub)
    #                 r_n = range(n)
    #                 selected = set(sample(r_n, k=floor(n * p.percent / 100)))
    #                 res0.append([sub[i] for i in r_n if i in selected])
    #                 res1.append([sub[i] for i in r_n if i not in selected])
    #         else:
    #             # select spaces
    #             n = len(d)
    #             selected = set(sample(range(n), k=floor(n * p.percent / 100)))
    #             res0 = [sub for i, sub in enumerate(d) if i in selected]
    #             res1 = [sub for i, sub in enumerate(d) if i not in selected]
    #         return [res0, res1]
    #
    #     if "first_last" in p.rule:
    #
    #         if "sub" in p.rule:
    #             # select axis into subs
    #             res0 = []
    #             res1 = []
    #             for sub in d:
    #                 n = len(sub)
    #                 if n < 3:
    #                     res0.append(sub)
    #                 else:
    #                     start = min(n, p.n_start)
    #                     end = max(start, n - p.n_end)
    #                     r_n = range(start, end)
    #                     res0.append([sub[i] for i in range(start)])
    #                     res0.append([sub[i] for i in range(end, n)])
    #                     res1.append([sub[i] for i in r_n])
    #         else:
    #             # select spaces
    #             if len(d) < 3:
    #                 res0 = d
    #                 res1 = []
    #             else:
    #                 n = len(d)
    #                 start = min(n, p.n_start)
    #                 end = max(start, n - p.n_end)
    #                 res0 = [d[i] for i in range(start)] + [d[i] for i in range(end, n)]
    #                 res1 = [sub for i, sub in enumerate(d[start:end])]
    #         return [res0, res1]
    #
    #     if "every_n" in p.rule:
    #         offset = -p.n_offset
    #
    #         if "sub" in p.rule:
    #             # sub axis
    #             res0 = [[sub[i] for sub in d for i in range(len(sub)) if ((i + offset) % p.every) == 0]]
    #             res1 = [[sub[i] for sub in d for i in range(len(sub)) if ((i + offset) % p.every) != 0]]
    #             # select when axis cross end point
    #             if self.closed and d[0][0] == 0 and d[-1][-1] == self.d_max:
    #                 res0[0].append(self.d_max + res0[0][0])
    #         else:
    #             res0 = [sub for i, sub in enumerate(d) if ((i + offset) % p.every) == 0]
    #             res1 = [sub for i, sub in enumerate(d) if ((i + offset) % p.every) != 0]
    #
    #         return [res0, res1]
    #
    #     # side / spaces
    #     if p.rule == "split_gaps_r_side":
    #         res0, res1 = [], []
    #         for sub in d:
    #             if len(sub) > 0:
    #                 for i, _d in enumerate(sub[1:]):
    #                     _r = self._select(sub[i], _d, space, p)
    #                     n = len(_r)
    #                     if n > 2:
    #                         res0.extend([_r[0:2], _r[-2:n]])
    #                         res1.extend([_r[i:i + 2] for i in range(1, n - 2)])
    #                     elif n > 1:
    #                         res0.extend([_r[0:2]])
    #         return [res0, res1]
    #
    #     # side -> even / odd
    #     if "side" in p.rule:
    #         res0, res1 = [],[]
    #         for sub in d:
    #             if len(sub) > 0:
    #                 for i, _d in enumerate(sub[1:]):
    #                     _r = self._select(sub[i], _d, space, p)
    #                     res0.extend([_r[i:i + 2] for i in range(0, len(_r) - 1, 2)])
    #                     res1.extend([_r[i:i + 2] for i in range(1, len(_r) - 1, 2)])
    #         return [res0, res1]
    #
    #     # corners only
    #     res = []
    #     for sub in d:
    #         if len(sub) > 0:
    #             for i, _d in enumerate(sub[1:]):
    #                 res.extend(self._select(sub[i], _d, space, p))
    #
    #     # only apply on single space between corners
    #     # add start and end on first and last
    #     if "gap_" in p.rule and closed:
    #         # res is a flat array
    #         # print("res before", res)
    #         last = res.pop()
    #         res.insert(0, last)
    #         # print("res after", res)
    #     else:
    #         # add start and end on first and last
    #         for sub in d:
    #              if len(sub) > 0:
    #                  res.insert(0, sub[0])
    #                  break
    #         for sub in reversed(d):
    #              if len(sub) > 0:
    #                  res.append(sub[-1])
    #                  break
    #
    #     res0, res1 = [], []
    #
    #     if p.rule == "split_gaps_r_corner":
    #         # corners / spaces
    #         n = len(res)
    #         if n > 2:
    #             res0, res1 = \
    #                 [res[0:2], res[-2:n]], \
    #                 [res[i:i + 2] for i in range(1, n - 2)]
    #         elif n > 1:
    #             res0, res1 = \
    #                 [res[0:2], res[-2:n]], \
    #                 []
    #     else:
    #         # even odd rule
    #         res0, res1 = \
    #             [res[i:i + 2] for i in range(0, len(res) - 1, 2)], \
    #             [res[i:i + 2] for i in range(1, len(res) - 1, 2)]
    #     return res0, res1

    def split(self, d, space: float, p, closed=False):

        if "gap" in p.rule:
            return self.select(d, space, p, closed)

        split = [
            self._split(sub[i], _d, space, p)
            for sub in d
            for i, _d in enumerate(sub[1:])
            if len(sub) > 0
        ]
        return [s[0] for s in split], [s[1] for s in split]

    def filter_close(self, d, dist=0.000001):
        if len(d) < 2:
            return d
        return [d[0]] + [_d for i, _d in enumerate(d[1:]) if abs(_d - d[i]) > dist]

    def _subdivide(self, d, n):
        res = []
        for i, _d in enumerate(d[1:]):
            d0 = d[i]
            dx = (_d - d0) / n
            for j in range(n + 1):
                res.append(d0 + dx * j)
        return res

    def subdivide(self, d, subdivisions):
        if subdivisions > 0:
            n = 1 + subdivisions
            try:
                iter(d[0])
                return [self._subdivide(_d, n) for _d in d]
            except:
                return self._subdivide(d, n)
        return d

    def _interp_vect(self, d, x_ref, _p):
        res = []
        j0 = len(x_ref)
        for i, x in enumerate(d):
            # allow cyclic x
            # x = _x % self.d_max
            j = self._segs_max(x)
            j_next = (j + 1) % j0
            _p0 = _p[j]
            x0 = x_ref[j]
            sx = x - x0
            dx = x_ref[j_next] - x0
            if dx > 0:
                t = sx / dx
                res.append(
                    _p0 + (_p[j_next] - _p0) * t
                )
            else:
                res.append(_p0)
        return res

    def _intersect(self, d):
        s = self.inclusive_segs(d)
        # print("_intersect s", s)
        f, l = d[0], d[-1]
        # print("_intersect f, l", f, l)
        if f > l:
            # while seg index grow
            #  8, 9, 0, 1, 2
            r = [f] + \
                [self.d[i + 1] for i in range(s[0], max(s))] + \
                [0] + \
                [self.d[i + 1] for i in range(min(s), s[-1])] + \
                [l]
        elif self.closed and f == 0 and l == self.d_max:
            # when closed, and s[0] == s[-1]
            r = self.d  # [f] + [self.d[i + 1] for i in range(len(s) - 1)]
        else:
            r = [f] + [self.d[i + 1] for i in range(s[0], s[-1])] + [l]
        # print("_intersect d", d, "r", r)
        return self.filter_close(r)

    def intersect(self, d):
        return [self._intersect(_d) for _d in d if len(_d) > 0]

    def _segs_max(self, _d):
        _s = self.tree.intersect(_d)
        if _s > -1 or self.closed:
            return _s
        return self.s[-1]

    def _segs(self, _d):
        _s = self.tree.intersect(_d)
        if _s > -1 or self.closed:
            return _s
        return 0

    def segs(self, d):
        return list(map(self._segs_max, d))

    def _last_segs(self, _d):
        _s = self.tree.intersect_last(_d)
        if _s > -1 or self.closed:
            return _s
        return 0

    def last_segs(self, d):
        return list(map(self._last_segs, d))

    def _inclusive_segs(self, _d):
        _s = self.tree.intersect_inclusive(_d)
        if _s > -1 or self.closed:
            return _s
        return -1

    def inclusive_segs(self, d):
        return list(map(self._inclusive_segs, d))

        # return np.array(np.interp(d, self.d, self.s, dtype='int')
    def pts(self, d):
        return self._interp_vect(d, self.d, self.p)

    def filter_empty_space(self, d, dist=0.000001):
        try:
            iter(d[0])
            return [_d for _d in d if abs(_d[-1] - _d[0]) > dist]
        except:
            return d

    def filter_empty(self, d):
        try:
            iter(d[0])
            return [_d for _d in d if len(_d) > 0]
        except:
            return d

    def param_t(self, d, d0, dx):
        if dx == 0:
            return [0 for _d in d]
        return [(_d - d0) / dx for _d in d]

    def filter_close_dt(self, d, t, dist=0.000001):
        if len(d) < 2:
            return d, t
        return list(zip(*[(d[0], t[0])] + [
                            (_d[0], _d[1])
                            for i, _d in enumerate(zip(d[1:], t[1:]))
                            if abs(_d[0] - d[i]) > dist
                        ]))

    def clamp(self, _d):
        """ keep coords in range [0: d_max]
        :param _d:
        :return:
        """
        return [x % self.d_max if x > self.d_max else x for x in _d]

    def lerp(self, d):
        """
        :param d:
        :return: coords, segment index
        """
        _d = self.filter_empty(d)
        if len(_d) < 1:
            return [], [], [], [], []

        # paramt along segments
        try:
            iter(_d[0])
            _d = [self.clamp(_t) for _t in _d]
            # d for segment index
            _segs = [self.segs(_t) for _t in _d]
            _t_local = [[(_dj[j] - self.d[i]) / self.l[i] for j, i in enumerate(_s)] for _dj, _s in zip(_d, _segs)]
            _t_local = self.haystack(_t_local)

        except Exception as ex:
            # print(ex)
            _d = self.clamp(_d)
            _s = self.segs(_d)
            _t_local = [(_d[j] - self.d[i]) / self.l[i] for j, i in enumerate(_s)]

        _d = self.haystack(_d)
        _d, _t_local = self.filter_close_dt(_d, _t_local)

        _segs = self.segs(_d)
        _t_global = self.param_t(_d, 0, self.d_max)

        _last_segs = self.last_segs(_d)

        # print("_t_local", _t_local)
        # print("_segs", _segs)
        # print("_last_segs", _last_segs)
        # print("_t_global", _t_global)

        return self.pts(_d), _segs, _last_segs, _t_local, _t_global

    # def sub_lerp(self, d):
    #     return [self.lerp(_d) for _d in d]

    def haystack(self, d):
        try:
            iter(d[0])
            return [_d for _ds in d for _d in _ds]
        except:
            return d


def update(self, context):
    self.update(context)


def update_collection(self, context):
    self.update(context, update_collection=True)


def update_manipulators(self, context):
    self.manipulable_refresh = True
    self.update(context)


class archipack_sources_provider_source(Archipacki18n, PropertyGroup):
    label: StringProperty()
    source_type: EnumProperty(
        items=(
            ("MESH", "Object (Mesh)", "", "OUTLINER_OB_MESH", 0),
            ("OBJECT", "Object (any)", "", "OBJECT_DATA", 1),
            ("COLLECTION", "Collection", "", "GROUP", 2),
            ("PRIMITIVE", "Primitive", "", "OBJECT_DATA", 3)
        ),
        default="OBJECT"
    )
    weight: FloatProperty(min=0, max=10, default=1, update=update)
    source_uid: IntProperty(default=-1)
    rotation: FloatVectorProperty(
        name="Rotation",
        default=[0, 0, 0],
        size=3,
        min=-2 * pi, max=2 * pi,
        unit='ROTATION', subtype='EULER',
        update=update
    )
    scale: FloatVectorProperty(
        name="Scale",
        default=[1, 1, 1],
        size=3,
        min=0.001, max=1000,
        update=update
    )
    location: FloatVectorProperty(
        name="Location",
        default=[0, 0, 0],
        size=3,
        unit='LENGTH', subtype='XYZ',
        update=update
    )

    material_offset: IntProperty(default=0, description="offset of material index for this object")

    def pre_transform(self, o):
        """ Pre-Transform object so it is aligned with x axis
        :param o:
        :param rM:
        :return:
        """
        sM = Matrix()
        for i in range(3):
            sM.row[i][i] = self.scale[i]

        rM = Matrix.Rotation(self.rotation[2], 4, "Z") @ \
            Matrix.Rotation(self.rotation[1], 4, "Y") @ \
            Matrix.Rotation(self.rotation[0], 4, "X")

        tM = Matrix.Translation(self.location) @ \
            rM @ \
            sM

        return tM @ o.matrix_world.inverted(), tM, rM, sM

    @property
    def icon(self):
        return {
            "MESH": "OUTLINER_OB_MESH",
            "OBJECT": "OBJECT_DATA",
            "COLLECTION": "GROUP",
            "PRIMITIVE": "OBJECT_DATA"
        }[self.source_type]

    def source(self, source_type):
        if "mesh" in source_type and self.source_type not in {"MESH", 'PRIMITIVE'}:
            return None
        if self.source_type in {'OBJECT', 'MESH'}:
            o = bpy.data.objects.get(self.label.strip())
        elif self.source_type == 'PRIMITIVE':
            o = bpy.data.objects.get(self.label.strip())
            if o is None:
                # create primitive (cylinder at this time)
                me = bpy.data.meshes.new(self.label.strip())
                # cylinder
                faces = [
                    (0, 1, 3, 2), (2, 3, 5, 4),
                    (4, 5, 7, 6), (6, 7, 9, 8),
                    (8, 9, 11, 10), (10, 11, 13, 12),
                    (12, 13, 15, 14), (14, 15, 17, 16),
                    (16, 17, 19, 18), (18, 19, 21, 20),
                    (20, 21, 23, 22), (22, 23, 25, 24),
                    (24, 25, 27, 26), (26, 27, 29, 28),
                    (28, 29, 31, 30), (30, 31, 33, 32),
                    (32, 33, 35, 34), (34, 35, 37, 36),
                    (36, 37, 39, 38), (38, 39, 41, 40),
                    (40, 41, 43, 42), (42, 43, 45, 44),
                    (44, 45, 47, 46), (46, 47, 49, 48),
                    (48, 49, 51, 50), (50, 51, 53, 52),
                    (52, 53, 55, 54), (54, 55, 57, 56),
                    (56, 57, 59, 58), (58, 59, 61, 60),
                    (3, 1, 63, 61, 59, 57, 55, 53, 51, 49, 47, 45, 43, 41, 39, 37, 35, 33, 31, 29, 27, 25, 23, 21, 19,
                     17, 15, 13, 11, 9, 7, 5), (60, 61, 63, 62),
                    (62, 63, 1, 0), (
                    0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50,
                    52, 54, 56, 58, 60, 62),
                ]
                verts = [
                    (0.0, 1.0, -1.0), (0.0, 1.0, 1.0),
                    (0.195, 0.981, -1.0), (0.195, 0.981, 1.0),
                    (0.383, 0.924, -1.0), (0.383, 0.924, 1.0),
                    (0.556, 0.831, -1.0), (0.556, 0.831, 1.0),
                    (0.707, 0.707, -1.0), (0.707, 0.707, 1.0),
                    (0.831, 0.556, -1.0), (0.831, 0.556, 1.0),
                    (0.924, 0.383, -1.0), (0.924, 0.383, 1.0),
                    (0.981, 0.195, -1.0), (0.981, 0.195, 1.0),
                    (1.0, 0.0, -1.0), (1.0, 0.0, 1.0),
                    (0.981, -0.195, -1.0), (0.981, -0.195, 1.0),
                    (0.924, -0.383, -1.0), (0.924, -0.383, 1.0),
                    (0.831, -0.556, -1.0), (0.831, -0.556, 1.0),
                    (0.707, -0.707, -1.0), (0.707, -0.707, 1.0),
                    (0.556, -0.831, -1.0), (0.556, -0.831, 1.0),
                    (0.383, -0.924, -1.0), (0.383, -0.924, 1.0),
                    (0.195, -0.981, -1.0), (0.195, -0.981, 1.0),
                    (-0.0, -1.0, -1.0), (-0.0, -1.0, 1.0),
                    (-0.195, -0.981, -1.0), (-0.195, -0.981, 1.0),
                    (-0.383, -0.924, -1.0), (-0.383, -0.924, 1.0),
                    (-0.556, -0.831, -1.0), (-0.556, -0.831, 1.0),
                    (-0.707, -0.707, -1.0), (-0.707, -0.707, 1.0),
                    (-0.831, -0.556, -1.0), (-0.831, -0.556, 1.0),
                    (-0.924, -0.383, -1.0), (-0.924, -0.383, 1.0),
                    (-0.981, -0.195, -1.0), (-0.981, -0.195, 1.0),
                    (-1.0, 0.0, -1.0), (-1.0, 0.0, 1.0),
                    (-0.981, 0.195, -1.0), (-0.981, 0.195, 1.0),
                    (-0.924, 0.383, -1.0), (-0.924, 0.383, 1.0),
                    (-0.831, 0.556, -1.0), (-0.831, 0.556, 1.0),
                    (-0.707, 0.707, -1.0), (-0.707, 0.707, 1.0),
                    (-0.556, 0.831, -1.0), (-0.556, 0.831, 1.0),
                    (-0.383, 0.924, -1.0), (-0.383, 0.924, 1.0),
                    (-0.195, 0.981, -1.0), (-0.195, 0.981, 1.0),

                ]
                edges = [
                    (0, 2), (3, 1),
                    (0, 1), (3, 2),
                    (2, 4), (5, 3),
                    (5, 4), (4, 6),
                    (7, 5), (7, 6),
                    (6, 8), (9, 7),
                    (9, 8), (8, 10),
                    (11, 9), (11, 10),
                    (10, 12), (13, 11),
                    (13, 12), (12, 14),
                    (15, 13), (15, 14),
                    (14, 16), (17, 15),
                    (17, 16), (16, 18),
                    (19, 17), (19, 18),
                    (18, 20), (21, 19),
                    (21, 20), (20, 22),
                    (23, 21), (23, 22),
                    (22, 24), (25, 23),
                    (25, 24), (24, 26),
                    (27, 25), (27, 26),
                    (26, 28), (29, 27),
                    (29, 28), (28, 30),
                    (31, 29), (31, 30),
                    (30, 32), (33, 31),
                    (33, 32), (32, 34),
                    (35, 33), (35, 34),
                    (34, 36), (37, 35),
                    (37, 36), (36, 38),
                    (39, 37), (39, 38),
                    (38, 40), (41, 39),
                    (41, 40), (40, 42),
                    (43, 41), (43, 42),
                    (42, 44), (45, 43),
                    (45, 44), (44, 46),
                    (47, 45), (47, 46),
                    (46, 48), (49, 47),
                    (49, 48), (48, 50),
                    (51, 49), (51, 50),
                    (50, 52), (53, 51),
                    (53, 52), (52, 54),
                    (55, 53), (55, 54),
                    (54, 56), (57, 55),
                    (57, 56), (56, 58),
                    (59, 57), (59, 58),
                    (58, 60), (61, 59),
                    (61, 60), (60, 62),
                    (63, 61), (63, 62),
                    (62, 0), (1, 63),

                ]
                me.from_pydata(verts, edges, faces)
                o = bpy.data.objects.new(self.label.strip(), me)
                o.use_fake_user = True
        else:
            o = bpy.data.collections.get(self.label.strip())
        return o

    def draw_list_item(self, context, layout, layout_type, active_data):
        row = layout.row(align=True)
        icon = self.icon
        if "mesh" in active_data.geometry and self.source_type not in {"MESH", 'PRIMITIVE'}:
            icon = "ERROR"
        self.draw_label(context, layout, row, self.label, icon=icon)
        if active_data.source_random and len(active_data.source_objects) > 1:
            self.draw_prop(context, layout, row, self, "weight")
        for i, p in enumerate(active_data.source_objects):
            if p == self:
                if not active_data.source_random:
                    op = self.draw_op(context, layout, row, "archipack.array_source_move_up", text="", icon="TRIA_UP")
                    op.geometry = active_data.name
                    op.index = i
                    op = self.draw_op(context, layout, row, "archipack.array_source_move_down", text="", icon="TRIA_DOWN")
                    op.geometry = active_data.name
                    op.index = i
                op = self.draw_op(context, layout, row, "archipack.array_source_remove", text="", icon="TRASH")
                op.geometry = active_data.name
                op.index = i
                break

    def draw(self, context, layout, where):
        self.draw_label(context, layout, where, "Location")
        row = where.row(align=True)
        self.draw_prop(context, layout, row, self, 'location', text="x", index=0)
        self.draw_prop(context, layout, row, self, 'location', text="y", index=1)
        self.draw_prop(context, layout, row, self, 'location', text="z", index=2)

        self.draw_label(context, layout, where, "Rotation")
        row = where.row(align=True)
        self.draw_prop(context, layout, row, self, 'rotation', text="x", index=0)
        self.draw_prop(context, layout, row, self, 'rotation', text="y", index=1)
        self.draw_prop(context, layout, row, self, 'rotation', text="z", index=2)

        self.draw_label(context, layout, where, "Scale")
        row = where.row(align=True)
        self.draw_prop(context, layout, row, self, 'scale', text="x", index=0)
        self.draw_prop(context, layout, row, self, 'scale', text="y", index=1)
        self.draw_prop(context, layout, row, self, 'scale', text="z", index=2)

    @property
    def parent_data(self):
        return self.id_data.archipack_array[0]

    def update(self, context):
        self.parent_data.update(context)


class RandomSourceProvider:
    """
    Parent must inherit from Archipacki18n
    and implement a source_random Boolean property
    """

    source_object: PointerProperty(
        name="Object",
        type=bpy.types.Object,
        options={'SKIP_SAVE'}
    )
    source_collection: PointerProperty(
        name="Collection",
        type=bpy.types.Collection,
        options={'SKIP_SAVE'}
    )
    source_objects_idx: IntProperty()
    source_objects: CollectionProperty(type=archipack_sources_provider_source)
    
    def move_source_up(self, index):
        if index > 0:
            self.source_objects.move(index, index - 1)
            
    def move_source_down(self, index):
        if index + 1 < len(self.source_objects):
            self.source_objects.move(index, index + 1)
            
    @property
    def source_uids(self):
        return set([g.source_uid for g in self.source_objects])

    def pick_sources(self, count, random, source_type):

        if count == 0:
            return [], []

        if random:
            return self.random_sources(count, source_type)
        else:
            return self.alternate_sources(count, source_type)

    def random_sources(self, count, source_type):

        sources = [
            [d, d.source(source_type), 0]
            for i, d in enumerate(self.source_objects)
        ]

        # filter weight > 0 and valid sources
        occurrences = list(filter(lambda s: s[1] is not None and s[0].weight > 0, sources))

        n_occur = len(occurrences)

        if n_occur == 0:
            return [], []

        weights = [
            d.weight
            for d, s, n in occurrences
        ]
        wt = sum(weights) / count
        if wt == 0:
            # weights are all 0
            d, s, n = occurrences[0]
            return [0] * count, [[d, s, count]]

        # relative weights, no need to compute last one as it is implicit
        if count < n_occur:
            # use a weighted pick
            w_i = [(i, w) for i, w in enumerate(weights)]
            w_i.sort(key=lambda x: x[1], reverse=True)
            relw = [[i, ceil(w / wt)] for i, w in w_i]
            # ensure ceil doesn't pick too much items
            total = 0
            for i, rw in enumerate(relw):
                total += rw[1]
                if total > count:
                    relw[i][1] = 0
            # sort by occurrences index (inverse order)
            relw.sort(key=lambda x: x[0])
            relw = [min(count, rw[1]) for rw in relw]

        else:
            relw = [min(count, round(w / wt)) for w in weights]

        relw.pop()

        available = set(range(count))

        occurrences[-1][2] = count - sum(relw)
        selected = [-1] * count
        for index, rw in enumerate(relw):
            if rw == 0:
                continue
            picked = sample(tuple(available), k=rw)
            available.difference_update(picked)
            occurrences[index][2] = rw
            for i in picked:
                selected[i] = index
            if len(available) == 0:
                break
        # print("selected", selected)
        # print("occurrences", "\n".join([str((i[1].name, i[2])) for i in occurrences]))

        return selected, occurrences

    def alternate_sources(self, count, source_type):
        sources = [
            (d, d.source(source_type), i)
            for i, d in enumerate(self.source_objects)
        ]
        # filter valid sources
        sources = list(filter(lambda s: s[1] is not None, sources))
        n_source = len(sources)
        if n_source == 0:
            return [], []
        n_repeat = floor(count / n_source)
        selected = [i for j in range(n_repeat) for i in range(n_source)]
        occurrences = [[d, s, n_repeat] for d, s, i in sources]
        for k in range(n_source * n_repeat, count):
            selected.append(k % n_source)
            occurrences[k % n_source][2] += 1
        return selected, occurrences

    def draw_sources(self, context, layout, where, draw_collection=True, draw_object=True, source_type="OBJECT"):
        row = where.row()
        split = row.split(factor=0.5)
        col1 = split.column()
        col2 = split.column(align=True)
        self.draw_prop(context, layout, col1, self, 'source_collection', text="")

        if draw_collection:
            op = self.draw_op(
                context, layout, col2, "archipack.array_source_add", icon="ADD", text="Collection Instance"
            )
            op.geometry = self.name
            op.source_type = "COLLECTION"
            op.source = ""
            if self.source_collection is not None:
                op.source = self.source_collection.name

        icon = {
            "MESH": "OUTLINER_OB_MESH",
            "OBJECT": "OBJECT_DATA"
        }[source_type]

        op = self.draw_op(
            context, layout, col2, "archipack.array_source_add", icon=icon, text="Collection Members"
        )
        op.geometry = self.name
        op.source = ""
        if self.source_collection is not None:
            op.source_type = "COLLECTION_" + source_type
            op.source = self.source_collection.name

        if draw_object:
            row = where.row()

            self.draw_prop(context, layout, row, self, 'source_object', text="")
            op = self.draw_op(context, layout, row, "archipack.array_source_add", icon="ADD", text="Object")
            op.geometry = self.name
            op.source_type = source_type
            op.source = ""
            if self.source_object is not None:
                op.source = self.source_object.name
            row = where.row()
            op = self.draw_op(context, layout, row, "archipack.array_source_add", icon="ADD", text="Primitive")
            op.geometry = self.name
            op.source_type = "PRIMITIVE"
            op.source = "Primitive"

        op = self.draw_op(context, layout, where, "archipack.array_source_remove", icon="TRASH", text="Remove all")
        op.geometry = self.name
        op.index = -1

        n_rows = max(1, len(self.source_objects))
        where.template_list(
            "ARCHIPACK_UL_SourceProvider",
            "source_objects",
            self,
            "source_objects",
            self,
            "source_objects_idx",
            rows=n_rows, maxrows=n_rows
        )

        if len(self.source_objects) > self.source_objects_idx > -1:
            self.source_objects[self.source_objects_idx].draw(context, layout, where)


"""
d = C.object.data.archipack_array[0]
d.geometrys[5].pick_sources(C, 25)


"""


class ARCHIPACK_UL_SourceProvider(UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):

        # self.use_filter_show = True
        item.draw_list_item(context, layout, self.layout_type, active_data)

        # layout_type in {'DEFAULT', 'COMPACT', 'GRID'}:

    # Called once to filter/reorder items.
    def filter_items(self, context, data, propname):

        col = getattr(data, propname)
        filter_name = self.filter_name.lower()

        flt_flags = [
            self.bitflag_filter_item if any(
                filter_name in filter_set for filter_set in (
                    str(i), item.label.lower()
                    )
            )
            else 0 for i, item in enumerate(col, 1)
        ]

        if self.use_filter_sort_alpha:
            flt_neworder = [x[1] for x in sorted(
                    zip(
                    [x[0] for x in sorted(enumerate(col), key=lambda x: x[1].label)],
                    range(len(col))
                    )
                )
            ]
        else:
            flt_neworder = []

        return flt_flags, flt_neworder


class archipack_array_geometry(Archipacki18n, RandomSourceProvider, ArchipackProfile, PropertyGroup):
    # name: StringProperty(default="Generator")

    profil_x: FloatProperty(
        name="Width",
        min=0.001,
        default=0.05, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    profil_y: FloatProperty(
        name="Depth",
        min=0.001,
        default=0.05, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    z: FloatProperty(
        name="Height",
        min=0.001,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )

    extend: FloatProperty(
        name="Extend",
        default=0,
        precision=5, step=1,
        unit='LENGTH',
        update=update
    )

    profil: EnumProperty(
        name="Profil",
        items=(
            ('SQUARE', 'Square', '', 0),
            ('CIRCLE', 'Circle', '', 1),
            ('SAFETY', 'Safety rail', '', 2),
            ('USER', 'User defined', '', 3)
        ),
        default='SQUARE',
        update=update
    )
    idmat: IntVectorProperty(
        default=[0],
        size=1
    )
    mat: EnumProperty(
        options={'SKIP_SAVE'},
        name="Material",
        items=mat_enum,
        get=mat_index_getter(MAT_RAIL),
        set=mat_index_setter(MAT_RAIL),
        update=update
    )
    rotate_corners: BoolProperty(
        default=True,
        name="Rotate corners",
        update=update
    )
    expand: BoolProperty(
        default=True,
        name="Expand"
    )
    #
    geometry: EnumProperty(
        name="Geometry",
        description="Geometry type",
        items=(
            ("none", "None", "none"),
            ("post", "Post, vertical", "Vertical profile suited for post and structural beams"),
            ("panel", "Panel, horizontal, bottom", "Horizontal profile altitude at bottom suited for panels"),
            ("rail", "Rail, horizontal, axis", "Horizontal profile altitude at axis suited for beams"),
            ("vert", "Vertex", "Single vertex suited for duplivert"),
            ("face", "Face", "Single face suited for dupliface"),
            ("object", "Object / Collection instances", "Object/ Collection instances, including hierarchy children"),
            ("mesh", "Mesh", "mesh, including hierarchy children"),
            ("deformable_mesh", "Deformable mesh", "Adapt mesh shape along the path, including hierarchy children"),
        ),
        default="face",
        update=update
    )
    subdivide: IntProperty(
        name="Subdivide",
        default=6,
        min=0,
        max=256,
        update=update
    )
    slope: BoolProperty(
        name="Slope",
        description="Follow path slope",
        default=True,
        update=update
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True
    )

    source_random: BoolProperty(
        name="Random",
        default=False,
        description="Choose random source",
        update=update
    )

    def draw(self, context, layout, where, index, draw_expand=True):
        icon = "TRIA_RIGHT"
        if self.expand:
            icon = "TRIA_DOWN"

        if draw_expand:
            col2 = where.box()

            # col2 = col2.box()
            # spacer = "".join(["|"] * depth)
            # if depth > 0:
            # col1.label(text="%s" % (index + 1))

            row = col2.row(align=True)
            self.draw_prop(context, layout, row, self, "name", text="")
            self.draw_prop(context, layout, row, self, "expand", icon=icon, emboss=True)
            self.draw_op(
                context, layout, row, "archipack.array_geometry_remove", icon='TRASH', text=""
                ).index = index
        else:
            col2 = where

        if self.expand or not draw_expand:
            self.draw_prop(context, layout, col2, self, 'geometry')
            # col1.label(text=spacer)
            # col2.prop(self, "side", text="Side")
            # col1.label(text=spacer)

            col2.separator()

            if self.geometry in {"deformable_mesh", "rail", "panel"}:
                self.draw_prop(context, layout, col2, self, 'subdivide')

            row = col2.row(align=True)
            if self.geometry in {"deformable_mesh", "mesh", "object", "post"}:
                self.draw_prop(context, layout, row, self, "slope", icon="RNDCURVE", emboss=True)
            self.draw_prop(context, layout, row, self, 'rotate_corners', icon="BLANK1", emboss=True)

            if self.geometry in {"object", "mesh", "deformable_mesh"}:
                if self.geometry == "object":
                    source_type = "OBJECT"
                    draw_collection = True
                else:
                    source_type = "MESH"
                    draw_collection = False
                self.draw_prop(context, layout, col2, self, 'source_random', icon="BLANK1", emboss=True)
                self.draw_sources(
                    context, layout, col2, draw_collection=draw_collection, source_type=source_type
                )

            if self.geometry in {"rail", "post", "panel"}:
                self.draw_prop(context, layout, col2, self, 'profil')
                if self.profil == 'USER':
                    self.draw_user_profile(context, col2)
                if self.geometry in {'panel', 'rail'}:
                    self.draw_prop(context, layout, col2, self, 'profil_x', text="Width")
                    self.draw_prop(context, layout, col2, self, 'profil_y', text="Height")
                else:
                    self.draw_prop(context, layout, col2, self, 'profil_x')
                    self.draw_prop(context, layout, col2, self, 'profil_y')
                if self.geometry == 'post':
                    self.draw_prop(context, layout, col2, self, 'z')
                if self.geometry == "rail":
                    self.draw_prop(context, layout, col2, self, 'extend')
            where.separator()
            # if self.geometry in {"rail", "post", "panel", "face"}:
            #    self.draw_prop(context, layout, col2, self, 'mat')

    @property
    def has_valid_geometry(self):
        for s in self.source_objects:
            if s.source(self.geometry) is not None:
                return True
        return False

    def id_mat(self, index):
        _idx = self.idmat[index]
        if _idx < len(self.id_data.materials):
            return _idx
        return 0

    def refresh_profile_size(self, context, x, y):
        self.profil_x = x
        self.profil_y = y
        self.auto_update = True
        self.update(context)

    @property
    def parent_data(self):
        return self.id_data.archipack_array[0]

    def update(self, context):
        if self.auto_update:
            self.parent_data.update(context)


class ArrayGenerator(Generator):
    """
      Generator for cutter objects
    """
    def __init__(self, o=None):
        Generator.__init__(self, o)
        self.line = None


class archipack_array_curve(Archipacki18n, PropertyGroup):
    """
    Store custom curve as shader nodes
    """
    use_curve: BoolProperty(name="Use curve", update=update)
    curve_uid: IntProperty(default=-1)
    curve_type: EnumProperty(
        items=(
            ('NONE', 'NONE', "None"),
            ('VECTOR', 'VECTOR', 'VECTOR')
        ),
        default="NONE"
    )

    @property
    def curve_map_name(self):
        return "%s-%s" % (self.id_data.name, self.curve_uid)

    @property
    def node_group_name(self):
        return "ArchipackCurveData-%s" % self.id_data.name

    @property
    def node_group(self):
        ng = bpy.data.node_groups.get(self.node_group_name)
        if ng is None:
            return None
        return ng

    @property
    def curve_map_data(self):
        ng = self.node_group
        if ng is None:
            return None
        cd = ng.nodes.get(self.curve_map_name)
        if cd is not None:
            cd.mapping.initialize()
        return cd

    def eval_curve(self, curve, d, x):
        cd = self.curve_map_data
        if cd is not None:
            mapping = cd.mapping
            c = mapping.curves[curve]
            if hasattr(mapping, "evaluate"):
                # 2.82+
                return d * mapping.evaluate(c, x / d)
            # 2.82-
            return d * c.evaluate(x / d)
        return x

    def on_create(self, min_y=0, curve_type="NONE", init_points=True):
        self.parent_data.new_curve_uid(self)
        ng = self.node_group
        if ng is None:
            ng = bpy.data.node_groups.new(self.node_group_name, 'ShaderNodeTree')
            ng.use_fake_user = True
        name = self.curve_map_name
        cd = ng.nodes.get(name)
        if cd is None:
            cd = ng.nodes.new('ShaderNodeRGBCurve')
            cd.name = name
            self.curve_type = curve_type
            cd.mapping.initialize()
            cd.mapping.clip_max_y = 1
            cd.mapping.clip_min_y = min_y
            if init_points:
                for _s in cd.mapping.curves:
                    for p in _s.points:
                        p.location.y = 1
            cd.mapping.update()
        return cd

    def on_delete(self):
        # t = time()
        cd = self.curve_map_data
        if cd is not None:
            ng = self.node_group
            ng.nodes.remove(cd)
        # print("archipack_array_curve on_delete %.6f" % (time()-t))

    def draw(self, context, layout, where):
        self.draw_prop(context, layout, where, self, "use_curve", emboss=True, icon="FCURVE")
        if self.use_curve:
            cd = self.curve_map_data
            if cd is not None:
                self.draw_op(context, layout, where, "archipack.object_update", icon="FILE_REFRESH")
                where.template_curve_mapping(cd, "mapping", type=self.curve_type, levels=False)
                where.separator()

    @property
    def parent_data(self):
        return self.id_data.archipack_array[0]

    def update(self, context):
        self.parent_data.update(context)


class GlobalTransforms:
    global_rotation: BoolProperty(
        name="Global rotation",
        default=False,
        update=update
    )
    global_rotations_override: BoolVectorProperty(
        name="Override rotation",
        size=3,
        default=[True, True, True],
        update=update
    )
    global_rotations: FloatVectorProperty(
        name="Rotation",
        default=[0, 0, 0],
        size=3,
        min=-2 * pi, max=2 * pi,
        unit='ROTATION', subtype='EULER',
        update=update
    )
    global_scales_override: BoolVectorProperty(
        name="Override rotation",
        size=3,
        default=[True, True, True],
        update=update
    )
    global_scales: FloatVectorProperty(
        name="Scale",
        default=[0, 0, 0],
        size=3,
        min=0.001, max=1000,
        update=update
    )
    global_translations_override: BoolVectorProperty(
        name="Override translation",
        size=3,
        default=[True, True, True],
        update=update
    )
    global_translations: FloatVectorProperty(
        name="Translation",
        default=[0, 0, 0],
        size=3,
        unit='LENGTH', subtype='XYZ',
        update=update
    )

    global_scale: BoolProperty(
        name="Global scale",
        default=False,
        update=update
    )

    global_translation: BoolProperty(
        name="Global offset",
        default=False,
        update=update
    )

    extrapolation: BoolProperty(
        name="Extrapolate on corners",
        description="Ensure continuity by interpolation of segment axis direction",
        default=False,
        update=update
    )
    extrapolation_limited: BoolProperty(
        name="Limit extrapolation",
        description="Start extrapolation at absolute distance from border",
        default=False,
        update=update
    )
    extrapolation_limit: FloatProperty(
        name="Limit",
        description="Distance from corner",
        default=0.1,
        min=0.0001,
        precision=5, step=1,
        unit='LENGTH',
        update=update
    )

    def draw_limits(self, context, layout, where):
        self.draw_prop(context, layout, where, self, 'extrapolation', icon="BLANK1", emboss=True)
        # if self.extrapolation:
        # self.draw_prop(context, layout, box, d, 'extrapolation_axis', icon="BLANK1", emboss=True)
        row = where.row(align=True)
        self.draw_prop(context, layout, row, self, 'extrapolation_limited', icon="BLANK1", emboss=True)
        self.draw_prop(context, layout, row, self, 'extrapolation_limit')

    def draw_transforms(self, context, layout, where):

        self.draw_prop(context, layout, where, self, 'global_rotation', emboss=True, icon="BLANK1")
        if self.global_rotation:
            row = where.row(align=True)
            self.draw_prop(context, layout, row, self, 'global_rotations', text="x", index=0)
            self.draw_prop(context, layout, row, self, 'global_rotations_override', text="", index=0)
            self.draw_prop(context, layout, row, self, 'global_rotations', text="y", index=1)
            self.draw_prop(context, layout, row, self, 'global_rotations_override', text="", index=1)
            self.draw_prop(context, layout, row, self, 'global_rotations', text="z", index=2)
            self.draw_prop(context, layout, row, self, 'global_rotations_override', text="", index=2)
            self.curves[CURVE_GROT].draw(context, layout, where)

        self.draw_prop(context, layout, where, self, 'global_scale', emboss=True, icon="BLANK1")
        if self.global_scale:
            row = where.row(align=True)
            self.draw_prop(context, layout, row, self, 'global_scales', text="x", index=0)
            self.draw_prop(context, layout, row, self, 'global_scales_override', text="", index=0)
            self.draw_prop(context, layout, row, self, 'global_scales', text="y", index=1)
            self.draw_prop(context, layout, row, self, 'global_scales_override', text="", index=1)
            self.draw_prop(context, layout, row, self, 'global_scales', text="z", index=2)
            self.draw_prop(context, layout, row, self, 'global_scales_override', text="", index=2)
            self.curves[CURVE_GSCA].draw(context, layout, where)

        self.draw_prop(context, layout, where, self, 'global_translation', emboss=True, icon="BLANK1")
        if self.global_translation:
            row = where.row(align=True)
            self.draw_prop(context, layout, row, self, 'global_translations', text="x", index=0)
            self.draw_prop(context, layout, row, self, 'global_translations_override', text="", index=0)
            self.draw_prop(context, layout, row, self, 'global_translations', text="y", index=1)
            self.draw_prop(context, layout, row, self, 'global_translations_override', text="", index=1)
            self.draw_prop(context, layout, row, self, 'global_translations', text="z", index=2)
            self.draw_prop(context, layout, row, self, 'global_translations_override', text="", index=2)
            self.curves[CURVE_GMOV].draw(context, layout, where)


class archipack_array_rule(Archipacki18n, GlobalTransforms, PropertyGroup):

    rule_uid: IntProperty(default=-1)

    curves: CollectionProperty(type=archipack_array_curve)

    space_z: FloatProperty(
        name="Spacing z",
        min=0.001,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    repeat_z: IntProperty(
        name="Duplicate z",
        min=1,
        default=1,
        update=update
    )
    repeat_y: IntProperty(
        name="Duplicate y",
        min=1,
        default=1,
        update=update
    )
    space_y: FloatProperty(
        name="Spacing y",
        min=0.001,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    rotation: FloatVectorProperty(
        name="Rotation",
        default=[0, 0, 0],
        size=3,
        min=-2 * pi, max=2 * pi,
        unit='ROTATION', subtype='EULER',
        update=update
    )
    offset: FloatProperty(
        name="Offset",
        default=0,
        precision=5, step=1,
        unit='LENGTH',
        update=update
    )

    alt: FloatProperty(
        name="Altitude",
        default=0,
        precision=5, step=1,
        unit='LENGTH',
        update=update
    )

    # ("AxisAdaptiveSpace", "(Axis) adaptive", "adaptive spacing, items on both sides"),

    rule: EnumProperty(
        items=(
            ("none", "pass through", "use parent rule"),
            ("AxisCenteredItem", "(Object) center", "single item at center, suited to generate objects / mesh"),
            ("AxisItemsOnBothSides", "(Axis) 2 items on border", "2 items on border"),
            ("AxisAdaptiveSpace", "(Axis) adaptive, items on both sides", "space with items on both sides"),
            ("AxisAdaptiveSpaceSideHalf", "(Axis) adaptive, half space on both sides", "adaptive spacing with half space on both sides"),
            ("AxisAdaptiveSpaceSideSpace", "(Axis) adaptive, space on both sides", "adaptive spacing with space on both sizes"),
            ("AxisFixedSpaceSideAdaptive", "(Axis) fixed space", "fixed"),
            ("AxisSubdivide", "(Axis) Subdivide space", ""),
            ("SplitByAngle", "(Axis) split by angle", "split by angle"),
            ("AxisBlueNoise", "(Axis) blue noise with minimal spacing", "Ideal for plants"),

            ("SpaceBetweenAxis", "(Convert) Space between axis", ""),
            ("split", "(Split) split %", "split left and right space"),

            ("SplitSideGapAdaptive", "(Split) sides adaptive / single space absolute", ""),
            ("SplitCornerGapAdaptive", "(Split) corner adaptive / single space absolute", ""),
            ("SplitSideGapFixed", "(Split) sides absolute / single space", ""),
            ("SplitCornerGapFixed", "(Split) corners absolute / single space", ""),
            ("SplitSideGapsAdaptive", "(Split) sides and gaps adaptive / spaces absolute", ""),
            ("SplitCornerGapsAdaptive", "(Split) corners and gaps adaptive / spaces absolute", ""),
            ("SplitSideGapsFixed", "(Split) sides absolute, gaps adaptive / spaces absolute", ""),
            ("SplitCornerGapsFixed", "(Split) corners absolute, gaps adaptive / spaces absolute", ""),
            ("SplitSideGapsFlexible", "(Split) sides / spaces adaptive", ""),
            ("SplitCornerGapsFlexible", "(Split) corners / spaces adaptive", ""),

            ("SelectEveryAxis", "(Select) Every n axis", ""),
            ("SelectEverySpace", "(Select) Every n space", ""),

            ("SelectRandomAxis", "(Select) Random axis", ""),
            ("SelectRandomSpace", "(Select) Random space", ""),

            ("SelectFirstLastAxis", "(Select) First and last axis", ""),
            ("SelectFirstLastSpace", "(Select) First and last space", ""),

        ),
        default="AxisAdaptiveSpace",
        update=update
    )
    # ("split_gaps_every_n_sub_space", "(Select) Every n pair of axis as space", ""),
    # ("split_gaps_random_sub_space", "(Select) Random pair of axis as space", ""),
    # ("split_gaps_first_last_sub_space", "(Select) First and last pair of axis as space", ""),
    # ("split_gaps_x_side", "(Split) sides and spaces adaptive / gaps absolute", ""),
    # ("split_gaps_x_corner", "(Split) corners and spaces adaptive / gaps absolute", ""),

    index: IntProperty(
        min=0
    )
    parent: IntProperty(
        min=-1,
        default=0
    )
    side: IntProperty(
        min=0, max=1,
        default=0,
        update=update
    )
    every: IntProperty(
        min=2,
        default=2,
        update=update
    )
    space: FloatProperty(
        name="Space",
        default=1,
        min=0.001,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )

    adaptive_width_mode: EnumProperty(
        description="Adapt width to available space",
        name='Adaptive width',
        items=adaptive_width_enum,
        update=update
    )
    clamp: BoolProperty(
        name="Clamp",
        description="Limit to available space",
        default=True,
        update=update
    )
    enable: BoolProperty(
        name="Enable",
        default=True,
        update=update
    )
    percent: FloatProperty(
        name="Percent",
        default=50,
        min=0.1,
        max=100,
        subtype='PERCENTAGE',
        update=update
    )
    angle_limit: FloatProperty(
        name="Angle",
        default=0.08726646259971647,
        min=0.01, max=pi/2,
        unit='ROTATION', subtype='ANGLE',
        update=update
    )
    sides: FloatProperty(
        name="Sides",
        description="offset on both sides",
        default=0,
        # min=0,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    n_sub: IntProperty(
        name="Subdivision",
        description="Subdivide into smaller parts",
        min=1,
        default=1,
        update=update
    )
    n_offset: IntProperty(
        name="Offset",
        description="skip n items from start",
        default=0,
        update=update
    )
    n_start: IntProperty(
        name="Start",
        description="n items from start",
        default=1,
        update=update
    )
    n_end: IntProperty(
        name="End",
        description="n items from end",
        default=1,
        update=update
    )
    start: FloatProperty(
        name="Start",
        description="offset at start",
        default=0,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    end: FloatProperty(
        name="End",
        description="offset at end",
        default=0,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    expand_subs: BoolProperty(
        default=True,
        name="Expand subs"
    )
    expand: BoolProperty(
        default=True,
        name="Expand"
    )
    z_up: BoolProperty(
        default=False,
        name="Keep z up",
        update=update
    )
    geometry_id: IntVectorProperty(
        default=[0],
        size=1
    )
    geometry: EnumProperty(
        options={'SKIP_SAVE'},
        name="Generator",
        items=gen_enums,
        get=geometry_getter(0),
        set=geometry_setter(0),
        update=update
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True
    )

    random_rotation: BoolProperty(
        name="Random rotation",
        default=False,
        update=update
    )
    random_rotation_x: FloatProperty(
        name="x",
        default=0,
        min=0, max=pi,
        unit='ROTATION', subtype='ANGLE',
        update=update
    )
    random_rotation_y: FloatProperty(
        name="y",
        default=0,
        min=0, max=pi,
        unit='ROTATION', subtype='ANGLE',
        update=update
    )
    random_rotation_z: FloatProperty(
        name="z",
        default=0,
        min=0, max=pi,
        unit='ROTATION', subtype='ANGLE',
        update=update
    )

    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('RULE', 'Rule', 'Display rules settings', 'NONE', 0),
            ('GEOM', 'Part', 'Display part settings', 'NONE', 1),
            ('TRS', 'Transform', 'Display transform settings override', 'NONE', 2)
        ),
        default='RULE',
    )

    @property
    def two_slots(self):
        return ("Split" in self.rule or "Select" in self.rule) and "SplitByAngle" not in self.rule

    def get_geometry(self):
        geoms = self.parent_data.geometrys
        geom_id = min(len(geoms) - 1, self.geometry_id[0])
        return geoms[geom_id]

    def draw(self, context, layout, where, side, parent, level, has_childs):

        # row = layout.row()
        # box = where.box()
        if level > 0:
            split = where.split(factor=0.02 * level)
            col1 = split.column()
            if has_childs:
                icon = "DISCLOSURE_TRI_RIGHT"
                if self.expand_subs:
                    icon = "DISCLOSURE_TRI_DOWN"
                self.draw_prop(context, layout, col1, self, "expand_subs", text="", icon=icon, emboss=False)
            else:
                self.draw_label(context, layout, col1, "", icon="BLANK1")
            col2 = split.column()
        else:
            col2 = where

        col2 = col2.box()
        row = col2.row(align=True)
        # col2 = col2.box()
        # spacer = "".join(["|"] * depth)
        # if depth > 0:
        # col1.label(text="%s" % (index + 1))
        # row = col1 #.row()
        icon = "TRIA_RIGHT"
        if self.expand:
            icon = "TRIA_DOWN"
        self.draw_prop(context, layout, row, self, "name", text="")
        self.draw_prop(context, layout, row, self, "expand",
            text="{}{}".format(
                side,
                " of %s" % parent if self.rule_uid > 0 else ""
            ),
            icon=icon,
            emboss=True
            )
        # row = col2.row(align=True)
        if self.rule_uid > 0:
            row.operator("archipack.array_rule_move_up", text="", icon="TRIA_UP").index = self.rule_uid
            row.operator("archipack.array_rule_move_down", text="", icon="TRIA_DOWN").index = self.rule_uid
        icon = "HIDE_ON"
        if self.enable:
            icon = "HIDE_OFF"
        row.prop(self, "enable", text="", icon=icon, emboss=True)
        # col2 = box
        if self.expand:

            row = col2.row(align=True)
            self.draw_prop(context, layout, row, self, "tabs", expand=True)

            if self.tabs == 'RULE':

                self.draw_prop(context, layout, col2, self, "rule", text="")
                row = col2.row()
                label = "sub"
                label2 = "spaces"
                if self.two_slots:
                    if "Side" in self.rule:
                        label = "sides / gaps"
                    elif "Corner" in self.rule:
                        label = "corner / gaps"
                    elif "Every" in self.rule:
                        label = "every"
                        label2 = "others"
                    elif "Random" in self.rule or "FirstLast" in self.rule:
                        label = "selected"
                        label2 = "others"
                    else:
                        label = "gaps"
                op = self.draw_op(context, layout, row, "archipack.array_rule_insert", text=label, icon="ADD")
                op.parent = self.rule_uid
                op.side = 0

                if self.two_slots:
                    op = self.draw_op(context, layout, row, "archipack.array_rule_insert", text=label2, icon="ADD")
                    op.parent = self.rule_uid
                    op.side = 1

                if self.rule_uid > 0:
                    self.draw_op(
                        context, layout, row, "archipack.array_rule_copy", text="", icon="DUPLICATE"
                    ).index = self.rule_uid
                    self.draw_op(
                        context, layout, row, "archipack.array_rule_remove", text="", icon="TRASH"
                    ).index = self.rule_uid

                col2.separator()

                if self.rule not in {"none", "SpaceBetweenAxis"}:
                    if self.rule == "SplitByAngle":
                        self.draw_prop(context, layout, col2, self, "angle_limit")
                    elif "Every" in self.rule:
                        self.draw_prop(context, layout, col2, self, "every")
                        self.draw_prop(context, layout, col2, self, "n_offset")
                    else:
                        if "FirstLast" in self.rule:
                            self.draw_prop(context, layout, col2, self, "n_start")
                            self.draw_prop(context, layout, col2, self, "n_end")
                        elif "Subdivide" in self.rule:
                            self.draw_prop(context, layout, col2, self, "n_sub")
                        elif self.rule not in {
                                "SplitSideGapFixed",
                                "AxisItemsOnBothSides",
                                "SplitCornerGapFixed",
                                "AxisCenteredItem",
                                "space"
                            }:
                            if self.rule in {"split"} or "Random" in self.rule:
                                self.draw_prop(context, layout, col2, self, "percent")
                            else:
                                self.draw_prop(context, layout, col2, self, "space")

                        if "Random" not in self.rule and "Every" not in self.rule and "FirstLast" not in self.rule:
                            # col1.label(text=spacer)
                            row = col2.row(align=True)
                            self.draw_prop(context, layout, row, self, "sides")
                            if "Axis" in self.rule:
                                self.draw_prop(context, layout, row, self, "clamp")

                            if self.rule == "AxisCenteredItem":
                                gen = self.get_geometry()
                                if gen.geometry in {'object', 'mesh', 'deformable_mesh'}:
                                    self.draw_label(context, layout, col2, "Adaptive size")
                                    row = col2.row(align=True)
                                    self.draw_prop(context, layout, row, self, 'adaptive_width_mode', expand=True)
                            else:
                                # col1.label(text=spacer)
                                row = col2.row()
                                self.draw_prop(context, layout, row, self, "start")
                                self.draw_prop(context, layout, row, self, "end")
                                # if "split" not in self.rule:

                                self.curves[CURVE_PATH].draw(context, layout, col2)
                # col1.label(text=spacer)

            elif self.tabs == 'GEOM':

                gen = self.get_geometry()
                row = col2.row(align=True)
                row.prop(self, "geometry", text="")

                if gen.geometry != "none":

                    self.draw_prop(context, layout, col2, self, 'alt')
                    self.draw_prop(context, layout, col2, self, 'offset')
                    row = col2.row(align=True)
                    self.draw_prop(context, layout, row, self, 'rotation', text="x", index=0)
                    self.draw_prop(context, layout, row, self, 'rotation', text="y", index=1)
                    self.draw_prop(context, layout, row, self, 'rotation', text="z", index=2)

                    row = col2.row()
                    self.draw_prop(context, layout, row, self, 'space_z')
                    self.draw_prop(context, layout, row, self, 'repeat_z')
                    row = col2.row()
                    self.draw_prop(context, layout, row, self, 'space_y')
                    self.draw_prop(context, layout, row, self, 'repeat_y')

                    if gen.geometry in {'object', 'mesh'}:
                        self.draw_prop(context, layout, col2, self, 'z_up', emboss=True, icon="BLANK1")

                    self.draw_prop(context, layout, col2, self, 'random_rotation', emboss=True, icon="BLANK1")
                    if self.random_rotation:
                        row = col2.row()
                        self.draw_prop(context, layout, row, self, 'random_rotation_x')
                        self.draw_prop(context, layout, row, self, 'random_rotation_y')
                        if gen.geometry in {"post", "object", "mesh", "deformable_mesh"}:
                            self.draw_prop(context, layout, row, self, 'random_rotation_z')

                    col2.separator()
                    gen.draw(context, layout, col2, 0, draw_expand=False)

            elif self.tabs == 'TRS':
                self.draw_limits(context, layout, col2)
                self.draw_transforms(context, layout, col2)

            where.separator()

    def on_create(self):
        if self.rule_uid < 0:
            self.parent_data.new_rule_uid(self)
            # path t modifier
            c = self.curves.add()
            c.on_create(curve_type="NONE", init_points=False)
            # global rotation
            c = self.curves.add()
            c.on_create(curve_type="VECTOR", min_y=-1)

            # global scale
            c = self.curves.add()
            c.on_create(curve_type="VECTOR")

            # global offset
            c = self.curves.add()
            c.on_create(curve_type="VECTOR", min_y=-1)
        else:
            self.curves[CURVE_PATH].on_create(curve_type="NONE", init_points=False)
            self.curves[CURVE_GROT].on_create(curve_type="VECTOR", min_y=-1)
            self.curves[CURVE_GSCA].on_create(curve_type="VECTOR")
            self.curves[CURVE_GMOV].on_create(curve_type="VECTOR", min_y=-1)

    def on_delete(self):
        t = time()
        if self.id_data.users < 2:
            for c in self.curves:
                ng = c.node_group
                if ng is not None:
                    ng.use_fake_user = False
                break
        print("archipack_array_rule on_delete %.6f" % (time() - t))

    @property
    def parent_data(self):
        return self.id_data.archipack_array[0]

    def update(self, context):
        if self.auto_update:
            self.parent_data.update(context)


class archipack_array_part(Archipacki18n, ArchipackSegment, PropertyGroup):
    
    manipulators: CollectionProperty(type=archipack_manipulator)

    @property
    def parent_data(self):
        return self.id_data.archipack_array[0]

    def draw_extra(self, context, layout, index):
        self.draw_prop(context, layout, layout, self, "altitude_ui")


POINT_0 = [[Vector((0, 0))]]
FACE = [[0.5 * Vector(p) for p in
       [(-0.5, -0.5), (-0.5, 0.5), (0.5, 0.5), (0.5, -0.5)]
]]


class archipack_array(Archipacki18n, GlobalTransforms, ArchipackUserDefinedPath, # ArchipackProfile,
                      ArchipackObject, DimensionProvider, Manipulable, PropertyGroup):

    rules: CollectionProperty(type=archipack_array_rule)
    geometrys: CollectionProperty(type=archipack_array_geometry)
    parts: CollectionProperty(type=archipack_array_part)

    curves: CollectionProperty(type=archipack_array_curve)

    rule_uuid: IntProperty(default=0)
    curve_uuid: IntProperty(default=0)
    source_uuid: IntProperty(default=0)

    def new_curve_uid(self, p):
        if p.curve_uid < 0:
            p.curve_uid = self.curve_uuid
            self.curve_uuid += 1

    def new_rule_uid(self, p):
        if p.rule_uid < 0:
            p.rule_uid = self.rule_uuid
            self.rule_uuid += 1
    
    def new_source_uid(self, p):
        if p.source_uid < 0:
            p.source_uid = self.source_uuid
            self.source_uuid += 1
            
    angle_limit: FloatProperty(
        name="Angle",
        description="Split in multiple path when angle is greater than this",
        min=0,
        max=2 * pi,
        default=pi / 12,
        subtype='ANGLE', unit='ROTATION',
        update=update_manipulators
    )

    # ('MATERIALS', '', 'Display materials settings', 'MATERIAL', 2)
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('RULES', 'Rules', 'Display rules settings', 'NONE', 1),
            ('SUB', 'Parts', 'Display parts settings', 'NONE', 2),
            ('PARTS', 'Axis', 'Display array segments settings', 'NONE', 3),
            ('MATERIALS', '', 'Display materials settings', 'MATERIAL', 4)
        ),
        default='MAIN',
    )
    project: BoolProperty(
        name="Project",
        description="Project to keep straight lines on xy plane",
        default=True,
        update=update
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True,
        update=update_manipulators
    )
    dimensions: EnumProperty(
        description="Space use dimensions",
        name="Dimensions",
        items=(
            ("2D", '2d', '2d', 'NONE', 0),
            ("3D", '3d', '3d', 'NONE', 1)
        ),
        default="2D",
        update=update
    )
    repeat_z: IntProperty(
        name="Duplicate z",
        min=1,
        default=1,
        update=update
    )
    space_z: FloatProperty(
        name="Spacing z",
        min=0.001,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    repeat_y: IntProperty(
        name="Duplicate y",
        min=1,
        default=1,
        update=update
    )
    space_y: FloatProperty(
        name="Spacing y",
        min=0.001,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update
    )
    offset: FloatProperty(
        name="Offset",
        default=0,
        precision=5, step=1,
        unit='LENGTH',
        update=update
    )

    random_seed: IntProperty(
        name="Random Seed",
        min=0,
        default=71,
        update=update
    )
    always_closed = False

    def local_bound_x(self, o, tM):
        # x = [(tM @ p.co).x for p in o.data.vertices]
        x = [(tM @ Vector(b)).x for b in o.bound_box]
        min_x = min(x)
        max_x = max(x)
        return min_x, max_x, max(0.001, max_x - min_x)

    def local_bound_y(self, o, tM):
        y = [(tM @ Vector(b)).y for b in o.bound_box]
        min_y = min(y)
        max_y = max(y)
        return min_y, max_y, max(0.001, max_y - min_y)

    def map_material_index(self, f, index_map):
        if f.material_index in index_map:
            return index_map[f.material_index]
        return 0

    def get_mesh_data(self, context, realtime, index_map, s, o, itM, rM, verts, faces, uvs, matids, vcolor, subdivide=0):
        # local -> parent
        tM = itM @ o.matrix_world

        print("get mesh data")

        # rotation (about parent's pivot) -> local
        # _rM = tM.inverted() @ rM @ tM
        # local x min after rotation
        x_min, x_max, x_size = self.local_bound_x(o, rM)
        # local x size after rotation
        scale = x_size / o.dimensions.x
        step = o.dimensions.x / (1 + subdivide)
        x0 = x_min / scale + step
        # s = o.dimensions.x / (1 + subdivide)
        # x = o.bound_box[0][0] + s
        dir = rM.inverted() @ Vector((scale, 0, 0))
        mat_offset = s.material_offset

        offset = len(verts)
        if realtime:
            mat_offset = s.material_offset
            verts.extend([tM @ Vector(v) for v in o.bound_box])
            uvs.extend([[(0, 0), (1, 0), (1, 1), (0, 1)]] * 6)
            faces.extend([[offset + i for i in f] for f in [
                (0, 1, 2, 3),
                (0, 1, 5, 4),
                (1, 2, 6, 5),
                (2, 3, 7, 6),
                (3, 0, 4, 7),
                (4, 5, 6, 7)
            ]])
            matids.extend([mat_offset + 1] * 6)
            col = Vector((1, 1, 1, 1))
            vcolor.extend([col] * 6 * 4)

        else:
            # bm = bmed._start_with_modifiers(context, o)
            bm = bmed._start(o)
            for i in range(subdivide):
                bmed.bisect(bm, (x0 + step * i) * dir, dir)

            layer = bm.loops.layers.uv.verify()
            _verts = bm.verts
            _faces = bm.faces
            _loops = bm.loops

            # XXX must convert to tuple ... without this, uvs got crazy values in the between
            uvs.extend([[tuple(loop[layer].uv) for loop in f.loops] for f in bm.faces])

            verts.extend([tM @ p.co for p in _verts])
            faces.extend([[offset + v.index for v in f.verts] for f in _faces])
            matids.extend([self.map_material_index(f, index_map) for f in _faces])
            vlay = bm.loops.layers.color.get("Archipack")
            if vlay is None:
                col = Vector((1, 1, 1, 1))
                vcolor.extend([col for f in bm.faces for loop in f.loops])
            else:
                vcolor.extend([loop[vlay] for f in bm.faces for loop in f.loops])
            bm.free()
        for c in o.children:
            self.get_mesh_data(context, realtime, index_map, s, c, itM, rM, verts, faces, uvs, matids, vcolor, subdivide)
        return x_size

    def get_generator(self, o=None):
        g = ArrayGenerator(o)
        g.add_parts(self)
        g.line = g.make_offset(self.offset)
        return g

    def setup_manipulators(self):

        if len(self.manipulators) < 1:
            s = self.manipulators.add()
            s.prop1_name = "n_parts"
            s.type_key = 'COUNTER'

        if len(self.manipulators) < 2:
            s = self.manipulators.add()
            s.prop2_name = '{"op1": "archipack.path_split", "op2": "archipack.segment_insert"}'
            s.type_key = "OP_PATH"

        self.setup_parts_manipulators('dumb_z')

    def tree(self):
        # self.rules[0].parent = -1
        tree = {p.rule_uid: [c for c in self.rules if c.parent == p.rule_uid] for p in self.rules}
        for uid, childs in tree.items():
            childs.sort(key=lambda c: c.index)
        # print("tree", {p.index: [(c.index, c.parent) for c in self.rules if c.parent == p.index] for p in self.rules})
        return tree

    def sort_rules(self):
        tree, flat, flat_map = self.flat_tree()
        print([c.index for c in flat])
        for i, c in enumerate(flat):
            c.index = i
        print([c.index for c in flat])

    def _flat_tree(self, tree, p, flat):
        childs = tree[p.rule_uid]
        flat.append(p)
        for c in childs:
            self._flat_tree(tree, c, flat)

    def flat_tree(self):
        tree = self.tree()
        root = self.rules[0]
        flat = []
        self._flat_tree(tree, root, flat)
        flat_map = {c.rule_uid: i for i, c in enumerate(flat)}
        return tree, flat, flat_map

    def rule_by_index(self, index):
        for p in self.rules:
            if p.rule_uid == index:
                return p
        return None

    def remove_rule(self, context, o, index):
        last = self.auto_update
        self.auto_update = False
        p = self.rule_by_index(index)
        for rule in self.rules:
            if rule.parent == p.rule_uid:
                rule.parent = p.parent
        for i, rule in enumerate(self.rules):
            if rule == p:
                p.on_delete()
                self.rules.remove(i)
                break
        self.sort_rules()
        self.auto_update = last

    def duplicate_rule(self, context, o, index):
        last = self.auto_update
        self.auto_update = False
        p = self.rule_by_index(index)
        clipboard = to_dict(p, {'curves', 'rule_uid', 'geometry'})
        clipboard['index'] = len(self.rules)
        clipboard['name'] = p.name + " (copy)"
        p = self.rules.add()
        for attr, val in clipboard.items():
            setattr(p, attr, val)
        p.on_create()
        self.sort_rules()
        # print("p.index, parent", p.index, p.parent)
        self.auto_update = last

    def insert_rule(self, context, o, parent, side):
        last = self.auto_update
        self.auto_update = False
        p = self.rules.add()
        p.parent = parent
        p.side = side
        p.index = -1
        p.name = "%s" % len(self.rules)
        p.on_create()
        self.sort_rules()
        # print("p.index, parent", p.index, p.parent)
        self.auto_update = last

    def move_rule_up(self, context, o, index):
        """ Move up in the stack
        Order is left / up / parent
        :param context:
        :param o:
        :param index:
        :return:
        """
        last = self.auto_update
        self.auto_update = False
        p = self.rule_by_index(index)
        tree, flat, flat_map = self.flat_tree()
        p0 = self.rule_by_index(p.parent)
        two_slots = p0.two_slots
        if two_slots and p.side == 1:
            p.side = 0
        else:
            # move up
            up_index = flat_map[p.rule_uid] - 1
            if up_index > -1:
                up = flat[up_index].rule_uid
                if up == p.parent and up_index > 0:
                    up = flat[up_index-1].rule_uid
                up_index = flat_map[up]
                if flat[up_index].two_slots:
                    p.side = 1
                else:
                    p.side = 0
                p.parent = up
                p.index = -1
                self.sort_rules()

        self.auto_update = last

    def move_rule_down(self, context, o, index):
        """ Move down in the stack
        Order is right / down (not parent)
        :param context:
        :param o:
        :param index:
        :return:
        """
        last = self.auto_update
        self.auto_update = False
        p = self.rule_by_index(index)
        tree, flat, flat_map = self.flat_tree()
        p0 = self.rule_by_index(p.parent)
        two_slots = p0.two_slots
        if two_slots and p.side == 0:
            p.side = 1
        else:
            # move down
            dw_index = flat_map[p.rule_uid] + 1
            if dw_index < len(flat):
                p.parent = flat[dw_index].rule_uid
                p.side = 0
                p.index = -1
            self.sort_rules()
        self.auto_update = last

    def print_tree(self):
        print(
            {p.rule_uid: [c.rule_uid for c in self.rules if c.parent == p.rule_uid] for p in self.rules}
        )

    def draw_subs(self, context, layout, where, ops, tree, p, level=0):
        if level == 0:
            parent = ""
            side = "Root"
        else:
            p0 = self.rule_by_index(p.parent)
            parent = p0.name
            if parent == "":
                if p0.rule_uid == 0:
                    parent = "Root"
                else:
                    parent = p0.rule_uid
            if p0.two_slots:
                if "Side" in p0.rule:
                    side = ("Border", "Space")[p.side]
                elif "Corner" in p0.rule:
                    side = ("Corner", "Space")[p.side]
                elif "Every" in p0.rule:
                    side = ("Every", "Other")[p.side]
                elif "Random" in p0.rule or "FirstLast" in p0.rule:
                    side = ("Selected", "Other")[p.side]
                else:
                    side = ("Gap", "Space")[p.side]
            else:
                side = "Sub"
        has_childs = len(tree[p.rule_uid]) > 0
        p.draw(context, layout, where, side, parent, level, has_childs)
        if p.expand_subs:
            if p.rule_uid in tree:
                for c in tree[p.rule_uid]:
                    self.draw_subs(context, layout, where, ops, tree, c, level + 1)

    def draw(self, context, layout, where):
        ops = self.rules[:]
        tree = self.tree()

        self.draw_subs(context, layout, where, ops, tree, ops[0])

        # ops.sort(key=lambda x: x.index)

            # if p.index == 0:
            #     parent = ""
            #     side = "Root"
            # else:
            #     p0 = ops[p.parent]
            #     parent = p0.name
            #     if parent == "":
            #         if p0.index == 0:
            #             parent = "Root"
            #         else:
            #             parent = p0.rule_uuid
            #
            #     if p0.two_slots:
            #         if "Side" in p0.rule:
            #             side = ("Border", "Space")[p.side]
            #         elif "Corner" in p0.rule:
            #             side = ("Corner", "Space")[p.side]
            #         elif "Every" in p0.rule:
            #             side = ("Every", "Other")[p.side]
            #         elif "Random" in p0.rule or "FirstLast" in p0.rule:
            #             side = ("Selected", "Other")[p.side]
            #         else:
            #             side = ("Gap", "Space")[p.side]
            #     else:
            #         side = "Sub"
            #
            # p.draw(context, layout, where, side, parent)

    def _build_matrix(self, _p, t_local, t_global, _k0, _k1, vz, p, p_t, p_r, p_s, gen, oM, size=None, space=None):

        # Check with deformable_mesh !!
        # might not need this at all
        if gen.rotate_corners:
            # interpolate rotation -> k1 is current segment
            v0, v1 = _k0.v_normalized, _k1.v_normalized
            if gen.geometry in {'rail', 'panel'}:
                # only scale for rail based extrusions
                s = 1 / cos(0.5 * acos(min(1, max(-1, v0 @ v1))))
            else:
                s = 1
            vx = s * (v0 + v1).normalized()

        else:
            vx = _k1.v_normalized

        tM = Matrix.Translation(_p)

        vx_local = vx_slope = vx
        slope = _k1.slope
        vx_z = slope
        # transforms in reverse order (last apply first)
        # global transform apply at object level for all but deformable mesh
        if gen.geometry != 'deformable_mesh':
            tM, vx_local, vx_slope, vx_z = self._global_matrix(p, p_t, p_r, p_s, gen, _k1, vz, t_local, t_global, tM)

            if gen.geometry in {"rail", "panel"}:
                # rail use vx_local when extrapolation is enabled
                if gen.rotate_corners and (self.extrapolation or p.extrapolation):
                    vx = vx_local

            elif slope != 0:
                if gen.geometry == "post":
                    # for post do not rotate unless "rotate on corners" checked
                    vx = vx_slope
                else:
                    # object and mesh
                    if gen.slope:
                        vx = vx_slope

        # adaptive scale
        sM = Matrix()
        if gen.geometry in {'object', 'mesh', 'deformable_mesh'}:
            if p.rule in {"AxisCenteredItem"} and space is not None and p.adaptive_width_mode != 'NONE':
                scale = space / size
                if "Z" in p.adaptive_width_mode:
                    for i in range(3):
                        sM.row[i][i] = scale
                elif "Y" in p.adaptive_width_mode:
                    for i in range(2):
                        sM.row[i][i] = scale
                elif "X" in p.adaptive_width_mode:
                    sM.row[0][0] = scale

        vy = vz.cross(vx)

        if gen.slope and gen.geometry == "object":
            # use rotation instead
            vx.z = vx_z / (vx_local @ vx_slope)
            vx = vx.normalized()
            # vy = vz.cross(vx)
            vz = vx.cross(vy)

        if gen.geometry in {"rail"}:
            # scale on local z axis for slope to keep constant cross section
            sM.col[2][2] = sqrt(1 + (vx_z * vx_z))
            # print(vx_z)
            # print("scale", sM.col[2][2])

        rM = Matrix([
            [vx.x, vy.x, vz.x, 0],
            [vx.y, vy.y, vz.y, 0],
            [vx.z, vy.z, vz.z, 0],
            [0, 0, 0, 1]
        ])

        if p.random_rotation:
            # Random rotation must occur before offset
            oM = oM @ Matrix.Rotation(p.random_rotation_z * uniform(-1.0, 1.0), 4, "Z") @ \
                Matrix.Rotation(p.random_rotation_y * uniform(-1.0, 1.0), 4, "Y") @ \
                Matrix.Rotation(p.random_rotation_x * uniform(-1.0, 1.0), 4, "X")

        if gen.slope:
            # skew for slope in local space
            slM = Matrix([
                [1, 0, 0, 0],
                [0, 1, 0, 0],
                [vx_z / (vx_local @ vx_slope), 0, 1, 0],
                [0, 0, 0, 1]
            ])
        else:
            slM = Matrix()

        return tM, rM, sM, oM, slM

    def _local_matrix(self, p, p_t, p_r, p_s, gen, it, g, _x, _s, t_axis):
        """ Wrapper for global matrix in local space for deformable_mesh
        :param p:
        :param p_t:
        :param p_r:
        :param p_s:
        :param it:
        :param g:
        :param _x:
        :param _s:
        :param t_axis:
        :param slope:
        :return:
        """
        d_max = it.d_max
        _k1 = g.line.segs[_s]
        t_global = t_axis + (_x / d_max)

        # cyclic may end up in out of bound
        if t_global > 1:
            t_global = t_global % 1

        t_local = (t_global * d_max - it.d[_s]) / it.l[_s]

        vz = Z_AXIS
        v_trans = Vector((_x, 0, 0))
        tM = Matrix.Translation(v_trans)
        tM, vx_local, vx_slope, vx_scale = self._global_matrix(
            p, p_t, p_r, p_s, gen, _k1, vz, t_local, t_global, tM, local=True
        )

        # TEST
        vy = vz.cross(vx_local)
        tM = tM @ Matrix([
            [vx_local.x, vy.x, vz.x, 0],
            [vx_local.y, vy.y, vz.y, 0],
            [vx_local.z, vy.z, vz.z, 0],
            [0, 0, 0, 1]
        ])

        tM = tM @ Matrix.Translation(-v_trans)
        return tM

    def _global_matrix(self, p, p_t, p_r, p_s, gen, _k1, vz, t_local, t_global, tM, local=False):
        """
        :param p:
        :param p_t:
        :param p_r:
        :param p_s:
        :param gen:
        :param _k1:
        :param vz:
        :param t_local:
        :param t_global:
        :param tM:
        :param local:
        :return: global matrix, vx_local interpolated, vx_slope not interp with deviation
        """
        extrapolate = self.extrapolation or p.extrapolation
        extrapolation_limited = self.extrapolation_limited
        extrapolate_limit = self.extrapolation_limit

        if p.extrapolation_limited:
            extrapolation_limited = True
            extrapolate_limit = p.extrapolation_limit

        if local:
            vx_local = X_AXIS
            az_local = 0
        else:
            vx_local = _k1.v_normalized
            az_local = _k1.z_angle
        v1 = vx_local
        a1 = az_local

        vx_z = _k1.slope
        vx_slope = vx_local

        if any(p_r) or any(p_t) or any(p_s) or extrapolate:
            # or t_local == 0 or t_local == 1

            if extrapolate:
                if _k1.has_next:
                    _k2 = _k1._next
                else:
                    _k2 = _k1

                if _k1.has_last:
                    _k0 = _k1._last
                else:
                    _k0 = _k1

                if extrapolation_limited:
                    _d1 = _k1.v_length
                    _dmax = min(extrapolate_limit, 0.5 * _d1)
                    _d = _d1 * t_local

                    t0 = max(0, min(1, _d / _dmax))
                    t1 = max(0, min(1, 1 - (_d1 - _d) / _dmax))
                else:
                    t0 = 2 * t_local
                    t1 = 2 * (t_local - 0.5)

                if t_local < 0.5:
                    t = t0
                    if self.curves[CURVE_LERP].use_curve:
                        t = 1 - self.curves[CURVE_LERP].eval_curve(3, 1, (1 - t0))
                    if local:
                        a = _k0.delta_angle(_k1)
                        v0 = Vector((cos(a), sin(a), 0))
                        a0 = 0
                    else:
                        v0 = _k0.v_normalized
                        a0 = _k2.z_angle
                    vs = (v0 + v1).normalized()
                    ve = v1
                    a0 = (a0 + a1)
                    ae = a1
                else:
                    t = t1
                    if self.curves[CURVE_LERP].use_curve:
                        t = self.curves[CURVE_LERP].eval_curve(3, 1, t1)
                    if local:
                        a = _k2.delta_angle(_k1)
                        v2 = Vector((cos(a), sin(a), 0))
                        a2 = 0
                    else:
                        v2 = _k2.v_normalized
                        a2 = _k2.z_angle
                    vs = v1
                    ve = (v1 + v2).normalized()
                    a0 = a1
                    ae = (a1 + a2)
                vx_local = (vs * (1 - t) + ve * t).normalized()
                az_local = (a0 * (1 - t) + ae * t)
            else:
                vx_local = v1
                az_local = a1

        vy_local = vz.cross(vx_local)

        if any(p_t):
            t = [
                _p.curves[CURVE_GMOV].eval_curve(i, 1, t_global)
                if _p is not None and _p.curves[CURVE_GMOV].use_curve else 1
                for i, _p in enumerate(p_t)
            ]
            xyz = [
                _p.global_translations[i] * t[i]
                if _p is not None else 0
                for i, _p in enumerate(p_t)
            ]

            vx_z = vx_local.z
            # transform may use slope ?
            if gen.slope:
                vx_z = _k1.slope

            # in reverse order (last apply first)
            # global rotation along z axis
            tM = tM @ Matrix.Translation(
                Matrix([
                    [vx_local.x, vy_local.x, vz.x, 0],
                    [vx_local.y, vy_local.y, vz.y, 0],
                    [vx_z, vy_local.z, vz.z, 0],
                    [0, 0, 0, 1]
                ]) @ Vector(xyz)
            )

        if any(p_r) or extrapolate:

            t = [
                _p.curves[CURVE_GROT].eval_curve(i, 1, t_global)
                if _p is not None and _p.curves[CURVE_GROT].use_curve else 1
                for i, _p in enumerate(p_r)
            ]
            rxyz = [
                _p.global_rotations[i] * t[i]
                if _p is not None else 0
                for i, _p in enumerate(p_r)
            ]

            if rxyz[2] != 0:
                tM = tM @ Matrix.Rotation(rxyz[2], 4, vz)

            if rxyz[1] != 0:
                # global rotation along y axis (in direction of line)
                tM = tM @ Matrix.Rotation(rxyz[1], 4, vy_local)

            # with slope, there is a deviation of vx vector
            # slope projection on y direction when x axis rotate
            #
            #  ____|     x axis deviation from -> sin(global_rotation_x) * slope
            #
            if vx_z != 0 and rxyz[0] != 0:
                # vector with deviation on z axis to compensate for slope
                vx_slope = Matrix.Rotation(atan2(vx_z * sin(rxyz[0]), 1), 4, vz) @ vx_slope
                # slope depends on x rotation
                vx_z = vx_z * cos(rxyz[0])

            # project on x axis  extrapolate and gen.rotate_corners and
            if self.project:
                x = abs(v1 @ vx_local)
                # x = abs(v1 @ vx_slope)
                s = 1
                if x != 0:
                    s = 1 / min(1, x)
                # scale on z axis instead

                # tM = tM @ Matrix.Scale(cos(az_local), 4, vz)
                tM = tM @ Matrix.Scale(s, 4, vy_local)

            # global rotation along  x axis (side from line)
            tM = tM @ Matrix.Rotation(rxyz[0], 4, vx_local)

        # global scale, does not use interpolated axis
        if any(p_s):
            t = [
                _p.curves[CURVE_GSCA].eval_curve(i, 1, t_global)
                if _p is not None and _p.curves[CURVE_GSCA].use_curve else 1
                for i, _p in enumerate(p_s)
            ]
            sxyz = [
                1 + _p.global_scales[i] * t[i]
                if _p is not None else 1
                for i, _p in enumerate(p_s)
            ]
            tM = tM @\
                 Matrix.Scale(sxyz[0], 4, X_AXIS) @ \
                 Matrix.Scale(sxyz[1], 4, Y_AXIS) @ \
                 Matrix.Scale(sxyz[2], 4, Z_AXIS)

        return tM, vx_local, vx_slope, vx_z

    def _make_matrix(self, g, ps, p, p_t, p_r, p_s, gen, oM, size=None, space=None):
        pos, seg, last, t_local, t_global = ps
        if len(pos) < 1:
            return []

        # print("seg", seg, "last", last)

        # build matrix
        if space is not None:
            return [
                self._build_matrix(
                    _p, _t_local, _t_global, g.line.segs[i], g.line.segs[j],
                    Z_AXIS, p, p_t, p_r, p_s, gen, oM, _size, _space
                )
                for _p, i, j, _t_local, _t_global, _size, _space
                in zip(pos, last, seg, t_local, t_global, size, space)
            ]
        return [
            self._build_matrix(
                _p, _t_local, _t_global, g.line.segs[i], g.line.segs[j],
                Z_AXIS, p, p_t, p_r, p_s, gen, oM
            )
            for _p, i, j, _t_local, _t_global
            in zip(pos, last, seg, t_local, t_global)
        ]

    def _vertical_profile(self, p):
        x, y = p
        return Vector((-x, y, 0))

    def _horizontal_profile(self, p):
        x, y = p
        # return Vector((x, 0, y))
        return Vector((0, x, y))

    def vertical_profile(self, rM, profile):
        return [[rM @ self._vertical_profile(p) for p in _p] for _p in profile]

    def horizontal_profile(self, rM, profile):
        return [[rM @ self._horizontal_profile(p) for p in _p] for _p in profile]

    def horizontal_loft(self, g, ps, profile, closed_shape, closed_path, uv, gen, p, p_t, p_r, p_s, oM, idmat,
                        verts, faces, matids, vcolors, uvs):

        transform = self._make_matrix(g, ps, p, p_t, p_r, p_s, gen, oM)
        # build faces using Panel
        n_profile = len(profile)

        if closed_path:
            transform.pop()

        n_sections = len(transform)
        if n_sections < 2:
            return
        lofter = Lofter(
            # closed_shape, index, x, y, idmat
            closed_shape,
            [i for i in range(n_profile)],
            [_p.x for _p in profile],
            [_p.z for _p in profile],
            [idmat] * n_profile,
            closed_path=closed_path,
            user_path_uv_v=uv,
            user_path_verts=n_sections
        )
        v = Vector((0, 0))
        color = self.random_color
        offset = len(verts)
        _tM = [tM @ rM @ oM @ sM for tM, rM, sM, _oM, slM in transform]
        verts.extend([
            tM @ _p
            for tM in _tM
            for _p in profile
        ])
        faces.extend(lofter.faces(16, offset=offset, path_type='USER_DEFINED'))
        matids.extend(lofter.mat(16, idmat, idmat, path_type='USER_DEFINED'))
        vcolors.extend(lofter.vcolors(16, color, path_type='USER_DEFINED'))
        uvs.extend(lofter.uv(16, v, v, v, v, 0, v, 0, 0, path_type='USER_DEFINED'))

    def vertical_loft(self, g, ps, profile, closed_shape, closed_path, gen, p, p_t, p_r, p_s, oM, idmat,
                      verts, faces, matids, vcolors, uvs):

        # pos, seg = ps
        transform = self._make_matrix(g, ps, p, p_t, p_r, p_s, gen, oM)
        if len(transform) < 1:
            return

        n_profile = len(profile)
        n_sections = 2
        # build faces using Panel
        lofter = Lofter(
            # closed_shape, index, x, y, idmat
            closed_shape,
            [i for i in range(n_profile)],
            [_p.x for _p in profile],
            [_p.y for _p in profile],
            [idmat for i in range(n_profile)],
            closed_path=closed_path,
            user_path_uv_v=[0, gen.z],
            user_path_verts=n_sections
        )
        offset = len(verts)
        # add top profile
        # py = [_p.y for _p in profile]
        # dy = (max(py) - min(py))
        _profile = profile + [Vector((_p.x, _p.y, _p.z + gen.z)) for _p in profile]

        # @ slM
        _tM = [tM @ rM @ slM @ oM for tM, rM, sM, _oM, slM in transform]

        verts.extend([
            tM @ _p
            for tM in _tM
            for _p in _profile
            ])

        v = Vector((0, 0))

        for i in range(len(transform)):
            color = self.random_color
            faces.extend(lofter.faces(16, offset=offset + i * 2 * n_profile, path_type='USER_DEFINED'))
            matids.extend(lofter.mat(16, idmat, idmat, path_type='USER_DEFINED'))
            vcolors.extend(lofter.vcolors(16, color, path_type='USER_DEFINED'))
            uvs.extend(lofter.uv(16, v, v, v, v, 0, v, 0, 0, path_type='USER_DEFINED'))

    def remove_objects(self, context, childs, to_remove):
        rem = [c for c in reversed(childs)]
        for child in rem:
            if to_remove < 1:
                return
            to_remove -= 1
            childs.pop()
            self.delete_object(context, child)

    def create_empty(self, context, c, name, prefix):
        """
        :param context:
        :param o:
        :return:
        """
        o = bpy.data.objects.new("%s_%s" % (prefix, name), None)
        o.matrix_world = c.matrix_world.copy()
        self.link_object_to_scene(context, o, layer_name="array")
        o.hide_select = True
        o.empty_display_type = 'ARROWS'
        o.empty_display_size = 0.05
        c.parent = o
        return o

    def create_collection_instance(self, context, _d):
        c = bpy.data.objects.new(_d.name, None)
        c.instance_type = "COLLECTION"
        c.instance_collection = _d.source('collection')
        self.link_object_to_scene(context, c, layer_name="array")
        return c

    def duplicate_source(self, context, o):
        """ Ensure dups are visible to render
        :param context:
        :param o:
        :return:
        """
        dup = self.duplicate_object(context, o, linked=True, layer_name="array")
        dup.hide_render = False
        dup.hide_set(state=False)
        return dup

    def update_objects(self, context, o, gen, sources, occurrences):
        childs = []

        source_uids = gen.source_uids

        for _d, _s, occur in occurrences:

            if occur > 0:
                source_uids.remove(_d.source_uid)

            subs = [
                c for c in o.children
                if "archipack_source" in c and c["archipack_source"] == _d.source_uid
            ]

            # real childs
            n_childs = len(subs)

            # remove child
            if n_childs > occur:
                self.remove_objects(context, subs, n_childs - occur)

            if n_childs < occur:
                new_subs = []
                if _d.source_type in {"OBJECT", "MESH", "PRIMITIVE"}:
                    new_subs = [
                        self.create_empty(
                            context,
                            self.create_empty(
                                context,
                                self.duplicate_source(context, _s),
                                _s.name, "Skew"
                            ),
                            _s.name, "Slope"
                        )
                        for i in range(occur - n_childs)
                    ]

                elif _d.source_type == "COLLECTION":
                    new_subs = [
                        self.create_empty(
                            context,
                            self.create_empty(
                                context,
                                self.create_collection_instance(context, _d),
                                _d.name, "Skew"
                            ),
                            _d.name, "Slope"
                        )
                        for i in range(occur - n_childs)
                    ]

                for c in new_subs:
                    c["archipack_source"] = _d.source_uid

                subs.extend(new_subs)

            childs.append(subs)

        # remove subs not found at all in occurrences
        subs = [
            c for c in o.children
            if "archipack_source" in c and c["archipack_source"] in source_uids
        ]
        if len(subs) > 0:
            self.remove_objects(context, subs, len(subs))

        return [childs[i].pop() for i in sources]

    def compute_space(self, it, p, d):
        sides = 2 * p.sides
        spaces = it.filter_empty_space(d)
        return [_s - _d[i] - sides for _d in spaces for i, _s in enumerate(_d[1:])]

    def limit_on_segments(self, g, p, it, d):
        # filter out points outside of limits of segment
        l = d
        if p.offset != 0:
            # compute segments limits
            line = g.line.make_offset(p.offset)
            d_end = 0
            d_lims = []
            for _d, _k in zip(it.d, line.segs):
                # relative space at segment start
                d_start = _d - d_end
                # absolute d_end
                d_end = _d + d_start + _k.v_length
                d_lims.append((_d + d_start, d_end))
            # flatten l arrays
            _l_flat = it.haystack(d)
            segs = it.segs(_l_flat)
            # filter out points
            l = [[_l
                  for j, _l in enumerate(_l_flat)
                  if d_lims[segs[j]][0] < _l < d_lims[segs[j]][1]
                  ]]
        return l

    def z_up(self, tM):
        loc = tM.translation
        sx, sy, sz = tM.to_scale()
        vy = tM.col[1].to_3d()
        vx = vy.cross(Z_AXIS).normalized()
        vy = Z_AXIS.cross(vx)
        return Matrix([
            [sx * vx.x, sx * vy.x, 0, loc.x],
            [sy * vx.y, sy * vy.y, 0, loc.y],
            [sz * vx.z, sz * vy.z, sz, loc.z],
            [0, 0, 0, 1]
        ])

    def remove_childs(self, context, o, gen):
        source_uids = gen.source_uids
        childs = [
            c for c in o.children
            if "archipack_source" in c and c["archipack_source"] in source_uids
        ]
        self.remove_objects(context, childs, len(childs))

    def sub_update(
            self, context, o, g, realtime, index_map, tree, p, p_t, p_r, p_s, alt_off_rot, it, d,
            verts, faces, matids, vcolors, uvs
    ):

        if p.global_translation:
            p_t = [p if state else _p for _p, state in zip(p_t, p.global_translations_override)]
        if p.global_rotation:
            p_r = [p if state else _p for _p, state in zip(p_r, p.global_rotations_override)]
        if p.global_scale:
            p_s = [p if state else _p for _p, state in zip(p_r, p.global_scales_override)]

        # pass to children
        z0, o0, r0, r1, r2 = alt_off_rot
        alt_off_rot = [
            a + b for a, b in zip(alt_off_rot, [p.alt, p.offset, p.rotation[2], p.rotation[1], p.rotation[0]])
        ]

        _d = d[p.side]

        gen = p.get_geometry()

        if len(_d) < 1:
            return

        t = time()
        # # Rules
        if p.rule in globals():
            print("found rule", p.rule)
            rule = globals()[p.rule]()
            l, r = rule.compute(it, _d, p)
        else:
            print("missing rule", p.rule)
            l = r = _d

        print("%s %.6f" % (p.rule, time() - t))

        if p.enable and gen.geometry != "none":
            t = time()

            # print("l", l)
            # print("_d", _d)

            closed_shape = [True]
            closed_path = False

            mat = gen.id_mat(MAT_RAIL)

            # Profile based geometry
            if gen.geometry == "vert":
                profile = POINT_0
            elif gen.geometry == "face":
                profile = FACE
            elif gen.geometry in {"rail", "post", "panel"}:

                x = 0.5 * gen.profil_x
                y = 0.5 * gen.profil_y
                if gen.profil == 'SQUARE':
                    profile = [[(-x, -y), (x, -y), (x, y), (-x, y)]]
                elif gen.profil == 'CIRCLE':
                    profile = [[(x * sin(0.1 * -a * pi), x * (0.5 + cos(0.1 * -a * pi))) for a in range(0, 20)]]
                elif gen.profil == 'SAFETY':
                    closed_shape = [False]
                    profile = [
                        [(i * x, j * y) for i, j in [
                            (0, -0.5),
                            (1, -0.35714),
                            (1, -0.21429),
                            (0, -0.07143),
                            (0, 0.07143),
                            (1, 0.21429),
                            (1, 0.35714),
                            (0, 0.5)]
                         ]
                    ]
                elif gen.profil == 'USER':
                    curve = gen.update_profile(context)
                    if curve and curve.type == 'CURVE':
                        sx, sy = 1, 1
                        if gen.user_profile_dimension.x > 0:
                            sx = gen.profil_x / gen.user_profile_dimension.x
                        if gen.user_profile_dimension.y > 0:
                            sy = gen.profil_y / gen.user_profile_dimension.y
                        wM = Matrix([
                            [sx, 0, 0, 0],
                            [0, sy, 0, 0],
                            [0, 0, 1, 0],
                            [0, 0, 0, 1]
                        ])
                        profile = [
                            [(p.x, p.y) for p in gen.coords_from_spline(spline, wM, 12, cw=True)]
                            for spline in curve.data.splines
                        ]
                        closed_shape = [spline.use_cyclic_u for spline in curve.data.splines]

                    else:
                        print("fence.update curve not found")
                        profile = FACE

            # Create geometry
            if gen.geometry in {'rail', 'panel'}:
                #
                psi = it.intersect(l)

                # subdivide along line to support global rotation
                if any(p_r) or any(p_s) or any(p_t) and gen.subdivide > 0:
                    psi = it.subdivide(psi, gen.subdivide)

                # print("psi", psi)
                rM = Matrix.Rotation(r2 + p.rotation[0], 4, "X")
                _profile = self.horizontal_profile(rM, profile)

                # close only when start and end match whole path and path is not split
                closed_path = self.is_closed and len(l) == 1 and l[0][0] == 0 and l[0][-1] == it.d[-1]

                if gen.geometry == 'panel':
                    z0 += 0.5 * gen.profil_y
                for _d in psi:

                    ps = it.lerp(_d)

                    for i in range(p.repeat_y):
                        for j in range(p.repeat_z):
                            # Offset matrix

                            oM = Matrix.Translation((0, -o0 - p.offset - i * p.space_y, z0 + p.alt + j * p.space_z))

                            if p.random_rotation:
                                oM = oM @ \
                                     Matrix.Rotation(p.random_rotation_y * uniform(-1.0, 1.0), 4, "Y") @ \
                                     Matrix.Rotation(p.random_rotation_x * uniform(-1.0, 1.0), 4, "X")

                            for _p, closed in zip(_profile, closed_shape):
                                self.horizontal_loft(g, ps, _p, closed, closed_path, _d, gen, p, p_t, p_r, p_s, oM, mat,
                                                     verts, faces, matids, vcolors, uvs)

            elif gen.geometry in {'post'}:
                rM = Matrix.Rotation(p.rotation[1], 4, "Y") @ \
                     Matrix.Rotation(p.rotation[0], 4, "X")
                _profile = self.vertical_profile(Matrix.Rotation(r0 + p.rotation[2], 4, "Z"), profile)

                # with offset, items may cross inside sharp edges
                # l_temp = self.limit_on_segments(g, p, it, l)
                # ps = it.lerp(l_temp)
                ps = it.lerp(l)

                for i in range(p.repeat_y):
                    for j in range(p.repeat_z):
                        # Offset matrix
                        oM = Matrix.Translation((0, -o0 - p.offset - i * p.space_y, z0 + p.alt + j * p.space_z)) @ rM
                        for _p, closed in zip(_profile, closed_shape):
                            self.vertical_loft(g, ps, _p, closed, False, gen, p, p_t, p_r, p_s, oM, mat,
                                          verts, faces, matids, vcolors, uvs)

            elif gen.geometry in {'vert', 'face'}:
                points = [it.lerp(l)]
                transform = []

                for i in range(p.repeat_y):
                    for j in range(p.repeat_z):
                        oM = Matrix.Translation((0, -o0 - p.offset - i * p.space_y, z0 + p.alt + j * p.space_z))
                        for ps in points:
                            transform.extend(self._make_matrix(g, ps, p, p_t, p_r, p_s, gen, oM))

                rM = Matrix.Rotation(r0 + p.rotation[2], 4, "Z") @ \
                     Matrix.Rotation(p.rotation[1], 4, "Y") @ \
                     Matrix.Rotation(p.rotation[0], 4, "X")
                _profile = self.vertical_profile(rM, profile)

                _p = _profile[0]
                offset = len(verts)
                _tM = [tM @ rM @ sM @ oM for tM, rM, sM, oM, slM in transform]
                verts.extend([tM @ pt for tM in _tM for pt in _p])
                if gen.geometry == "face":
                    color = self.random_color
                    n_trs = len(transform)
                    n_pts = len(_p)
                    f_idx = range(offset, offset + n_pts)
                    faces.extend([[j + (i * n_pts) for j in f_idx] for i in range(n_trs)])
                    matids.extend([mat] * n_trs)
                    vcolors.extend([color] * (n_pts * n_trs))
                    uvs.extend([profile[0] for i in range(n_trs)])

            elif gen.geometry == 'object':
                if gen.has_valid_geometry:

                    # with offset, items may cross inside sharp edges
                    # this also lower number of segments !!
                    # l = self.limit_on_segments(g, p, it, l)

                    # the issue here is to handle correct number of items
                    # when sides > space

                    ps = it.lerp(l)

                    # when rule is single item at axis, remove 1 item from each space
                    if p.rule == "AxisCenteredItem":

                        # XXX stupid as this will match ps[0] in all cases
                        # try:
                        #     # between spaces
                        #     iter(_d[0])
                        #     n_items = sum([len(_di) - 1 for _di in _d])
                        # except:
                        #     # between axis
                        #     print("compute_scale between axis..")
                        #     n_items = len(_d) - 1

                        # compute available space between points -> skip empty ones
                        x_space = self.compute_space(it, p, _d)

                    else:
                        x_space = None

                    n_items = len(ps[0])

                    if n_items > 0:

                        sources, occurrences = gen.pick_sources(
                            self.repeat_z * p.repeat_y * p.repeat_z * n_items,
                            gen.source_random, "any"
                        )
                        if len(occurrences) > 0:
                            # compute sizes for occurrences

                            x_sizes = []
                            pre_transform = []

                            for _s, c, occur in occurrences:
                                itM, tM, rM, sM = _s.pre_transform(c)
                                pre_transform.append(tM)
                                if _s.source_type in {"MESH", "OBJECT"}:
                                    x_min, x_max, x_size = self.local_bound_x(c, tM)
                                    x_sizes.append(x_size)
                                elif _s.source_type == "COLLECTION":
                                    x_sizes.append(-1)

                            # compute sizes array
                            if len(x_sizes) < 2:
                                x_size = [[[[x_sizes[0]] * n_items] * p.repeat_z] * p.repeat_y] * self.repeat_z
                            else:
                                n_k = n_items
                                n_j = n_k * p.repeat_z
                                n_i = n_j * p.repeat_y
                                x_size = [
                                    [
                                        [
                                            [
                                                x_sizes[sources[m + k * n_k + n_j * j + n_i * i]]
                                                for m in range(n_items)
                                            ]
                                            for k in range(p.repeat_z)
                                        ]
                                        for j in range(p.repeat_y)
                                    ]
                                    for i in range(self.repeat_z)
                                ]

                            transform = []
                            rM = Matrix.Rotation(r0 + p.rotation[2], 4, "Z") @ \
                                 Matrix.Rotation(p.rotation[1], 4, "Y") @ \
                                 Matrix.Rotation(p.rotation[0], 4, "X")

                            for i in range(self.repeat_z):
                                for j in range(p.repeat_y):
                                    for k in range(p.repeat_z):

                                        oM = Matrix.Translation(
                                            (0, -o0 - p.offset - j * p.space_y, z0 + p.alt + i * self.space_z + k * p.space_z)
                                        ) @ rM

                                        transform.extend(
                                            self._make_matrix(
                                                g, ps, p, p_t, p_r, p_s, gen, oM,
                                                size=x_size[i][j][k],
                                                space=x_space
                                            )
                                        )

                            childs = self.update_objects(context, o, gen, sources, occurrences)

                            # slope (object)
                            # rotation object -> 45 deg
                            # rotation skew helper (from parent with slope)
                            # da = -0.5 * (a_slope+90)
                            # scale skew helper
                            # sz = sqrt(2)*0.5/sin(da)
                            # sx = sqrt(2)*0.5/cos(da)
                            # object's scale z
                            # cos(-a_slope)

                            for j, _tM, c in zip(sources, transform, childs):
                                tM, rM, sM, oM, slM = _tM
                                # scale matrix must apply to object
                                skew_M = Matrix()

                                if gen.slope:
                                    # slope angle
                                    a = asin(rM.col[0][2])
                                    # print("a", degrees(a))
                                    # Skew helper (from parent with slope)
                                    da = 0.5 * (a + pi / 2)
                                    skew_M.col[0][0] = sqrt(2) * 0.5 / cos(da)
                                    skew_M.col[2][2] = sqrt(2) * 0.5 / sin(da)
                                    skew_M = Matrix.Rotation(-pi / 2 + da, 4, Y_AXIS) @ skew_M
                                    # object's scale z
                                    sM = sM @ Matrix.Scale(cos(-a), 4, Z_AXIS)
                                    sM = Matrix.Rotation(pi/4, 4, Y_AXIS) @ sM

                                # print("rM\n", rM)
                                # print("sM\n", sM)
                                # print("oM\n", oM)
                                # print("pre_transform[j]\n", pre_transform[j])
                                # sM = rM.inverted() @ sM @ rM
                                # print("sM\n", sM)
                                tM = tM @ rM @ oM
                                # print("tM\n", tM)
                                if p.z_up:
                                    tM = self.z_up(tM)
                                # TODO: split in to parent child where child follow line so scale apply in child matrix
                                c.parent = o
                                c.matrix_world = o.matrix_world @ tM
                                # c.children[0].matrix_world = o.matrix_world @ tM @ pre_transform[j]
                                # c.matrix_world = o.matrix_world @ tM @ sM
                                # Transform
                                c.children[0].matrix_world = o.matrix_world @ tM
                                # Object
                                c.children[0].children[0].matrix_world = o.matrix_world @ tM @ sM @ pre_transform[j]
                                # Skew
                                c.children[0].matrix_world = o.matrix_world @ tM @ skew_M
                                c.matrix_world = o.matrix_world @ tM

            elif gen.geometry == 'mesh':
                if gen.has_valid_geometry:

                    _verts, _faces, _matid, _uvs, _vcolor = [], [], [], [], []

                    ps = it.lerp(l)

                    # when rule is single item at axis, remove 1 item from each space
                    if p.rule == "AxisCenteredItem":

                        # XXX stupid as this will match ps[0] in all cases
                        # try:
                        #     # between spaces
                        #     iter(_d[0])
                        #     n_items = sum([len(_di) - 1 for _di in _d])
                        # except:
                        #     # between axis
                        #     print("compute_scale between axis..")
                        #     n_items = len(_d) - 1

                        # compute available space between points -> skip empty ones
                        x_space = self.compute_space(it, p, _d)

                    else:
                        x_space = None

                    n_items = len(ps[0])

                    if n_items > 0:
                        sources, occurrences = gen.pick_sources(
                            p.repeat_y * p.repeat_z * n_items,
                            gen.source_random, "mesh"
                        )

                        if len(occurrences) > 0:

                            # compute available space between points
                            # print("_d", _d)
                            # x_space = self.compute_space(p, _d)

                            # compute sizes for occurrences
                            # pre_transform = []
                            x_sizes = []
                            for _s, c, occur in occurrences:

                                # pre_transform.append(tM)
                                itM, tM, rM, sM = _s.pre_transform(c)
                                _tmp_verts, _tmp_faces, _tmp_uvs, _tmp_matid, _tmp_vcolor = [], [], [], [], []
                                x_size = self.get_mesh_data(
                                    context, realtime, index_map[c.name],
                                    _s, c, itM, rM @ sM, _tmp_verts, _tmp_faces, _tmp_uvs, _tmp_matid, _tmp_vcolor
                                )
                                _verts.append(_tmp_verts)
                                _faces.append(_tmp_faces)
                                _uvs.append(_tmp_uvs)
                                _matid.append(_tmp_matid)
                                _vcolor.append(_tmp_vcolor)
                                x_sizes.append(x_size)

                            # compute sizes array
                            if len(x_sizes) < 2:
                                x_size = [[[x_sizes[0]] * n_items] * p.repeat_z] * p.repeat_y
                            else:
                                n_j = n_items
                                n_i = n_j * p.repeat_z
                                x_size = [
                                        [
                                            [
                                                x_sizes[sources[m + n_j * j + n_i * i]]
                                                for m in range(n_items)
                                            ]
                                            for j in range(p.repeat_z)
                                        ]
                                        for i in range(p.repeat_y)
                                    ]

                            transform = []
                            rM = Matrix.Rotation(r0 + p.rotation[2], 4, "Z") @ \
                                 Matrix.Rotation(p.rotation[1], 4, "Y") @ \
                                 Matrix.Rotation(p.rotation[0], 4, "X")
                            for i in range(p.repeat_y):
                                for j in range(p.repeat_z):
                                    oM = Matrix.Translation(
                                        (0, -o0 - p.offset - i * p.space_y, z0 + p.alt + j * p.space_z)
                                    ) @ rM

                                    transform.extend(
                                        self._make_matrix(
                                            g, ps, p, p_t, p_r, p_s, gen, oM,
                                            size=x_size[i][j],
                                            space=x_space
                                        )
                                    )

                            for j, _tM in zip(sources, transform):
                                tM, rM, sM, oM, slM = _tM
                                tM = tM  @ rM @ slM @ oM @ sM
                                if p.z_up:
                                    tM = self.z_up(tM)
                                # print(j, tM)
                                offset = len(verts)
                                verts.extend([tM @ _p for _p in _verts[j]])
                                faces.extend([[offset + i for i in f] for f in _faces[j]])
                                matids.extend(_matid[j])
                                uvs.extend(_uvs[j])
                                vcolors.extend(_vcolor[j])

            elif gen.geometry == 'deformable_mesh':
                if gen.has_valid_geometry:

                    _verts, _faces, _matid, _uvs, _vcolor = [], [], [], [], []

                    ps = it.lerp(l)

                    n_items = len(ps[0])

                    # when rule is single item at axis, remove 1 item from each space
                    if p.rule == "AxisCenteredItem":
                        # # compute items count
                        # try:
                        #     # between spaces
                        #     iter(_d[0])
                        #     n_items = sum([len(_di) - 1 for _di in _d])
                        # except:
                        #     # between axis
                        #     print("compute_scale between axis..")
                        #     n_items = len(_d) - 1
                        # compute available space between points
                        x_space = self.compute_space(it, p, _d)
                        # print("x_space", x_space)

                    else:
                        # n_items = len(ps[0])
                        x_space = [1] * n_items

                    if n_items > 0:
                        sources, occurrences = gen.pick_sources(
                            p.repeat_y * p.repeat_z * n_items,
                            gen.source_random, "mesh"
                        )

                        if len(occurrences) > 0:

                            # compute sizes for occurrences

                            x_sizes = []

                            # rotate vertices
                            _rM = Matrix.Rotation(r0 + p.rotation[2], 4, "Z") @ \
                                 Matrix.Rotation(p.rotation[1], 4, "Y") @ \
                                 Matrix.Rotation(p.rotation[0], 4, "X")

                            for _s, c, occur in occurrences:
                                itM, tM, rM, sM = _s.pre_transform(c)
                                _itM = tM @ _rM @ c.matrix_world.inverted()
                                _tmp_verts, _tmp_faces, _tmp_uvs, _tmp_matid, _tmp_vcolor = [], [], [], [], []
                                x_size = self.get_mesh_data(
                                    context, realtime, index_map[c.name],
                                    _s, c, _itM, rM @ sM @ _rM,
                                    _tmp_verts, _tmp_faces, _tmp_uvs, _tmp_matid, _tmp_vcolor,
                                    gen.subdivide
                                )
                                _verts.append(_tmp_verts)
                                _faces.append(_tmp_faces)
                                _uvs.append(_tmp_uvs)
                                _matid.append(_tmp_matid)
                                _vcolor.append(_tmp_vcolor)
                                x_sizes.append(x_size)

                            # print(_uvs[0])

                            # compute sizes array
                            if len(x_sizes) < 2:
                                x_size = [[[x_sizes[0]] * n_items] * p.repeat_z] * p.repeat_y
                            else:
                                n_j = n_items
                                n_i = n_j * p.repeat_y
                                x_size = [
                                    [
                                        [
                                            x_sizes[sources[m + n_j * j + n_i * i]]
                                            for m in range(n_items)
                                        ]
                                        for j in range(p.repeat_y)
                                    ]
                                    for i in range(p.repeat_z)
                                ]

                            # max space for each source
                            x_space_by_source = [[]] * len(occurrences)

                            for i, space in enumerate(x_space):
                                x_space_by_source[sources[i]].append(space)

                            # max width to look for bend segments
                            widths = [0.5 * max(spaces) for spaces in x_space_by_source]

                            slope = gen.slope

                            transform = []
                            bend = []

                            # compute bend matrix including slope
                            n_segs = len(g.line.segs)
                            t_axis = []
                            # rM = Matrix.Rotation(r0 + p.rotation, 4, 'Z')

                            pos, seg, last, t_local, _t_global = ps

                            t_axis.extend(_t_global)
                            j = 0
                            for p0, s in zip(pos, seg):
                                width = widths[sources[j]]
                                j += 1
                                bend_pt = [[], []]

                                _k = g.line.segs[s]
                                s_len = _k.v_length
                                res, _, t0 = _k.point_sur_segment(Vector(p0))
                                _k0 = _k
                                _d0 = 0
                                _d = (1 - t0) * s_len
                                _s = s
                                _dz = _k.slope * _d
                                # compute bend points right part
                                while _d0 < width:
                                    # add a bend point
                                    _s += 1
                                    if _s >= n_segs:
                                        if _k0.has_next:
                                            _k1 = _k0._next
                                        else:
                                            _k1 = _k0
                                    else:
                                        _k1 = g.line.segs[_s]
                                    a = _k1.delta_angle(_k0)
                                    # a = _k0.delta_angle(_k1)
                                    # move z points > _d + rotate & skew _d > points > _d0
                                    if slope:
                                        bend_pt[0].append((
                                            (_s - 1) % n_segs,
                                            _d0,
                                            _d,
                                            Matrix.Translation(Vector((_d0, 0, 0))) @
                                            Matrix([
                                                [1, 0, 0, 0],
                                                [0, 1, 0, 0],
                                                [_k0.slope, 0, 1, 0],
                                                [0, 0, 0, 1]
                                            ]) @ Matrix.Translation(Vector((-_d0, 0, 0))),
                                            Matrix.Translation(Vector((_d, 0, _dz))) @
                                            Matrix.Rotation(a, 4, "Z") @
                                            Matrix.Translation(Vector((-_d, 0, 0)))
                                        ))
                                    else:
                                        bend_pt[0].append((
                                            (_s - 1) % n_segs,
                                            _d0,
                                            _d,
                                            Matrix.Translation(Vector((_d, 0, 0))) @
                                            Matrix.Rotation(a, 4, "Z") @
                                            Matrix.Translation(Vector((-_d, 0, 0)))
                                            ))

                                    if not _k0.has_next:
                                        break

                                    _d0 = _d
                                    _d += _k1.v_length
                                    _dz = _k1.dz
                                    _k0 = _k1

                                _k0 = _k
                                _d0 = 0
                                _d = t0 * s_len
                                _s = s
                                _dz = _k.slope * _d
                                # compute bend points left part
                                while _d0 < width:
                                    # add a bend point
                                    _s -= 1
                                    if _s < 0:
                                        if _k0.has_last:
                                            _k1 = _k0._last
                                        else:
                                            _k1 = _k0
                                    else:
                                        _k1 = g.line.segs[_s]

                                    a = _k0.delta_angle(_k1)
                                    if slope:
                                        bend_pt[1].append((
                                            (_s + 1) % n_segs,
                                            -_d0,
                                            -_d,
                                            Matrix.Translation(Vector((-_d0, 0, 0))) @
                                            Matrix([
                                                [1, 0, 0, 0],
                                                [0, 1, 0, 0],
                                                [_k0.slope, 0, 1, 0],
                                                [0, 0, 0, 1]
                                            ]) @ Matrix.Translation(Vector((_d0, 0, 0))),
                                            Matrix.Translation(Vector((-_d, 0, -_dz))) @
                                            Matrix.Rotation(-a, 4, "Z") @
                                            Matrix.Translation(Vector((_d, 0, 0)))
                                            # Matrix.Translation(Vector((0, 0, -_dz)))
                                        ))
                                    else:
                                        bend_pt[1].append((
                                            (_s + 1) % n_segs,
                                            -_d0,
                                            -_d,
                                            Matrix.Translation(Vector((-_d, 0, 0))) @
                                            Matrix.Rotation(-a, 4, "Z") @
                                            Matrix.Translation(Vector((_d, 0, 0)))
                                        ))

                                    if not _k0.has_last:
                                        break

                                    _d0 = _d
                                    _d += _k1.v_length
                                    _dz = _k1.dz
                                    _k0 = _k1

                                bend.append(bend_pt)

                            for i in range(p.repeat_y):
                                for j in range(p.repeat_z):
                                    oM = Matrix.Translation(
                                        (0, -o0 - p.offset - i * p.space_y, z0 + p.alt + j * p.space_z)
                                    )
                                    transform.extend(
                                        self._make_matrix(
                                            g, ps, p, p_t, p_r, p_s, gen, oM,
                                            size=x_size[i][j],
                                            space=x_space
                                        )
                                    )

                            i = 0
                            # store global transform matrix for each x
                            for j, _tM in zip(sources, transform):

                                b_right, b_left = bend[i]
                                t_global = t_axis[i]

                                tM, rM, sM, oM, slM = _tM
                                # _tM = tM @ lM  @ oM
                                _tM = tM @ rM
                                offset = len(verts)

                                # adaptive scale
                                # if x_space[i] != x_size[j]:
                                    # sM = Matrix.Scale(x_space[i] / x_size[j], 4, Vector((1, 0, 0)))
                                _lM = oM @ sM
                                _tmp = [_lM @ _p for _p in _verts[j]]

                                # else:
                                # _tmp = [oM @ _p for _p in _verts[j]]
                                    # t_global for left part

                                # print("i", i, "t_axis", t_axis[i])
                                i = (i + 1) % len(t_axis)

                                # global matrix for each x
                                _xdict = {_p.x for _p in _tmp}
                                _x = [_p.x for _p in _tmp]

                                # slopes: move z points > _d + rotate & skew _d > points > _d0
                                if gen.slope:
                                    for _s, _d0, _d, sM, zM in reversed(b_right):

                                        # t_global = t_axis[i] + _p.x
                                        # t_local = (t_axis[i] + _p.x - it.d[_s]) / it.l[_s]
                                        # local matrix dict for each x coord
                                        # _d >= x > _d0 so 0 is only moved once with left part
                                        _gm_dict = {
                                            x: self._local_matrix(p, p_t, p_r, p_s, gen, it, g, x, _s, t_global)
                                            for x in _xdict if _d >= x > _d0
                                        }
                                        _tmp = [_gm_dict[x] @ pt if _d >= x > _d0 else pt for x, pt in zip(_x, _tmp)]
                                        _tmp = [
                                            zM @ pt if x > _d
                                            else sM @ pt if x > _d0
                                            else pt
                                            for x, pt in zip(_x, _tmp)
                                        ]
                                    for _s, _d0, _d, sM, zM in reversed(b_left):
                                        _gm_dict = {
                                            x: self._local_matrix(p, p_t, p_r, p_s, gen, it, g, x, _s, t_global)
                                            for x in _xdict if _d < x <= _d0
                                        }
                                        _tmp = [_gm_dict[x] @ pt if _d < x <= _d0 else pt for x, pt in zip(_x, _tmp)]
                                        _tmp = [
                                            zM @ pt if x < _d
                                            else sM @ pt if x < _d0
                                            else pt
                                            for x, pt in zip(_x, _tmp)
                                        ]
                                # rotate verts along pivot
                                else:
                                    for _s, _d0, _d, rM in reversed(b_right):
                                        # print("right _d > _d0", _d > _d0, "_d0", _d0, "_d", _d, "_s", _s)
                                        _gm_dict = {
                                            x: self._local_matrix(p, p_t, p_r, p_s, gen, it, g, x, _s, t_global)
                                            for x in _xdict if _d >= x > _d0
                                        }
                                        _tmp = [_gm_dict[x] @ pt if _d >= x > _d0 else pt for x, pt in zip(_x, _tmp)]
                                        _tmp = [rM @ pt if x > _d else pt for x, pt in zip(_x, _tmp)]

                                    for _s, _d0, _d, rM in reversed(b_left):
                                        # print("left _d < _d0", _d < _d0, "_d0", _d0, "_d", _d, "_s", _s)
                                        _gm_dict = {
                                            x: self._local_matrix(p, p_t, p_r, p_s, gen, it, g, x, _s, t_global)
                                            for x in _xdict if _d < x <= _d0
                                        }
                                        # _d < _d0
                                        _tmp = [_gm_dict[x] @ pt if _d < x <= _d0 else pt for x, pt in zip(_x, _tmp)]
                                        _tmp = [rM @ pt if x < _d else pt for x, pt in zip(_x, _tmp)]

                                verts.extend([_tM @ pt for pt in _tmp])
                                faces.extend([[offset + i for i in f] for f in _faces[j]])
                                matids.extend(_matid[j])
                                uvs.extend(_uvs[j])
                                vcolors.extend(_vcolor[j])

            print("%s make_matrix %.6f" % (p.geometry, time() - t))

        if p.rule_uid in tree:
            _d = [l, r]
            for child in tree[p.rule_uid]:
                self.sub_update(
                    context, o, g, realtime, index_map, tree,
                    child, p_t, p_r, p_s, alt_off_rot, it, _d,
                    verts, faces, matids, vcolors, uvs
                )

    def get_array_modifier(self, o, add=False):
        mod = o.modifiers.get("Archipack z array")
        if mod is None and add:
            mod = o.modifiers.new('Archipack z array', 'ARRAY')
            mod.use_constant_offset = True
            mod.use_relative_offset = False
            mod.fit_type = 'FIXED_COUNT'
        return mod

    def on_create(self):
        # interpolation
        if len(self.curves) < 1:
            c = self.curves.add()
        else:
            c = self.curves[0]
        c.on_create(curve_type="NONE", init_points=False)
        # global rotation
        if len(self.curves) < 2:
            c = self.curves.add()
        else:
            c = self.curves[1]
        c.on_create(curve_type="VECTOR", min_y=-1)
        # global scale
        if len(self.curves) < 3:
            c = self.curves.add()
        else:
            c = self.curves[2]
        c.on_create(curve_type="VECTOR")
        # global offset
        if len(self.curves) < 4:
            c = self.curves.add()
        else:
            c = self.curves[3]
        c.on_create(curve_type="VECTOR", min_y=-1)

    def update(self, context):

        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        # create missing curves on copy
        self.on_create()
        for p in self.rules:
            p.on_create()

        # remove children not available in sources objects
        sources = set()
        for p in self.rules:
            if p.enable:
                gen = p.get_geometry()
                if gen.geometry == "object":
                    sources.update(gen.source_uids)

        to_remove = [
            c for c in o.children
            if "archipack_source" in c and c["archipack_source"] not in sources
        ]

        if len(to_remove) > 0:
            self.remove_objects(context, to_remove, len(to_remove))

        # clean up manipulators before any data model change
        if self.manipulable_refresh:
            self.manipulable_disable(o)
        # self.update_parts()

        g = self.get_generator()
        g.locate_manipulators(self)

        # part counter
        self.manipulators[0].set_pts([
            g.segs[-2].lerp(1.1),
            g.segs[-2].lerp(1.1 + 0.5 / g.segs[-2].length),
            (-1, 0, 0)
        ])

        # materials
        materials = []
        # mat name: final index
        mat_indexes = {}
        # dict  mesh name: {index: final index}
        index_map = {}

        n_mats = len(o.material_slots)
        for i, geom in enumerate(self.geometrys):
            # 3 cases
            # - internal
            # - mesh
            # - object

            if geom.geometry in {"post", "rail", "panel"}:
                for j, index in enumerate(geom.idmat):
                    if index < n_mats:
                        slot = o.material_slots[index]
                        if slot is not None and slot.material is not None:
                            mat_name = slot.material.name
                            if mat_name not in mat_indexes:
                                mat_indexes[mat_name] = len(materials)
                                materials.append(slot.material)
                            geom.idmat[j] = mat_indexes[mat_name]

            elif "mesh" in geom.geometry:
                for s in geom.source_objects:
                    c = s.source("mesh")
                    s.material_offset = len(materials)
                    if c is not None:
                        index_map[c.name] = {}
                        for j, slot in enumerate(c.material_slots):
                            if slot is not None and slot.material is not None:
                                mat_name = slot.material.name
                                if mat_name not in mat_indexes:
                                    mat_indexes[mat_name] = len(materials)
                                    materials.append(slot.material)
                                index_map[c.name][j] = mat_indexes[mat_name]

        # apply materials
        o.data.materials.clear()
        for i, mat in enumerate(materials):
            o.data.materials.append(mat)
        # o.data.materials.update()

        # Update mesh
        seed(self.random_seed)

        verts = []
        faces = []
        matids = []
        uvs = []
        vcolors = []
        t = time()
        print("\n\n***************\n")
        it = Interpolator(g, dimension=self.dimensions)
        d = it.split_by_angle(self.angle_limit)

        p = self.rules[0]

        # use global settings here
        p_t = [self if state and self.global_translation else None for state in self.global_translations_override]
        p_r = [self if state and self.global_rotation else None for state in self.global_rotations_override]
        p_s = [self if state and self.global_scale else None for state in self.global_scales_override]
        alt_off_rot = [0, 0, 0, 0, 0]

        # throttle.add(context, o, self)
        realtime = False  # throttle.is_active(o.name)

        tree = self.tree()
        self.sub_update(
            context, o, g, realtime, index_map, tree, p, p_t, p_r, p_s, alt_off_rot, it, [d, d],
            verts, faces, matids, vcolors, uvs)

        # print(uvs)

        print("sub update: %.4f\n\n*****************" % (time() - t))

        t = time()

        # print("verts", verts)
        if len(verts) > 0:
            bmed.buildmesh(o, verts, faces, matids, uvs, vcolors, weld=True, clean=False)
            self.shade_smooth(context, o, 0.418879)
        else:
            bmed.emptymesh(o)

        print("build mesh: %s verts %.4f\n\n*****************" % (len(verts), time() - t))

        mod = self.get_array_modifier(o, add=True)
        mod.constant_offset_displace[2] = self.space_z
        mod.count = self.repeat_z

        # restore context
        self.restore_context(context)

    def manipulable_setup(self, context, o):
        """
            NOTE:
            this one assume context.active_object is the instance this
            data belongs to, failing to do so will result in wrong
            manipulators set on active object
        """
        self.setup_manipulators()
        self.manipulable_setup_parts(context, o)

        if not self.is_closed:
            for m in self.manipulators:
                self.manip_stack.append(m.setup(context, o, self))

    def on_delete(self, context, o):
        t = time()
        for p in self.rules:
            p.on_delete()
        logger.debug("archipack_array on_delete %.6f" % (time() - t))
        ArchipackObject.on_delete(self, context, o)

class ARCHIPACK_OT_array_geometry_add(Operator):
    bl_idname = "archipack.array_geometry_add"
    bl_label = "Insert"
    bl_description = "Add geometry"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            last_state = d.auto_update
            d.auto_update = False
            p = d.geometrys.add()
            p.name = "Generator {}".format(len(d.geometrys))
            d.auto_update = last_state
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_geometry_remove(Operator):
    bl_idname = "archipack.array_geometry_remove"
    bl_label = "Remove"
    bl_description = "Remove geometry"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            last_state = d.auto_update
            d.auto_update = False
            for rule in d.rules:
                if rule.geometry_id[0] > self.index:
                    rule.geometry_id[0] -= 1
            d.geometrys.remove(self.index)
            d.auto_update = last_state
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_geometry_default(Operator):
    bl_idname = "archipack.array_geometry_default"
    bl_label = "Default"
    bl_description = "Add default geometry"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            last = d.auto_update
            d.auto_update = False
            p = d.geometrys.add()
            p.geometry = "post"
            p.name = "Post"
            p = d.geometrys.add()
            p.geometry = "rail"
            p.name = "Rail"
            p = d.geometrys.add()
            p.geometry = "panel"
            p.name = "Panel"
            p = d.geometrys.add()
            p.geometry = "object"
            p.name = "Object / collection"
            p = d.geometrys.add()
            p.geometry = "mesh"
            p.name = "Mesh"
            p = d.geometrys.add()
            p.geometry = "deformable_mesh"
            p.name = "Deformable Mesh"
            d.auto_update = last
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_rule_insert(Operator):
    bl_idname = "archipack.array_rule_insert"
    bl_label = "Insert"
    bl_description = "Insert nested rule"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}

    parent: IntProperty(default=0)
    side: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.insert_rule(context, o, self.parent, self.side)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_rule_remove(Operator):
    bl_idname = "archipack.array_rule_remove"
    bl_label = "Remove"
    bl_description = "Remove rule"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.remove_rule(context, o, self.index)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_rule_move_up(Operator):
    bl_idname = "archipack.array_rule_move_up"
    bl_label = "Move up"
    bl_description = "Move rule up"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.move_rule_up(context, o, self.index)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_rule_copy(Operator):
    bl_idname = "archipack.array_rule_copy"
    bl_label = "Duplicate"
    bl_description = "Duplicate"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.duplicate_rule(context, o, self.index)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_rule_move_down(Operator):
    bl_idname = "archipack.array_rule_move_down"
    bl_label = "Move down"
    bl_description = "Move rule down"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            d.move_rule_down(context, o, self.index)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_source_add(Operator):
    bl_idname = "archipack.array_source_add"
    bl_label = "Add source"
    bl_description = "Add source"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    geometry: StringProperty()
    source: StringProperty()
    source_type: StringProperty()

    def add_object(self, d, g, s):
        p = g.source_objects.add()
        d.new_source_uid(p)
        p.label = s.name
        if s.type == "MESH":
            p.source_type = "MESH"
        else:
            p.source_type = "OBJECT"

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            if self.source == "":
                self.report({'WARNING'}, "Archipack: Select a source object")
                return {'CANCELLED'}
            g = d.geometrys.get(self.geometry)

            if self.source_type == "MESH":
                s = context.scene.objects.get(self.source.strip())
                if s is None or s.type != "MESH":
                    self.report({'WARNING'}, "Archipack: Object must be a Mesh")
                    return {'CANCELLED'}

            if self.source_type == "PRIMITIVE":
                p = g.source_objects.add()
                d.new_source_uid(p)
                p.label = "Primitive"
                p.source_type = "PRIMITIVE"

            elif "COLLECTION_" in self.source_type:
                sub_type = self.source_type[11:]

                if sub_type == "MESH":
                    childs = [c for c in bpy.data.collections[self.source].objects if c.type == "MESH"]

                else:
                    childs = bpy.data.collections[self.source].objects

                if len(childs) == 0:
                    self.report({'WARNING'}, "Archipack: Objects must be Mesh")
                    return {'CANCELLED'}

                for c in childs:
                    self.add_object(d, g, c)

            elif "COLLECTION" in self.source_type:
                c = bpy.data.collections[self.source]
                p = g.source_objects.add()
                d.new_source_uid(p)
                p.label = c.name
                p.source_type = "COLLECTION"
            else:
                c = context.scene.objects.get(self.source.strip())
                self.add_object(d, g, c)

            g.source_collection = None
            g.source_object = None
            d.update(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_source_move_up(Operator):
    bl_idname = "archipack.array_source_move_up"
    bl_label = "Move up"
    bl_description = "Move source up"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    geometry: StringProperty()
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            g = d.geometrys.get(self.geometry)
            g.move_source_up(self.index)
            d.update(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_source_move_down(Operator):
    bl_idname = "archipack.array_source_move_down"
    bl_label = "Move down"
    bl_description = "Move source down"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    geometry: StringProperty()
    index: IntProperty(default=0)

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            g = d.geometrys.get(self.geometry)
            g.move_source_down(self.index)
            d.update(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_source_remove(Operator):
    bl_idname = "archipack.array_source_remove"
    bl_label = "Remove source"
    bl_description = "Remove source"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    geometry: StringProperty()
    index: IntProperty()

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            d = archipack_array.datablock(o)
            if d is None:
                return {'CANCELLED'}
            g = d.geometrys.get(self.geometry)
            if self.index == -1:
                g.source_objects.clear()
                d.update(context)
            else:
                last = d.auto_update
                d.auto_update = False
                g.source_objects.remove(self.index)
                for r in d.rules:
                    if r.geometry_id[0] > self.index:
                        r.geometry_id[0] -= 1
                d.auto_update = last

            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_PT_array(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_array"
    bl_label = "Array"

    @classmethod
    def poll(cls, context):
        return archipack_array.poll(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_array.datablock(o)
        if d is None:
            return

        layout = self.layout

        self.draw_common(context, layout)
        self.draw_op(context, layout, layout, "archipack.path_merge")
        row = layout.row(align=True)
        self.draw_prop(context, layout, row, d, 'auto_update', icon="AUTO", emboss=True)
        # if not d.auto_update:
        #    self.draw_op(context, layout, row, "archipack.object_update", icon="FILE_REFRESH")

        box = layout.box()
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.array_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_array_preset_menu.bl_label, icon="PRESET"
                     ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.array_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.array_preset", icon='REMOVE', text="").remove_active = True

        self.draw_prop(context, layout, layout, d, "tabs", expand=True)
        layout.separator()
        if d.tabs != 'RULES':
            box = layout.box()

        if d.tabs == 'PARTS':
            expand = d.template_user_path(context, box, focus=False)
            if expand:
                if d.user_defined_path != "":
                    self.draw_prop(context, layout, box, d, 'user_defined_reverse')
            d.template_parts(context, layout, draw_type=False, draw_split=True)

        elif d.tabs == 'SUB':
            self.draw_op(context, layout, box, "archipack.array_geometry_add", icon='ADD', text="Add")
            self.draw_op(context, layout, box, "archipack.array_geometry_default", icon='ADD', text="Default")
            for i, p in enumerate(d.geometrys):
                p.draw(context, layout, layout, i)

        elif d.tabs == 'MAIN':
            self.draw_prop(context, layout, box, d, 'dimensions')
            self.draw_prop(context, layout, box, d, 'angle_limit')
            self.draw_prop(context, layout, box, d, 'repeat_z')
            self.draw_prop(context, layout, box, d, 'space_z')
            self.draw_prop(context, layout, box, d, 'offset')
            self.draw_prop(context, layout, box, d, 'random_seed')

            box = layout.box()

            d.draw_limits(context, layout, box)
            self.draw_prop(context, layout, box, d, 'project', icon='BLANK1', emboss=True)

            if d.extrapolation:
                c = d.curves[0]
                c.draw(context, layout, box)
            d.draw_transforms(context, layout, box)

        elif d.tabs == 'RULES':
            # self.draw_label(context, layout, box, "Rules")
            d.draw(context, layout, layout)

        elif d.tabs == 'MATERIALS':
            if "archipack_material" in o:
                o.archipack_material[0].draw(context, box)
            box = layout.box()
            self.draw_label(context, layout, box, "Apply materials")
            for p in d.geometrys:
                if p.geometry in {"rail", "post", "panel", "face"}:
                    self.draw_prop(context, layout, box, p, 'mat', text=p.name)


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_array(ArchipackCreateTool, Operator):
    bl_idname = "archipack.array"
    bl_label = "Array"
    bl_description = "Create Array"

    def create(self, context):
        o, m = self.create_mesh("Array")
        d = m.archipack_array.add()
        g = d.geometrys.add()
        g.geometry = 'vert'
        g.name = "Vertex"
        d.on_create()

        p = d.rules.add()
        p.rule = 'none'
        p.on_create()
        p.parent = -1
        # make manipulators selectable
        d.manipulable_selectable = True
        d.set_parts(1)
        d.parts[0].length = 2.5
        # Link object into scene
        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        self.add_material(context, o)
        self.load_preset(context, o, d)
        return o

    def execute(self, context):
        if context.mode == "OBJECT":
            bpy.ops.object.select_all(action="DESELECT")
            o = self.create(context)
            o.location = self.get_cursor_location(context)
            # select and make active
            self.add_to_reference(context, o)
            self.select_object(context, o, True)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_from_curve(ArchipackCreateTool, Operator):
    bl_idname = "archipack.array_from_curve"
    bl_label = "Array curve"
    bl_description = "Create array(s) from a curve"

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'CURVE'

    def create_one(self, context, curve, i):
        bpy.ops.archipack.array(filepath=self.filepath)
        o = context.active_object
        d = archipack_array.datablock(o)
        d.auto_update = False
        d.user_defined_spline = i
        d.user_defined_path = curve.name
        d.user_defined_resolution = min(128, curve.data.resolution_u)
        d.auto_update = True
        return o

    def create(self, context):
        o = None
        curve = context.active_object

        sel = []
        for i, spline in enumerate(curve.data.splines):
            o = self.create_one(context, curve, i)
            sel.append(o)
        for obj in sel:
            self.select_object(context, obj, True)
        return o

    def execute(self, context):
        curve = context.active_object
        self.set_cursor_location(context, curve.matrix_world @ Vector(curve.bound_box[0]))

        if context.mode == "OBJECT":
            bpy.ops.object.select_all(action="DESELECT")
            o = self.create(context)
            # select and make active
            self.select_object(context, o, True)
            return {'FINISHED'}

        elif context.mode == 'EDIT_CURVE':
            # Tynkatopi's contrib
            d = curve.data
            spline_index = 0

            if d.splines.active:
                spline_index = d.splines[:].index(d.splines.active)

            rot = curve.rotation_euler.copy()
            curve.rotation_euler = 0, 0, 0
            bpy.ops.object.mode_set(mode='OBJECT')
            o = self.create_one(context, curve, 0)
            if o:
                d = archipack_array.datablock(o)
                o.rotation_euler = 0, 0, 0
                o.parent = curve
                # update here so array location match spline vertex 1
                d.user_defined_spline = spline_index
                self.select_object(context, o)

            # select and make active
            self.select_object(context, curve, True)
            curve.rotation_euler = rot
            bpy.ops.object.mode_set(mode='EDIT')
            return {'FINISHED'}

        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object/Edit mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_array_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.array_draw"
    bl_label = "Draw a array"
    bl_description = "Create a array by drawing its baseline in 3D view"

    filepath: StringProperty(default="")

    @classmethod
    def poll(cls, context):
        return True

    def draw_callback(self, _self, context):
        # logger.debug("ARCHIPACK_OT_wall2_draw.draw_callback")
        self.feedback.draw(context)

    def get_datablock(self, o):
        return archipack_array.datablock(o)

    @property
    def z(self):
        return 1.0

    def sp_callback(self, context, event, state, sp):
        # logger.debug("ARCHIPACK_OT_wall2_draw.sp_callback event %s %s state:%s", event.type, event.value, state)

        if state == SUCCESS:

            if self.state == CREATE:
                takeloc = self.takeloc
                delta = sp.placeloc - self.takeloc
            else:
                takeloc = sp.takeloc
                delta = sp.delta

            o = self.o

            # old = context.object
            if o is None:
                # self.select_object(context, self.act, True)
                self.set_cursor_location(context, takeloc)
                bpy.ops.archipack.array('INVOKE_DEFAULT', filepath=self.filepath)
                # self.unselect_object(context, self.act)

                # context.window_manager.archipack.auto_manipulate = False

                o = context.object
                o.location = takeloc
                self.o = o
                d = archipack_array.datablock(o)
                # d.manipulable_selectable = False
                part = d.parts[0]
                part.length = delta.length
                state = MANIPULATE
            else:

                if not self.is_valid(o):
                    self.state = CANCEL
                    return

                # select and make active
                # self.select_object(context, o, True)
                d = archipack_array.datablock(o)
                # Check for end close to start and close when applicable
                dp = sp.placeloc - o.location
                if dp.length < 0.01:
                    d.is_closed = True
                    self.state = CANCEL
                    return

                part = d.add_part(o, delta.length)

            # print("self.o :%s" % o.name)
            rM = o.matrix_world.inverted().to_3x3()
            g = d.get_geometry()
            w = g.line.segs[-2]
            dp = rM @ delta
            da = w.signed_angle(w.v, dp)
            # atan2(dp.y, dp.x) - w.straight(1).angle
            a0 = w.limit_angle(part.a0 + da)
            part.a0 = a0
            d.update(context)

            # self.select_object(context, old, True)
            # self.select_object(context, o, True)

            self.flag_next = True
            if context.area is not None:
                context.area.tag_redraw()
            # print("feedback.on:%s" % self.feedback.on)

        self.state = state

    def sp_init(self, context, event, state, sp):
        logger.debug("ARCHIPACK_OT_array_draw.sp_init event %s %s state:%s" % (event.type, event.value, state))
        if state == SUCCESS:
            # point placed, check if object was under mouse
            logger.debug("self.mouse_to_scene_raycast(context, event)")

            res, pt, y, i, o, tM = self.mouse_to_scene_raycast(context, event)
            logger.debug("self.mouse_to_scene_raycast done")

            if res:
                # hover another object
                if self.is_snapping(context, event, sp.placeloc):
                    # user snap, use direction as constraint
                    tM.translation = sp.placeloc.copy()
                else:
                    # without snap must use ray intersection on xy plane
                    # Note: not certain about this behaviour, might use ray cast pt instead ?
                    pt = self.mouse_to_plane(context, event)
                    if pt is not None:
                        tM.translation = pt

                self.takeloc = tM.translation

                self.act = o
                self.takemat = tM
            else:

                self.takeloc = sp.placeloc.copy()
                if not self.is_snapping(context, event, sp.placeloc):
                    # without snap use ray intersection on xy plane
                    pt = self.mouse_to_plane(context, event)
                    if pt is not None:
                        self.takeloc = pt

            self.state = FREEMOVE
            # print("feedback.on:%s" % self.feedback.on)
        elif state == CANCEL:
            self.state = state
            return

        logger.debug("sp_init() done %s", self.state)

    def exit(self, context):
        # d = archipack_wall2.datablock(self.o)
        # if d is not None:
        #    d.manipulable_selectable = True
        self.o = None
        self.feedback.disable()
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):
        # Fix layout switch issue
        if context.area is None:
            self.exit(context)
            return {'FINISHED'}

        if event.type in {'NONE', 'EVT_TWEAK_L', 'WINDOW_DEACTIVATE'} or "TIMER" in event.type:
            return {'PASS_THROUGH'}

        context.area.tag_redraw()

        # logger.debug("ARCHIPACK_OT_wall2_draw.modal(%s) type:%s  value:%s", self.state, event.type, event.value)

        if self.keymap.check(event, self.keymap.delete):
            self.exit(context)
            return {'FINISHED', 'PASS_THROUGH'}

        o = self.o

        if o is not None and not self.is_valid(o):
            self.exit(context)
            return {'FINISHED'}

        if self.state == MANIPULATE:
            self.state = SUCCESS

            if self.max_style_draw_tool:
                # re-select to enable manipulate
                self.select_object(context, o, True)
                return {'RUNNING_MODAL'}

        if self.state == STARTING and event.type not in {'ESC', 'RIGHTMOUSE'}:
            # wait for takeloc being visible when button is over horizon
            takeloc = self.mouse_to_plane(context, event)
            if takeloc is not None:
                logger.debug("ARCHIPACK_OT_array_draw.modal(STARTING) location:%s", takeloc)
                snap_point(context, takeloc=takeloc,
                           callback=self.sp_init,
                           constraint_axis=(False, False, False),
                           release_confirm=False)
            return {'RUNNING_MODAL'}

        elif self.state == FREEMOVE:
            # print("RUNNING")
            # logger.debug("ARCHIPACK_OT_wall2_draw.modal(RUNNING) location:%s", self.takeloc)
            self.state = CREATE
            snap_point(context, takeloc=self.takeloc,
                       draw=self.sp_draw,
                       takemat=self.takemat,
                       transform_orientation=self.get_transform_orientation(context),
                       callback=self.sp_callback,
                       constraint_axis=(True, True, False),
                       release_confirm=self.max_style_draw_tool)
            return {'RUNNING_MODAL'}

        elif self.state != CANCEL:

            if event.type in {'D', 'd'}:
                logger.debug("ARCHIPACK_OT_array_draw.modal(%s) D pressed", self.state)
                self.exit(context)
                bpy.ops.archipack.array_preset_menu('INVOKE_DEFAULT', preset_operator="archipack.array_draw")
                return {'FINISHED'}

            elif event.type in {'C', 'c'}:

                logger.debug("ARCHIPACK_OT_array_draw.modal(%s) C pressed", self.state)
                d = archipack_array.datablock(o)
                if d is not None:
                    d.closed = True
                self.exit(context)
                return {'FINISHED'}

            elif event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:

                # print('LEFTMOUSE %s' % (event.value))
                self.feedback.instructions(context, "Draw a array", "Click & Drag to add a segment", [
                    ('ENTER', 'Add part'),
                    ('BACK_SPACE', 'Remove part'),
                    ('CTRL', 'Snap'),
                    ('C', 'Close array and exit'),
                    ('D', 'Draw another array'),
                    ('MMBTN', 'Constraint to axis'),
                    ('X Y', 'Constraint to axis'),
                    ('RIGHTCLICK or ESC', 'exit')
                ])

                # press with max mode release with blender mode
                if self.max_style_draw_tool:
                    evt_value = 'PRESS'
                else:
                    evt_value = 'RELEASE'

                if event.type in {'LEFTMOUSE'} and event.value == evt_value or \
                        event.type in {'RET', 'NUMPAD_ENTER', 'SPACE'}:

                    if self.flag_next:
                        self.flag_next = False

                        # select and make active
                        self.select_object(context, o, True)

                        d = archipack_array.datablock(o)
                        g = d.get_geometry()
                        p0 = g.segs[-2].p0
                        p1 = g.segs[-2].p1
                        dp = p1 - p0
                        takemat = o.matrix_world @ Matrix([
                            [dp.x, dp.y, 0, p1.x],
                            [dp.y, -dp.x, 0, p1.y],
                            [0, 0, 1, 0],
                            [0, 0, 0, 1]
                        ])
                        takeloc = o.matrix_world @ p1
                        # self.unselect_object(context, o)
                    else:
                        takemat = None
                        takeloc = self.mouse_to_plane(context, event)

                    if takeloc is not None:
                        logger.debug("ARCHIPACK_OT_array_draw.modal(CREATE) location:%s", takeloc)

                        snap_point(context, takeloc=takeloc,
                                   takemat=takemat,
                                   draw=self.sp_draw,
                                   callback=self.sp_callback,
                                   constraint_axis=(True, True, False),
                                   release_confirm=self.max_style_draw_tool)

                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
        ):
            if o is not None:

                # select and make active
                self.select_object(context, o, True)
                d = archipack_array.datablock(o)
                if d.num_parts > 1:
                    d.n_parts -= 1
                    # realign last vector so it is aligned with current one.
                    d.parts[-1].a0 = 0
            return {'RUNNING_MODAL'}

        if self.state == CANCEL or (event.type in {'ESC', 'RIGHTMOUSE'}):

            logger.debug("ARCHIPACK_OT_array_draw.modal(CANCEL) %s", event.type)
            if o is None:

                # select and make active
                self.select_object(context, self.act, True)

                for o in self.sel:
                    self.select_object(context, o)
            else:
                self.select_object(context, o, True)

            self.exit(context)
            return {'FINISHED'}

        return {'PASS_THROUGH'}

    def add_to_reference(self, context, o):
        ref = self.get_reference_point(self.act)
        if ref is None:
            # print("ref is None")
            ref = o
        # print("ref name:", ref.name)
        with context_override(context, ref, [o]) as ctx:
            self.call_operator(context, ctx, bpy.ops.archipack.add_reference_point)
            # bpy.ops.archipack.add_reference_point(ctx)

    def invoke(self, context, event):

        if context.mode == "OBJECT":

            bpy.ops.archipack.disable_manipulate()

            # self.auto_manipulate = context.window_manager.archipack.auto_manipulate
            prefs = get_prefs(context)
            self.max_style_draw_tool = prefs.max_style_draw_tool
            self.keymap = Keymaps(context)
            self.init_gl()

            self.feedback = FeedbackPanel()
            self.feedback.instructions(context, "Draw a array", "Click & Drag to start", [
                ('CTRL', 'Snap'),
                ('MMBTN', 'Constraint to axis'),
                ('X Y', 'Constraint to axis'),
                ('SHIFT+CTRL+TAB', 'Switch snap mode'),
                ('RIGHTCLICK or ESC', 'exit without change')
            ])
            self.feedback.enable()
            args = (self, context)

            self.sel = context.selected_objects[:]
            self.act = context.active_object

            bpy.ops.object.select_all(action="DESELECT")

            d = archipack_array.datablock(self.act)
            if event.alt and d is not None and not d.is_closed:
                self.state = RESTART
                self.flag_next = True
                self.o = self.act
            else:
                self.state = STARTING

            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------


class ARCHIPACK_OT_array_preset_create(PresetMenuOperator, Operator):
    bl_description = "Show Array presets and create object at cursor location"
    bl_idname = "archipack.array_preset_create"
    bl_label = "Array Presets"
    preset_subdir = "archipack_array"


class ARCHIPACK_OT_array_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Show Array presets and draw"
    bl_idname = "archipack.array_preset_draw"
    bl_label = "Array Presets"
    preset_subdir = "archipack_array"

    def skip_menu(self, context, event):
        if event.alt:
            o = context.active_object
            d = archipack_array.datablock(o)
            return d is not None and not d.is_closed
        return False


class ARCHIPACK_OT_array_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Show Array Presets"
    bl_idname = "archipack.array_preset_menu"
    bl_label = "Array preset"
    preset_subdir = "archipack_array"


class ARCHIPACK_OT_array_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Add a Array Preset"
    bl_idname = "archipack.array_preset"
    bl_label = "Array preset"
    preset_menu = "ARCHIPACK_OT_array_preset_menu"

    @property
    def blacklist(self):
        return ["parts", "n_parts"]

    def prepare_preset(self, context, o, preset):
        # TODO: save user defined profile

        return


class ARCHIPACK_OT_array_preset_from_curve(PresetMenuOperator, Operator):
    bl_description = "Create a Array from curve"
    bl_idname = "archipack.array_preset_from_curve"
    bl_label = "Array"
    preset_subdir = "archipack_array"
    preset_operator: StringProperty(
        options={'SKIP_SAVE'},
        default="archipack.array_from_curve"
    )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o and o.type == 'CURVE'


@persistent
def cleanup(dumb):
    """ Cleanup curve shader node groups not removed on delete
    :param dumb:
    :return:
    """
    for ng in bpy.data.node_groups:
        if ng.name.startswith("ArchipackCurveData"):
            me = bpy.data.meshes.get(ng.name[19:])
            if me is None:
                ng.use_fake_user = False


def register():
    bpy.utils.register_class(archipack_sources_provider_source)
    bpy.utils.register_class(ARCHIPACK_UL_SourceProvider)
    bpy.utils.register_class(archipack_array_geometry)
    bpy.utils.register_class(archipack_array_curve)

    bpy.utils.register_class(archipack_array_rule)

    bpy.utils.register_class(archipack_array_part)
    bpy.utils.register_class(archipack_array)
    Mesh.archipack_array = CollectionProperty(type=archipack_array)
    bpy.utils.register_class(ARCHIPACK_OT_array_rule_insert)
    bpy.utils.register_class(ARCHIPACK_OT_array_rule_remove)
    bpy.utils.register_class(ARCHIPACK_OT_array_rule_copy)

    bpy.utils.register_class(ARCHIPACK_OT_array_rule_move_up)
    bpy.utils.register_class(ARCHIPACK_OT_array_rule_move_down)
    bpy.utils.register_class(ARCHIPACK_OT_array_geometry_add)
    bpy.utils.register_class(ARCHIPACK_OT_array_geometry_default)
    bpy.utils.register_class(ARCHIPACK_OT_array_geometry_remove)
    bpy.utils.register_class(ARCHIPACK_OT_array)
    bpy.utils.register_class(ARCHIPACK_PT_array)
    bpy.utils.register_class(ARCHIPACK_OT_array_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_array_preset)
    bpy.utils.register_class(ARCHIPACK_OT_array_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_array_preset_draw)
    bpy.utils.register_class(ARCHIPACK_OT_array_draw)
    bpy.utils.register_class(ARCHIPACK_OT_array_from_curve)
    bpy.utils.register_class(ARCHIPACK_OT_array_preset_from_curve)
    bpy.utils.register_class(ARCHIPACK_OT_array_source_move_up)
    bpy.utils.register_class(ARCHIPACK_OT_array_source_move_down)
    bpy.utils.register_class(ARCHIPACK_OT_array_source_add)
    bpy.utils.register_class(ARCHIPACK_OT_array_source_remove)
    save_pre.append(cleanup)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_OT_array_source_remove)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_source_add)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_source_move_up)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_source_move_down)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_from_curve)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_preset_from_curve)
    bpy.utils.unregister_class(ARCHIPACK_PT_array)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_rule_insert)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_rule_remove)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_rule_copy)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_rule_move_up)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_rule_move_down)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_geometry_add)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_geometry_remove)
    bpy.utils.unregister_class(ARCHIPACK_OT_array_geometry_default)
    bpy.utils.unregister_class(ARCHIPACK_OT_array)
    bpy.utils.unregister_class(archipack_array)
    bpy.utils.unregister_class(archipack_array_part)
    bpy.utils.unregister_class(archipack_array_rule)
    bpy.utils.unregister_class(archipack_array_curve)

    bpy.utils.unregister_class(archipack_array_geometry)
    bpy.utils.unregister_class(ARCHIPACK_UL_SourceProvider)
    bpy.utils.unregister_class(archipack_sources_provider_source)

    del Mesh.archipack_array
    save_pre.remove(cleanup)
