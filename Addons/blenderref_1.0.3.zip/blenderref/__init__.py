# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "BlenderRef",
    "author" : "NormalSteve", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 3),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Reference Imaging" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
main = {'sna_gplus_1': [], 'sna_switch': [], }
on_props = {'sna_g2': [], 'sna_user_gal_2': [], 'sna_user_cats_2': [], }


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def find_neighbors(var):
    enum_name = "'SCENE_PLACEHOLDER.sna_switching_arrows'".replace("SCENE_PLACEHOLDER.", "")[1:-1]
    # Check if the property exists
    if hasattr(bpy.types.Scene, enum_name):
        # Access the enum property
        enum_property = bpy.types.Scene.bl_rna.properties[enum_name]
        # Extract the items
        enum_items = enum_property.enum_items
        # Store items in a list
        enum_list = [item.identifier for item in enum_items]
        if len(enum_list) < 3:
            return None, None
        if var not in enum_list:
            return None, None
        index = enum_list.index(var)
        previous_item = enum_list[index - 1] if index > 0 else enum_list[-1]
        next_item = enum_list[index + 1] if index < len(enum_list) - 1 else enum_list[0]
        return previous_item, next_item
    else:
        print(f"The enum property '{enum_name}' does not exist in bpy.types.Scene")
        return None, None


def sna_update_sna_user_dir_custom_7A7FC(self, context):
    sna_updated_prop = self.sna_user_dir_custom
    on_props['sna_user_cats_2'] = []
    for i_5F4DB in range(len([os.path.join(bpy.context.scene.sna_user_dir_custom, f) for f in os.listdir(bpy.context.scene.sna_user_dir_custom) if os.path.isdir(os.path.join(bpy.context.scene.sna_user_dir_custom, f))])):
        if True:
            on_props['sna_user_cats_2'].append([[os.path.join(bpy.context.scene.sna_user_dir_custom, f) for f in os.listdir(bpy.context.scene.sna_user_dir_custom) if os.path.isdir(os.path.join(bpy.context.scene.sna_user_dir_custom, f))][i_5F4DB], [os.path.join(bpy.context.scene.sna_user_dir_custom, f) for f in os.listdir(bpy.context.scene.sna_user_dir_custom) if os.path.isdir(os.path.join(bpy.context.scene.sna_user_dir_custom, f))][i_5F4DB], '', load_preview_icon([os.path.join(bpy.context.scene.sna_user_dir_custom, f) for f in os.listdir(bpy.context.scene.sna_user_dir_custom) if os.path.isdir(os.path.join(bpy.context.scene.sna_user_dir_custom, f))][i_5F4DB])])
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()


_item_map = dict()


def make_enum_item(_id, name, descr, preview_id, uid):
    lookup = str(_id)+"\0"+str(name)+"\0"+str(descr)+"\0"+str(preview_id)+"\0"+str(uid)
    if not lookup in _item_map:
        _item_map[lookup] = (_id, name, descr, preview_id, uid)
    return _item_map[lookup]


def sna_update_sna_catagory_cust_31352(self, context):
    sna_updated_prop = self.sna_catagory_cust
    on_props['sna_user_gal_2'] = []
    for i_F5C2D in range(len([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))])):
        if bpy.context.scene.sna_switching_arrows == "jpg":
            if (os.path.splitext([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D])[1] == '.jpg'):
                on_props['sna_user_gal_2'].append([[os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D], [os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D], '', load_preview_icon([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D])])
        elif bpy.context.scene.sna_switching_arrows == "png":
            if (os.path.splitext([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D])[1] == '.png'):
                on_props['sna_user_gal_2'].append([[os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D], [os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D], '', load_preview_icon([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D])])
        elif bpy.context.scene.sna_switching_arrows == "tiff":
            if (os.path.splitext([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D])[1] == '.tiff'):
                on_props['sna_user_gal_2'].append([[os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D], [os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D], '', load_preview_icon([os.path.join(sna_updated_prop, f) for f in os.listdir(sna_updated_prop) if os.path.isfile(os.path.join(sna_updated_prop, f))][i_F5C2D])])
        else:
            pass
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


def sna_update_sna_main_gallery_g2_2D60C(self, context):
    sna_updated_prop = self.sna_main_gallery_g2
    prev_context = bpy.context.area.type
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.empty_add(type='IMAGE', align='VIEW', scale=(2.0, 2.0, 2.0))
    bpy.context.area.type = prev_context
    bpy.ops.image.open('INVOKE_DEFAULT', filepath=bpy.path.abspath(sna_updated_prop), directory=bpy.context.scene.sna_catagory_cust)
    image_E1490 = bpy.data.images.load(filepath=bpy.path.abspath(sna_updated_prop), )
    bpy.context.active_object.data = image_E1490
    bpy.context.view_layer.objects.active.empty_display_size = 3.0


class SNA_PT_BLENDERREF_DC132(bpy.types.Panel):
    bl_label = 'BlenderRef'
    bl_idname = 'SNA_PT_BLENDERREF_DC132'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Bref'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.scene, 'sna_user_dir_custom', text='', icon_value=0, emboss=True, expand=True)
        layout.prop(bpy.context.scene, 'sna_catagory_cust', text='', icon_value=0, emboss=True, expand=False)
        row_84C3A = layout.row(heading='', align=True)
        row_84C3A.alert = False
        row_84C3A.enabled = True
        row_84C3A.active = True
        row_84C3A.use_property_split = False
        row_84C3A.use_property_decorate = False
        row_84C3A.scale_x = 1.0
        row_84C3A.scale_y = 1.0
        row_84C3A.alignment = 'Center'.upper()
        row_84C3A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_C2E31 = row_84C3A.column(heading='', align=True)
        col_C2E31.alert = False
        col_C2E31.enabled = True
        col_C2E31.active = True
        col_C2E31.use_property_split = False
        col_C2E31.use_property_decorate = False
        col_C2E31.scale_x = 1.0
        col_C2E31.scale_y = 7.0
        col_C2E31.alignment = 'Expand'.upper()
        col_C2E31.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_C2E31.operator('sna.new_swicth_06bd3', text='', icon_value=6, emboss=True, depress=False)
        op.sna_s_values_switch = 'Previous'
        row_84C3A.template_icon_view(bpy.context.scene, 'sna_main_gallery_g2', show_labels=True, scale=7.0, scale_popup=7.0)
        col_0478E = row_84C3A.column(heading='', align=True)
        col_0478E.alert = False
        col_0478E.enabled = True
        col_0478E.active = True
        col_0478E.use_property_split = False
        col_0478E.use_property_decorate = False
        col_0478E.scale_x = 1.0
        col_0478E.scale_y = 7.0
        col_0478E.alignment = 'Expand'.upper()
        col_0478E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_0478E.operator('sna.new_swicth_06bd3', text='', icon_value=4, emboss=True, depress=False)
        op.sna_s_values_switch = 'Next'
        col_63CF8 = layout.column(heading='', align=False)
        col_63CF8.alert = False
        col_63CF8.enabled = True
        col_63CF8.active = True
        col_63CF8.use_property_split = False
        col_63CF8.use_property_decorate = False
        col_63CF8.scale_x = 1.0
        col_63CF8.scale_y = 1.0
        col_63CF8.alignment = 'Expand'.upper()
        col_63CF8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_17D16 = col_63CF8.row(heading='', align=False)
        row_17D16.alert = False
        row_17D16.enabled = True
        row_17D16.active = True
        row_17D16.use_property_split = False
        row_17D16.use_property_decorate = False
        row_17D16.scale_x = 1.0
        row_17D16.scale_y = 1.25
        row_17D16.alignment = 'Expand'.upper()
        row_17D16.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_17D16.prop(bpy.context.scene, 'sna_switching_arrows', text=' ', icon_value=0, emboss=True, expand=True)
        if property_exists("bpy.context.active_object.display", globals(), locals()):
            if hasattr(bpy.types,"DATA_PT_empty"):
                if not hasattr(bpy.types.DATA_PT_empty, "poll") or bpy.types.DATA_PT_empty.poll(context):
                    bpy.types.DATA_PT_empty.draw(self, context)
                else:
                    layout.label(text="Can't display this panel here!", icon="ERROR")
            else:
                layout.label(text="Can't display this panel!", icon="ERROR")


class SNA_OT_New_Swicth_06Bd3(bpy.types.Operator):
    bl_idname = "sna.new_swicth_06bd3"
    bl_label = "new_swicth"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_s_values_switch: bpy.props.StringProperty(name='S_Values_switch', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_s_values_switch == "Previous":
            find_neighbors_AE01A = find_neighbors(bpy.context.scene.sna_switching_arrows)
            bpy.context.scene.sna_switching_arrows = find_neighbors_AE01A[0]
        elif self.sna_s_values_switch == "Next":
            find_neighbors_D3C6B = find_neighbors(bpy.context.scene.sna_switching_arrows)
            bpy.context.scene.sna_switching_arrows = find_neighbors_D3C6B[1]
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_catagory_cust_enum_items(self, context):
    enum_items = on_props['sna_user_cats_2']
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def sna_main_gallery_g2_enum_items(self, context):
    enum_items = on_props['sna_user_gal_2']
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_main_gallery_g2 = bpy.props.EnumProperty(name='Main_gallery_G2', description='', items=sna_main_gallery_g2_enum_items, update=sna_update_sna_main_gallery_g2_2D60C)
    bpy.types.Scene.sna_catagory_cust = bpy.props.EnumProperty(name='Catagory_Cust', description='', items=sna_catagory_cust_enum_items, update=sna_update_sna_catagory_cust_31352)
    bpy.types.Scene.sna_user_dir_custom = bpy.props.StringProperty(name='User_dir_custom', description='', default='', subtype='DIR_PATH', maxlen=0, update=sna_update_sna_user_dir_custom_7A7FC)
    bpy.types.Scene.sna_switching_arrows = bpy.props.EnumProperty(name='switching_arrows', description='', items=[('jpg', 'jpg', '', 899, 0), ('png', 'png', '', 905, 1), ('tiff', 'tiff', '', 909, 2)])
    bpy.utils.register_class(SNA_PT_BLENDERREF_DC132)
    bpy.utils.register_class(SNA_OT_New_Swicth_06Bd3)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_switching_arrows
    del bpy.types.Scene.sna_user_dir_custom
    del bpy.types.Scene.sna_catagory_cust
    del bpy.types.Scene.sna_main_gallery_g2
    bpy.utils.unregister_class(SNA_PT_BLENDERREF_DC132)
    bpy.utils.unregister_class(SNA_OT_New_Swicth_06Bd3)
