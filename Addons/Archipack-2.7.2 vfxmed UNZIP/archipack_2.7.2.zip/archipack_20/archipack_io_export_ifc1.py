# -*- coding:utf-8 -*-

# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# 
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------

import bpy
import time
import os
from getpass import getuser
from bpy.types import Operator, Panel
from bpy.props import StringProperty, EnumProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper
from .archipack_prefs import get_prefs
from .archipack_abstraction import (
    ArchipackObjectsManager,
    context_override
)


import logging
logger = logging.getLogger(__package__)


HAS_BLENDERBIM = False
BIM_VERSION = 0


def user_name():
    u = ""
    try:
        u = getuser()
    except:
        pass
    return u


IFC_CLASS_MAP = {
    # Sunlight provide interface for lat/lon parameters with presets,
    # also allow to define scene origin other than 0,0
    # "archipack_sun": "IfcSite",
    # archipack_building still not exposed in ui
    "archipack_building": "IfcBuilding",
    "archipack_reference_point": "IfcBuildingStorey",
    "archipack_wall": "IfcWall",
    "archipack_wall2": "IfcWall",
    "archipack_custom_wall": "IfcWall",
    "archipack_window": "IfcWindow",
    "archipack_door": "IfcDoor",
    "archipack_slab": "IfcSlab",
    "archipack_stair": "IfcStair",
    # ArchiCad reference
    # Kitchen Cabinets           IfcFurnishingElement
    # Cabinet with Sink          IfcFlowTerminal > IfcSanitaryTerminalType with PredefinedType SINK.
    # Cabinet with Dishwasher    IfcFlowTerminal > IfcElectricApplianceType with PredefinedType DIRECTWATERHEATER.
    "archipack_kitchen": "IfcFurniture",
    # use IfcMember instead ??  as column / beam are direction dependants
    "archipack_beam": "IfcColumn",
    # Moldings                   IfcCovering with PredefinedType as MOLDING on ceiling and SKIRTINGBOARD on floor
    "archipack_molding": "IfcCovering",
    # FLOORING
    "archipack_floor": "IfcCovering",
    "archipack_fence": "IfcRailing",
    "archipack_ceiling": "IfcCovering",
    # ShadingDevice is a 4x2 entity
    "archipack_blind": "IfcShadingDevice",
    "archipack_window_shutter": "IfcShadingDevice",
    "archipack_hole": "IfcOpeningElement",
    "archipack_custom_hole": "IfcOpeningElement",
    "archipack_roof": "IfcRoof",
    "archipack_terrain": "IfcGeographicElement"
}


PREDEFINED_TYPES = {
    # Sunlight provide interface for lat/lon parameters with presets,
    # also allow to define scene origin other than 0,0
    # "archipack_sun": "IfcSite",
    # archipack_building still not exposed in ui
    # "archipack_building": "IfcBuilding",
    # "archipack_reference_point": "IfcBuildingStorey",
    # NOTE: wall type depends on location  SOLIDWALL or PARTITIONNING
    "archipack_wall": "SOLIDWALL",
    "archipack_wall2": "SOLIDWALL",
    "archipack_custom_wall": "SOLIDWALL",
    "archipack_window": "WINDOW",
    "archipack_window_shutter": "SHUTTER",
    "archipack_door": "DOOR",
    # "archipack_slab": "FLOOR",
    # Stair type depends on landings, when > than 3 stair is USERDEFINED
    # "archipack_stair": "",
    # ArchiCad reference
    # Kitchen Cabinets           IfcFurnishingElement
    # Cabinet with Sink          IfcFlowTerminal > IfcSanitaryTerminalType with PredefinedType SINK.
    # Cabinet with Dishwasher    IfcFlowTerminal > IfcElectricApplianceType with PredefinedType DIRECTWATERHEATER.
    # "archipack_kitchen": "",
    # use IfcMember instead ??  as column / beam are direction dependants
    "archipack_beam": "COLUMN",
    # Moldings                   IfcCovering with PredefinedType as MOLDING on ceiling and SKIRTINGBOARD on floor
    "archipack_molding": "SKIRTINGBOARD",
    # FLOORING
    "archipack_floor": "FLOORING",
    "archipack_fence": "BALUSTRADE",
    "archipack_ceiling": "CEILING",
    # ShadingDevice is a 4x2 entity
    # "archipack_blind": "SHUTTER",
    "archipack_hole": "OPENING",
    "archipack_custom_hole": "OPENING",
    "archipack_roof": "GABLE_ROOF",
    "archipack_terrain": "TERRAIN"
}


class ArchipackIfcClassifier(ArchipackObjectsManager):

    @classmethod
    def get_key(cls, o, d):
        key = None
        if d is not None:
            key = d.__class__.__name__
        elif cls.has_flag(o, ("custom_hole", "hole")):
            key = "archipack_hole"
        return key

    def get_component_key(self, o):
        d = self.archipack_datablock(o)
        key = self.get_key(o, d)
        return key, d

    def transverse(self, sel, apk):
        """ Transverse selection and filter archipack objects
        :param sel: array blender objects
        :param apk: dict: {archipack_class: {object, datablock}}
        :return: void
        """
        for o in sel:
            key, d = self.get_component_key(o)
            if key:
                if key not in apk:
                    apk[key] = {}
                if key != "archipack_roof" or not d.schrinkwrap_target:
                    apk[key][o] = d

    def rec_transverse(self, o, apk):
        """ Recursively transverse parent -> child
        :param o:   blender parent object
        :param apk: dict: {archipack_class: {object, datablock}}
        :return: void
        """
        self.transverse(o.children, apk)
        for c in o.children:
            self.rec_transverse(c, apk)

    def assoc_fills_voids(self, apk):
        """ Associate voids to walls and fills to voids
        :param apk: dict: {archipack_class: {object, datablock}}
        :return: walls = {voids: set(voids)}, fills = {void, fill}
        """
        fills = {}
        for fill_cls in {"archipack_window", "archipack_door"}:
            if fill_cls in apk:
                for o, d in apk[fill_cls].items():
                    hole = d.find_hole(o)
                    # NOTE: may object generate many holes ???
                    fills[hole] = o

        voids = {}
        for wall_cls in {"archipack_wall2", "archipack_wall", "archipack_custom_wall"}:
            if wall_cls in apk:
                for o, d in apk[wall_cls].items():
                    voids[o] = set()
                    modif = self.get_archipack_bool_modifier(o)
                    if modif is not None:
                        if modif.type == "BOOLEAN":
                            if modif.object:
                                for m in modif.object.modifiers:
                                    if m.type == "BOOLEAN" and m.object is not None:
                                        voids[o].add(m.object)
                        elif modif.type == "NODES":
                            for n in modif.node_group.nodes:
                                if n.type =="OBJECT_INFO" and n.inputs[0].default_value is not None:
                                    voids[o].add(n.inputs[0].default_value)
        return voids, fills


def has_blenderbim():
    try:
        from blenderbim import bl_info as bim_info
        return True
    except ImportError:
        pass
    return False


def init_blenderbim():

    try:
        # import at runtime to prevent deps cycle hell
        from blenderbim import bl_info as bim_info
        major, minor, BIM_VERSION = bim_info['version']
        from blenderbim.bim.export_ifc import (
                IfcParser,
                IfcExporter,
                IfcExportSettings
            )

        if BIM_VERSION >= 200722:
            # standalone qto
            from blenderbim.bim.qto import (
                QtoCalculator
            )
        else:
            from blenderbim.bim.export_ifc import (
                QtoCalculator
            )

        logger.info("found blenderBIM addon")
        print("Archipack PRO : blenderBIM support for bim export enabled")

    except ImportError as ex:
        logger.info("BlenderBIM addon not found %s" % ex)
        print("BlenderBIM addon not found %s" % ex)
        print("Archipack PRO : blenderBIM addon not found, support for bim export will be disabled")
        return None, None, None, None

    class ArchipackIfcExporter(IfcExporter):
        def __init__(self, ifc_export_settings, ifc_parser, qto_calculator=None):
            if BIM_VERSION >= 200722:
                IfcExporter.__init__(self, ifc_export_settings, ifc_parser)
            else:
                IfcExporter.__init__(self, ifc_export_settings, ifc_parser, qto_calculator)

        def create_solid_representation(self, representation):
            # NOTE: fallback for < 14.07.2020 blenderbim version, may be removed
            mesh = representation['raw']
            if not representation['is_parametric']:
                mesh = representation['raw_object'].evaluated_get(bpy.context.evaluated_depsgraph_get()).to_mesh()
            self.create_vertices(mesh.vertices)
            # fallback to at least 1 slot
            n_slots = max(1, len(representation['raw_object'].material_slots))
            ifc_raw_items = [[]] * n_slots
            for polygon in mesh.polygons:
                ifc_raw_items[polygon.material_index % n_slots].append(self.file.createIfcFace([
                    self.file.createIfcFaceOuterBound(
                        self.file.createIfcPolyLoop([self.ifc_vertices[vertice] for vertice in polygon.vertices]),
                        True)]))
            # TODO: May not actually be a closed shell, but who checks anyway?
            items = [self.file.createIfcFacetedBrep(self.file.createIfcClosedShell(i)) for i in ifc_raw_items if i]
            return self.file.createIfcShapeRepresentation(
                self.ifc_rep_context[representation['context']][representation['subcontext']][
                representation['target_view']]['ifc'],
                representation['subcontext'], 'Brep', items)

    class ArchipackIfcParser(ArchipackIfcClassifier, IfcParser):
        """
        Abstraction layer between archipack and blenderBIM
        """
        def __init__(self, settings=None, keep_booleans=True, export_plan=False, qto_calculator=None):
            if settings is not None:

                if BIM_VERSION >= 200722:
                    IfcParser.__init__(self, settings, qto_calculator)
                else:
                    IfcParser.__init__(self, settings)

            self.unique_fills_indexes = set()
            self.preprocessed_objects = set()
            self._keep_booleans = keep_booleans
            self.preprocessed_alternate_representations = set()
            self.preprocessed_plan_unique_source_objects = set()
            self.export_plan_representation = export_plan

        def parse(self, sel):
            geoms = self.pre_process_geometry(bpy.context, sel)
            IfcParser.parse(self, geoms)

        def _filter_component(self, o):
            """
            :param o: child of main object
            :return: True if child object is not a component
            """
            return (
                o.type != 'MESH' or
                o.data and (
                    "archipack_blind" in o.data or
                    "archipack_window_shutter" in o.data or
                    "archipack_window_curtain" in o.data
                ) or
                self.has_flag(o, "hole")
            )

        def _get_components(self, o, components):
            for c in o.children:
                self._get_components(c, components)
                # filter non components objects
                if self._filter_component(c):
                    continue
                components.append(c)

        def _remove_geometry(self, o, filtered, flat, flat_names):
            if o.name in filtered:
                del filtered[o.name]
            if o.name in flat:
                del flat[o.name]
            if o.name in flat_names:
                flat_names.remove(o.name)

        def _find_holes(self, o):
            holes = []
            for m in o.modifiers:
                if m.type != 'BOOLEAN' or m.object is None:
                    continue
                if "archipack_hybridhole" in m.object:
                    operand = m.object
                    for mod in operand.modifiers:
                        if mod.type != 'BOOLEAN' or mod.object is None:
                            continue
                        holes.append(mod.object)
            return holes

        def post_process_geometry(self, context):

            # Disable throttle as object name change in the meantime
            prefs = get_prefs(context)
            last_state = prefs.throttle_enable
            prefs.throttle_enable = False

            for name in self.preprocessed_objects:
                o = bpy.data.objects.get(name)
                if o is not None:
                    d = None
                    for key in o.data.keys():
                        if "archipack_" in key:
                            d = getattr(o.data, key)[0]
                            break
                    if d is not None:
                        # print("postprocess", name)
                        with context_override(context, o, [o]) as ctx:
                            d.update(ctx)

            for name in self.preprocessed_alternate_representations:
                o = self.get_scene_object(context, name)
                o.data.use_fake_user = False
                self.delete_object(context, o)

            prefs.throttle_enable = last_state

        def get_ifc_collection(self, o):
            return [coll for coll in o.users_collection if coll.name.startswith("Ifc")][0]

        def _add_plan_representation(self, o, symbol, ifc_context):
            self.set_curve_origin(o, symbol)
            symbol.name = o.name
            symbol.data.name = '%s/%s' % (ifc_context, o.data.name.split("/")[3])
            symbol.data.use_fake_user = True
            self.preprocessed_alternate_representations.add(symbol.name)

        def set_curve_origin(self, o, c):
            trs = o.matrix_world.inverted() @ c.matrix_world
            for spline in c.data.splines:
                # fix issue #9
                if spline.type in {'POLY', 'NURBS'}:
                    for p in spline.points:
                        p.co = (trs @ p.co.to_3d()).to_4d()

                elif spline.type == "BEZIER":
                    for p in spline.bezier_points:
                        p.co = trs @ p.co
                        p.handle_left = trs @ p.handle_left
                        p.handle_right = trs @ p.handle_right

            c.matrix_world = o.matrix_world.copy()

        def pre_process_axis_representation(self, context, wall, ifc_context):
            d = wall.data.archipack_wall2[0]
            g = d.get_generator(wall)
            w = g.axis.as_curve(name=wall.name)
            w.data.name = "%s/%s".format(ifc_context, wall.name.split("/")[3])
            w.data.use_fake_user = True
            self.preprocessed_alternate_representations.add(w.name)

        def pre_process_plan_representation(self, context, wall, ifc_context):

            openings = []
            parts = []

            d = wall.data.archipack_wall2[0]
            inter = []
            # doors holes
            doors = []
            windows = []

            geom_mode = 'PLAN_2D'  #'FOOTPRINT'

            try:
                io, geom, t_childs = d.as_geom(context, wall, geom_mode, inter, doors, windows)
            except:
                print("Archipack ifc export error with wall %s : topology error" % wall.name)
                return

            # collect polygons
            geoms = []
            if geom.type_id == 6:
                # Multipolygon
                geoms = geom.geoms
            elif geom.type_id == 3:
                # Polygon
                geoms = [geom]
            elif geom.type_id == 7:
                # GeometryCollection components may be Polygon and Multipolygon
                for g in geom.geoms:
                    if g.type_id == 3:
                        geoms.append(g)
                    elif g.type_id == 6:
                        geoms.extend(g.geoms)

            if len(geoms) < 1:
                # no polygons found, probably a topology error like crossing walls
                print("Archipack ifc export error with wall %s : no polygon found" % wall.name)
                return

            wall_collection = self.get_ifc_collection(wall)

            # ensure reversed cw ccw for interiors
            for poly in geoms:
                is_ccw = poly.exterior.is_ccw
                for i, c in enumerate(poly.interiors):
                    if c.is_ccw == is_ccw:
                        poly.interiors[i] = c.reverse()

            w = io._to_curve(geom, wall.name, '2D')
            d = w.data
            d.name = '%s/%s' % (ifc_context, wall.data.name.split("/")[3])
            d.use_fake_user = True
            self.set_curve_origin(wall, w)
            self.preprocessed_alternate_representations.add(w.name)
            # w.users_collection.objects.unlink(w)
            # bpy.ops.objects.delete(w)
            # wall_collection.objects.link(w)
            # filtered[d.name] = d

            # wall fill under windows
            # if len(inter) > 0:
            #     # TODO: keep track of rel-void element
            #     for i, c in enumerate(inter):
            #         f = io._to_curve(c, "{}-w-2d-{}".format(wall.name, i), '2D')

            # windows / doors
            for c in windows:
                if c.name in self.preprocessed_plan_unique_source_objects:
                    continue
                if "archipack_window" in c.data:
                    d = c.data.archipack_window[0]
                else:
                    continue
                self.preprocessed_plan_unique_source_objects.add(c.name)
                symbol = d.as_2d(context, c)
                self._add_plan_representation(c, symbol, ifc_context)

            for c in doors:
                if c.name in self.preprocessed_plan_unique_source_objects:
                    continue
                if "archipack_door" in c.data:
                    d = c.data.archipack_door[0]
                else:
                    continue
                self.preprocessed_plan_unique_source_objects.add(c.name)
                symbol = d.as_2d(context, c)
                self._add_plan_representation(c, symbol, ifc_context)

        def pre_process_geometry(self, context, sel):
            # Store object name that require refresh after export

            # join components to match Ifc entity structure
            filtered = {o.name: o for o in sel if o.type in {'MESH', 'EMPTY'}}
            flat = {}
            flat_names = set()
            for o in sel:
                key, d = self.get_component_key(o)
                if key:
                    flat[o.name] = tuple([o, d.__class__.__name__])
                    flat_names.add(o.name)

            if self.export_plan_representation:

                ifc_context = "Plan/Annotation/PLAN_VIEW"

                for name, (o, apk_cls) in flat.items():
                    if "wall" in apk_cls:
                        self.pre_process_plan_representation(context, o, ifc_context)

                    elif "slab" in apk_cls:
                        symbols = o.data.archipack_slab[0].as_2d(context, o)
                        for symbol in symbols:
                            self._add_plan_representation(o, symbol, ifc_context)

                    elif "stair" in apk_cls:
                        symbol = o.data.archipack_stair[0].as_2d(context, o)
                        self._add_plan_representation(o, symbol, ifc_context)

            # keep track of processed mesh to prevent re-merge of components
            instances = set()
            while len(flat_names) > 0:
                n = flat_names.pop()
                o, apk_cls = flat[n]
                if apk_cls in IFC_CLASS_MAP:
                    # keep archipack containers
                    if apk_cls in {'archipack_building'}:
                        continue

                    elif apk_cls == 'archipack_reference_point':
                        # skip empty ref points
                        if len([c for c in o.children if c.name in filtered]) < 1:
                            self._remove_geometry(o, filtered, flat, flat_names)

                    elif "wall" in apk_cls or "hole" in apk_cls:
                        # use "is_parametric" for walls with booleans
                        # to prevent boolean modifier evaluation
                        o.BIMObjectProperties.is_parametric = self._keep_booleans

                        instances.add(o.name)
                        # add holes to selection
                        holes = self._find_holes(o)
                        for hole in holes:
                            if hole.name not in filtered:
                                filtered[hole.name] = hole

                    else:
                        # components are children of main object (including nested childs)
                        components = []
                        self._get_components(o, components)
                        if len(components) > 0:
                            for c in components:
                                # remove merged geometry in list of entity to export
                                self._remove_geometry(c, filtered, flat, flat_names)
                                # print("pre process remove", c.name)
                            if o.data.name not in instances:
                                # print("pre process", o.name)
                                self.preprocessed_objects.add(o.name)
                                # Join geometry
                                with context_override(bpy.context, o, components) as ctx:
                                    self.call_operator(bpy.context, ctx, bpy.ops.object.join, None, 'INVOKE_DEFAULT')
                                    # bpy.ops.object.join(ctx, 'INVOKE_DEFAULT')
                        instances.add(o.data.name)

            return list(filtered.values())

        def resolve_voids_and_fills(self, i, obj):
            holes = self._find_holes(obj)
            if len(holes) > 0:
                for hole in holes:
                    void_or_projection = self.get_product_index_from_raw_name(hole.name)
                    if void_or_projection is None:
                        print("Skip hole %s" % hole.name)
                        continue
                    self.rel_voids_elements.setdefault(i, []).append(void_or_projection)
                    if not hole.parent:
                        continue
                    fill = self.get_product_index_from_raw_name(hole.parent.name)
                    # Ensure fill is not used twice by same hole on different walls
                    if fill and fill not in self.unique_fills_indexes:
                        self.rel_fills_elements.setdefault(void_or_projection, []).append(fill)
                        self.unique_fills_indexes.add(fill)
            else:
                IfcParser.resolve_voids_and_fills(self, i, obj)

    return ArchipackIfcExporter, ArchipackIfcParser, QtoCalculator, IfcExportSettings


class ArchipackIfcStructure(ArchipackIfcClassifier):

    @staticmethod
    def ensure_collections():
        for coll in bpy.data.collections:
            if coll.name.startswith("Ifc"):
                return True
        return False

    def _add_predefined_type(self, o, predefined_type):
        p = o.BIMObjectProperties.attributes.get("PredefinedType")
        if p is None:
            p = o.BIMObjectProperties.attributes.add()
            p.name = "PredefinedType"
            p.string_value = predefined_type.upper()

    def ifc_name(self, o, apk_cls, ifc_context):
        ifc_class = IFC_CLASS_MAP[apk_cls]
        self.ifc_name_context(o, ifc_class, ifc_context)
        if apk_cls in PREDEFINED_TYPES:
            self._add_predefined_type(o, PREDEFINED_TYPES[apk_cls])

    def link_to_ifc_collection(self, o, coll):
        if coll not in o.users_collection:
            coll.objects.link(o)

    def create_ifc_collection(self, name, parent_coll):
        o = bpy.data.objects.new(name=name, object_data=None)
        # o.matrix_world = Matrix()
        coll = self.create_collection(
            parent_coll,
            name=o.name,
            separator="|",
            unique=True
        )
        self.link_to_ifc_collection(o, coll)
        return o, coll

    def create_ifc_structure(self, context):

        sel = context.scene.objects

        apk = {}
        # assoc {archipack_class: {object: datablock}}
        self.transverse(sel, apk)

        # TODO: handle pre-existing site / building + hierarchy ??
        context_prefix = "Model/Body/MODEL_VIEW"

        if "archipack_reference_point" in apk:

            coll = context.scene.collection

            project, p_coll = self.create_ifc_collection("IfcProject/Project", coll)
            site, site_coll = self.create_ifc_collection("IfcSite/Site", p_coll)
            building, b_coll = self.create_ifc_collection("IfcBuilding/Building", site_coll)
            # Geographical elements are child of IfcSite
            if "archipack_terrain" in apk:
                for terrain, d in apk["archipack_terrain"].items():
                    self.ifc_name(terrain, "archipack_terrain", context_prefix)
                    self.link_to_ifc_collection(terrain, site_coll)

            for ref, d in apk["archipack_reference_point"].items():

                if len(ref.children) < 1:
                    continue

                # get objects associated with this storey
                sub = {}
                self.rec_transverse(ref, sub)
                storey, s_coll = self.create_ifc_collection("IfcBuildingStorey/%s" % ref.name, b_coll)
                storey.matrix_world = ref.matrix_world.copy()

                for apk_cls, objs in sub.items():
                    if apk_cls in {"archipack_terrain"}:
                        continue
                    # print(apk_cls)
                    if apk_cls in IFC_CLASS_MAP:
                        for o, _d in objs.items():
                            self.ifc_name(o, apk_cls, context_prefix)
                            self.link_to_ifc_collection(o, s_coll)

                            for key in {'archipack_hole', 'archipack_custom_hole'}:
                                for c in o.children:
                                    if key in c:
                                        # print(o.name, "hole:", c.name)
                                        self.ifc_name(c, 'archipack_hole', context_prefix)
                                        self.link_to_ifc_collection(c, s_coll)

    def clean_name(self, o, apk_cls, ifc_context):
        ifc_class = IFC_CLASS_MAP[apk_cls]
        if ifc_class in o.name:
            p_len = len(ifc_class) + 1
            o.name = o.name[p_len:]
        if o.data and ifc_context in o.data.name:
             p_len = len(ifc_context) + 1
             o.data.name = o.data.name[p_len:]

    def _remove_ifc_collection(self, context, parent, c):
        o = bpy.data.objects.get(c.name)
        if o is not None:
            self._delete_object(context, o)
        parent.children.unlink(c)
        bpy.data.collections.remove(c)

    def remove_ifc_collection(self, context, coll):
        for c in coll.children:
            self.remove_ifc_collection(context, c)
            self._remove_ifc_collection(context, coll, c)

    def remove_ifc_structure(self, context):

        sel = context.scene.objects

        apk = {}
        # assoc {archipack_class: {object: datablock}}
        self.transverse(sel, apk)
        context_prefix = "Model/Body/MODEL_VIEW"

        if "archipack_reference_point" in apk:
            for ref, d in apk["archipack_reference_point"].items():
                self.clean_name(ref, "archipack_reference_point", context_prefix)
                # get objects associated with this storey
                sub = {}
                self.rec_transverse(ref, sub)
                for apk_cls, objs in sub.items():
                    if apk_cls in IFC_CLASS_MAP:
                        for o, _d in objs.items():
                            self.clean_name(o, apk_cls, context_prefix)
                            for key in {'archipack_hole', 'archipack_custom_hole'}:
                                for c in o.children:
                                    if key in c:
                                        self.clean_name(c, 'archipack_hole', context_prefix)

        # Remove Ifc collections + helpers
        coll = context.scene.collection.children.get("IfcProject/Project")
        if coll is not None:
            self.remove_ifc_collection(context, coll)
            self._remove_ifc_collection(context, context.scene.collection, coll)


class ARCHIPACK_IO_Export_ifc(ExportHelper, ArchipackObjectsManager, Operator):
    bl_idname = "export_ifc.archipack"
    bl_label = "Industry Foundation Classes (archipack) (.ifc)"
    bl_description = "Industry Foundation Classes ASCII"

    bl_options = {'PRESET'}
    filename_ext = ".ifc"
    filepath: StringProperty(subtype='FILE_PATH')

    # ExportHelper class properties
    filter_glob: StringProperty(
         default="*.ifc",
         options={'HIDDEN'},
    )

    zip: BoolProperty(
        name="Export zipped (.ifczip)",
        default=False
    )
    export_plan_representation: BoolProperty(
        name="Export 2d plan representation",
        default=False
    )
    schema: EnumProperty(
        name="IFC schema",
        items=(
            ('23', "ifc 2X3", "Schema 2x3"),
            ('42', "ifc 4X2", "Schema 4x2"),
        ),
        default='42'
    )
    export_materials: BoolProperty(
        name="Export materials",
        default=True
    )
    selected_only: BoolProperty(
        name="Only selected",
        default=False
    )
    user: StringProperty(
        default=user_name().capitalize()
    )
    email: StringProperty(
        default="%s@" % user_name().lower()
    )
    company: StringProperty(
        default="Company"
    )
    project: StringProperty(
        default="Project"
    )

    def is_valid_ifc_object(self, o):
        if o.name.startswith("Ifc"):
            for coll in o.users_collection:
                if coll.name.startswith("Ifc"):
                    return True
        return False

    def ensure_plan_context(self, context):
        ctx = None
        name, target_view =  'Annotation', 'PLAN_VIEW'
        for _c in context.scene.BIMProperties.plan_subcontexts:
            if _c.name == name and _c.target_view == target_view:
                ctx = _c
                break
        if ctx is None:
            ctx = context.scene.BIMProperties.plan_subcontexts.add()
            ctx.name = name
            ctx.target_view = target_view
        context.scene.BIMProperties.has_plan_context = True

    def ensure_model_context(self, context):
        ctx = None
        name, target_view = 'Body', 'MODEL_VIEW'
        for _c in context.scene.BIMProperties.model_subcontexts:
            if _c.name == name and _c.target_view == target_view:
                ctx = _c
                break
        if ctx is None:
            ctx = context.scene.BIMProperties.model_subcontexts.add()
            ctx.name = name
            ctx.target_view = target_view
        context.scene.BIMProperties.has_model_context = True

    def draw(self, context):
        pass

    def execute(self, context):
        ArchipackIfcExporter, ArchipackIfcParser, QtoCalculator,  IfcExportSettings = init_blenderbim()
        # bpy.ops.object.mode_set(mode='OBJECT')
        result = {'FINISHED'}
        start = time.time()
        base_path, ext = os.path.splitext(os.path.realpath(self.filepath))

        filename = os.path.basename(base_path)
        ext = '.ifc'
        if self.zip:
            ext = '.ifczip'

        output_file = bpy.path.ensure_ext(base_path, ext)

        if ArchipackIfcExporter is not None:
            # This is a modified version of Moult's exporter to handle our own parser methods for booleans
            context.window.cursor_set("WAIT")
            struct_man = ArchipackIfcStructure()
            has_structure = struct_man.ensure_collections()

            if not has_structure:
                struct_man.create_ifc_structure(context)

            if self.selected_only:
                selected_objects = context.selected_objects
            else:
                selected_objects = context.scene.objects

            selected_objects = [o for o in selected_objects if self.is_valid_ifc_object(o)]

            if len(selected_objects) < 1:
                self.report({'WARNING'}, "Nothing to export")
                context.window.cursor_set("DEFAULT")
                return {'CANCELLED'}

            logger = logging.getLogger('ExportIFC')
            logging.basicConfig(
                filename=context.scene.BIMProperties.data_dir + 'process.log',
                filemode='a', level=logging.DEBUG
            )

            context.scene.BIMProperties.ifc_file = output_file

            self.ensure_model_context(context)
            if self.export_plan_representation:
                self.ensure_plan_context(context)

            keep_booleans = True
            qto = QtoCalculator()

            settings = IfcExportSettings.factory(context, output_file, logger)
            parser = ArchipackIfcParser(settings, keep_booleans, self.export_plan_representation, qto)
            settings.logger.info('Starting export')
            exporter = ArchipackIfcExporter(settings, parser, qto)
            exporter.export(selected_objects)

            settings.logger.info('Export finished in {:.2f} seconds'.format(time.time() - start))

            # restore geometry
            parser.post_process_geometry(context)
            if not has_structure:
                 # remove "on the fly" structure
                 struct_man.remove_ifc_structure(context)

            context.window.cursor_set("DEFAULT")

        else:
            self.report({"WARNING"}, 'blenderBIM addon not found, fallback to python export')
            if ext == 'ifc':
                ifc_export(self, context, output_file)
            else:
                import zipfile
                tmp_name = "%s.ifc" % filename
                tmp_file = os.path.join(bpy.app.tempdir, tmp_name)
                ifc_export(self, context, tmp_file)
                with zipfile.ZipFile(output_file, mode='w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
                    zf.write(tmp_file, tmp_name)

                os.remove(tmp_file)

        self.report({"INFO"}, 'Export finished in {:.2f} seconds'.format(time.time() - start))
        return result


class ARCHIPACK_OT_ifc_structure(ArchipackIfcClassifier, Operator):
    bl_label = "Ifc structure"
    bl_idname = 'archipack.ifc_structure'
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Create ifc collection(s) and object classes"

    selected_only: BoolProperty(name="Selected only", default=False)

    # def invoke(self, context, event):
    #    return context.window_manager.invoke_confirm(self, event)

    @classmethod
    def poll(cls, context):
        return has_blenderbim()

    def execute(self, context):
        bpy.ops.archipack.disable_manipulate()
        struct_man = ArchipackIfcStructure()
        struct_man.create_ifc_structure(context)
        return {'FINISHED'}


class ARCHIPACK_PT_Export_ifc(Panel):
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_label = "Options"
    bl_parent_id = "FILE_PT_operator"

    @classmethod
    def poll(cls, context):
        sfile = context.space_data
        operator = sfile.active_operator
        return operator.bl_idname == "EXPORT_IFC_OT_archipack"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.
        sfile = context.space_data
        operator = sfile.active_operator
        layout.prop(operator, "zip")
        layout.prop(operator, "selected_only")
        layout.prop(operator, "export_plan_representation")
        if has_blenderbim():
            return
        layout.prop(operator, "schema")
        layout.prop(operator, "export_materials")
        layout.prop(operator, "project")
        layout.prop(operator, "company")
        layout.prop(operator, "user")
        layout.prop(operator, "email")


class ARCHIPACK_OT_ifc_structure_remove(ArchipackIfcClassifier, Operator):
    bl_label = "Cleanup"
    bl_idname = 'archipack.ifc_structure_remove'
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Cleanup object names from Ifc prefixes"

    selected_only: BoolProperty(name="Selected only", default=False)

    # def invoke(self, context, event):
    #    return context.window_manager.invoke_confirm(self, event)

    @classmethod
    def poll(cls, context):
        return has_blenderbim()

    def execute(self, context):
        bpy.ops.archipack.disable_manipulate()
        struct_man = ArchipackIfcStructure()
        struct_man.remove_ifc_structure(context)
        return {'FINISHED'}


def menu_func_export(self, context):
    if has_blenderbim():
        self.layout.operator(ARCHIPACK_IO_Export_ifc.bl_idname, text=ARCHIPACK_IO_Export_ifc.bl_label)


def register():
    bpy.utils.register_class(ARCHIPACK_PT_Export_ifc)
    bpy.utils.register_class(ARCHIPACK_OT_ifc_structure)
    bpy.utils.register_class(ARCHIPACK_OT_ifc_structure_remove)
    bpy.utils.register_class(ARCHIPACK_IO_Export_ifc)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    import bpy
    bpy.utils.unregister_class(ARCHIPACK_OT_ifc_structure)
    bpy.utils.unregister_class(ARCHIPACK_OT_ifc_structure_remove)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(ARCHIPACK_IO_Export_ifc)
    bpy.utils.unregister_class(ARCHIPACK_PT_Export_ifc)
