# -*- coding:utf-8 -*-

# Easyref Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy

# To check if we are inside a camera ----------------------------------------------------------
def CamRef_Check_Cam_Statut():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            r3d = area.spaces.active.region_3d
            if r3d.view_perspective=='CAMERA':
                bpy.ops.view3d.view_camera()

def get_addon_preferences():
    addon_key = __package__.split(".")[0]
    return bpy.context.preferences.addons[addon_key].preferences

# REFERENCES
def easyref_reference_size(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.empty_display_size = easyref_empties.all_refs_size

def easyref_all_references_opacity(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.color[3] = easyref_empties.all_refs_opacity

def easyref_all_references_depth(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.empty_image_depth = easyref_empties.all_refs_depth

def easyref_all_references_side(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.empty_image_side = easyref_empties.all_refs_side

def easyref_all_references_ortho(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.show_empty_image_orthographic = easyref_empties.all_refs_ortho

def easyref_all_references_persp(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.show_empty_image_perspective = easyref_empties.all_refs_persp

def easyref_all_references_only_axis_aligned(self, context):
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    for j, refs in enumerate(easyref_ref_list):
        refs.show_empty_image_only_axis_aligned = easyref_empties.all_refs_only_axis_aligned #bpy.context.object.show_empty_image_only_axis_aligned = True

def easyref_all_references_size(self, context):
    prefs = get_addon_preferences()
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref if not ref.hide_viewport]

    for refs in easyref_ref_list:
        refs.empty_display_size = easyref_empties.all_refs_size

    prefs.ref_size = easyref_empties.all_refs_size

def easyref_all_references_distance(self, context):
    prefs = get_addon_preferences()
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

    # Définir la distance comme une valeur positive
    distance = abs(easyref_empties.all_refs_distance)

    for refs in easyref_ref_list:
        # Utiliser un dictionnaire pour mapper les directions et les axes
        direction_mapping = {
            "easyref_front": (1, distance),
            "easyref_back": (1, -distance),
            "easyref_left": (0, distance),
            "easyref_right": (0, -distance),
            "easyref_top": (2, -distance),
            "easyref_bottom": (2, distance)
        }

        # Appliquer la distance selon la direction
        for direction, (axis, value) in direction_mapping.items():
            if refs.get(direction):
                refs.location[axis] = value
                break  # Une référence ne peut avoir qu'une seule direction

    # Mettre à jour les préférences
    prefs.prefs_refs_distance = distance

def easyref_all_references_distance_y(self, context):
    prefs = get_addon_preferences()
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref ]

    for j, refs in enumerate(easyref_ref_list):
        refs.location[1] = easyref_empties.all_refs_distance_y

    prefs.prefs_refs_distance = easyref_empties.all_refs_distance_y

def easyref_all_references_distance_z(self, context):
    prefs = get_addon_preferences()
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref ]

    for j, refs in enumerate(easyref_ref_list):
        if refs.get("easyref_top") or refs.get("easyref_bottom"):
            continue
        refs.location[2] = easyref_empties.all_refs_distance_z

    prefs.prefs_refs_distance = easyref_empties.all_refs_distance_z

def view3d_find( return_area = False ):
    # returns first 3d view, normally we get from context
    for area in bpy.context.window.screen.areas:
        if area.type == 'VIEW_3D':
            v3d = area.spaces[0]
            rv3d = v3d.region_3d
            for region in area.regions:
                if region.type == 'WINDOW':
                    if return_area: return region, rv3d, v3d, area
                    return region, rv3d, v3d
    return None, None

# Update UI and 3Dview ------------------------------------------------------------------------
def EasyRef_Update_UI():
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            area.tag_redraw()

def get_ref_view_area(context):
    prefs = get_addon_preferences()
    """
    Check if a reference view is open and return its area.
    Returns:
        area: The reference view area if found, None otherwise
    """
    # Check if reference view is enabled in scene properties
    if not context.scene.easyref_props.has_ref_view:
        return None
        
    # Get the reference view side from scene properties
    ref_side = context.scene.easyref_props.ref_view_side
    
    # Find reference view area by checking background color
    for i, area in enumerate(context.screen.areas):
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            color = space.shading.background_color
            # Check if this is our reference view by comparing colors with tolerance
            if (abs(color[0] - prefs.ref_view_bg_color[0]) < 0.0001 and 
                abs(color[1] - prefs.ref_view_bg_color[1]) < 0.0001 and 
                abs(color[2] - prefs.ref_view_bg_color[2]) < 0.0001):
                return area
                        
    return None

def easyref_empty_image_offset_x(self, context):
    """Update the image offset X for selected references"""
    for obj in context.selected_objects:
        if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE':
            obj.empty_image_offset[0] = self.empty_image_offset_x

def easyref_empty_image_offset_y(self, context):
    """Update the image offset Y for selected references"""
    for obj in context.selected_objects:
        if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE':
            obj.empty_image_offset[1] = self.empty_image_offset_y

_handle_dict = {
    "handle": None,
    "space": None
}