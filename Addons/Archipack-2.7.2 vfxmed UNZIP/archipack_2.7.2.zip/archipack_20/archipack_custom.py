# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, FloatVectorProperty, BoolProperty,
    CollectionProperty, StringProperty, IntProperty,
    EnumProperty, PointerProperty
)
from .archipack_snap import snap_point
from .bmesh_utils import BmeshEdit as bmed
from bpy_extras import view3d_utils
from math import pi
from mathutils import Vector, Matrix
from mathutils.geometry import (
    intersect_line_plane
    )
from .archipack_manipulator import Manipulable
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_gl import (
    FeedbackPanel,
    GlPolygon,
    SquareHandle,
    GlLine,
    GlText,
    TriHandle
)
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackPanel,
    ArchipackObject,
    ArchipackDrawTool,
    ArchipackCreateTool,
    ArchipackArrayTool,
    ArchipackObjectsManager,
    Callbacks
    )
from .archipack_abstraction import (
    ensure_select_and_restore, X_AXIS, Y_AXIS, Z_AXIS, ArchipackFlagsManager,
    context_override,
    stop_auto_manipulate
)
from .archipack_segments2 import OpeningGenerator
from .archipack_keymaps import Keymaps
from .archipack_dimension import DimensionProvider
from .archipack_snap import (
    CANCEL,
    FREEMOVE
)


# Custom object may be nested into wrapper classes
wrapper_classes = {
    "archipack_window",
    "archipack_door",
    "archipack_hole",
    "archipack_nested_custom",
    "archipack_kitchen_cabinet",
    "archipack_kitchen_module"
}


def update(self, context):
    self.update(context)


def update_manipulators(self, context):
    self.manipulable_refresh = True
    self.update(context)


class Changed:
    """
    Fake part to store last state on change
    """
    def __init__(self):
        self.prop = ""
        self.last = 0
        pass

    def init(self, d, prop):
        # changed property name
        # print("Changed.init()", prop)
        self.prop = prop
        self.last = getattr(d, prop)

    def get_change(self):
        prop, last = self.prop, self.last
        self.prop = ""
        self.last = 0
        return prop, last


def change_getter(attr):
    def getter(self):
        return getattr(self, attr)
    return getter


def change_setter(attr):
    def setter(self, value):
        self.__class__.change.init(self, attr)
        setattr(self, attr, value)
        return None
    return setter


def update_user_object(self, context):
    # print("update_user_object")
    self.update_user_object(context)
    self.cleanup_user_defined_objects(context, bpy.data.objects)




class Customizable:
    """
    Provide Custom/user defined object based geometry support for windows and doors
    """

    user_defined_object: PointerProperty(
        name="",
        type=Object,
        update=update_user_object
    )

    def cleanup_custom_mesh(self, o):
        if o and self.has_flag(o, "custom_mesh"):
            self.clear_modifier_stack(o)
            self.set_flag(o, "custom_mesh", False)

    def update_user_object(self, context):
        self.cleanup_custom_mesh(context.active_object)
        self.manipulable_refresh = True
        self.update(context)

    @property
    def has_user_defined_custom(self):
        """user defined object is an archipack Custom
        :return:
        """
        return archipack_custom.filter(self.user_defined_object)

    @property
    def has_user_defined_object(self):
        """user defined object is a dum Object
        :return:
        """
        return self.has_user_object and not self.has_user_defined_custom

    @property
    def has_user_object(self):
        return self.user_defined_object is not None

    def _transform_childrens(self, src, dst):
        """Propagate child location relative to parent in hierarchy
        This will trigger a matrix update in childrens
        """
        for s, d in zip(src.children, dst.children):
            d.matrix_world = dst.matrix_world.copy()
            d.location = s.location.copy()
            d.rotation_euler = s.rotation_euler.copy()
            self.safe_scale(d)
            self._transform_childrens(s, d)

    def _update_custom_childs(self, context, source, o, translate, linked, vertex_groups=None):
        """Delete and restore strategy, keep hole"""
        if o.name == source.name:
            return

        self.link_materials(context, source, o)

        for c in o.children:
            # Do never delete holes to keep reference in boolean modifier
            if not self.has_flag(c, ("custom_hole", "hole")):
                self.delete_object(context, c)

        # custom hole
        hole_dst = self.find_hole(o)

        layer_name = o.users_collection[0].name

        for c in source.children:

            if self.has_flag(c, "custom_hole") and hole_dst is not None:
                # transfert custom hole data from source
                bm = bmed._start(c)
                bmed._end(bm, hole_dst)

                if vertex_groups is not None:
                    bmed.set_vertex_groups(hole_dst, vertex_groups)
                new_c = hole_dst

            else:

                is_hole = self.has_flag(c, ("hole", "custom_hole"))

                if is_hole:
                    layer = "Holes"
                else:
                    layer = layer_name

                new_c = self.duplicate_object(
                    context, c, linked and not is_hole, layer_name=layer
                )
                new_c.parent = o

                # self.set_parent(context, o, new_c)

                # flag as custom member object to be able to delete
                self.set_flag(new_c, 'custom_member', True)

                if is_hole:
                    self.hide_for_render_engines(new_c)
                    # print("Customizable.update_custom_childs create hole_dst", c.name, new_c.name)

            new_c.matrix_world = o.matrix_world.copy()
            new_c.location = c.location + translate
            new_c.rotation_euler = c.rotation_euler.copy()
            # copy euler may screw the matrix scale to 0 ..
            self.safe_scale(new_c)

            self._transform_childrens(c, new_c)

    def custom_datablock_update(
            self, context, source, o, translation=Vector(), override_attrs=None
    ):
        """update custom datablock based window"""

        # Copy source custom datablock to this object
        if not archipack_custom.filter(o):
            with context_override(context, o, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.archipack.custom, {
                    "source": source.name,
                    "mode": 'COPY'
                })
                #                   bpy.ops.archipack.custom(ctx, source=source.name, mode='COPY')
            # copy modifier stack
            self.copy_modifier_stack(source, o)

        # first update object's mesh
        transform = Matrix.Translation(translation)

        # reset mesh to source one
        bm = bmed.bmesh_from_obj(source, transform=transform)
        bmed._end(bm, o)

        # transfer vertex groups
        vertex_groups = bmed.vertex_groups_from_obj(source)
        bmed.set_vertex_groups(o, vertex_groups)

        # store source hole vertex groups
        vertex_groups = None
        hole = self.find_hole(source)
        if hole is not None:
            vertex_groups = bmed.vertex_groups_from_obj(hole)

        # never link to source object
        self._update_custom_childs(context, source, o, translation, False, vertex_groups)

        # Reset childs of linked objects before updating
        # as custom callback handle linked too
        linked_objects = self.get_linked_objects(context, o)
        for linked in linked_objects:
            # link, so mesh get updated
            self._update_custom_childs(context, o, linked,  translation, True, vertex_groups)

        # reset xx_cur to original as we do restart from scratch
        # to support mesh "bending" in post process
        dst = archipack_custom.datablock(o)
        src = archipack_custom.datablock(source)

        # synchro set reference as last, then set value
        # always update 4 times, as we are starting from scratch every time
        for attr in ['x', 'y', 'z', 'altitude']:
            # sequential update as it is "change" from last based
            setattr(dst, "%s_cur" % attr, getattr(src, "%s_cur" % attr))
            if override_attrs is not None and attr in override_attrs:
                setattr(dst, attr, override_attrs[attr])
            else:
                setattr(dst, attr, getattr(self, attr))
            # when setting value, context is global one, so if not selected, update by hand
            if not o.select_get():
                with context_override(context, o, [o]) as ctx:
                    dst.update(ctx)

        return None

    def custom_geometry_update(self, context, source, o, translation=Vector(), linked=True):
        """update dumb window"""
        transform = Matrix.Translation(translation)

        bm = bmed.bmesh_from_obj(
            source, transform=transform
        )
        bmed._end(bm, o)

        if not self.has_flag(o, "custom_mesh"):
            self.copy_modifier_stack(source, o)
            self.set_flag(o, "custom_mesh", True)

        self._update_custom_childs(context, source, o, translation, linked)

        # Synch childs of linked objects
        linked_objects = self.get_linked_objects(context, o)
        for c in linked_objects:
            if c.name != o.name:
                self.update_custom_childs(context, o, c, translation, linked)

        return None

    def remove_custom_childs(self, context, o):
        # clean up custom datablock
        if archipack_custom.filter(o):
            o.data.archipack_custom.remove(0)
            self.clear_modifier_stack(o)

        for c in o.children:
            if self.has_flag(c, "custom_member"):
                self.delete_object(context, c)


class archipack_custom_part(ArchipackObject, PropertyGroup):
    """
      Defines and custom part
      Provide access to custom parent ui
      While parent resize from axis
      parts might have pivot not matching parent one
      so we must recompute pivot location
    """

    # pivot weight = same weight as a vertex in that location
    # ['left', 'right', 'front', 'back', 'bottom', 'top']
    pivot_weight: FloatVectorProperty(
        default=[0, 0, 0, 0, 0, 0],
        size=6
    )
    deformable: BoolProperty(
        name="Deformable",
        description="Allow deformations on the object",
        default=True
    )

    def find_custom(self, context):
        o = self.find_in_selection(context)
        if o and o.parent:
            self.restore_auto_manipulate(context)
            return o.parent


class archipack_custom(ArchipackObject, Manipulable, DimensionProvider, PropertyGroup):
    """
      This is the custom root
      use parent-child relationship to identify parts
    """
    change = Changed()
    # temporary source to save preset
    source: PointerProperty(type=Object)

    mode: EnumProperty(
        name="Mode",
        items=(
            ('FULL', 'Full', 'Use xyz and altitude', 0),
            ('WALL', 'Wall', 'Use xz and altitude', 1),
            ('FLOOR', 'Floor', 'Use xyz', 2),
            ('ALT', 'Altitude', 'Use only altitude', 3)
        ),
        default="FULL",
        update=update_manipulators
    )

    draw_target: EnumProperty(
        name="Draw target",
        description="Draw tool target objects",
        items=(
            ("WALL", "Wall", "Snap to walls", 0),
            ("FLOOR", "Floor", "Snap to floors / slabs", 1),
        ),
        default="WALL"
    )

    x_cur: FloatProperty(
        name="Width",
        min=0.01
    )
    y_cur: FloatProperty(
        name="Depth",
        min=0.01
    )
    z_cur: FloatProperty(
        name="Height",
        min=0.01
    )
    altitude_cur: FloatProperty(
        name="Altitude"
    )
    # use xyz instead of _ui to make compatible with wall's maniuplators
    x: FloatProperty(
        options={'SKIP_SAVE', 'HIDDEN'},
        name="Width",
        min=0.01, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        get=change_getter("x_cur"),
        set=change_setter("x_cur"),
        update=update
    )
    y: FloatProperty(
        options={'SKIP_SAVE', 'HIDDEN'},
        name="Depth",
        min=0.01, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        get=change_getter("y_cur"),
        set=change_setter("y_cur"),
        update=update
    )
    z: FloatProperty(
        options={'SKIP_SAVE', 'HIDDEN'},
        name="Height",
        min=0.01, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        get=change_getter("z_cur"),
        set=change_setter("z_cur"),
        update=update
    )
    altitude: FloatProperty(
        options={'SKIP_SAVE', 'HIDDEN'},
        name="Altitude", precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        get=change_getter("altitude_cur"),
        set=change_setter("altitude_cur"),
        update=update
    )

    auto_update: BoolProperty(
        default=True,
        update=update,
        options={'SKIP_SAVE'}
    )

    flip: BoolProperty(
        default=False,
        # update=update,
        description='flip outside and outside material of hole'
    )

    @property
    def is_nested(self):
        """Return True if the custom object is also another kind of object"""
        for key in self.id_data.keys():
            if key in wrapper_classes:
                return True
        return self.has_flag(self.id_data, "nested_custom", write=False)

    def find_parts(self, o):
        sel = []
        self.rec_get_childrens(o, sel, archipack_custom_part.filter)
        return sel

    @staticmethod
    def relocate(o, dx, dy, dz, da):
        """
          apply delta to child location
        """
        d = archipack_custom_part.datablock(o)
        # child location relative to parent
        # loc = o.location
        # ['left', 'right', 'front', 'back', 'top']
        # delta location of pivot
        pivot = Vector()
        pivot.x = dx * (d.pivot_weight[0] + d.pivot_weight[1])
        pivot.y = dy * (d.pivot_weight[2] + d.pivot_weight[3])
        # pivot.z = dz * (d.pivot_weight[4])
        translation = pivot + Vector((0, 0, da))
        # Move child so the pivot stay in same location relative to parent
        o.location += translation
        for c in o.children:
            c.location -= translation
        return pivot

    @staticmethod
    def get_weights(o, group_index):
        for i, v in enumerate(o.data.vertices):
            for g in v.groups:
                if g.group == group_index:
                    yield i, g.weight
                    break

    def resize(self, bm, o, vgroups, group_name, delta, use_weights=True):
        # recompute locations in object coordsys
        if group_name in vgroups:
            group_index = vgroups[group_name]
            weights = self.get_weights(o, group_index)
            if use_weights:
                for i, w in weights:
                    bm.verts[i].co += delta * w
            else:
                verts = [bm.verts[i] for i, w in weights]
                bmed.translate(bm, delta, verts=verts)
            return True
        return False

    def get_generator(self, o=None):
        return OpeningGenerator(self, o, typ="CUSTOM")
    
    def setup_manipulators(self):
        # update manipulators data model
        n_manips = len(self.manipulators)
        if n_manips < 1:
            s = self.manipulators.add()
            s.type_key = "SNAP_SIZE_LOC"
            s.prop2_name = "x"
        else:
            s = self.manipulators[0]
        s.prop1_name = "x"

        if n_manips < 2:
            s = self.manipulators.add()
            s.type_key = "SNAP_SIZE_LOC"
            s.prop2_name = "y"
        else:
            s = self.manipulators[1]
        s.prop1_name = "y"
        if n_manips < 3:
            s = self.manipulators.add()
            s.normal = Vector((0, 1, 0))
        else:
            s = self.manipulators[2]
        s.prop1_name = "z"
        if n_manips < 4:
            s = self.manipulators.add()
            s.normal = Vector((0, 1, 0))
        else:
            s = self.manipulators[3]
        s.prop1_name = "altitude"

    def manipulable_setup(self, context, o):

        if self.is_nested:
            # print("Skip Custom object.manipulable_setup()")
            return

        # print("Custom object.manipulable_setup()")

        self.setup_manipulators()

        if self.mode != 'ALT':
            # x
            self.manip_stack.append(self.manipulators[0].setup(context, o, self))
            if self.mode != 'WALL':
                # y
                self.manip_stack.append(self.manipulators[1].setup(context, o, self))
            # z
            self.manip_stack.append(self.manipulators[2].setup(context, o, self))

        if self.mode != 'FLOOR':
            # altitude
            self.manip_stack.append(self.manipulators[3].setup(context, o, self))

    def _synch_childs(self, o, dx, dy, dz, da):
        childs = self.find_parts(o)
        # update linked child location relative to parent
        # vertices are updated through linked data
        for c in childs:
            self.relocate(c, dx, dy, dz, da)

    def synch_childs(self, context, o, dx, dy, dz, da):
        """
            synch childs nodes of linked objects
            update location relative to parent
        """
        linked = self.get_linked_objects(context, o)
        for c in linked:
            if c.name != o.name:
                self._synch_childs(c, dx, dy, dz, da)

    def update(self, context):
        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        prop, last = self.change.get_change()

        # early skip update, so we may blindly set values from outside
        # if prop == "" or getattr(self, prop) == last:
        #    print("*******************\nCustom update skip as value does not change", prop, last)
        #    self.restore_context(context)
        #    return
        # print("archipack_custom.update()", o.name, prop, last)

        self.setup_manipulators()

        parts = self.find_parts(o)
        parts.append(o)

        dx, dy, dz, da = 0, 0, 0, 0

        changed = False

        if prop == "x_cur":
            dx = 0.5 * (self.x_cur - last)
            changed = dx != 0

        elif prop == "y_cur":
            dy = 0.5 * (self.y_cur - last)
            changed = dy != 0

        elif prop == "z_cur":
            dz = self.z_cur - last
            changed = dz != 0

        elif prop == "altitude_cur":
            da = self.altitude_cur - last
            changed = da != 0


        if changed:

            # transform = None
            # if self.mirror_x or self.mirror_y:
            #     transform = Matrix()
            #     if self.mirror_x:
            #         dx = -dx
            #         transform[0][0] = -1
            #
            #     if self.mirror_y:
            #         dy = -dy
            #         transform[1][1] = -1

            # update parts mesh and location
            for c in parts:

                cd = archipack_custom_part.datablock(c)
                # kills vertex groups !
                # bm = bmed.bmesh_from_obj(c, flip_normals=self.mirror_x != self.mirror_y, transform=transform)
                bm = bmed._start(c)
                bmed.ensure_bmesh(bm)

                # print("archipack_custom.update() part", prop, last, getattr(self, prop), c.name)

                if cd is None or cd.deformable:

                    # apply changes to mesh, skip not deformable
                    vgroups = {vgroup.name: vgroup.index for vgroup in c.vertex_groups}

                    if prop == "x_cur":
                        self.resize(bm, c, vgroups, "right", Vector((dx, 0, 0)))
                        self.resize(bm, c, vgroups, "left", Vector((-dx, 0, 0)))

                    elif prop == "y_cur":
                        self.resize(bm, c, vgroups, "front", Vector((0, -dy, 0)))
                        self.resize(bm, c, vgroups, "back", Vector((0, dy, 0)))

                    elif prop == "z_cur":
                        self.resize(bm, c, vgroups, "top", Vector((0, 0, dz)))

                if c.name == o.name:
                    # keep pivot at origin, apply translate to mesh
                    if prop == "altitude_cur":
                        bmed.translate(bm, Vector((0, 0, da)))
                else:
                    # apply translation to pivot only, this also will apply to linked mesh
                    # move non deformable objects
                    delta = self.relocate(c, dx, dy, dz, da)
                    if cd is None or cd.deformable:
                        bmed.translate(bm, -delta)

                bmed._end(bm, c)

            # update linked childs location
            self.synch_childs(context, o, dx, dy, dz, da)

        if not self.is_nested:
            x, y, z, alt = 0.5 * self.x_cur, 0.5 * self.y_cur, self.z_cur, self.altitude_cur
            self.manipulators[0].set_pts([(-x, -y, 0), (x, -y, 0), (1, 0, 0)])
            self.manipulators[1].set_pts([(-x, -y, 0), (-x, y, 0), (-1, 0, 0)])
            self.manipulators[2].set_pts([(x, -y, alt), (x, -y, alt + z), (-1, 0, 0)])
            self.manipulators[3].set_pts([(x, -y, 0), (x, -y, alt), (-1, 0, 0)])

            self.add_dimension_point(0, Vector((-x, -y, 0)))
            self.add_dimension_point(1, Vector((x, -y, 0)))
            self.update_dimensions(context, o)

        self.restore_context(context)

    def interactive_hole(self, o):
        return self.find_hole(o)

    def find_hole(self, o):
        return self.find_one_by_flag(o,  ("custom_hole", "hole"))

    @staticmethod
    def remove_hole(context, hole, walls):
        ctx = context.copy()
        ctx['object'] = hole
        ctx['selected_objects'] = walls
        self.call_operator(context, ctx, bpy.ops.archipack.remove_hole)

    def on_delete(self, context, obj):
        walls = set()
        wall2 = {}
        sel = context.selected_objects[:]
        # collect walls
        ref = self.get_reference_point(obj)
        if ref is not None:
            walls = [
                c for c in ref.children
                if (
                        c.data and (
                            "archipack_wall2" in c.data
                            or "archipack_wall" in c.data
                            or self.has_flag(c, "custom_wall")
                        )
                )
            ]
            wall2 = {
                c: c.data.archipack_wall2[0]
                for c in ref.children
                if c.data and "archipack_wall2" in c.data
            }

        for o in sel:
            if archipack_custom.filter(o):
                hole = self.find_hole(o)
                if hole is not None:
                    self.remove_hole(context, hole, walls)

                if o.name != obj.name:
                    self.delete_object(context, o)

        for c, d in wall2.items():
            d.setup_childs(context, c, openings_only=True)
            for i, child in enumerate(d.childs):
                if child.child_name == obj.name:
                    d.childs.remove(i)
                    break
            d.synch_dimension(context, c)
        ArchipackObject.on_delete(self, context, obj)


class ARCHIPACK_PT_custom(ArchipackPanel, Archipacki18n, ArchipackFlagsManager, Panel):
    bl_idname = "ARCHIPACK_PT_custom"
    bl_label = "Custom object"

    @classmethod
    def poll(cls, context):
        return archipack_custom.poll(context.active_object)

    def draw(self, context):
        layout = self.layout

        if context.mode in {'EDIT_MESH', 'PAINT_WEIGHT'}:
            self.draw_label(context, layout, layout, text="Average weights")

            self.draw_op(
                context, layout, layout, "archipack.custom_average_weight", text="Left / right"
            ).groups = "SIDES"

            self.draw_op(
                context, layout, layout, "archipack.custom_average_weight", text="Front / back"
            ).groups = "FRONT"

            self.draw_op(
                context, layout, layout, "archipack.custom_average_weight", text="Top / bottom"
            ).groups = "TOP"

            return

        o = context.active_object
        d = archipack_custom.datablock(o)

        if d is None:
            return

        if d.is_nested:
            for key in o.data.keys():
                if key in wrapper_classes:
                    self.draw_label(context, layout, layout, text="Custom %s" % key[10:].capitalize())
                    break
            if self.has_flag(o.data, "nested_custom", write=False):
                self.draw_op(context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF")
            return

        self.draw_common(context, layout)
        if o.data.users > 1:
            self.draw_op(context, layout, layout, 'archipack.custom', icon='UNLINKED',
                         text="Make unique", postfix="({})".format(o.data.users)).mode = 'UNIQUE'
        
        self.draw_op(context, layout, layout, 'archipack.custom_array', icon="MOD_ARRAY", text="Array")

        box = layout.box() 
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.custom_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_custom_preset_menu.bl_label, icon="PRESET"
                     ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.custom_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.custom_preset", icon='REMOVE', text="").remove_active = True

        box = layout.box()
        self.draw_prop(context, layout, box, d, 'mode', text="")
        self.draw_prop(context, layout, box, d, 'draw_target', text="")
        if d.mode != 'ALT':
            self.draw_prop(context, layout, box, d, 'x')
            if d.mode != 'WALL':
                self.draw_prop(context, layout, box, d, 'y')
            self.draw_prop(context, layout, box, d, 'z')

        if d.mode != 'FLOOR':
            self.draw_prop(context, layout, box, d, 'altitude')


        # self.draw_op(context, layout, box, 'archipack.custom_draw', icon="GREASEPENCIL")
        # self.draw_op(context, layout, layout, 'archipack.custom_manipulators', icon="TOOL_SETTINGS")


class ARCHIPACK_PT_custom_part(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_custom_part"
    bl_label = "Custom part"

    @classmethod
    def poll(cls, context):
        return archipack_custom_part.poll(context.active_object)

    def draw(self, context):
        layout = self.layout
        d = archipack_custom_part.datablock(context.active_object)
        self.draw_prop(context, layout, layout, d, "deformable")
        self.draw_op(context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF")


class ARCHIPACK_OT_make_custom(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.make_custom"
    bl_label = "Make Custom object"
    bl_description = "Add custom parametric ability to selection"
    bl_category = 'Archipack'
    bl_options = {'UNDO'}  # 'REGISTER',

    x: FloatProperty(
        name="x"
    )
    y: FloatProperty(
        name="y"
    )
    z: FloatProperty(
        name="z"
    )

    x_min: FloatProperty(
        name="min",
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    x_max: FloatProperty(
        name="max",
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    x_soft: FloatProperty(
        name="soft",
        min=0, max=100,
        subtype="PERCENTAGE"
    )
    y_min: FloatProperty(
        name="min",
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    y_max: FloatProperty(
        name="max",
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    y_soft: FloatProperty(
        name="soft",
        min=0, max=100,
        subtype="PERCENTAGE"
    )
    z_min: FloatProperty(
        name="max",
        min=0,
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    z_max: FloatProperty(
        name="max",
        min=0,
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    z_soft: FloatProperty(
        name="soft",
        min=0, max=100,
        subtype="PERCENTAGE"
    )
    mode: EnumProperty(
        name="Mode",
        items=(
            ('SIMPLE', "Simple", "Use manipulator location"),
            ('ADVANCED', "Advanced", "Estimate using vertex location"),
        ),
        default='SIMPLE'
    )

    def save_params(self, o):
        dst = {}
        for key in {'x', 'y', 'z'}:
            for variant in {'', '_min', '_max', '_soft'}:
                attr = "%s%s" % (key, variant)
                dst[attr] = getattr(self, attr)
        o['archipack_custom_modal_setup'] = dst

    def load_params(self, o):
        if "archipack_custom_modal_setup" in o:
            src = o['archipack_custom_modal_setup']
            for key in {'x', 'y', 'z'}:
                for variant in {'', '_min', '_max', '_soft'}:
                    attr = "%s%s" % (key, variant)
                    setattr(self, attr, src[attr])
            return True
        return False

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.label(text="min", text_ctxt="archipack")
        row.label(text="max", text_ctxt="archipack")
        row.label(text="soft", text_ctxt="archipack")
        row = layout.row(align=True)
        row.prop(self, "x_min", text="x")
        row.prop(self, "x_max", text="")
        row.prop(self, "x_soft", text="")
        row = layout.row(align=True)
        row.prop(self, "y_min", text="y")
        row.prop(self, "y_max", text="")
        row.prop(self, "y_soft", text="")
        row = layout.row(align=True)
        row.label(text="z")
        row.prop(self, "z_max", text="")
        row.prop(self, "z_soft", text="")

    @staticmethod
    def weight(o, group, itM, soft, limit):
        """                 p.z
                    0          limit    p.z max
                          | soft |
                        start

                Matrix in at soft end inside
                         min         soft        soft          max
                         |                                      |
                         |          <-|            |->          |

                so when soft enabled z coord in [0|1] is weight
                when not enabled matrix is at min / max and positive is weight 1
                negative are weight 0
        """
        for v in o.data.vertices:
            p = itM @ v.co
            if soft > 0:
                start = max(0, limit - soft)
                w = min(1, max(0, (p.z - start) / soft))
            else:
                # fix precision issue
                if p.z + 0.0001 >= limit:
                    w = 1
                else:
                    w = 0
            if w > 0:
                group.add([v.index], w, 'REPLACE')
            else:
                group.remove([v.index])

    @staticmethod
    def pivot_weight(d, i, p, soft, limit):
        if soft > 0:
            start = max(0, limit - soft)
            w = min(1, max(0, (p.z - start) / soft))
        else:
            if p.z + 0.0001 >= limit:
                w = 1
            else:
                w = 0
        if i in {0, 2}:
            w = -w
        d.pivot_weight[i] = w

    def compute_limits(self, sel):
        rot_90 = pi / 2
        # print("add_vertex_groups")
        # matrix to retrieve vertex distance from center
        # tM = Matrix.Translation(self.origin)
        rM_top = Matrix()
        rM_front = Matrix.Rotation(rot_90, 4, 'X')
        rM_back = Matrix.Rotation(-rot_90, 4, 'X')
        rM_left = Matrix.Rotation(-rot_90, 4, 'Y')
        rM_right = Matrix.Rotation(rot_90, 4, 'Y')

        limit = [
            self.x_min, self.x_max,
            self.y_min, self.y_max,
            self.z_max
        ]

        # The idea here is to find closest vertex under limit and set it as true limit
        itM = [(self.tM @ rM).inverted()  for rM in [rM_left, rM_right, rM_front, rM_back, rM_top]]

        for i, ctm in enumerate(itM):
            verts = []
            for c in sel:
                tM = ctm @ c.matrix_world
                verts.extend([(tM @ v.co).z for v in c.data.vertices])

            # retrieve min
            verts.sort()
            n_verts = len(verts) - 1
            j = 0
            l = limit[i]
            while verts[j] < l and j < n_verts:
                j += 1
            limit[i] = verts[j]

        soft = [
            (limit[0] + limit[1]) * 0.005 * self.x_soft, (limit[0] + limit[1]) * 0.005 * self.x_soft,
            (limit[2] + limit[3]) * 0.005 * self.y_soft, (limit[2] + limit[3]) * 0.005 * self.y_soft,
            (self.bound_z - limit[4]) * 0.01 * self.z_soft
        ]
        limit[4] += (self.bound_z - limit[4]) * 0.01 * self.z_soft

        return limit, soft

    def add_vertex_groups(self, o, d, dc, pivot_weight, limit, soft):
        vgroups = {vgroup.name: vgroup.index for vgroup in o.vertex_groups}
        rot_90 = pi / 2
        # print("add_vertex_groups")
        # matrix to retrieve vertex distance from center
        # tM = Matrix.Translation(self.origin)
        rM_top = Matrix()
        rM_front = Matrix.Rotation(rot_90, 4, 'X')
        rM_back = Matrix.Rotation(-rot_90, 4, 'X')
        rM_left = Matrix.Rotation(-rot_90, 4, 'Y')
        rM_right = Matrix.Rotation(rot_90, 4, 'Y')
        itM = [(self.tM @ rM).inverted() @ o.matrix_world for rM in [rM_left, rM_right, rM_front, rM_back, rM_top]]

        groups = ['left', 'right', 'front', 'back', 'top']

        for n, tm, s, l in zip(groups, itM, soft, limit):

            if n not in vgroups:
                g = o.vertex_groups.new()
                g.name = n
            else:
                g = o.vertex_groups[n]
            self.weight(o, g, tm, s, l)

        if pivot_weight:
            # in world space
            # itM = [(tM @ rM).inverted() @ o.matrix_world for rM in [rM_left, rM_right, rM_back, rM_front, rM_top]]
            i = 0
            for tm, s, l in zip(itM, soft, limit):
                self.pivot_weight(dc, i, tm @ Vector(), s, l)
                i += 1

    @staticmethod
    def clear_parent_inverse(tM, o):
        """
          Set matrix_parent_inverse to identity
          keeping visual transforms
          so .location of child is in parent coordsys
        """
        loc = tM.inverted() @ o.matrix_world.translation
        o.matrix_world = tM.copy()
        o.location = loc

    def create(self, context):

        act = context.object

        if act is None:
            return
        # print("create", act.name)

        d = archipack_custom.datablock(act)
        if d is None:
            # print("Add archipack_custom")
            d = act.data.archipack_custom.add()

        names = set()
        names.add(act.name)
        sel = []

        def _filter(c):
            res = c.name not in names and c.type == "MESH"
            names.add(c.name)
            return res

        for o in context.selected_objects[:]:
            self.rec_get_childrens(o, sel, _filter)

        objs = context.selected_objects[:]
        objs.extend(sel)
        if self.mode == "SIMPLE":
            limit = [
                self.x_min, self.x_max,
                self.y_min, self.y_max,
                self.z_max + (self.bound_z - self.z_max) * 0.01 * self.z_soft
            ]
            soft = [
                (self.x_max + self.x_min) * 0.005 * self.x_soft, (self.x_max + self.x_min) * 0.005 * self.x_soft,
                (self.y_max + self.y_min) * 0.005 * self.y_soft, (self.y_max + self.y_min) * 0.005 * self.y_soft,
                (self.bound_z - self.z_max) * 0.01 * self.z_soft
            ]
        else:
            limit, soft = self.compute_limits(objs)

        self.add_vertex_groups(act, d, d, False, limit, soft)

        for o in sel:

            if archipack_custom.filter(o):
                o.data.archipack_custom.remove(0)
            # NOTE: custom_part is a Mesh property
            # it is impossible as it to handle pivot of random object
            dc = archipack_custom_part.datablock(o)

            if dc is None:
                dc = o.data.archipack_custom_part.add()

            self.add_vertex_groups(o, d, dc, True, limit, soft)

        return act

    def check_hover(self):
        self.min.check_hover(self.mouse_pos)
        self.max.check_hover(self.mouse_pos)
        self.z_handle.check_hover(self.mouse_pos)
        self.xsoft.check_hover(self.mouse_pos)
        self.ysoft.check_hover(self.mouse_pos)
        self.zsoft.check_hover(self.mouse_pos)

    def mouse_release(self, context, event):
        self.active = False
        self.check_hover()
        self.min.active = False
        self.max.active = False
        self.z_handle.active = False
        self.xsoft.active = False
        self.ysoft.active = False
        self.zsoft.active = False
        self.create(context)
        return False

    def sp_callback(self, context, event, state, sp):

        if state != CANCEL:
            if self.min.active:
                x, y, z = self.itM @ sp.placeloc
                # print("xy", x, y)
                self.x_min = -min(self.x_max, x)
                self.y_min = -min(self.y_max, y)
                # print(self.x_min, self.y_min)
                self.create(context)
            if self.max.active:
                x, y, z = self.itM @ sp.placeloc
                # print("xy", x, y)
                self.x_max = max(-self.x_min, x)
                self.y_max = max(-self.y_min, y)
                # print(self.x_max, self.y_max)
                self.create(context)
        if state != FREEMOVE:
            self.mouse_release(context, event)

    def mouse_move(self, context, event):
        self.mouse_pos = Vector((event.mouse_region_x, event.mouse_region_y))
        if self.active:
            # draggin mouse
            if self.min.active:
                pos_3d = self.get_pos3d(context)
                dp = self.itM @ pos_3d

                self.x_min = -min(self.x_max, dp.x)
                self.y_min = -min(self.y_max, dp.y)

            elif self.max.active:
                pos_3d = self.get_pos3d(context)
                dp = self.itM @ pos_3d
                self.x_max = max(-self.x_min, dp.x)
                self.y_max = max(-self.y_min, dp.y)

            elif self.z_handle.active:
                pos_3d = self.get_pos3d(context, normal=Vector((1, 0, 0)))
                dp = self.itM @ pos_3d
                self.z_max = min(self.bound_z, dp.z)

            elif self.xsoft.active:
                pos_3d = self.get_pos3d(context)
                dp = self.itM @ pos_3d
                dx = self.x_max + self.x_min
                # print("dx", dx, "xmax", self.x_max, "xmin", self.x_min)
                # print("dp.x", dp.x)
                if dx > 0:
                    self.x_soft = 200 * (dp.x + self.x_min) / dx
                # print("x_soft", self.x_soft)

            elif self.ysoft.active:
                pos_3d = self.get_pos3d(context)
                dp = self.itM @ pos_3d
                dy = self.y_max + self.y_min
                if dy > 0:
                    self.y_soft = 200 * (dp.y + self.y_min) / dy
                # print(self.y_soft)

            elif self.zsoft.active:
                #  bound  ____   __  2x object +-z
                #                /\
                #  soft   ___    dz
                #  z_max  ___    |   0.5 * object
                #  origin __         0x object

                pos_3d = self.get_pos3d(context, normal=Vector((1, 0, 0)))
                dp = self.itM @ pos_3d
                dz = self.bound_z - self.z_max
                if dz > 0:
                    self.z_soft = 100 * (dp.z - self.z_max) / dz
        else:
            self.check_hover()

    def mouse_press(self, context, event):
        if self.min.hover:

            self.active = True
            self.min.active = True
            takemat = self.tM @ Matrix.Translation(Vector((-self.x_min, -self.y_min, 0)))
            snap_point(context, takemat=takemat,
                       callback=self.sp_callback,
                       constraint_axis=(True, True, False))

        elif self.max.hover:
            self.active = True

            self.max.active = True
            takemat = self.tM @ Matrix.Translation(Vector((self.x_max, self.y_max, 0)))
            snap_point(context, takemat=takemat,
                       callback=self.sp_callback,
                       constraint_axis=(True, True, False))

        elif self.z_handle.hover:
            self.active = True
            self.z_handle.active = True

        elif self.xsoft.hover:
            self.active = True
            self.xsoft.active = True

        elif self.ysoft.hover:
            self.active = True
            self.ysoft.active = True

        elif self.zsoft.hover:
            self.active = True
            self.zsoft.active = True

    def get_pos3d(self, context, normal=Vector((0, 0, 1))):
        """
            convert mouse pos to 3d point over plane defined by origin and normal
            pt is in world space
        """
        region = context.region
        rv3d = context.region_data
        view_vector_mouse = view3d_utils.region_2d_to_vector_3d(region, rv3d, self.mouse_pos)
        ray_origin_mouse = view3d_utils.region_2d_to_origin_3d(region, rv3d, self.mouse_pos)
        pt = intersect_line_plane(
            ray_origin_mouse, ray_origin_mouse + view_vector_mouse,
            self.origin, normal, False
        )
        # fix issue with parallel plane
        if pt is None:
            pt = intersect_line_plane(
                ray_origin_mouse, ray_origin_mouse + view_vector_mouse,
                self.origin, view_vector_mouse, False
            )
        return pt

    def modal(self, context, event):

        if hasattr(context, "area") and context.area is not None:
            context.area.tag_redraw()

        if event.type == 'MOUSEMOVE':
            self.mouse_move(context, event)

        elif event.value == 'PRESS':

            if event.type == 'LEFTMOUSE':
                self.mouse_press(context, event)

            elif event.type in {'ESC', 'RIGHTMOUSE'}:
                if self.active:
                    self.mouse_release(context, event)
                self.create(context)
                self.save_params(context.active_object)
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                return {'FINISHED'}

        elif event.value == 'RELEASE':

            if event.type == 'LEFTMOUSE':
                self.mouse_release(context, event)

        if self.active:
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def draw_handler(self, _self, context):
        #  p3     p2
        #  p0     p1
        #
        p0 = self.tM @ Vector((-self.x_min, -self.y_min, 0))
        p1 = self.tM @ Vector((self.x_max, -self.y_min, 0))
        p2 = self.tM @ Vector((self.x_max, self.y_max, 0))
        p3 = self.tM @ Vector((-self.x_min, self.y_max, 0))
        sx = (p1 - p0).normalized()
        sy = (p3 - p0).normalized()
        vx = sx * self.bound_x
        vy = sy * self.bound_y
        pz = self.tM @ Vector((0, 0, self.z_max))
        sz = self.tM.col[2].to_3d()

        # pa = self.tM @ Vector((0, 0, -self.z_min))
        self.rect.set_pos([p0, p1, p3, p2])

        self.min.set_pos(context, p0, X_AXIS)
        self.max.set_pos(context, p2, X_AXIS)
        self.z_handle.set_pos(context, pz, Z_AXIS, normal=Y_AXIS)
        # self.a_handle.set_pos(context, pa, Z_AXIS, normal=Y_AXIS)

        self.line_xmin.p = 0.5 * (p0 + p1 - vx)
        self.line_xmax.p = 0.5 * (p2 + p3 - vx)
        self.line_ymin.p = 0.5 * (p0 + p3 - vy)
        self.line_ymax.p = 0.5 * (p1 + p2 - vy)
        self.line_xmin.v = vx
        self.line_xmax.v = vx
        self.line_ymin.v = vy
        self.line_ymax.v = vy
        dx = (self.x_min + self.x_max) * self.x_soft / 200
        dy = (self.y_min + self.y_max) * self.y_soft / 200
        dz = (self.bound_z - self.z_max) * self.z_soft / 100

        self.line_xsoft_min.p = self.line_ymin.p + sx * dx
        self.line_ysoft_min.p = self.line_xmin.p + sy * dy
        self.line_xsoft_max.p = self.line_ymax.p - sx * dx
        self.line_ysoft_max.p = self.line_xmax.p - sy * dy
        self.rect_xmin.set_pos([self.line_xsoft_min.p, self.line_ymin.p, self.line_xsoft_min.p1, self.line_ymin.p1])
        self.rect_xmax.set_pos([self.line_xsoft_max.p, self.line_ymax.p, self.line_xsoft_max.p1, self.line_ymax.p1])
        self.rect_ymin.set_pos([self.line_ysoft_min.p, self.line_xmin.p, self.line_ysoft_min.p1, self.line_xmin.p1])
        self.rect_ymax.set_pos([self.line_ysoft_max.p, self.line_xmax.p, self.line_ysoft_max.p1, self.line_xmax.p1])

        self.line_xsoft_min.v = vy
        self.line_ysoft_min.v = vx
        self.line_xsoft_max.v = vy
        self.line_ysoft_max.v = vx

        self.xsoft.set_pos(context, 0.5 * (p0 + p3) + sx * dx, X_AXIS)
        self.ysoft.set_pos(context, 0.5 * (p0 + p1) + sy * dy, Y_AXIS)
        self.zsoft.set_pos(context, pz + sz * dz, Z_AXIS, normal=Y_AXIS)

        self.line_zmax.p = pz - 0.5 * vx
        self.line_zsoft.p = self.line_zmax.p + sz * dz
        self.line_zmax.v = vx
        self.line_zsoft.v = vx
        self.rect_zmax.set_pos([self.line_zmax.p, self.line_zmax.p1, self.line_zsoft.p, self.line_zsoft.p1])
        self.rect.draw(context)

        self.text_xmin.set_pos(context, None, self.line_ymin.sized_normal(0.5, -0.5).p1, X_AXIS)
        self.text_xmax.set_pos(context, None, self.line_ymax.sized_normal(0.5, 0.5).p1, X_AXIS)
        self.text_ymin.set_pos(context, None, self.line_xmin.sized_normal(0.5, 0.5).p1, X_AXIS)
        self.text_ymax.set_pos(context, None, self.line_xmax.sized_normal(0.5, -0.5).p1, X_AXIS)
        self.text_z.set_pos(context, None, self.line_zmax.sized_normal(0.5, 0.1).p1, X_AXIS, normal=Y_AXIS)
        # self.text_a.set_pos(context, None, self.line_zmin.sized_normal(0.5, 0.1).p1, X_AXIS, normal=Y_AXIS)

        self.line_xmin.draw(context)
        self.line_xmax.draw(context)
        self.line_ymin.draw(context)
        self.line_ymax.draw(context)
        # self.line_zmin.draw(context)
        self.line_zmax.draw(context)

        self.line_xsoft_min.draw(context)
        self.line_ysoft_min.draw(context)
        self.line_xsoft_max.draw(context)
        self.line_ysoft_max.draw(context)
        self.line_zsoft.draw(context)

        self.rect_xmin.draw(context)
        self.rect_xmax.draw(context)
        self.rect_ymin.draw(context)
        self.rect_ymax.draw(context)
        self.rect_zmax.draw(context)

        self.xsoft.draw(context)
        self.ysoft.draw(context)
        self.zsoft.draw(context)

        self.text_xmin.draw(context)
        self.text_xmax.draw(context)
        self.text_ymin.draw(context)
        self.text_ymax.draw(context)
        self.text_z.draw(context)
        # self.text_a.draw(context)

        self.min.draw(context)
        self.max.draw(context)
        self.z_handle.draw(context)
        # self.a_handle.draw(context)

    def invoke(self, context, event):
        o = context.active_object
        try:
            o.rotation_euler = (0, 0, 0)
        except:
            pass

        # apply both rotation and scale for all objects
        sel = []
        self.rec_get_childrens(o, sel)

        # make unique
        for c in sel:
            if c.data and c.data.users > 1:
                c.data = c.data.copy()

        with context_override(context, o, sel) as ctx:
            self.call_operator(context, ctx, bpy.ops.object.transform_apply, {
                "location": False,
                "rotation": True,
                "scale": True
            })
            # bpy.ops.object.transform_apply(ctx, location=False, rotation=True, scale=True)

        # cleanup datablocks
        if "archipack_custom_part" in o.data:
            o.data.archipack_custom_part.remove(0)
            del o.data["archipack_custom_part"]

        for c in sel:
            if c.name != o.name and "archipack_custom" in c.data:
                c.data.archipack_custom.remove(0)
                del c.data["archipack_custom"]

        p0 = Vector(o.bound_box[0])
        p1 = Vector(o.bound_box[7])
        bound = p0 + p1
        x, y, z = 0.5 * o.dimensions

        self.bound_x = 10 * x
        self.bound_y = 10 * y
        self.bound_z = 2 * z

        if not self.load_params(o):
            self.x, self.y, self.z = x, y, z
            self.x_min = x
            self.x_max = x
            self.y_min = y
            self.y_max = y
            self.z_max = z

        sensor_size = 10
        size = 0.05
        self.active = False
        self.pmin = o.matrix_world @ p0
        self.origin = o.matrix_world @ (0.5 * bound)

        tM = o.matrix_world @ Matrix.Translation(0.5 * bound)
        self.tM = tM
        self.itM = tM.inverted()

        self.mouse_pos = Vector((0, 0))
        self.rect = GlPolygon(d=3, colour=(1, 1, 1, 0.2))
        self.min = SquareHandle(sensor_size, size, draggable=True)
        self.max = SquareHandle(sensor_size, size, draggable=True)
        self.z_handle = SquareHandle(sensor_size, size, draggable=True)

        self.xsoft = TriHandle(sensor_size, size, draggable=True)
        self.ysoft = TriHandle(sensor_size, size, draggable=True)
        self.zsoft = TriHandle(sensor_size, size, draggable=True)

        self.line_xmin = GlLine()
        self.line_xmax = GlLine()
        self.line_ymin = GlLine()
        self.line_ymax = GlLine()
        self.line_zmax = GlLine()

        self.line_xmin.colour_inactive = (1, 0, 0, 1)
        self.line_xmax.colour_inactive = (1, 0, 0, 1)
        self.line_ymin.colour_inactive = (0, 1, 0, 1)
        self.line_ymax.colour_inactive = (0, 1, 0, 1)
        self.line_zmax.colour_inactive = (0, 0, 1, 1)

        self.rect_xmin = GlPolygon(d=3, colour=(0, 1, 0, 0.2))
        self.rect_xmax = GlPolygon(d=3, colour=(0, 1, 0, 0.2))
        self.rect_ymin = GlPolygon(d=3, colour=(1, 0, 0, 0.2))
        self.rect_ymax = GlPolygon(d=3, colour=(1, 0, 0, 0.2))
        # self.rect = GlPolygon(d=3, colour=(1, 1, 1, 0.2))
        self.rect_zmax = GlPolygon(d=3, colour=(0, 0, 1, 0.2))

        self.line_xsoft_min = GlLine()
        self.line_xsoft_max = GlLine()
        self.line_ysoft_min = GlLine()
        self.line_ysoft_max = GlLine()
        self.line_zsoft = GlLine()

        self.line_xsoft_min.colour_inactive = (0, 1, 0, 1)
        self.line_xsoft_max.colour_inactive = (0, 1, 0, 1)
        self.line_ysoft_min.colour_inactive = (1, 0, 0, 1)
        self.line_ysoft_max.colour_inactive = (1, 0, 0, 1)
        self.line_zsoft.colour_inactive = (0, 0, 1, 1)

        self.line_xmin.colour_inactive = (1, 0, 0, 1)
        self.line_xmax.colour_inactive = (1, 0, 0, 1)
        self.line_ymin.colour_inactive = (0, 1, 0, 1)
        self.line_ymax.colour_inactive = (0, 1, 0, 1)
        self.line_zmax.colour_inactive = (0, 0, 1, 1)

        self.text_xmin = GlText(label="Left", colour=(0, 1, 0, 1), font_size=16)
        self.text_xmax = GlText(label="Right", colour=(0, 1, 0, 1), font_size=16)
        self.text_ymin = GlText(label="Outside", colour=(1, 0, 0, 1), font_size=16)
        self.text_ymax = GlText(label="Inside", colour=(1, 0, 0, 1), font_size=16)
        self.text_z = GlText(label="Top", colour=(0, 0, 1, 1), font_size=16, z_axis=Y_AXIS)

        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_handler,
            args, 'WINDOW', 'POST_PIXEL'
        )

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        # print("execute")
        with stop_auto_manipulate(context):
            self.create(context)
        # print("execute select object")
        #    self.select_object(context, o, True)
        return {'FINISHED'}


class ARCHIPACK_OT_custom_manipulators(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.custom_manipulators"
    bl_label = "Manipulators location"
    bl_description = "Define location of manipulators"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}

    x: FloatProperty(
        name="x",
        min=0,
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )

    y: FloatProperty(
        name="y",
        min=0,
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )

    z: FloatProperty(
        name="z",
        min=0,
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )
    altitude: FloatProperty(
        name="Altitude",
        min=0,
        precision=5,
        unit='LENGTH', subtype='DISTANCE'
    )

    @classmethod
    def poll(cls, context):
        return archipack_custom.poll(context.active_object)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "x", text_ctxt="archipack")
        layout.prop(self, "y", text_ctxt="archipack")
        layout.prop(self, "z", text_ctxt="archipack")
        layout.prop(self, "altitude", text_ctxt="archipack")

    @staticmethod
    def clear_parent_inverse(tM, itM, o):
        """
          Set matrix_parent_inverse to identity
          keeping visual transforms
          so .location of child is in parent coordsys
        """
        loc = itM @ o.matrix_world.translation
        o.matrix_world = tM.copy()
        o.location = loc

    def create(self, context):
        o = context.object
        d = archipack_custom.datablock(o)
        if d is not None:
            d.auto_update = False
            d.x_cur, d.y_cur, d.z_cur = 2 * self.x, 2 * self.y, self.z
            d.altitude_cur = self.altitude
            d.auto_update = True

    def check_hover(self):
        self.x_handle.check_hover(self.mouse_pos)
        self.y_handle.check_hover(self.mouse_pos)
        self.z_handle.check_hover(self.mouse_pos)
        self.a_handle.check_hover(self.mouse_pos)

    def mouse_release(self, context, event):
        self.active = False
        self.check_hover()
        self.x_handle.active = False
        self.y_handle.active = False
        self.z_handle.active = False
        self.a_handle.active = False
        self.create(context)
        return False

    def mouse_move(self, context, event):
        self.mouse_pos = Vector((event.mouse_region_x, event.mouse_region_y))
        if self.active:

            if self.z_handle.active:
                pos_3d = self.get_pos3d(context, normal=Vector((1, 0, 0)))
                dp = self.itM @ pos_3d
                self.z = abs(dp.z) - self.altitude

            if self.a_handle.active:
                pos_3d = self.get_pos3d(context, normal=Vector((1, 0, 0)))
                dp = self.itM @ pos_3d
                self.altitude = abs(dp.z)

        else:
            self.check_hover()

    def sp_callback(self, context, event, state, sp):

        if state != CANCEL:
            if self.x_handle.active or self.y_handle.active:

                x, y, z = self.itM @ sp.placeloc
                self.x = abs(x)
                self.y = abs(y)
                self.create(context)

        if state != FREEMOVE:
            self.mouse_release(context, event)

    def mouse_press(self, context, event):
        if self.x_handle.hover:

            self.active = True
            self.x_handle.active = True
            takemat = self.tM @ Matrix.Translation(Vector((self.x, -self.y, 0)))
            snap_point(context, takemat=takemat,
                       callback=self.sp_callback,
                       constraint_axis=(True, True, False))

        elif self.y_handle.hover:
            self.active = True

            self.y_handle.active = True
            takemat = self.tM @ Matrix.Translation(Vector((-self.x, self.y, 0)))
            snap_point(context, takemat=takemat,
                       callback=self.sp_callback,
                       constraint_axis=(True, True, False))

        elif self.z_handle.hover:
            self.active = True
            self.z_handle.active = True

        elif self.a_handle.hover:
            self.active = True
            self.a_handle.active = True

    def get_pos3d(self, context, normal=Vector((0, 0, 1))):
        """
            convert mouse pos to 3d point over plane defined by origin and normal
            pt is in world space
        """
        region = context.region
        rv3d = context.region_data
        view_vector_mouse = view3d_utils.region_2d_to_vector_3d(region, rv3d, self.mouse_pos)
        ray_origin_mouse = view3d_utils.region_2d_to_origin_3d(region, rv3d, self.mouse_pos)
        pt = intersect_line_plane(
            ray_origin_mouse, ray_origin_mouse + view_vector_mouse,
            self.origin, normal, False
        )
        # fix issue with parallel plane
        if pt is None:
            pt = intersect_line_plane(
                ray_origin_mouse, ray_origin_mouse + view_vector_mouse,
                self.origin, view_vector_mouse, False
            )
        return pt

    def modal(self, context, event):
        # Fix layout switch issue
        if context.area is None:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}
        context.area.tag_redraw()

        if event.type == 'MOUSEMOVE':
            self.mouse_move(context, event)

        elif event.value == 'PRESS':

            if event.type == 'LEFTMOUSE':
                self.mouse_press(context, event)

            elif event.type in {'ESC', 'RIGHTMOUSE'}:
                if self.active:
                    self.mouse_release(context, event)
                self.create(context)
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                return {'FINISHED'}

        elif event.value == 'RELEASE':

            if event.type == 'LEFTMOUSE':
                self.mouse_release(context, event)

        if self.active:
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def draw_handler(self, _self, context):
        # p6   p2     p1     p5
        # p7   p3     p0     p4
        p0 = self.tM @ Vector((self.x, -self.y, 0))
        p1 = self.tM @ Vector((self.x, self.y, 0))
        p2 = self.tM @ Vector((-self.x, self.y, 0))
        p3 = self.tM @ Vector((-self.x, -self.y, 0))
        p4 = self.tM @ Vector((4 * self.x, -self.y, 0))
        p5 = self.tM @ Vector((4 * self.x, self.y, 0))
        p6 = self.tM @ Vector((-4 * self.x, self.y, 0))
        p7 = self.tM @ Vector((-4 * self.x, -self.y, 0))
        vz = Vector((0, 0, self.altitude + self.z))
        pz = self.tM @ vz
        pa = self.tM @ Vector((0, 0, self.altitude))

        self.wall_r.set_pos([p4, p5, p0, p1])
        self.wall_l.set_pos([p3, p2, p7, p6])

        self.x_handle.set_pos(context, p0, X_AXIS)
        self.y_handle.set_pos(context, p2, X_AXIS)
        self.z_handle.set_pos(context, pz, Z_AXIS, normal=Y_AXIS)
        self.a_handle.set_pos(context, pa, Z_AXIS, normal=Y_AXIS)
        vx, vy = p4 - p7, p1 - p0
        self.line_xmin.p = p7
        self.line_xmin.v = vx
        self.line_xmax.p = p6
        self.line_xmax.v = vx
        self.line_ymin.p = p0
        self.line_ymin.v = vy
        self.line_ymax.p = p3
        self.line_ymax.v = vy
        self.line_zmin.p = pa - 0.5 * vx
        self.line_zmax.p = pz - 0.5 * vx
        self.line_zmin.v = vx
        self.line_zmax.v = vx

        self.wall_l.draw(context)
        self.wall_r.draw(context)

        self.text_x.set_pos(context, None, 0.5 * (p2 + p7), X_AXIS)
        self.text_y.set_pos(context, None, 0.5 * (p0 + p3 - vy), X_AXIS)
        self.text_z.set_pos(context, None, self.tM @ Vector((0, 0, self.altitude + self.z + 0.1)), X_AXIS, normal=Y_AXIS)
        self.text_a.set_pos(context, None, self.tM @ Vector((0, 0, self.altitude + 0.1)), X_AXIS, normal=Y_AXIS)

        self.line_xmin.draw(context)
        self.line_xmax.draw(context)
        self.line_ymin.draw(context)
        self.line_ymax.draw(context)
        self.line_zmin.draw(context)
        self.line_zmax.draw(context)

        self.text_x.draw(context)
        self.text_y.draw(context)
        self.text_z.draw(context)
        self.text_a.draw(context)

        self.x_handle.draw(context)
        self.y_handle.draw(context)
        self.z_handle.draw(context)
        self.a_handle.draw(context)

    def invoke(self, context, event):
        o = context.active_object

        d = archipack_custom.datablock(o)

        if d is None:
            d = o.data.archipack_custom.add()

        if archipack_custom_part.filter(o):
            o.data.archipack_custom_part.remove(0)

        tM = o.matrix_world

        self.tM = tM
        self.itM = tM.inverted()

        x, y, z = o.dimensions
        self.x, self.y, self.z = 0.5 * x, 0.5 * y, z
        self.altitude = o.bound_box[0][2]

        sensor_size = 10
        size = 0.05
        self.active = False

        self.origin = tM.translation
        self.mouse_pos = Vector((0, 0))
        self.wall_l = GlPolygon(d=3, colour=(1, 0, 0, 0.2))
        self.wall_r = GlPolygon(d=3, colour=(1, 0, 0, 0.2))

        self.x_handle = SquareHandle(sensor_size, size, draggable=True)
        self.y_handle = SquareHandle(sensor_size, size, draggable=True)
        self.z_handle = SquareHandle(sensor_size, size, draggable=True)
        self.a_handle = SquareHandle(sensor_size, size, draggable=True)

        self.line_xmin = GlLine()
        self.line_xmax = GlLine()
        self.line_ymin = GlLine()
        self.line_ymax = GlLine()
        self.line_zmin = GlLine()
        self.line_zmax = GlLine()

        self.line_xmin.colour_inactive = (1, 0, 0, 1)
        self.line_xmax.colour_inactive = (1, 0, 0, 1)
        self.line_ymin.colour_inactive = (0, 1, 0, 1)
        self.line_ymax.colour_inactive = (0, 1, 0, 1)
        self.line_zmin.colour_inactive = (0, 0, 1, 1)
        self.line_zmax.colour_inactive = (0, 0, 1, 1)

        self.text_x = GlText(label="Wall", colour=(1, 0, 0, 1), font_size=16)
        self.text_y = GlText(label="Outside", colour=(0, 1, 0, 1), font_size=16)
        self.text_z = GlText(label="Top", colour=(0, 0, 1, 1), font_size=16)
        self.text_a = GlText(label="Altitude", colour=(0, 0, 1, 1), font_size=16)

        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_handler,
            args, 'WINDOW', 'POST_PIXEL'
        )

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        self.create(context)
        return {'FINISHED'}


class ARCHIPACK_OT_custom_average_weight(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.custom_average_weight"
    bl_label = "Average vertex weights"
    bl_description = "Give selected vertex the same weight so they move together"
    bl_options = {'UNDO'}

    groups: EnumProperty(
        name="Side",
        items=(
            ("TOP", "Top", "Use top vertex group"),
            ("SIDES", "Left / Right", "Use left and right vertex groups"),
            ("FRONT", "Front / Back", "Use front and back vertex groups"),
            ("FREE", "Use selectd group", "Use selected vertex group")
        ),
        default="FREE"
    )

    @classmethod
    def poll(cls, context):
        return context.mode in {'EDIT_MESH', 'PAINT_WEIGHT'}

    def execute(self, context):
        o = context.active_object

        group_idx = o.vertex_groups.active_index

        bpy.ops.object.mode_set(mode="OBJECT")

        childs = []
        self.rec_get_childrens(o, childs, archipack_custom_part.filter)
        sel = [o for o in context.selected_objects if o.vertex_groups and len(o.vertex_groups) > group_idx]

        if self.groups == 'FREE':
            groups = [o.vertex_groups.active.name]

        elif self.groups == "SIDES":
            groups = ["left", "right"]

        elif self.groups == "FRONT":
            groups = ['front', 'back']

        else:
            groups = ["top"]

        for group_name in groups:

            weights = []
            pivot_idx = ('left', 'right', 'front', 'back', 'bottom', 'top').index(group_name)
            for o in sel:
                group = o.vertex_groups.get(group_name)
                if group is not None:
                    verts = {v.index: {g.group for g in v.groups}  for v in o.data.vertices if v.select}
                    if len(verts) > 1:
                        weights.extend([group.weight(index) for index, groups in verts.items() if group.index in groups])

            if weights:
                # average does not depends on number of vertex
                mini, maxi = min(weights), max(weights)
                average = 0.5 * (mini + maxi)

                # apply average to childs pivots between mini and maxi
                # GNIII ???
                # for c in childs:
                #    d = archipack_custom_part.datablock(c)
                #    if mini < d.pivot_weight[pivot_idx] < maxi:
                #        d.pivot_weight[pivot_idx] = average

                self.report({'INFO'}, "Assign %.4f weight to %s" % (average, group_name))
                if average > 0:
                    for o in sel:
                        group = o.vertex_groups.get(group_name)
                        verts = [v.index for v in o.data.vertices if v.select]
                        if len(verts) > 1:
                            if group is None:
                                group = o.vertex_groups.new(name=group_name)
                            group.add(verts, average, 'REPLACE')
            else:
                self.report({'INFO'}, "Skip : no selected vertex belong to %s group" % (group_name))

        bpy.ops.object.mode_set(mode="EDIT")

        return {'FINISHED'}

class ARCHIPACK_OT_custom_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.custom_draw"
    bl_label = "Draw Custom"
    bl_description = "Draw Custom object over walls"

    filepath: StringProperty(default="")
    draw_target = 'WALL'
    feedback = None
    stack = []
    object_name = ""
    rotate_90 = 0

    @classmethod
    def poll(cls, context):
        return archipack_custom.poll(context.active_object)

    def draw_callback(self, _self, context):
        self.feedback.draw(context)

    def add_object(self, context, event):
        o = context.active_object
        bpy.ops.object.select_all(action="DESELECT")
        o = self.duplicate_object(context, o, False)
        self.object_name = o.name
        self.select_object(context, o, True)
        return o

    def remove_object(self, context, o):
        if archipack_custom.filter(o):
            with context_override(context, None, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.archipack.delete)

    def exit(self, context, o):
        self.remove_object(context, o)
        self.feedback.disable()
        try:
            context.space_data.show_gizmo = True
        except:
            pass
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):
        # Fix layout switch issue
        if context.area is None:
            self.exit(context, None)
            return {'FINISHED'}

        context.area.tag_redraw()
        o = self.get_scene_object(context, self.object_name)

        if o is None:
            self.exit(context, None)
            return {'FINISHED'}

        d = archipack_custom.datablock(o)

        # hide all from raycast
        to_hide = []
        self.rec_get_childrens(o, to_hide)

        for obj in to_hide:
            self.hide_object(obj)

        if self.draw_target == "WALL":
            res, tM, wall, width, y, z_offset = self.mouse_hover_wall(context, event)
        else:
            # Floor with ability to snap holding control
            res, tM, wall, width, y, z_offset = self.mouse_hover_floor(context, event, o, d)

        for obj in to_hide:
            self.show_object(obj)

        if event.value == 'PRESS':

            if event.type in {'C', 'D'}:
                self.exit(context, o)
                bpy.ops.archipack.custom_preset_menu(
                    'INVOKE_DEFAULT',
                    preset_operator="archipack.custom_draw")
                self.restore_walls(context)
                return {'FINISHED'}

            elif event.type in 'R':
                self.rotate_90 = (self.rotate_90 + (pi / 2)) % (2 * pi)
                tM = tM @ Matrix.Rotation(self.rotate_90, 4, "Z")

            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
                if wall is not None:

                    if d is not None:
                        # o must be a custom here
                        if d.find_hole(o) is not None:
                            ctx = context.copy()
                            ctx['object'] = wall
                            ctx['selected_objects'] = [o]
                            self.call_operator(context, ctx, bpy.ops.archipack.single_boolean)

                        # Ensure custom is child of reference point when there is no hole
                        elif o.parent is None:
                            ref = self.get_reference_point(wall)
                            if ref is not None:
                                loc = ref.matrix_world.inverted() @ o.matrix_world.translation
                                o.parent = ref
                                o.location = loc

                        if len(self.stack) > 0 and not event.shift:
                            last = self.stack[-1]
                            d_last = last.data.archipack_custom[0]
                            if d_last.y == d.y:
                                # Must disable manipulators before link !!
                                bpy.ops.archipack.disable_manipulate()
                                self.link_object(last, o)

                        if "archipack_wall2" in wall.data:
                            # link as wall child
                            with ensure_select_and_restore(context, wall, [wall]):
                                wd = wall.data.archipack_wall2[0]
                                wg = wd.get_generator()
                                wd.setup_childs(context, wall, g=wg, openings_only=True)
                                wd.relocate_childs(context, wall, g=wg)
                                wd.update_dimension(context, wall, wg)

                        self.stack.append(o)
                        self.select_object(context, o, True)
                        o = self.add_object(context, event)
                        o.matrix_world = tM

                    return {'RUNNING_MODAL'}
            # prevent selection of other object in rightclick select mode
            if event.type in {'RIGHTMOUSE'}:
                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
                ):
            if len(self.stack) > 0:
                last = self.stack.pop()
                self.remove_object(context, last)

            return {'RUNNING_MODAL'}

        if event.value == 'RELEASE':

            if event.type in {'ESC', 'RIGHTMOUSE'}:
                self.exit(context, o)
                return {'FINISHED'}

        if res and d is not None:
            o.matrix_world = tM.copy()
            if abs(d.y - width) > 0.001:
                self.select_object(context, o, True)
                d.y = width

        return {'PASS_THROUGH'}

    def invoke(self, context, event):

        if context.mode == "OBJECT":
            self.stack = []
            self.keymap = Keymaps(context)
            # exit manipulate_mode if any
            bpy.ops.archipack.disable_manipulate()
            # Hide manipulators
            context.space_data.show_gizmo = False
            # invoke with shift pressed will use current object as basis for linked copy
            o = context.active_object
            # context.scene.objects.active = None
            bpy.ops.object.select_all(action="DESELECT")
            self.select_object(context, o, True)
            o = self.add_object(context, event)
            d = archipack_custom.datablock(o)
            self.draw_target = d.draw_target

            self.feedback = FeedbackPanel()
            
            instructions = [
                ('LEFTCLICK, RET, SPACE, ENTER', 'Create a Custom'),
                ('BACKSPACE, CTRL+Z', 'undo last'),
                ('D', 'Draw another Custom'),
                ('SHIFT', 'Make independant copy'),
                ('RIGHTCLICK or ESC', 'exit')
            ]

            if self.draw_target == 'WALL':
                self.feedback.instructions(
                    context, "Draw a Custom", "Click & Drag over a wall", instructions
                )
            else:
                instructions.insert(3, ('CTRL', 'Snap (hold)'))
                instructions.insert(3, ('R', 'Rotate 90°'))
                self.feedback.instructions(
                    context, "Draw a Custom", "Click & Drag over a floor / slab", instructions
                )
                
            self.feedback.enable()
            args = (self, context)

            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_custom(ArchipackCreateTool, Operator):
    bl_idname = "archipack.custom"
    bl_label = "Custom"
    bl_description = "Custom"

    source: StringProperty()
    # auto_manipulate : BoolProperty(default=True)
    mode: EnumProperty(
        items=(
            ('CREATE', 'Create', '', 0),
            ('REFRESH', 'Refresh', '', 1),
            ('UNIQUE', 'Make unique', '', 2),
            ('COPY', 'Copy', 'copy data', 3),
        ),
        default='CREATE'
    )

    def create(self, context):
        o, m = self.create_mesh("Custom")
        d = m.archipack_custom.add()
        # Link object into scene
        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)
        # select and make active
        self.select_object(context, o, True)
        self.add_material(context, o, material="DEFAULT", category="custom")
        self.load_preset(context, o, d)

        if d.source is not None:

            # transfer data from source to current object
            o.data.user_remap(d.source.data)

            # transfer vertex groups
            vertex_groups = bmed.vertex_groups_from_obj(d.source)
            bmed.set_vertex_groups(o, vertex_groups)

            # transfer modifiers if any
            self.copy_modifier_stack(d.source, o)

            name = d.source.name
            for child in d.source.children:
                c = self._duplicate_childs(context, child, True)
                # cls.set_parent(context, p, c)
                c.parent = o
                c.matrix_local = child.matrix_local.copy()
                # keep parent inverse as objects are not supposed to move while duplicating
                c.matrix_parent_inverse = child.matrix_parent_inverse.copy()
                self.safe_scale(c)
                c.location = child.location
            self.delete_object(context, d.source)
            o.name = name

        return o

    def copy(self, context):

        # adds a custom datablock to a copy of the mesh
        source = bpy.data.objects.get(self.source)
        src = archipack_custom.datablock(source)

        if src is None:
            return

        act = self.get_context_value(context, "object")

        if act is None or archipack_custom.filter(act):
            return

        d = act.data.archipack_custom.add()
        d.auto_update = False
        for attr in ['x', 'y', 'z', 'x_cur', 'y_cur', 'z_cur', 'altitude_cur', 'mode', 'altitude']:
            setattr(d, attr, getattr(src, attr))

        self.set_flag(act, "flip", self.has_flag(source, "flip"))

        d.auto_update = True

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------

    def update(self, context):
        o = context.active_object
        d = archipack_custom.datablock(o)
        if d is not None:
            d.update(context)
            linked_objects = self.get_linked_objects(context, o)
            # bpy.ops.object.select_linked(type='OBDATA')
            for linked in linked_objects:
                if linked != o:
                    archipack_custom.datablock(linked).update(context)

        # bpy.ops.object.select_all(action="DESELECT")
        # select and make active
        # self.select_object(context, o, True)

    def unique(self, context):
        obj = context.active_object
        sel = context.selected_objects[:]
        uniques = []

        for o in sel:
            if archipack_custom.filter(o):
                # select and make active
                Callbacks.call("unique", context, o, None)
                self.rec_get_childrens(o, uniques)
        if bool(uniques):
            bpy.ops.archipack.disable_manipulate()
            with ensure_select_and_restore(context, uniques[0], uniques):
                bpy.ops.object.make_single_user(
                    type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False
                )
            self.select_object(context, obj, True)
    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------

    def execute(self, context):
        if context.mode == "OBJECT":
            if self.mode == 'CREATE':
                bpy.ops.object.select_all(action="DESELECT")
                o = self.create(context)
                o.location = self.get_cursor_location(context)
                # select and make active
                self.select_object(context, o, True)

            elif self.mode == 'REFRESH':
                self.update(context)
            elif self.mode == 'UNIQUE':
                self.unique(context)
            elif self.mode == 'COPY':
                self.copy(context)

            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------

class ARCHIPACK_OT_custom_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and draw Custom over wall"
    bl_idname = "archipack.custom_preset_draw"
    bl_label = "Custom preset"
    preset_subdir = "archipack_custom"


class ARCHIPACK_OT_custom_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Choose a Custom preset"
    bl_idname = "archipack.custom_preset_menu"
    bl_label = "Custom preset"
    preset_subdir = "archipack_custom"


class ARCHIPACK_OT_custom_preset_create(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and create standalone Custom at cursor location"
    bl_idname = "archipack.custom_preset_create"
    bl_label = "Custom preset"
    preset_subdir = "archipack_custom"


class ARCHIPACK_OT_custom_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Custom Preset"
    bl_idname = "archipack.custom_preset"
    bl_label = "Custom preset"
    preset_menu = "ARCHIPACK_OT_custom_preset_menu"

    def prepare_preset(self, context, o, preset):
        d = archipack_custom.datablock(o)
        d.source = o


class ARCHIPACK_OT_custom_array(ArchipackArrayTool, Operator):
    bl_idname = "archipack.custom_array"
    bl_label = "Custom Array"
    bl_description = "Duplicate selected customs"
    bl_options = {'UNDO'}
    # XXX crash on redo when using spinner values ..
    # bl_options = {'REGISTER', 'UNDO'}

    def filter_object(self, o):
        return archipack_custom.filter(o)

    def get_object_datablock(self, o):
        return archipack_custom.datablock(o)


def register():
    bpy.utils.register_class(archipack_custom_part)
    bpy.utils.register_class(archipack_custom)
    Mesh.archipack_custom = CollectionProperty(type=archipack_custom)
    Mesh.archipack_custom_part = CollectionProperty(type=archipack_custom_part)
    bpy.utils.register_class(ARCHIPACK_PT_custom)
    bpy.utils.register_class(ARCHIPACK_PT_custom_part)
    bpy.utils.register_class(ARCHIPACK_OT_custom)
    bpy.utils.register_class(ARCHIPACK_OT_custom_draw)
    bpy.utils.register_class(ARCHIPACK_OT_custom_array)
    bpy.utils.register_class(ARCHIPACK_OT_make_custom)
    bpy.utils.register_class(ARCHIPACK_OT_custom_manipulators)
    bpy.utils.register_class(ARCHIPACK_OT_custom_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_custom_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_custom_preset_draw)
    bpy.utils.register_class(ARCHIPACK_OT_custom_preset)
    bpy.utils.register_class(ARCHIPACK_OT_custom_average_weight)


def unregister():
    bpy.utils.unregister_class(archipack_custom)
    bpy.utils.unregister_class(archipack_custom_part)
    bpy.utils.unregister_class(ARCHIPACK_PT_custom)
    bpy.utils.unregister_class(ARCHIPACK_PT_custom_part)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_array)
    bpy.utils.unregister_class(ARCHIPACK_OT_make_custom)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_manipulators)
    del Mesh.archipack_custom
    del Mesh.archipack_custom_part
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_custom_average_weight)

