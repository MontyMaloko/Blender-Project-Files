# -*- coding:utf-8 -*-

# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# 
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import PropertyGroup
from bpy.props import (
    FloatProperty, CollectionProperty, BoolProperty
)
from mathutils import Vector, Matrix
import bmesh
from math import cos, sin, tan
from .bmesh_utils import BmeshEdit as bmed


class archipack_bend(PropertyGroup):
    """
     Store bend locations and angle
    """
    x: FloatProperty()
    a: FloatProperty()


class Bendable:
    """
     Provide bend-able ability to objects so they may follow walls corners
    """
    bend: CollectionProperty(type=archipack_bend)

    @property
    def bend_yw(self):
        """
        TODO: Override in children classes
        :return: y distance from axis to inner pivot / w thickness
        """
        return 0, 0

    @staticmethod
    def _bend_bmesh(bm, tM, itM, angle, scale, x, dx):
        plane_co = tM.translation
        plane_no = tM.col[0].to_3d()
        # adx = abs(dx)
        # vec = plane_no * 2 * dx
        # vec = plane_no * dx
        _vx = [(itM @ v.co).x for v in bm.verts]

        if x > 0:
            side = [v for x, v in zip(_vx, bm.verts) if x > 0.001]
            # trs = [v for x, v in zip(_vx, bm.verts) if x > adx]
        else:
            side = [v for x, v in zip(_vx, bm.verts) if x < -0.001]
            # trs = [v for x, v in zip(_vx, bm.verts) if x < -adx]

        # center = []

        if len(side) < len(bm.verts):
            bmed.bisect(bm, plane_co, plane_no)
            center = [v for v in bm.verts if 0.001 > (itM @ v.co).x > -0.001]
            bmesh.ops.rotate(
                bm,
                verts=center,
                cent=plane_co,
                matrix=Matrix.Rotation(0.5 * angle, 3, 'Z'),
                space=Matrix()
            )
            bmesh.ops.scale(bm, verts=center, space=tM.inverted(), vec=scale)

        bmesh.ops.rotate(
            bm,
            verts=side,
            cent=plane_co,
            matrix=Matrix.Rotation(angle, 3, 'Z'),
            space=Matrix()
        )

        # bmesh.ops.translate(
        #     bm,
        #     verts=side + center,
        #     vec=vec,
        #     space=Matrix()
        # )

    def _bend_segment(self, o, sel, angle, x, y, w, base_bmesh):
        """ Bend mesh
        :param o: main object
        :param sel: collection of objects to bend
        :param angle:
        :param x:
        :param y: pivot offset from axis in inside direction (-)
        # :param thick: thick between inside and outside
        :return:
        """
        if angle > 0:
            y += w

        if x < 0:
            angle = -angle
        dx = y * tan(0.5 * angle)

        scale = 1.0 / cos(0.5 * abs(angle))
        scale = Vector((scale, scale, 1))

        plane_loc = Vector((x - dx, y, 0))
        # plane_loc = Vector((x - dx , y, 0))
        plane_tM = o.matrix_world @ Matrix.Translation(plane_loc)
        plane_itM = plane_tM.inverted()
        # print("angle", angle, "dx", dx, "y", y)
        for c in sel:
            # plane matrix in object coordsys
            tM = c.matrix_world.inverted() @ plane_tM
            # vertex in plane coordsys
            itM = plane_itM @ c.matrix_world
            if base_bmesh is None:
                bm = bmed._start(c)
                self._bend_bmesh(bm, tM, itM, angle, scale, x, -dx)
                bmed._end(bm, c)
            else:
                self._bend_bmesh(base_bmesh, tM, itM, angle, scale, x, -dx)

    def bend_mesh(self, o, sel, base_bmesh=None):
        y, w = self.bend_yw

        bend = self.bend[:]
        bend.sort(key=lambda x: x.x)
        for b in bend:
            if b.x < 0:
                self._bend_segment(o, sel, b.a, b.x, y, w, base_bmesh)

        for b in reversed(bend):
            if b.x > 0:
                self._bend_segment(o, sel, b.a, b.x, y, w, base_bmesh)

    @staticmethod
    def _bend_segment_2d(coords, angle, x, y, w, add_section=True):
        """ Bend 2d symbol
        :param coords: object to update
        :param angle:
        :param x:
        :param y: pivot offset from axis in inside direction (-)
        :param add_section: add section at rotation center
        :return:
        """

        if angle > 0:
            y += w

        if x < 0:
            angle = -angle

        closed = coords[0] == coords[-1]
        dx = y * tan(0.5 * angle)
        scale = 1.0 / cos(0.5 * abs(angle))
        plane_co = Vector((x - dx, y, 0))
        plane_tM = Matrix.Translation(plane_co)
        plane_itM = plane_tM.inverted()
        plane_no = plane_tM.col[0].to_3d()

        # vertex in plane coordsys
        if x > 0:
            side = [i for i, v in enumerate(coords) if (plane_itM @ v).x > 0.001]
        else:
            side = [i for i, v in enumerate(coords) if (plane_itM @ v).x < -0.001]

        to_add = []
        if len(side) < len(coords):
            p0 = coords[-1]
            ip0 = plane_itM @ p0
            for i, p1 in enumerate(coords):
                ip1 = plane_itM @ p1
                if ip1.x * ip0.x < 0:
                    # both sides, insert a coord before p0
                    u = p1 - p0
                    d = plane_no.dot(u)
                    w = p0 - plane_co
                    t = -plane_no.dot(w) / d
                    if i > 0 or closed:
                        to_add.append((i, p0 + t * u))
                p0 = p1
                ip0 = ip1

        rM = plane_tM @ Matrix.Rotation(angle, 4, 'Z') @ plane_itM
        for i in side:
            coords[i] = rM @ coords[i]

        if add_section:
            tM = plane_tM @ Matrix.Rotation(0.5 * angle, 4, 'Z') @ Matrix.Scale(scale, 4) @ plane_itM
            for i, co in reversed(to_add):
                coords.insert(i, tM @ co)

    def bend_coords(self, coords, add_section=True):
        y, w = self.bend_yw

        bend = self.bend[:]
        bend.sort(key=lambda x: x.x)
        for b in bend:
            if b.x < 0:
                self._bend_segment_2d(coords, b.a, b.x, y, w, add_section=add_section)

        for b in reversed(bend):
            if b.x > 0:
                self._bend_segment_2d(coords, b.a, b.x, y, w, add_section=add_section)


def register():
    bpy.utils.register_class(archipack_bend)


def unregister():
    bpy.utils.unregister_class(archipack_bend)
