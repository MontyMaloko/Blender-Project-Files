# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Jacob Morris - Stephen Leger (s-leger)
# ----------------------------------------------------------
import time
import bpy
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, CollectionProperty, StringProperty,
    BoolProperty, IntProperty, EnumProperty,
    FloatVectorProperty, IntVectorProperty, PointerProperty
    )
from mathutils import Vector, Matrix
from math import radians, cos, sin, pi, sqrt
from .archipack_manipulator import Manipulable, archipack_manipulator
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_abstraction import context_override, stop_auto_manipulate
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackCreateTool,
    ArchipackObject,
    ArchipackPanel,
    update_source
)
from .archipack_cutter import (
    ArchipackCutter,
    ArchipackCutterPart,
    update_operation
    )
from .archipack_dimension import DimensionProvider
from .archipack_curveman import ArchipackUserDefinedPath
from .archipack_segments2 import ArchipackSegment
from .archipack_throttle import throttle
from .archipack_material import build_mat_enum
from .archipack_floor import FloorGenerator
import logging
logger = logging.getLogger(__package__)


X_AXIS = Vector((1, 0, 0))
Z_AXIS = Vector((0, 0, 1))
MAT_GROUT = 0
MAT_FLOOR = 1


material_enums = []
mat_enum, mat_index_getter, mat_index_setter = build_mat_enum('idmat', material_enums)


# ------------------------------------------------------------------
# Define property class to store object parameters and update mesh
# ------------------------------------------------------------------

class CeilingGenerator(FloorGenerator):

    def get_verts(self, verts):
        _v = []
        segs = self.segs
        for _k in segs:
            _k.pts(_v)
        verts.extend(list(reversed(_v)))

    def cut(self, o, d, realtime):
        """
            either external or holes cuts
        """
        self.as_lines()
        self.limits(d)
        self.is_convex()
        if not realtime:
            itM = o.matrix_world.inverted()
            for c in o.children:
                _d = archipack_ceiling_cutter.datablock(c)
                if _d is not None:
                    tM = itM @ c.matrix_world
                    g = _d.ensure_direction(tM)
                    self.slice(g)


def update(self, context):
    if self.auto_update:
        self.update(context, realtime_update=False)


def update_manipulators(self, context):
    if self.auto_update:
        self.manipulable_refresh = True
        self.update(context)


def update_path(self, context):
    self.update_path(context)


class archipack_ceiling_part(Archipacki18n, ArchipackSegment, PropertyGroup):
    manipulators: CollectionProperty(type=archipack_manipulator)

    @property
    def parent_data(self):
        return self.id_data.archipack_ceiling[0]


class archipack_ceiling(Archipacki18n, ArchipackUserDefinedPath, ArchipackObject, Manipulable, DimensionProvider, PropertyGroup):
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('PARTS', 'Shape', 'Display ceiling segments settings', 'NONE', 1),
            ('MATERIALS', '', 'Display materials settings', 'MATERIAL', 2)
        ),
        default='MAIN',
    )
    parts: CollectionProperty(type=archipack_ceiling_part)

    pattern: EnumProperty(
        name='Ceiling Pattern',
        items=(
            ("boards", "Boards", ""),
            ("square_parquet", "Square Parquet", ""),
            ("herringbone_parquet", "Herringbone Parquet", ""),
            ("herringbone", "Herringbone", ""),
            ("regular_tile", "Regular Tile", ""),
            ("hopscotch", "Hopscotch", ""),
            ("stepping_stone", "Stepping Stone", ""),
            ("hexagon", "Hexagon", ""),
            ("windmill", "Windmill", ""),
            ("realtime", "Realtime", "Realtime optimized simple mesh"),
            ("user", "User defined", "")
        ),
        default="boards",
        update=update
    )
    rotation: FloatProperty(
        name='Rotation',
        subtype='ANGLE', unit='ROTATION',
        min=-pi,
        max=pi,
        update=update
    )
    spacing: FloatProperty(
        name='Spacing',
        description='The amount of space between boards or tiles in both directions',
        unit='LENGTH', subtype='DISTANCE',
        min=0,
        default=0.005,
        precision=5,
        update=update
    )
    thickness: FloatProperty(
        name='Thickness',
        description='Thickness',
        unit='LENGTH', subtype='DISTANCE',
        min=0.0,
        default=0.005,
        precision=5,
        update=update
    )
    vary_thickness: BoolProperty(
        name='Random Thickness',
        description='Vary thickness',
        default=False,
        update=update
    )
    thickness_variance: FloatProperty(
        name='Variance',
        description='How much vary by',
        min=0, max=100,
        default=25,
        precision=5,
        subtype='PERCENTAGE',
        update=update
    )

    board_width: FloatProperty(
        name='Width',
        description='The width',
        unit='LENGTH', subtype='DISTANCE',
        min=0.02,
        default=0.2,
        precision=5,
        update=update
    )
    vary_width: BoolProperty(
        name='Random Width',
        description='Vary width',
        default=False,
        update=update
    )
    width_variance: FloatProperty(
        name='Variance',
        description='How much vary by',
        subtype='PERCENTAGE',
        min=1, max=100, default=50,
        precision=5,
        update=update
    )
    width_spacing: FloatProperty(
        name='Width Spacing',
        description='The amount of space between boards in the width direction',
        unit='LENGTH', subtype='DISTANCE',
        min=0,
        default=0.002,
        precision=5,
        update=update
    )

    board_length: FloatProperty(
        name='Length',
        description='The length of the boards',
        unit='LENGTH', subtype='DISTANCE',
        precision=5,
        min=0.02,
        default=2,
        update=update
    )
    short_board_length: FloatProperty(
        name='Length',
        description='The length of the boards',
        unit='LENGTH', subtype='DISTANCE',
        precision=5,
        min=0.02,
        default=2,
        update=update
    )
    vary_length: BoolProperty(
        name='Random Length',
        description='Vary board length',
        default=False,
        update=update
    )
    length_variance: FloatProperty(
        name='Variance',
        description='How much board length can vary by',
        subtype='PERCENTAGE',
        min=1, max=100, default=50,
        precision=5, update=update
    )
    max_boards: IntProperty(
        name='Max Boards',
        description='Max number of boards in one row',
        min=1,
        default=100,
        update=update
    )
    length_spacing: FloatProperty(
        name='Length Spacing',
        description='The amount of space between boards in the length direction',
        unit='LENGTH', subtype='DISTANCE',
        min=0,
        default=0.002,
        precision=5,
        update=update
    )

    # parquet specific
    boards_in_group: IntProperty(
        name='Boards in Group',
        description='Number of boards in a group',
        min=1, default=4,
        update=update
    )

    # tile specific
    tile_width: FloatProperty(
        name='Width',
        description='Width of the tiles',
        unit='LENGTH', subtype='DISTANCE',
        min=0.002,
        default=0.2,
        precision=5,
        update=update
    )
    tile_length: FloatProperty(
        name='Length',
        description='Length of the tiles',
        unit='LENGTH', subtype='DISTANCE',
        precision=5,
        min=0.02,
        default=0.3,
        update=update
    )

    # grout
    add_grout: BoolProperty(
        name='Add Grout',
        description='Add grout',
        default=False,
        update=update
    )
    mortar_depth: FloatProperty(
        name='Depth',
        description='The depth of the mortar from the surface of the tile',
        unit='LENGTH', subtype='DISTANCE',
        precision=5,
        step=0.005,
        min=0,
        default=0.001,
        update=update
    )
    offset_x: FloatProperty(
        name='Offset x',
        unit='LENGTH', subtype='DISTANCE',
        description='Offset pattern on x axis',
        min=0, default=0,
        precision=5,
        update=update
    )
    offset_y: FloatProperty(
        name='Offset y',
        unit='LENGTH', subtype='DISTANCE',
        description='Offset pattern on y axis',
        min=0, default=0,
        precision=5,
        update=update
    )
    altitude: FloatProperty(
        name='Altitude',
        unit='LENGTH', subtype='DISTANCE',
        description='Altitude',
        min=0, default=0,
        precision=5,
        update=update
    )
    # regular tile
    random_offset: BoolProperty(
        name='Random Offset',
        description='Random amount of offset for each row of tiles',
        update=update, default=False
    )
    offset: FloatProperty(
        name='Offset',
        description='How much to offset each row of tiles',
        min=0, max=100, default=0,
        precision=5,
        update=update
    )
    offset_fac_integer: IntProperty(
        name='Ratio small/big',
        description="Small tile size with respect to big one",
        min=2,
        max=12,
        default=3,
        update=update
    )
    offset_variance: FloatProperty(
        name='Variance',
        description='How much to vary the offset each row of tiles',
        min=0.001, max=100, default=50,
        precision=5,
        update=update
    )

    # bevel
    bevel: BoolProperty(
        name='Bevel',
        update=update,
        default=False,
        description='Bevel upper faces'
    )
    bevel_amount: FloatProperty(
        name='Bevel',
        description='Bevel amount',
        unit='LENGTH', subtype='DISTANCE',
        min=0.0001, default=0.001,
        precision=5, step=0.05,
        update=update
    )
    solidify: BoolProperty(
        name="Solidify",
        default=True,
        update=update
    )
    z: FloatProperty(
        name="dumb z",
        description="Dumb z for manipulator placeholder",
        default=0.01,
        options={'SKIP_SAVE'}
    )
    x_offset: FloatProperty(
        name='Offset',
        description='How much to offset boundary',
        default=0,
        precision=5,
        update=update
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True,
        update=update_manipulators
    )
    normalize_uvs: BoolProperty(
        name="Normalize uvs",
        description="Use normalized uvs (use full texture on each tile)",
        default=False,
        update=update
    )
    # Note: 2 to 7 are for future use
    idmat: IntVectorProperty(
        default=[
            0, 1,
            2, 3, 4, 5, 6, 7
        ],
        size=8
    )
    always_closed = True
    use_fast_boolean: BoolProperty(
        name="Fast boolean",
        description="Use fast boolean to cut boundary and holes, might not be as safe as slow one",
        default=False,
        update=update
    )
    user_defined_pattern: PointerProperty(
        name="",
        type=Object,
        update=update_source
    )

    def get_generator(self, o=None):
        g = CeilingGenerator(o)
        g.rotation_matrix = Matrix.Rotation(self.rotation, 4, "Z") @ \
            Matrix.Rotation(pi, 4, "X") @ \
            Matrix.Translation(Vector((0, 0, -self.altitude)))
        g.add_parts(self)
        # g.line = g.make_offset(self.x_offset)
        return g

    def from_spline(self, context, o, curve, ccw=False, cw=False):
        ArchipackUserDefinedPath.from_spline(self, context, o, curve, ccw=True)

    def add_manipulator(self, name, pt1, pt2, pt3):
        m = self.manipulators.add()
        m.prop1_name = name
        m.set_pts([pt1, pt2, pt3])

    def update_manipulators(self):
        self.manipulators.clear()  # clear every time, add new ones
        self.add_manipulator("length", (0, 0, 0), (0, self.length, 0), (-0.4, 0, 0))
        self.add_manipulator("width", (0, 0, 0), (self.width, 0, 0), (0.4, 0, 0))

        z = self.thickness

        if self.pattern == "boards":
            self.add_manipulator("board_length", (0, 0, z), (0, self.board_length, z), (0.1, 0, z))
            self.add_manipulator("board_width", (0, 0, z), (self.board_width, 0, z), (-0.2, 0, z))
        elif self.pattern == "square_parquet":
            self.add_manipulator("short_board_length", (0, 0, z), (0, self.short_board_length, z), (-0.2, 0, z))
        elif self.pattern in ("herringbone", "herringbone_parquet"):
            dia = self.short_board_length * cos(radians(45))
            dia2 = self.board_width * cos(radians(45))
            self.add_manipulator("short_board_length", (0, 0, z), (dia, dia, z), (0, 0, z))
            self.add_manipulator("board_width", (dia, 0, z), (dia - dia2, dia2, z), (0, 0, z))
        else:
            tl = self.tile_length
            tw = self.tile_width

            if self.pattern in ("regular_tile", "hopscotch", "stepping_stone"):
                self.add_manipulator("tile_width", (0, tl, z), (tw, tl, z), (0, 0, z))
                self.add_manipulator("tile_length", (0, 0, z), (0, tl, z), (0, 0, z))
            elif self.pattern == "hexagon":
                self.add_manipulator("tile_width", (tw / 2 + self.spacing, 0, z), (tw * 1.5 + self.spacing, 0, z),
                                     (0, 0, 0))
            elif self.pattern == "windmill":
                self.add_manipulator("tile_width", (0, 0, z), (tw, 0, 0), (0, 0, z))
                self.add_manipulator("tile_length", (0, tl / 2 + self.spacing, z), (0, tl * 1.5 + self.spacing, z),
                                     (0, 0, z))

    def setup_manipulators(self):

        if len(self.manipulators) < 1:
            s = self.manipulators.add()
            s.type_key = "SIZE"
            s.prop1_name = "z"
            s.normal = Vector((0, 1, 0))

        if len(self.manipulators) < 2:
            s = self.manipulators.add()
            s.prop2_name = '{"op1": "archipack.segment_insert", "op2": "archipack.segment_insert"}'
            s.type_key = "OP_PATH"

        self.setup_parts_manipulators('z')

    def update(self, context, realtime_update=True, merge_geometry=False):
        """
        NOTE: realtime_update prevent crash with ui when changes are done on multiple objects
        :param context:
        :param realtime_update:
        :return:
        """
        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        tim = time.time()

        # print("ceiling.update()")

        # clean up manipulators before any data model change
        if self.manipulable_refresh:
            self.manipulable_disable(o)

        # self.update_parts()

        if self.num_parts < 3:
            self.restore_context(context)
            return

        if realtime_update:
            throttle.add(context, o, self)

        g = self.get_generator()
        g.locate_manipulators(self)

        g.set_offset(self.x_offset)

        realtime = throttle.is_active(o.name) and not merge_geometry

        t = time.time()
        g.cut(o, self, realtime)
        logger.debug("Ceiling.update() cut:%.4f seconds", time.time() - t)

        realtime = throttle.is_active(o.name) or self.pattern == "realtime"

        t = time.time()
        if not merge_geometry:
            pattern = self.user_defined_pattern
        else:
            pattern = None

        me = g.floor(context, o, self, pattern, realtime, merge_geometry=merge_geometry)

        if merge_geometry:
            self.restore_context(context)
            return me

        self.shade_smooth(context, o, 0.209)

        logger.debug("Ceiling.update() ceiling:%.4f seconds", time.time() - t)
        self.update_dimensions(context, o)

        logger.debug("Ceiling.update() throttle:%s %s :%.4f seconds", realtime, o.name, time.time() - tim)
        # restore context
        self.restore_context(context)

    @property
    def user_defined_objects(self):
        return [
                self.user_defined_pattern
        ]

    def manipulable_setup(self, context, o):
        # locate manipulators
        self.get_generator()
        self.setup_manipulators()
        self.manipulable_setup_parts(context, o)
        for m in self.manipulators:
            self.manip_stack.append(m.setup(context, o, self))


class archipack_ceiling_cutter_segment(ArchipackCutterPart, PropertyGroup):
    manipulators: CollectionProperty(type=archipack_manipulator)

    @property
    def parent_data(self):
        return self.id_data.archipack_ceiling_cutter[0]


class archipack_ceiling_cutter(ArchipackCutter, ArchipackObject, Manipulable, DimensionProvider, PropertyGroup):
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display cutter settings', 'NONE', 0),
            ('PARTS', 'Shape', 'Display cutter segments settings', 'NONE', 1)
        ),
        default='MAIN',
    )
    parts: CollectionProperty(type=archipack_ceiling_cutter_segment)

    def update_parent(self, context, o):
        if o is not None and o.parent:
            d = archipack_ceiling.datablock(o.parent)
            if d is not None:
                cutables = [o.parent]
                self.filter_cutables(context, o, cutables)
                # print("ceiling_cutter.update_parent()", cutables)
                for c in cutables:
                    # _d = archipack_ceiling.datablock(c)
                    with context_override(context, c, [c]) as ctx:
                        d.update(ctx)
                self.store_cutables(o, cutables)


# ------------------------------------------------------------------
# Define panel class to show object parameters in ui panel (N)
# ------------------------------------------------------------------


class ARCHIPACK_PT_ceiling(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_ceiling"
    bl_label = "Ceilinging"

    @classmethod
    def poll(cls, context):
        # ensure your object panel only show when active object is the right one
        return archipack_ceiling.poll(context.active_object)

    def draw(self, context):
        o = context.active_object

        if not archipack_ceiling.filter(o):
            return
        layout = self.layout

        d = archipack_ceiling.datablock(o)

        self.draw_common(context, layout)

        box = layout.box()
        row = box.row(align=True)
        not_realtime = d.pattern != "realtime"
        # Presets operators
        self.draw_op(context, layout, row, "archipack.ceiling_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_ceiling_preset_menu.bl_label, icon="PRESET"
                    ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.ceiling_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.ceiling_preset", icon='REMOVE', text="").remove_active = True

        self.draw_op(context, layout, layout, 'archipack.ceiling_cutter', icon="MOD_BOOLEAN").parent = o.name

        self.draw_prop(context, layout, layout, d, "tabs", expand=True)
        box = layout.box()

        if d.tabs == 'PARTS':
            expand = d.template_user_path(context, box, focus=False)
            if expand:
                self.draw_prop(context, layout, box, d, 'x_offset')
            d.template_parts(context, layout)

        elif d.tabs == 'MAIN':
            self.draw_prop(context, layout, box, d, "altitude")
            self.draw_prop(context, layout, box, d, 'pattern', text="")

            if not_realtime:
                self.draw_prop(context, layout, box, d, 'rotation')
                self.draw_prop(context, layout, box, d, "offset_x")
                self.draw_prop(context, layout, box, d, "offset_y")

            box.separator()
            if d.pattern == 'user':
                self.draw_label(context, layout, box, "Pattern object")
                self.draw_prop(context, layout, box, d, "user_defined_pattern")

            else:
                self.draw_prop(context, layout, box, d, 'thickness')

            if not_realtime:

                if d.pattern != 'user':
                    self.draw_prop(context, layout, box, d, 'vary_thickness', icon='RNDCURVE')
                    if d.vary_thickness:
                        self.draw_prop(context, layout, box, d, 'thickness_variance')

                box.separator()
                self.draw_prop(context, layout, box, d, 'solidify', icon='MOD_SOLIDIFY')

                if d.pattern != 'user':
                    box.separator()
                    if d.pattern == 'boards':
                        self.draw_prop(context, layout, box, d, 'max_boards')
                        self.draw_prop(context, layout, box, d, 'board_length')
                        self.draw_prop(context, layout, box, d, 'vary_length', icon='RNDCURVE')
                        if d.vary_length:
                            self.draw_prop(context, layout, box, d, 'length_variance')
                        box.separator()

                        # width
                        self.draw_prop(context, layout, box, d, 'board_width')
                        # vary width
                        self.draw_prop(context, layout, box, d, 'vary_width', icon='RNDCURVE')
                        if d.vary_width:
                            self.draw_prop(context, layout, box, d, 'width_variance')
                        box.separator()
                        self.draw_prop(context, layout, box, d, 'length_spacing')
                        self.draw_prop(context, layout, box, d, 'width_spacing')

                    elif d.pattern in {'square_parquet', 'herringbone_parquet', 'herringbone'}:
                        self.draw_prop(context, layout, box, d, 'short_board_length')

                        if d.pattern != "square_parquet":
                            self.draw_prop(context, layout, box, d, "board_width")
                        self.draw_prop(context, layout, box, d, "spacing")

                        if d.pattern == 'square_parquet':
                            self.draw_prop(context, layout, box, d, 'boards_in_group')
                    elif d.pattern in {'regular_tile', 'hopscotch', 'stepping_stone', 'hexagon', 'windmill'}:
                        # width and length and mortar
                        if d.pattern != "hexagon":
                            self.draw_prop(context, layout, box, d, "tile_length")
                        self.draw_prop(context, layout, box, d, "tile_width")
                        self.draw_prop(context, layout, box, d, "spacing")

                        if d.pattern == 'hopscotch':
                            self.draw_prop(context, layout, box, d, "offset_fac_integer")

                    if d.pattern in {"regular_tile", "boards"}:
                        box.separator()
                        self.draw_prop(context, layout, box, d, "random_offset", icon="RNDCURVE")
                        if d.random_offset:
                            self.draw_prop(context, layout, box, d, "offset_variance")
                        else:
                            self.draw_prop(context, layout, box, d, "offset")

                # grout
                box.separator()
                self.draw_prop(context, layout, box, d, 'add_grout', icon='MESH_GRID')
                if d.add_grout:
                    self.draw_prop(context, layout, box, d, 'mortar_depth')

                # bevel
                box.separator()
                self.draw_prop(context, layout, box, d, 'bevel', icon='MOD_BEVEL')
                if d.bevel:
                    self.draw_prop(context, layout, box, d, 'bevel_amount')

            self.draw_prop(context, layout, box, d, 'use_fast_boolean')

        elif d.tabs == 'MATERIALS':
            if "archipack_material" in o:
                o.archipack_material[0].draw(context, box)
            box = layout.box()
            self.draw_prop(context, layout, box, d, 'normalize_uvs')


class ARCHIPACK_PT_ceiling_cutter(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_ceiling_cutter"
    bl_label = "Ceiling Cutter"

    @classmethod
    def poll(cls, context):
        return archipack_ceiling_cutter.poll(context.active_object)

    def draw(self, context):
        d = archipack_ceiling_cutter.datablock(context.active_object)
        if d is None:
            return
        layout = self.layout

        self.draw_common(context, layout, draw_animation=False)

        d.draw(context, layout)


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_ceiling(ArchipackCreateTool, Operator):
    bl_idname = "archipack.ceiling"
    bl_label = "Ceiling"
    bl_description = "Ceiling"

    def create(self, context):
        """
            expose only basic params in operator
            use object property for other params
        """
        o, m = self.create_mesh("Ceiling")
        d = m.archipack_ceiling.add()
        # make manipulators selectable
        d.manipulable_selectable = True
        x = 4
        angle_90 = pi / 2
        d.set_parts(4)
        for i, p in enumerate(d.parts):
            p.a0 = angle_90
            p.length = x
        d.parts[0].a0 = - angle_90
        # Link object into scene
        self.link_object_to_scene(context, o)
        o.color = (1, 0.25, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        self.add_material(context, o)
        self.load_preset(context, o, d)
        return o

    def execute(self, context):
        if context.mode == "OBJECT":
            bpy.ops.object.select_all(action="DESELECT")
            with stop_auto_manipulate(context):
                o = self.create(context)
                o.location = self.get_cursor_location(context)
            self.add_to_reference(context, o)
            self.select_object(context, o, True)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_ceiling_from_curve(ArchipackCreateTool, Operator):
    bl_idname = "archipack.ceiling_from_curve"
    bl_label = "Ceiling curve"
    bl_description = "Create ceiling from curve(s)"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'CURVE'
    # -----------------------------------------------------
    # Draw (create UI interface)
    # -----------------------------------------------------
    # noinspection PyUnusedLocal

    def create(self, context, curves):
        # handle multiple curves, curves with many splines
        for curve in curves:
            if curve.type == "CURVE":
                for i, spline in enumerate(curve.data.splines):
                    bpy.ops.archipack.ceiling(filepath=self.filepath)
                    o = context.active_object
                    d = archipack_ceiling.datablock(o)
                    d.user_defined_spline = i
                    d.from_spline(context, o, curve)
                    d.auto_update = True
                    d.update(context)

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            curves = context.selected_objects[:]
            bpy.ops.object.select_all(action="DESELECT")
            self.create(context, curves)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_ceiling_from_wall(ArchipackCreateTool, Operator):
    bl_idname = "archipack.ceiling_from_wall"
    bl_label = "->Ceiling"
    bl_description = "Create ceiling(s) from a wall"

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.data is not None and 'archipack_wall2' in o.data

    def create(self, context):
        o, m = self.create_mesh("Ceiling")
        d = m.archipack_ceiling.add()
        d.manipulable_selectable = True
        d.auto_update = False
        self.link_object_to_scene(context, o)
        o.color = (1, 0.25, 0, 1)

        self.select_object(context, o, True)
        self.add_material(context, o)
        self.load_preset(context, o, d, auto_update=False)
        return o

    def ceiling_from_wall(self, context, w, wd):
        """
         Create ceilinging from surrounding wall
         Use slab cutters, windows and doors, T childs walls
        """
        tim = time.time()
        # wall is either a single or collection of polygons
        try:
            io, wall, childs = wd.as_geom(context, w, 'CEILING', [], [], [])

        except RecursionError as ex:
            self.report({"ERROR"}, "RecursionError while building geometry: %s" % ex)
            import traceback
            traceback.print_exc()
            return None

        except Exception as ex:
            self.report({"ERROR"}, "Error while building geometry: %s" % ex)
            import traceback
            traceback.print_exc()
            return None

        o = None

        polys = []
        self.filter_polygons(wall, polys)

        if len(polys) < 1:
            # GeometryCollection / anything else likely to be empty
            self.report({"WARNING"}, "Topology error or No closed space found")
            return None

        sel = []
        logger.debug("ceiling_from_wall() curves :%.4f seconds", time.time() - tim)

        for poly in polys:

            boundary = io._to_curve(poly.exterior, "{}-boundary".format(w.name), '2D')
            boundary.location.z = w.matrix_world.translation.z

            logger.debug("ceiling_from_wall() boundary :%.4f seconds", time.time() - tim)
            o = self.create(context)
            sel.append(o)
            # o.matrix_world = w.matrix_world.copy()
            d = archipack_ceiling.datablock(o)
            d.altitude = wd.z - wd.z_offset - d.thickness
            logger.debug("ceiling_from_wall() create :%.4f seconds", time.time() - tim)
            d.user_defined_path = boundary.name

            logger.debug("ceiling_from_wall() user_defined_path :%.4f seconds", time.time() - tim)
            self.delete_object(context, boundary)
            logger.debug("ceiling_from_wall() delete_object :%.4f seconds", time.time() - tim)
            d.user_defined_path = ""
            logger.debug("ceiling_from_wall() ceiling :%.4f seconds", time.time() - tim)
            for hole in poly.interiors:
                curve = io._to_curve(hole, "{}-cut".format(o.name), '3D')
                bpy.ops.archipack.ceiling_cutter(parent=o.name, curve=curve.name)
                c = context.active_object
                cd = archipack_ceiling_cutter.datablock(c)
                cd.user_defined_path = ""
                self.delete_object(context, curve)
                self.unselect_object(context, c)

            logger.debug("ceiling_from_wall() cutters :%.4f seconds", time.time() - tim)

            # link to reference point here to retrieve slabs holes too when updating
            self.select_object(context, o, True)
            self.select_object(context, w, True)
            bpy.ops.archipack.add_reference_point()
            self.unselect_object(context, w)

            # select and make active
            self.select_object(context, o, True)
            # make low throttle so user feedback on creation is real time
            throttle.add(context, o, d, duration=0.01)
            d.auto_update = True
            self.unselect_object(context, o)
            logger.debug("ceiling_from_wall() %s :%.4f seconds", o.name, time.time() - tim)

        for obj in sel:
            self.select_object(context, obj)

        return o

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            wall = context.active_object
            bpy.ops.object.select_all(action="DESELECT")
            wd = wall.data.archipack_wall2[0]
            with stop_auto_manipulate(context):
                o = self.ceiling_from_wall(context, wall, wd)
            self.select_object(context, wall, True)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_ceiling_cutter(ArchipackCreateTool, Operator):
    bl_idname = "archipack.ceiling_cutter"
    bl_label = "Ceiling Cutter"
    bl_description = "Ceiling Cutter"

    parent: StringProperty("")
    curve: StringProperty("")

    def create(self, context):
        o, m = self.create_mesh("Ceiling Cutter")
        d = m.archipack_ceiling_cutter.add()
        d.manipulable_selectable = True
        parent = self.get_scene_object(context, self.parent)
        curve = self.get_scene_object(context, self.curve)

        logger.debug("ARCHIPACK_OT_ceiling_cutter.create()", self.parent, parent)

        if parent is not None:
            o.parent = parent
            bbox = parent.bound_box
            angle_90 = pi / 2
            x0, y0, z = bbox[0]
            x1, y1, z = bbox[6]
            x = max(1, 0.2 * (x1 - x0))

            o.matrix_world = parent.matrix_world @ Matrix.Translation(Vector((-3 * x, 0, 0)))
            # d.auto_update = False
            d.set_parts(4)
            for i, p in enumerate(d.parts):
                p.a0 = angle_90
                p.length = x
            d.parts[0].a0 = - angle_90
            # d.auto_update = True
        else:
            o.location = self.get_cursor_location(context)

        # Link object into scene
        self.link_object_to_scene(context, o)
        o.color = (1, 0, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        self.load_preset(context, o, d)
        update_operation(d, context)

        if curve is not None:
            d.user_defined_path = curve.name
        else:
            d.update(context)

        return o

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            bpy.ops.object.select_all(action="DESELECT")
            with stop_auto_manipulate(context):
                o = self.create(context)
            self.select_object(context, o, True)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to load presets (with polls)
# ------------------------------------------------------------------


class ARCHIPACK_OT_ceiling_preset_create(PresetMenuOperator, Operator):
    bl_description = "Show Ceiling presets and create object at cursor location"
    bl_idname = "archipack.ceiling_preset_create"
    bl_label = "Ceiling"
    preset_subdir = "archipack_ceiling"


class ARCHIPACK_OT_ceiling_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Create Ceiling from presets"
    bl_idname = "archipack.ceiling_preset_menu"
    bl_label = "Ceiling preset"
    preset_subdir = "archipack_ceiling"


class ARCHIPACK_OT_ceiling_preset_from_wall(PresetMenuOperator, Operator):
    bl_description = "Create ceiling(s) from a wall"
    bl_idname = "archipack.ceiling_preset_from_wall"
    bl_label = "-> Ceiling"
    preset_subdir = "archipack_ceiling"
    preset_operator: StringProperty(
        options={'SKIP_SAVE'},
        default="archipack.ceiling_from_wall"
    )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o and o.data and "archipack_wall2" in o.data


class ARCHIPACK_OT_ceiling_preset_from_curve(PresetMenuOperator, Operator):
    bl_description = "Create a Ceiling from curve"
    bl_idname = "archipack.ceiling_preset_from_curve"
    bl_label = "-> Ceiling"
    preset_subdir = "archipack_ceiling"
    preset_operator: StringProperty(
        options={'SKIP_SAVE'},
        default="archipack.ceiling_from_curve"
    )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o and o.type == 'CURVE'


class ARCHIPACK_OT_ceiling_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Ceiling Preset"
    bl_idname = "archipack.ceiling_preset"
    bl_label = "Ceiling preset"
    preset_menu = "ARCHIPACK_OT_ceiling_preset_menu"

    @property
    def blacklist(self):
        return ['parts', 'n_parts', 'thickness', 'altitude']


def register():
    bpy.utils.register_class(archipack_ceiling_cutter_segment)
    bpy.utils.register_class(archipack_ceiling_cutter)
    Mesh.archipack_ceiling_cutter = CollectionProperty(type=archipack_ceiling_cutter)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_cutter)
    bpy.utils.register_class(ARCHIPACK_PT_ceiling_cutter)

    bpy.utils.register_class(archipack_ceiling_part)
    bpy.utils.register_class(archipack_ceiling)
    Mesh.archipack_ceiling = CollectionProperty(type=archipack_ceiling)
    bpy.utils.register_class(ARCHIPACK_PT_ceiling)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_preset_from_wall)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_preset_from_curve)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_preset)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_from_curve)
    bpy.utils.register_class(ARCHIPACK_OT_ceiling_from_wall)


def unregister():
    bpy.utils.unregister_class(archipack_ceiling_cutter_segment)
    bpy.utils.unregister_class(archipack_ceiling_cutter)
    del Mesh.archipack_ceiling_cutter
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_cutter)
    bpy.utils.unregister_class(ARCHIPACK_PT_ceiling_cutter)

    bpy.utils.unregister_class(archipack_ceiling_part)
    bpy.utils.unregister_class(archipack_ceiling)
    del Mesh.archipack_ceiling
    bpy.utils.unregister_class(ARCHIPACK_PT_ceiling)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_preset_from_wall)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_preset_from_curve)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_from_curve)
    bpy.utils.unregister_class(ARCHIPACK_OT_ceiling_from_wall)
