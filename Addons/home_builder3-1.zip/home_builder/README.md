# Home Builder
This is an add-on for Blender that focuses on the designing interior spaces for homes.

This is a work in progress to migrate the functionality for the previous version of Home Builder to Blender 3. If you are looking for the working version of Home Builder that is compatible with Blender 2.93 please view this repo.

https://github.com/CreativeDesigner3D/Library_Home_Builder
