# -*- coding:utf-8 -*-

# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# 
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import time
from .archipack_logging import logger
from .archipack_polylines import CoordSys, Q_tree, Line
from bpy.props import FloatVectorProperty


class SnappableGenerator:

    def snap_sides(self, d):
        """Handle generator's snap
        :param d: datablock
        """
        t = d.extremes
        s0, s1 = self.axis.segs[0], self.axis.segs[-2]
        if s0.length > 0:
            s0.p0 = s0.lerp(t[0] / s0.length)
        if s1.length > 0:
            s1.p1 = s1.lerp(1 + t[1] / s1.length)
        s0, s1 = self.outside.segs[0], self.outside.segs[-2]
        if s0.length > 0:
            s0.p0 = s0.lerp(t[2] / s0.length)
        if s1.length > 0:
            s1.p1 = s1.lerp(1 + t[3] / s1.length)
        s0, s1 = self.inside.segs[0], self.inside.segs[-2]
        if s0.length > 0:
            s0.p0 = s0.lerp(t[4] / s0.length)
        if s1.length > 0:
            s1.p1 = s1.lerp(1 + t[5] / s1.length)


class Snappable:
    """
    Provide 2d shape snap ability to objects in order to fill spaces boundarys
    between walls / standalone windows and doors / beams
    """
    extremes: FloatVectorProperty(
        description="distance of intersections for axis outside and inside",
        size=6,
        default=[0, 0, 0, 0, 0, 0]
    )

    def find_snappables(self, o, include_self=False, filter=None):
        res = []
        p = self.get_reference_point(o)
        if p is not None:
            def _filter(c):
                return (
                    self.archipack_datablock(c, filter) is not None and
                    (include_self or o.name != c.name)
                )
            self.rec_get_childrens(p, res, _filter)
        return {c: self.archipack_datablock(c, filter) for c in res}

    @staticmethod
    def snap_ext(s0, tree, maxdist, near='END', whitelist={'inside', 'outside', 'axis'}, exclude=""):
        """Main snap routine"""
        closest = -1

        if near == 'END':
            pt = s0.p1
            ref_t = 100
            t = 1
        else:
            pt = s0.p0
            ref_t = -100
            t = 0
        p0 = pt

        count, selection = tree.intersects_pt(pt, maxdist)

        for i in selection:
            name, idx, seg, _type = tree._geoms[i]
            if _type in whitelist and name != exclude:
                res, p, u, v = s0.intersect_ext(seg, collinear_threshold=0.01)

                # Collinear segments not crossing (d > 0.001)
                if (res is False or res is None) and s0.is_collinear(seg):
                    continue

                # allow 1 mm to fix precision issues -> disallow extend !!
                if seg.length > 0:
                    dv = 0.001 / seg.length
                else:
                    dv = 0

                d = (p0 - p).length
                if 1 + dv > v > -dv and d < maxdist:
                    # intersects into seg interval
                    if near == 'END':
                        # u minimum in interval [0:100]
                        if ref_t > u > 0:
                            ref_t = u
                            if u > 1:
                                t = d
                            else:
                                t = -d
                            pt = p
                            closest = i
                    else:
                        # u maximum in interval [-100:1]
                        # print(name, " idx:", idx, " type:", _type, " u:", u, " ref_t:",ref_t)
                        if 1 > u > ref_t:
                            ref_t = u
                            if u > 0:
                                t = d
                            else:
                                t = -d
                            pt = p
                            closest = i

        return closest > -1, t, pt, closest

    def get_snap_generator(self, tM):
        """TODO: Override, Must return a gemerator like with axis, inside and outside, including "valid segs" """
        raise NotImplementedError

    @staticmethod
    def fill_snap_tree(tree, o_d, itM):
        """Fill snap tree with data
        :param tree: Q_tree to fill
        :param o_d: dict, Object: datablock
        :param itM: the coordinate system of the tree
        """
        t = time.time()
        for o, d in o_d.items():
            name = o.name
            g = d.get_snap_generator(itM @ o.matrix_world)

            for i, seg in enumerate(g.outside.valid_segs):
                tree.insert_seg(seg, (name, i, seg, "outside"))
            for i, seg in enumerate(g.inside.valid_segs):
                tree.insert_seg(seg, (name, i, seg, "inside"))
            # allow snap on start and end
            if not (hasattr(d, "is_closed") and d.is_closed):
                seg = Line(g.outside.segs[0].p0, p1=g.inside.segs[0].p0)
                tree.insert_seg(seg, (name, 0, seg, "inside"))
                seg = Line(g.outside.segs[-2].p1, p1=g.inside.segs[-2].p1)
                tree.insert_seg(seg, (name, 0, seg, "inside"))
        logger.debug("fill_snap_tree %.4f seconds", time.time() - t)

    @staticmethod
    def create_snap_tree(o_d, itM=None):
        """
        :param o_d: dict, Object: datablock
        :param itM: the coordinate system of the tree
        """
        coordsys = CoordSys(o_d.keys(), itM=itM)
        tree = Q_tree(coordsys, max_depth=8)
        return coordsys, tree

    def snap_sides(self, g, tree, dist, snap_start=True, snap_end=True):
        """Main snap routine for generators, basically set extremes distances
        NOTE: caller must reset self.extremes[0:6] = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        """
        t = time.time()
        if snap_start:
            s0 = g.axis.segs[0]
            maxdist = min(dist, 0.3 * s0.length)
            it, maxi0, p, idx = self.snap_ext(s0, tree, maxdist, near='START', whitelist={'outside', 'inside'})
            if it:
                name, idx, seg, _type = tree._geoms[idx]
                self.extremes[0] = maxi0
                res, p, t = g.outside.segs[0].intersect(seg)
                d = (g.outside.segs[0].p0 - p).length
                if t < 0:
                    d = -d
                self.extremes[2] = d
                res, p, t = g.inside.segs[0].intersect(seg)
                d = (g.inside.segs[0].p0 - p).length
                if t < 0:
                    d = -d
                self.extremes[4] = d

        logger.debug("snap_sides start %.4f", (time.time() - t))

        t = time.time()
        if snap_end:
            s0 = g.axis.segs[-2]
            maxdist = min(dist, 0.3 * s0.length)
            it, mini0, p, idx = self.snap_ext(s0, tree, maxdist, near='END', whitelist={'outside', 'inside'})
            if it:
                # check for axis intersection, then compute sides on same segment.
                name, idx, seg, _type = tree._geoms[idx]
                self.extremes[1] = mini0
                res, p, t = g.outside.segs[-2].intersect(seg)

                d = (g.outside.segs[-2].p1 - p).length
                if t < 1:
                    d = -d
                self.extremes[3] = d
                res, p, t = g.inside.segs[-2].intersect(seg)

                d = (g.inside.segs[-2].p1 - p).length
                if t < 1:
                    d = -d
                self.extremes[5] = d

        logger.debug("snap_sides end %.4f", (time.time() - t))

    def snap(self, o, maxdist=0.2):
        """ Snap o to any snappable arround
        :param o: blender's object
        :param maxdist: distance max for snap
        """
        self.extremes[0:6] = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)

        # get snappables
        def _filter(c, key):
            return (
                    key in {"archipack_wall2", "archipack_beam"} or
                    (key in {"archipack_window", "archipack_door"} and self.has_flag(c, "standalone"))
            )

        o_d = self.find_snappables(o, include_self=False, filter=_filter)

        if len(o_d) > 0:
            t = time.time()
            coordsys, tree = self.create_snap_tree(o_d)
            self.fill_snap_tree(tree, o_d, coordsys.invert)

            logger.debug("Snappable build tree %.4f", (time.time() - t))
            # print("Snappable build tree %.4f" % ((time.time() - t)))

            g = self.get_snap_generator(coordsys.invert @ o.matrix_world)
            self.snap_sides(g, tree, maxdist)

            logger.debug("Snappable.snap() %s %.4f", o.name, time.time() - t)
            # print("Snappable.snap() %s %.4f" % (o.name, time.time() - t))
