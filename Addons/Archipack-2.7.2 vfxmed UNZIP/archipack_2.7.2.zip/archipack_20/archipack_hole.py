# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object
from bpy.props import (
    FloatProperty, IntProperty, BoolProperty, BoolVectorProperty, IntVectorProperty,
    CollectionProperty, FloatVectorProperty, EnumProperty, StringProperty, PointerProperty
)
from mathutils import Vector, Matrix
import time
from random import uniform
from math import tan, floor
from .bmesh_utils import BmeshEdit as bmed
from .panel import Panel as HolePanel
from .archipack_manipulator import Manipulable
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_autoboolean import ArchipackBoolManager
from .archipack_gl import FeedbackPanel
from .archipack_abstraction import ensure_select_and_restore, Callbacks, context_override
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackPanel,
    ArchipackObject,
    ArchipackCreateTool,
    ArchipackDrawTool,
    ArchipackArrayTool
)
from .archipack_segments2 import OpeningGenerator
from .archipack_keymaps import Keymaps
from .archipack_dimension import DimensionProvider
from .archipack_bendable import Bendable
from .archipack_custom import Customizable

from .archipack_iconmanager import icons


import logging

logger = logging.getLogger("archipack_hole")


def random_color():
    return Vector((uniform(0.0, 1.0), uniform(0.0, 1.0), uniform(0.0, 1.0), 1))


def update(self, context):
    self.update(context)


def update_childs(self, context):
    self.update(context, childs_only=True)


def set_cols(self, value):
    if self.n_cols != value:
        self.auto_update = False
        self._set_width(value)
        self.auto_update = True
        self.n_cols = value
    return None


def get_cols(self):
    return self.n_cols


class archipack_hole(ArchipackObject, Manipulable, Customizable, DimensionProvider, Bendable, PropertyGroup):
    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('SUB', 'Parts', 'Display components settings', 'NONE', 1),
            ('MATERIALS', '', 'Display materials settings', 'MATERIAL', 2)
        ),
        default='MAIN',
    )
    x: FloatProperty(
        name='Width',
        min=0.1,
        default=100.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Width', update=update
    )
    y: FloatProperty(
        name='Depth',
        min=0.05,
        default=0.20, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Depth', update=update,
    )
    z: FloatProperty(
        name='Height',
        min=0.1,
        default=2.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Height', update=update,
    )
    angle_y: FloatProperty(
        name='Angle',
        unit='ROTATION',
        subtype='ANGLE',
        min=-1.5, max=1.5,
        default=0, precision=5,
        description='Angle', update=update,
    )
    radius: FloatProperty(
        name='Radius',
        min=0.1,
        default=2.5, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Radius', update=update,
    )
    elipsis_b: FloatProperty(
        name='Ellipsis',
        min=0.1,
        default=0.5, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Ellipsis vertical size', update=update,
    )
    altitude: FloatProperty(
        name='Altitude',
        default=0.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Altitude', update=update,
    )
    offset: FloatProperty(
        name='Offset',
        default=0.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Offset', update=update,
    )
    
    finishing_out: FloatProperty(
        name='Finishing thickness',
        min=0,
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Thickness of outside wall finishing'
    )
    finishing_int: FloatProperty(
        name='Finishing thickness',
        min=0,
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Thickness of outside wall finishing'
    )
    
    curve_steps: IntProperty(
        name="Resolution",
        min=2,
        max=128,
        default=16, update=update,
    )
    hole_margin: FloatProperty(
        name='Hole margin',
        min=0.0,
        default=0.01, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        update=update,
        description='how much hole surround wall'
    )
    z_offset: FloatProperty(
        name="Hole depth z",
        unit='LENGTH', subtype='DISTANCE',
        description='Depth of hole under the door',
        default=0.1, precision=5, step=1,
        min=0,
        update=update
    )
    mat_hole_inside: IntProperty(
        name="Hole Inside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    mat_hole_outside: IntProperty(
        name="Hole Outside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    mat_finish_inside: IntProperty(
        name="Finish Inside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    mat_finish_outside: IntProperty(
        name="Finish Outside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    hole_shape: EnumProperty(
        name='Shape',
        items=(
            ('RECTANGLE', 'Rectangle', '', 0),
            ('ROUND', 'Top Round', '', 1),
            ('ELLIPSIS', 'Top elliptic', '', 2),
            ('QUADRI', 'Top oblique', '', 3),
            ('CIRCLE', 'Full circle', '', 4)
        ),
        default='RECTANGLE', update=update,
    )

    auto_mat: BoolProperty(
        name="Auto materials",
        default=True
    )
    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True,
        update=update
    )
    cut_moldings: BoolProperty(
        default=False,
        name="Cut moldings",
        description="Make this hole a molding cutter in wall thickness"
    )
    portal: BoolProperty(
        default=False,
        name="Portal",
        description="Makes this hole a light portal, enabling better photon gathering during render",
        update=update
    )
    portal_energy: FloatProperty(
        default=0.3,
        min=0, step=1, precision=5,
        name="Energy",
        description="Portal lamp energy for eevee",
        update=update
    )

    @property
    def bend_yw(self):
        return -0.5 * self.y, self.y

    @property
    def shape(self):
        return self.hole_shape

    @property
    def hole(self):
        #    _____   y_outside
        #   |       -y
        #   x        yc
        #   |       y
        #   |_____   y_inside
        #
        y0 = self.hole_center_y
       
        # is half of finishing gap
        gap = 0.0001

        y = y0 + gap
        y_inside = y + self.finishing_int + self.hole_margin  # inside wall

        x0 = - gap

        outside_mat = self.mat_hole_outside
        inside_mat = self.mat_hole_inside
        in_finish_mat = self.mat_finish_inside
        out_finish_mat = self.mat_finish_outside

        y_outside = -(y + self.finishing_out + self.hole_margin)
        yc = max(-y + 2 * gap, min(y - 2 * gap, self.offset))

        # Hole without overflow
        return HolePanel(
            False,  # closed
            [0, 0, 0, 0, 0],  # x index
            [x0],
            [y_outside, -y, yc, y, y_inside],
            [out_finish_mat, outside_mat, inside_mat, in_finish_mat],  # material index
            side_cap_front=4,  # cap index
            side_cap_back=0
        )

    @property
    def hole_center_y(self):
        """
        Hole center on y axis - this is the location of ground
        :return:
        """
        y = 0.5 * self.y  # - self.offset

        return y

    @property
    def fill_symbol(self):
        # Provide lines on each side for moldings on hole side
        x0 = 0
        y0 = self.hole_center_y + 0.001
        y1 = -y0

        return HolePanel(
            False,  # closed
            [0, 0],  # x index
            [x0],
            [y1, y0],
            [0, 0],  # material index
            closed_path=True,
            side_cap_front=1,
            side_cap_back=0  # cap index
        )

    @property
    def hole_symbol(self):
        #   Provide hole for moldings
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        #   x0
        x0 = 0
        y0 = self.hole_center_y + 0.001
        y1 = -y0
        y2 = 0

        return HolePanel(
            False,  # closed
            [0, 0, 0],  # x index
            [x0],
            [y1, y2, y0],
            [0, 0, 0],  # material index
            closed_path=True,
            side_cap_front=2,
            side_cap_back=0  # cap index
        )

    @property
    def inside_hole(self):
        #
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        #   x0
        x0 = 0
        y = self.hole_center_y
        y2 = max(-y, min(y, self.offset))
        # y2 = self.hole_center_y
        y0 = y + self.hole_margin
        inside_mat = self.mat_hole_inside
        return HolePanel(
            False,  # closed
            [0, 0],  # x index
            [x0],
            [y0, y2],
            [inside_mat, inside_mat],  # material index
            closed_path=True,
            side_cap_front=0,
            side_cap_back=1  # cap index
        )

    @property
    def outside_hole(self):
        #
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        #   x0
        x0 = 0
        y = self.hole_center_y
        y2 = max(-y, min(y, self.offset))
        y1 = -(y + self.hole_margin)
        outside_mat = self.mat_hole_outside
        return HolePanel(
            False,  # closed
            [0, 0],  # x index
            [x0],
            [y2, y1],
            [outside_mat, outside_mat],  # material index
            closed_path=True,
            side_cap_front=0,
            side_cap_back=1  # cap index
        )

    def find_portal(self, o):

        for child in o.children:
            if child.type == 'LIGHT':
                return child
        return None

    def update_portal(self, context, o):

        lamp = self.find_portal(o)
        if self.portal:
            if lamp is None:
                d = bpy.data.lights.new(name="Portal", type='AREA')
                lamp = bpy.data.objects.new("Portal", d)
                self.link_object_to_scene(context, lamp, layer_name="Lights")
                lamp.parent = o

            d = lamp.data
            d.shape = 'RECTANGLE'
            d.size = self.x
            d.size_y = self.z

            # eevee
            d.energy = self.portal_energy
            d.use_contact_shadow = True
            # cycles
            if hasattr(d, "cycles"):
                d.cycles.is_portal = True

            tM = Matrix([
                [1, 0, 0, 0],
                [0, 0, -1, -0.5 * self.y],
                [0, 1, 0, 0.5 * self.z + self.altitude],
                [0, 0, 0, 1]
            ])
            lamp.matrix_world = o.matrix_world @ tM

        else:
            self.delete_object(context, lamp)

    def get_generator(self, o=None):
        return OpeningGenerator(self, o, "HOLE")

    def setup_manipulators(self):
        if len(self.manipulators) == 4:
            return
        s = self.manipulators.add()
        s.prop1_name = "x"
        s.prop2_name = "x"
        s.type_key = "SNAP_SIZE_LOC"
        s = self.manipulators.add()
        s.prop1_name = "y"
        s.prop2_name = "y"
        s.type_key = "SNAP_SIZE_LOC"
        s = self.manipulators.add()
        s.prop1_name = "z"
        s.normal = Vector((0, 1, 0))
        s = self.manipulators.add()
        s.prop1_name = "altitude"
        s.normal = Vector((0, 1, 0))

    def _synch_hole(self, context, linked, hole):
        l_hole = self.find_hole(linked)
        if l_hole is None:
            l_hole = bpy.data.objects.new("hole", hole.data)
            l_hole['archipack_hole'] = True
            # Link object into scene
            self.link_object_to_scene(context, l_hole)
            l_hole.parent = linked
            l_hole.matrix_world = linked.matrix_world.copy()
            l_hole.location = hole.location.copy()
            ArchipackBoolManager.prepare_hole(context, l_hole)
        else:
            l_hole.data = hole.data

    def synch_childs(self, context, o):
        """
            synch childs nodes of linked objects
        """
        # bpy.ops.object.select_all(action='DESELECT')
        # select and make active
        # self.select_object(context, o, True)
        hole = self.find_hole(o)
        linked_objects = self.get_linked_objects(context, o)
        # bpy.ops.object.select_linked(type='OBDATA')
        for linked in linked_objects:
            if linked.name != o.name:
                ld = archipack_hole.datablock(linked)
                ld.update_portal(context, linked)
                if hole is not None:
                    self._synch_hole(context, linked, hole)

    def _get_tri_radius(self, _x, _z):
        return Vector((0, self.y, 0)), Vector((0, 0, 0)), \
               Vector((_x, _z, 0)), Vector((_x, 0, 0))

    def _get_quad_radius(self, _x, _z):
        fx_z = _z / _x
        center_y = min(_z,
                       abs(tan(self.angle_y) * _x))
        if self.angle_y < 0:
            center_x = 0.5 * _x
        else:
            center_x = -0.5 * _x
        return Vector((center_x, center_y, 0)), Vector((0, 0, 0)), \
               Vector((_x, _z, 0)), Vector((_x, 0, 0))

    def _get_round_radius(self, _x, _z):
        """
            bound radius to available space
            return center, origin, size, radius
        """
        x = 0.5 * _x
        # minimum space available
        y = min(_z, x)
        # minimum radius inside
        r = y + x * (x - (y * y / x)) / (2 * y)
        radius = max(self.radius, 0.001 + r)
        return Vector((0, _z - radius, 0)), Vector((0, 0, 0)), \
               Vector((_x, _z, 0)), Vector((radius, 0, 0))

    def _get_circle_radius(self, _x, _z):
        """
            return center, origin, size, radius
        """
        return Vector((0, 0.5 * _x, 0)), Vector((0, 0, 0)), \
               Vector((_x, _z, 0)), Vector((0.5 * _x, 0, 0))

    def _get_ellipsis_radius(self, _x, _z):
        """
            return center, origin, size, radius
        """
        y = self.z
        radius_b = max(0, 0.001 + min(y, self.elipsis_b))
        return Vector((0, _z - radius_b, 0)), Vector((0, 0, 0)), \
               Vector((_x, _z, 0)), Vector((_x / 2, radius_b, 0))

    def get_radius(self, _x, _z):
        """
            return center, origin, size, radius
        """
        if self.shape == 'ROUND':
            return self._get_round_radius(_x, _z)
        elif self.shape == 'ELLIPSIS':
            return self._get_ellipsis_radius(_x, _z)
        elif self.shape == 'CIRCLE':
            return self._get_circle_radius(_x, _z)
        elif self.shape == 'QUADRI':
            return self._get_quad_radius(_x, _z)
        elif self.shape in ['TRIANGLE', 'PENTAGON']:
            return self._get_tri_radius(_x, _z)
        else:
            return Vector((0, 0, 0)), Vector((0, 0, 0)), \
                   Vector((_x, _z, 0)), Vector((0, 0, 0))

    def update(self, context, childs_only=False):
        # support for "copy to selected"
        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        t = time.time()
        # logger.debug("hole.update is_updating:%s" % (self.is_updating))
        self.setup_manipulators()

        dst = self.find_one_by_flag(o, 'custom_filling')
        if self.has_user_object:
            if dst is None:
                dst, me = self.create_mesh("Filling")
                dst.parent = o
                self.link_object_to_scene(context, dst, layer_name="Openings")
                dst.matrix_world = o.matrix_world.copy()
                self.set_flag(dst, "custom_filling", True)

        elif dst is not None:
            self.delete_object(context, dst)

        if self.has_user_defined_custom:
            translate = Vector((0, 0, self.altitude))
            override = None
            self.custom_datablock_update(
                context, self.user_defined_object, dst, translate, override
            )

        elif self.has_user_defined_object:
            self.custom_geometry_update(
                context, self.user_defined_object, dst, translation=Vector((0, 0, 0))
            )

        if childs_only is False:
            center, origin, size, radius = self.get_radius(self.x, self.z + self.z_offset + 0.001)
            is_not_circle = self.shape != 'CIRCLE'
            offset = Vector((0, self.altitude - self.z_offset - 0.001, 0))
            hole = self.hole
            verts = hole.vertices(self.curve_steps, offset, center, origin, size, radius,
                                    self.angle_y, 0, shape_z=None, path_type=self.shape)
            logger.debug("hole.update verts %.4f" % (time.time() - t))
            faces = hole.faces(self.curve_steps, path_type=self.shape)

            logger.debug("hole.update faces %.4f" % (time.time() - t))
            mat = hole.mat(self.curve_steps, 0, 0, path_type=self.shape)
            logger.debug("hole.update mat %.4f" % (time.time() - t))
            uvs = hole.uv(self.curve_steps, center, origin, size, radius,
                            self.angle_y, 0, 0, 0, path_type=self.shape)
            logger.debug("hole.update uvs %.4f" % (time.time() - t))
            col = random_color()
            vcolors = hole.vcolors(self.curve_steps, col, path_type=self.shape)
            logger.debug("hole.update vcolors %.4f" % (time.time() - t))
        
            logger.debug("hole.update frame %.4f" % (time.time() - t))
            bmed.buildmesh(o, verts, faces, mat, uvs, vcolors=vcolors)
            logger.debug("hole.update buildmesh %.4f" % (time.time() - t))
            self.shade_smooth(context, o, 0.20944)

        logger.debug("hole.update 0 %.4f" % (time.time() - t))

        self.update_portal(context, o)
        
        logger.debug("hole.update 1 %.4f" % (time.time() - t))

        # update hole
        if childs_only is False:
            self.interactive_hole(context, o)

        logger.debug("hole.update 2 %.4f" % (time.time() - t))

        if len(self.bend) > 0:
            sel = [c for c in o.children if c.type == "MESH"]
            sel.append(o)
            self.bend_mesh(o, sel)

        # store 3d points for gl manipulators
        x, y = 0.5 * self.x, 0.5 * self.y
        self.manipulators[0].set_pts([(-x, -y, 0), (x, -y, 0), (0.5, 0, 0)])
        self.manipulators[1].set_pts([(-x, -y, 0), (-x, y, 0), (-1, 0, 0)])
        self.manipulators[2].set_pts([(x, -y, self.altitude), (x, -y, self.altitude + self.z), (-1, 0, 0)])
        self.manipulators[3].set_pts([(x, -y, 0), (x, -y, self.altitude), (-1, 0, 0)])

        # soft_segment_2d for dimension points
        p0, p1 = Vector((-x, -y, 0)), Vector((x, -y, 0))
        p2, p3 = Vector((-0.5 * self.x, y, 0)), Vector((0.5 * self.x, y, 0))

        coords = [p0, p1, p2, p3]
        if len(self.bend) > 0:
            self.bend_coords(coords, add_section=False)

        self.add_dimension_point(0, coords[0])
        self.add_dimension_point(1, coords[1])
        self.add_dimension_point(2, coords[2])
        self.add_dimension_point(3, coords[3])

        # support for instances childs, update at object level
        self.synch_childs(context, o)
        logger.debug("hole.update 3 %.4f" % (time.time() - t))

        # synch dimensions when apply
        if o.parent:
            self.update_dimensions(context, o)

        logger.debug("hole.update end %.4f" % (time.time() - t))
        # restore context
        self.restore_context(context)
        logger.debug("hole.restore_context %.4f" % (time.time() - t))

    def find_hole(self, o):
        return self.find_one_by_flag(o, 'hole')

    @property
    def user_defined_objects(self):
        return [
            self.user_defined_object
        ]
    
    def interactive_hole(self, context, o):
        hole_obj = self.find_hole(o)

        if hole_obj is None:
            hole_obj, m = self.create_mesh("hole")
            # Link object into scene
            self.set_flag(hole_obj, 'hole', True)
            self.set_flag(hole_obj, 'skip_material', True)
            self.link_object_to_scene(context, hole_obj)
            hole_obj.parent = o
            hole_obj.matrix_world = o.matrix_world.copy()
            self.hide_for_render_engines(hole_obj)
            Callbacks.call("create", context, hole_obj, None)

        hole = self.hole
        center, origin, size, radius = self.get_radius(self.x, self.z + self.z_offset + 0.001)
        x0 = 0

        x0 = -0.001

        shape_z = [-0.001, x0]

        verts = hole.vertices(self.curve_steps,
                              Vector((0, self.altitude - self.z_offset, 0)),
                              center, origin, size, radius,
                              self.angle_y, 0, shape_z=shape_z, path_type=self.shape)

        faces = hole.faces(self.curve_steps, path_type=self.shape)

        matids = hole.mat(self.curve_steps, 2, 2, path_type=self.shape)

        uvs = hole.uv(self.curve_steps, center, origin, size, radius,
                      self.angle_y, 0, 0, 0, path_type=self.shape)
        col = random_color()
        vcolors = hole.vcolors(self.curve_steps, col, path_type=self.shape)
        bmed.buildmesh(hole_obj, verts, faces, matids, uvs, vcolors=vcolors)
        Callbacks.call("update", context, hole_obj, None)
        return hole_obj

    def _add_spline(self, curve, coords):
        spline = curve.splines.new('POLY')
        spline.use_endpoint_u = False
        spline.use_cyclic_u = coords[-1] == coords[0]
        if coords[-1] == coords[0]:
            coords.pop()
        spline.points.add(len(coords) - 1)
        for i, coord in enumerate(coords):
            x, y, z = coord
            spline.points[i].co = (x, y, z, 1)

    def _to_curve(self, context, coords, name: str, dimensions: str = '3D'):
        curve = bpy.data.curves.new(name, type='CURVE')
        curve.dimensions = dimensions
        for co in coords:
            self._add_spline(curve, co)
        curve_obj = bpy.data.objects.new(name, curve)
        # Link object into scene
        self.link_object_to_scene(context, curve_obj)
        # select and make active
        self.select_object(context, curve_obj, True)
        return curve_obj

    def as_2d(self, context, o):

        # frame
        center, origin, size, radius = self.get_radius(self.x, self.z)
        offset = Vector((0, 0, 0))

        # draw borders
        connect = 2
        
        coords = self.hole.as_2d(self.curve_steps, offset, center, origin,
                                   size, radius, 0, 0, connect=connect)

        if len(self.bend) > 0:
            coords = [[Vector(co) for co in coord] for coord in coords]
            self.bend_coords(coords, add_section=True)

        curve = self._to_curve(context, coords, name="{}-2d".format(o.name), dimensions='2D')
        curve.matrix_world = o.matrix_world.copy()
        return curve

    def hole_2d(self, mode='PLAN_2D'):
        """
          return coords of full / inside hole in 2d top ortho view
        """
        if mode == 'BOUND':
            x, y = 0.5 * self.x, 0.5 * self.y + 0.01
            coords = [(-x, -y, 0), (-x, y, 0), (x, y, 0), (x, -y, 0), (-x, -y, 0)]

        else:
            v = Vector((0, 0, 0))

            # center, origin, size, radius = self.get_radius(self.x, self.z)
            size = Vector((self.x, self.z + 0.001, self.y))
            if mode == 'INSIDE':
                # in side hole for floors
                coords = self.inside_hole.as_2d(16,
                                v,
                                v, v, size, v,
                                0, 0, shape_z=None, path_type='RECTANGLE')
            elif mode == 'OUTSIDE':
                # out side hole for floors
                coords = self.outside_hole.as_2d(16,
                                v,
                                v, v, size, v,
                                0, 0, shape_z=None, path_type='RECTANGLE')
            elif mode == 'FILL':
                # lines on each side for moldings
                coords = self.fill_symbol.as_2d(16,
                                v,
                                v, v, size, v,
                                0, 0, shape_z=None, path_type='RECTANGLE')
            else:
                # whole hole for symbols / moldings
                coords = self.hole_symbol.as_2d(16,
                                v,
                                v, v, size, v,
                                0, 0, shape_z=None, path_type='RECTANGLE')
            coords = [Vector(co) for co in coords[0]]


        if len(self.bend) > 0:
            self.bend_coords(coords, add_section=(mode != 'FILL'))

        # Use only first curve
        return coords

    def remove_hole(self, context, hole, walls):
        ctx = context.copy()
        ctx['object'] = hole
        ctx['selected_objects'] = walls
        self.call_operator(context, ctx, bpy.ops.archipack.remove_hole)

    def on_delete(self, context, obj):
        # print("hole.on_delete")
        walls = set()
        wall2 = {}
        sel = context.selected_objects[:]
        # collect walls
        ref = self.get_reference_point(obj)
        if ref is not None:
            walls = [c for c in ref.children
                     if (c.data and (
                        "archipack_wall2" in c.data
                        or "archipack_wall" in c.data
                        )
                        or self.has_flag(c, "custom_wall")
                )]
            wall2 = {
                c: c.data.archipack_wall2[0]
                for c in ref.children
                if c.data and "archipack_wall2" in c.data
            }

        for o in sel:
            if archipack_hole.filter(o):
                hole = self.find_hole(o)
                if hole is not None:
                    self.remove_hole(context, hole, walls)

                if o.name != obj.name:
                    self.delete_object(context, o)

        for c, d in wall2.items():
            # update providers
            d.setup_childs(context, c, openings_only=True)
            for i, child in enumerate(d.childs):
                if child.child_name == obj.name:
                    d.childs.remove(i)
                    break
            d.synch_dimension(context, c, remove_object=obj.name)
        ArchipackObject.on_delete(self, context, obj)
        # print("hole.on_delete success")


class ARCHIPACK_PT_hole(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_hole"
    bl_label = "Hole"

    @classmethod
    def poll(cls, context):
        return archipack_hole.filter(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_hole.datablock(o)
        if d is None:
            return
        layout = self.layout

        self.draw_common(context, layout)

        row = layout.row(align=True)
        self.draw_op(context, layout, row, 'archipack.hole', icon='FILE_REFRESH', text="Refresh").mode = 'REFRESH'
        if o.data.users > 1:
            self.draw_op(context, layout, row, 'archipack.hole', icon='UNLINKED',
                         text="Make unique", postfix="({})".format(o.data.users)).mode = 'UNIQUE'
        # self.draw_op(context, layout, row, 'archipack.hole', text="Delete", icon='ERROR').mode = 'DELETE'
        self.draw_op(context, layout, layout, "archipack.hole_array", icon='MOD_ARRAY', text="Array")

        box = layout.box()
        # self.draw_label(context, layout, box, "Styles")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.hole_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_hole_preset_menu.bl_label, icon="PRESET"
            ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.hole_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.hole_preset", icon='REMOVE', text="").remove_active = True

        self.draw_prop(context, layout, layout, d, 'tabs', expand=True)

        box = layout.box()

        if d.tabs == 'MAIN':
            # self.draw_prop(context, layout, box, d, 'hole_type')
            self.draw_prop(context, layout, box, d, 'x')
            self.draw_prop(context, layout, box, d, 'y')
            if d.hole_shape != 'CIRCLE':
                self.draw_prop(context, layout, box, d, 'z')

            self.draw_prop(context, layout, box, d, 'altitude')
            self.draw_prop(context, layout, box, d, 'offset')
            self.draw_prop(context, layout, box, d, 'z_offset')
            self.draw_prop(context, layout, box, d, 'hole_margin')

            self.draw_prop(context, layout, box, d, 'user_defined_object', text="Fill")

            box = layout.box()
            self.draw_prop(context, layout, box, d, 'hole_shape')
            if d.hole_shape in ['ROUND', 'CIRCLE', 'ELLIPSIS']:
                self.draw_prop(context, layout, box, d, 'curve_steps')
            if d.hole_shape in ['ROUND']:
                self.draw_prop(context, layout, box, d, 'radius')
            elif d.hole_shape == 'ELLIPSIS':
                self.draw_prop(context, layout, box, d, 'elipsis_b')
            elif d.hole_shape == 'QUADRI':
                self.draw_prop(context, layout, box, d, 'angle_y')

            self.draw_prop(context, layout, box, d, 'cut_moldings')

        elif d.tabs == 'SUB':
            self.draw_prop(context, layout, box, d, 'portal', icon="LIGHT_AREA", emboss=True)
            self.draw_prop(context, layout, box, d, 'portal_energy')

        elif d.tabs == 'MATERIALS':

            if "archipack_material" in o:
                o.archipack_material[0].draw(context, box)

            icon = "TRIA_RIGHT"
            if not d.auto_mat:
                icon = "TRIA_DOWN"
            self.draw_prop(context, layout, box, d, 'auto_mat', icon=icon, emboss=True, text="Hole material auto")
            if not d.auto_mat:
                self.draw_prop(context, layout, box, d, 'mat_hole_inside')
                self.draw_prop(context, layout, box, d, 'mat_hole_outside')
                self.draw_prop(context, layout, box, d, 'mat_finish_inside')
                self.draw_prop(context, layout, box, d, 'mat_finish_outside')


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_hole(ArchipackCreateTool, Operator):
    bl_idname = "archipack.hole"
    bl_label = "Hole"
    bl_description = "Hole"

    x: FloatProperty(
        name='width',
        min=0.1, max=10000,
        default=2.0, precision=5,
        description='Width'
    )
    y: FloatProperty(
        name='depth',
        min=0.1, max=10000,
        default=0.20, precision=5,
        description='Depth'
    )
    z: FloatProperty(
        name='height',
        min=0.1, max=10000,
        default=1.2, precision=5,
        description='height'
    )
    altitude: FloatProperty(
        name='altitude',
        min=0.0, max=10000,
        default=1.0, precision=5,
        description='altitude'
    )
    mode: EnumProperty(
        items=(
            ('CREATE', 'Create', '', 0),
            ('REFRESH', 'Refresh', '', 2),
            ('UNIQUE', 'Make unique', '', 3),
        ),
        default='CREATE'
    )

    # auto_manipulate : BoolProperty(default=True)

    def create(self, context):
        o, m = self.create_mesh("Hole")
        d = m.archipack_hole.add()
        d.x = self.x
        d.y = self.y
        d.z = self.z
        d.altitude = self.altitude
        # Link object into scene
        self.link_object_to_scene(context, o, layer_name="openings")
        o.color = (0, 1, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        self.add_material(context, o, material="DEFAULT", category="hole")
        self.load_preset(context, o, d)

        # select frame
        # self.select_object(context, o, True)

        if not bpy.app.background:
            # hide hole from cycles
            self.hide_for_render_engines(o)

        return o

    def update(self, context):
        o = context.active_object
        d = archipack_hole.datablock(o)
        if d is not None:
            d.update(context)
            linked_objects = self.get_linked_objects(context, o)
            # bpy.ops.object.select_linked(type='OBDATA')
            for linked in linked_objects:
                if linked != o:
                    archipack_hole.datablock(linked).update(context)

        # bpy.ops.object.select_all(action="DESELECT")
        # select and make active
        # self.select_object(context, o, True)

    def unique(self, context):
        obj = context.active_object
        sel = context.selected_objects[:]
        uniques = []
        for o in sel:
            if archipack_hole.filter(o):
                # select and make active
                uniques.append(o)
                Callbacks.call("unique", context, o, None)
                for child in o.children:
                    d = child.data
                    if 'archipack_hole' in child or (
                            d is not None and (
                            'archipack_dimension' in d
                    )):
                        uniques.append(child)
                        # select text and handles too
                        for c in child.children:
                            uniques.append(c)

        if bool(uniques):
            bpy.ops.archipack.disable_manipulate()
            with ensure_select_and_restore(context, uniques[0], uniques):
                bpy.ops.object.make_single_user(
                    type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False
                )
            self.select_object(context, obj, True)

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            if self.mode == 'CREATE':
                bpy.ops.object.select_all(action="DESELECT")
                o = self.create(context)
                o.location = self.get_cursor_location(context)
                # select and make active
                self.select_object(context, o, True)

            elif self.mode == 'REFRESH':
                self.update(context)
            elif self.mode == 'UNIQUE':
                self.unique(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_hole_array(ArchipackArrayTool, Operator):
    bl_idname = "archipack.hole_array"
    bl_label = "Hole Array"
    bl_description = "Duplicate selected holes"
    bl_options = {'UNDO'}
    # XXX crash on redo when using spinner values ..
    # bl_options = {'REGISTER', 'UNDO'}

    def filter_object(self, o):
        return archipack_hole.filter(o)

    def get_object_datablock(self, o):
        return archipack_hole.datablock(o)


class ARCHIPACK_OT_hole_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.hole_draw"
    bl_label = "Draw Holes"
    bl_description = "Draw Holes over walls"

    filepath: StringProperty(default="")
    feedback = None
    stack = []
    object_name = ""
    auto_manipulating = False

    @classmethod
    def poll(cls, context):
        return True

    def draw_callback(self, _self, context):
        # print("feedback.draw()")
        self.feedback.draw(context)

    def add_object(self, context, event):
        bpy.ops.object.select_all(action="DESELECT")
        # print("add_object bpy.ops.archipack.hole")
        bpy.ops.archipack.hole(filepath=self.filepath)
        o = context.active_object

        if o is None:
            o = context.object

        self.object_name = o.name
        # print("add_object bpy.ops.archipack.generate_hole")
        # bpy.ops.archipack.generate_hole()
        return o

    def remove_object(self, context, o):
        if archipack_hole.filter(o):
            with context_override(context, None, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.archipack.delete)

    def exit(self, context, o):
        self.remove_object(context, o)
        self.feedback.disable()
        try:
            context.space_data.show_gizmo = True
        except:
            pass
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        self.restore_walls(context)
        # print("hole_draw.exit() success")

    def modal(self, context, event):

        o = self.get_scene_object(context, self.object_name)

        if o is None or context.area is None:
            self.exit(context, o)
            return {'FINISHED'}

        context.area.tag_redraw()

        d = archipack_hole.datablock(o)
        hole = None
        if d is not None:
            hole = d.find_hole(o)

        # hide hole from raycast
        to_hide = [o]
        to_hide.extend(list(o.children))
        if hole is not None:
            to_hide.append(hole)

        for obj in to_hide:
            self.hide_object(obj)

        res, tM, wall, width, y, z_offset = self.mouse_hover_wall(context, event)

        for obj in to_hide:
            self.show_object(obj)

        if res and d is not None:
            o.matrix_world = tM.copy()
            if abs(d.z_offset - z_offset) > 0.001:
                self.select_object(context, o, True)
                d.z_offset = z_offset
            if abs(d.y - width) > 0.001:
                self.select_object(context, o, True)
                d.y = width

        if event.value == 'PRESS':

            if event.type in {'C', 'D'}:
                self.exit(context, o)
                bpy.ops.archipack.hole_preset_menu('INVOKE_DEFAULT', preset_operator="archipack.hole_draw")
                return {'FINISHED'}

            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
                if wall is not None:

                    # self.select_object(context, wall, True)
                    ctx = context.copy()
                    ctx['object'] = wall
                    ctx['selected_objects'] = [o]
                    self.call_operator(context, ctx, bpy.ops.archipack.single_boolean)

                    # o must be a hole here
                    if d is not None:
                        # do it first as bend depends on this
                        if "archipack_wall2" in wall.data:
                            # ensure holes always look outside
                            with ensure_select_and_restore(context, wall, [wall]):
                                wd = wall.data.archipack_wall2[0]
                                wg = wd.get_generator()
                                wd.setup_childs(context, wall, g=wg, openings_only=True)
                                wd.relocate_childs(context, wall, g=wg)
                                wd.update_dimension(context, wall, wg)
                        # Link if y does match
                        # with last stacked one
                        # unless shift pressed
                        if len(self.stack) > 0 and not event.shift:
                            last = self.stack[-1]
                            d_last = last.data.archipack_hole[0]
                            if d_last.y == d.y and len(d_last.bend) == 0 and len(d.bend) == 0:
                                # Must disable manipulators before link !!
                                bpy.ops.archipack.disable_manipulate()
                                self.link_object(last, o)

                        self.stack.append(o)
                        o = self.add_object(context, event)

                        o.matrix_world = tM

                    return {'RUNNING_MODAL'}

            # prevent selection of other object
            if event.type in {'RIGHTMOUSE'}:
                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
        ):
            if len(self.stack) > 0:
                last = self.stack.pop()
                self.remove_object(context, last)
            return {'RUNNING_MODAL'}

        if event.value == 'RELEASE':

            if event.type in {'ESC', 'RIGHTMOUSE'}:
                self.exit(context, o)
                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):

        if context.mode == "OBJECT":

            o = context.active_object

            self.stack = []
            self.keymap = Keymaps(context)

            # exit manipulate_mode if any
            bpy.ops.archipack.disable_manipulate()
            # Hide manipulators
            context.space_data.show_gizmo = False
            # invoke with alt pressed will use current object as basis for linked copy
            if self.filepath == '' and archipack_hole.filter(o):
                self.stack.append(o)
                o = self.duplicate_object(context, o, False)
                self.object_name = o.name
            else:
                o = self.add_object(context, event)

            # select and make active
            # bpy.ops.object.select_all(action="DESELECT")
            # self.select_object(context, o, True)

            self.feedback = FeedbackPanel()
            self.feedback.instructions(context, "Draw a hole", "Click & Drag over a wall", [
                ('LEFTCLICK, RET, SPACE, ENTER', 'Create a hole'),
                ('BACKSPACE, CTRL+Z', 'undo last'),
                ('D', 'Draw another hole'),
                ('SHIFT', 'Make independant copy'),
                ('RIGHTCLICK or ESC', 'exit')
            ])
            self.feedback.enable()
            args = (self, context)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_hole_portals(Operator):
    bl_idname = "archipack.hole_portals"
    bl_label = "Portals"
    bl_description = "Create portal for each hole"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        for o in context.scene.objects:
            d = archipack_hole.datablock(o)
            if d is not None:
                d.update_portal(context)

        return {'FINISHED'}


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------

class ARCHIPACK_OT_hole_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and draw holes over wall"
    bl_idname = "archipack.hole_preset_draw"
    bl_label = "Hole preset"
    preset_subdir = "archipack_hole"


class ARCHIPACK_OT_hole_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Show Hole Presets"
    bl_idname = "archipack.hole_preset_menu"
    bl_label = "Hole preset"
    preset_subdir = "archipack_hole"


class ARCHIPACK_OT_hole_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Hole Preset"
    bl_idname = "archipack.hole_preset"
    bl_label = "Hole preset"
    preset_menu = "ARCHIPACK_OT_hole_preset_menu"

    @property
    def blacklist(self):
        return ['y']


def register():
    bpy.utils.register_class(archipack_hole)
    Mesh.archipack_hole = CollectionProperty(type=archipack_hole)
    bpy.utils.register_class(ARCHIPACK_OT_hole_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_hole_preset_draw)
    bpy.utils.register_class(ARCHIPACK_PT_hole)
    bpy.utils.register_class(ARCHIPACK_OT_hole)
    bpy.utils.register_class(ARCHIPACK_OT_hole_preset)
    bpy.utils.register_class(ARCHIPACK_OT_hole_draw)
    bpy.utils.register_class(ARCHIPACK_OT_hole_portals)
    bpy.utils.register_class(ARCHIPACK_OT_hole_array)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_OT_hole_array)
    bpy.utils.unregister_class(archipack_hole)
    del Mesh.archipack_hole
    bpy.utils.unregister_class(ARCHIPACK_OT_hole_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_hole_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_PT_hole)
    bpy.utils.unregister_class(ARCHIPACK_OT_hole)
    bpy.utils.unregister_class(ARCHIPACK_OT_hole_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_hole_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_hole_portals)
