# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
# Presets sharing IO
# ----------------------------------------------------------
import os
import bpy
import zipfile
# noinspection PyUnresolvedReferences
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper
from .archipack_iconmanager import icon_man
from .archipack_preset import get_prefs
from shutil import copy2, rmtree


class ARCHIPACK_IO_Import_Preset(Operator, ImportHelper):
    bl_description = "Import archipack presets files in the apk format (.apk)"
    bl_idname = "archipack.import_presets"
    bl_label = "Archipack presets APK (.apk)"
    bl_options = {"UNDO"}

    override: BoolProperty(name="Override", default=False, description="Override presets with same name")

    # ImportHelper mixin class uses this
    filename_ext = ".apk"

    filter_glob: StringProperty(
        default="*.apk",
        options={"HIDDEN"},
    )

    def copytree(self, src, dst, errors, symlinks=False):
        names = os.listdir(src)
        os.makedirs(dst, exist_ok=True)
        for name in names:
            srcname = os.path.join(src, name)
            dstname = os.path.join(dst, name)
            try:
                if symlinks and os.path.islink(srcname):
                    linkto = os.readlink(srcname)
                    os.symlink(linkto, dstname)
                elif os.path.isdir(srcname):
                    self.copytree(srcname, dstname, errors, symlinks)
                else:
                    if os.path.exists(dstname):
                        path, name = os.path.split(dstname)
                        filename, ext = os.path.splitext(name)
                        if ext == '.json':
                            print("Skip :", filename)
                            self.report({'INFO'}, "Skip {}".format(filename))
                    else:
                        copy2(srcname, dstname)
            except OSError as why:
                errors.append((srcname, dstname, str(why)))

    def execute(self, context):

        outdir = icon_man.create_preset_folder("", create=True)

        if self.override:
            extract_path = outdir
        else:
            extract_path = os.path.join(bpy.app.tempdir, "apk")
            os.makedirs(extract_path, exist_ok=True)

        with zipfile.ZipFile(self.filepath, "r") as z:
            z.extractall(extract_path)

        if not self.override:
            errors = []
            self.copytree(extract_path, outdir, errors, symlinks=True)
            if errors:
                self.report({'ERROR'}, "Error while extracting presets (see console for details)")
                for _src, _dst, why in errors:
                    print(_src, _dst, why)
            rmtree(extract_path, ignore_errors=True)

        return {"FINISHED"}


class ARCHIPACK_IO_Export_Preset(Operator, ExportHelper):
    bl_description = "Export archipack presets files in the apk format (.apk)"
    bl_idname = "archipack.export_presets"
    bl_label = "Archipack presets APK (.apk)"
    bl_options = {"UNDO"}

    # ExportHelper mixin class uses this
    filename_ext = ".apk"

    filter_glob: StringProperty(
        default="*.apk",
        options={"HIDDEN"},
    )

    def make_zipfile(self, output_filename, source_dir):
        relroot = os.path.abspath(source_dir)
        with zipfile.ZipFile(output_filename, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zip:
            for root, dirs, files in os.walk(source_dir):
                if "archipack" in root:
                    zip.write(root, os.path.relpath(root, relroot))
                    for file in files:
                        filename = os.path.join(root, file)
                        if os.path.isfile(filename):
                            arcname = os.path.join(os.path.relpath(root, relroot), file)
                            zip.write(filename, arcname)

    def execute(self, context):
        srcdir = icon_man.create_preset_folder("", create=False)
        self.make_zipfile(self.filepath, srcdir)

        return {"FINISHED"}


def menu_func_export(self, context):
    self.layout.operator(ARCHIPACK_IO_Export_Preset.bl_idname)


def menu_func_import(self, context):
    self.layout.operator(ARCHIPACK_IO_Import_Preset.bl_idname)


def register():
    bpy.utils.register_class(ARCHIPACK_IO_Import_Preset)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.utils.register_class(ARCHIPACK_IO_Export_Preset)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.utils.unregister_class(ARCHIPACK_IO_Import_Preset)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.utils.unregister_class(ARCHIPACK_IO_Export_Preset)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
