# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import time
import logging

logger = logging.getLogger(__package__)
import bpy
import bmesh
from .archipack_prefs import get_prefs
from mathutils import Matrix, Vector


class BmeshEdit:

    @staticmethod
    def new_empty_bmesh():
        return bmesh.new(use_operators=True)

    @staticmethod
    def ensure_bmesh(bm):
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

    @staticmethod
    def index_update(bm):
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()

    @staticmethod
    def _start_with_modifiers(context, o):
        depsgraph = context.evaluated_depsgraph_get()
        m = o.evaluated_get(depsgraph).to_mesh()
        bm = bmesh.new(use_operators=True)
        bm.from_mesh(m)
        return bm

    @staticmethod
    def _start(o, context=None):
        """
            private, start bmesh editing of active object
        """
        # objman.select_object(context, o, True)
        bm = bmesh.new(use_operators=True)
        if context is not None and o.modifiers:
            depsgraph = context.evaluated_depsgraph_get()
            me = o.evaluated_get(depsgraph).to_mesh()
        else:
            me = o.data
        bm.from_mesh(me)
        return bm

    @staticmethod
    def select(bm, verts, faces, edges):
        for v in bm.verts:
            v.select = verts
        for ed in bm.edges:
            ed.select = edges
        for f in bm.faces:
            f.select = faces

    @staticmethod
    def ensure_vcolors(bm, name="Archipack", color=(0,0,0,1)):
        layer = bm.loops.layers.color.get(name)
        if layer is None:
            layer = bm.loops.layers.color.new(name)
            for f in bm.faces:
                for loop in f.loops:
                    loop[layer] =color
        return layer

    @staticmethod
    def ensure_uvs(bm, name="UVMap"):
        layer = bm.loops.layers.uv.get(name)
        if layer is None:
            layer = bm.loops.layers.uv.new(name)
        return layer

    @classmethod
    def bmesh_join(cls, o, list_of_bmeshes, temporary=False, normal_update=False, base_bmesh=None):
        """
            takes as input a list of bm references and outputs a single merged bmesh
            allows an additional 'normal_update=True' to force _normal_ calculations.
        """
        if base_bmesh is not None:
            bm = base_bmesh
        elif temporary:
            bm = bmesh.new(use_operators=True)
        else:
            bm = cls._start(o)
        
        add_vert = bm.verts.new
        add_face = bm.faces.new
        add_edge = bm.edges.new

        for bm_to_add in list_of_bmeshes:
            offset = len(bm.verts)

            bevel_layers = []

            if bpy.app.version[0] < 4:
                # not supported in 4.x
                bevel = bm_to_add.verts.layers.bevel_weight.items()
                for name, src in bevel:
                    dst = bm.verts.layers.bevel_weight.get(name)
                    if dst is None:
                        dst = bm.verts.layers.bevel_weight.new(name)
                    bevel_layers.append((src, dst))

            for vert in bm_to_add.verts:

                v = add_vert(vert.co)
                v.select = vert.select
                for src, dst in bevel_layers:
                    v[dst] = vert[src]

            bm.verts.index_update()
            BmeshEdit.ensure_bmesh(bm)
            
            if bm_to_add.faces:

                # vertex colors
                cols = bm_to_add.loops.layers.color.items()
                cols_layers = []
                for name, src in cols:
                    dst = bm.loops.layers.color.get(name)
                    if dst is None:
                        dst = bm.loops.layers.color.new(name)
                    cols_layers.append((src, dst))

                # uvs
                uvs = bm_to_add.loops.layers.uv.items()
                uvs_layers = []
                for name, src in uvs:
                    dst = bm.loops.layers.uv.get(name)
                    if dst is None:
                        dst = bm.loops.layers.uv.new(name)
                    uvs_layers.append((src, dst))

                for face in bm_to_add.faces:
                    f = add_face(tuple(bm.verts[i.index + offset] for i in face.verts))
                    f.select = face.select
                    f.material_index = face.material_index
                    for j, loop in enumerate(face.loops):
                        for src, dst in uvs_layers:
                            f.loops[j][dst].uv = loop[src].uv
                        # vertex colors
                        for src, dst in cols_layers:
                            f.loops[j][dst] = loop[src]

                bm.faces.index_update()

            if bm_to_add.edges:

                # bevel
                bevel_layers = []
                crease_layers = []

                if bpy.app.version[0] < 4:

                    bevel = bm_to_add.edges.layers.bevel_weight.items()
                    for name, src in bevel:
                        dst = bm.edges.layers.bevel_weight.get(name)
                        if dst is None:
                            dst = bm.edges.layers.bevel_weight.new(name)
                        bevel_layers.append((src, dst))

                    # crease
                    crease = bm_to_add.edges.layers.crease.items()
                    for name, src in crease:
                        dst = bm.edges.layers.crease.get(name)
                        if dst is None:
                            dst = bm.edges.layers.crease.new(name)
                        crease_layers.append((src, dst))

                for edge in bm_to_add.edges:
                    edge_seq = tuple(bm.verts[i.index + offset] for i in edge.verts)
                    try:
                        ed = add_edge(edge_seq)
                        ed.select = edge.select
                        for src, dst in bevel_layers:
                            ed[dst] = edge[src]
                        for src, dst in crease_layers:
                            ed[dst] = edge[src]
                    except ValueError:
                        # edge exists!
                        pass
                bm.edges.index_update()

        # cleanup
        for old_bm in list_of_bmeshes:
            old_bm.free()

        cls.ensure_bmesh(bm)

        if temporary:
            return bm
        else:
            cls._end(bm, o)

        return None

    @classmethod
    def _end(cls, bm, o):
        """
            private, end bmesh editing of active object
        """
        cls.ensure_bmesh(bm)
        bm.normal_update()
        bm.to_mesh(o.data)
        bm.free()

    @staticmethod
    def _matids(bm, matids):
        for f, matid in zip(bm.faces, matids):
            f.material_index = matid

    @staticmethod
    def normal_update(bm):
        for f in bm.faces:
            f.normal_update()

    @staticmethod
    def _uvs(bm, uvs, layer_name):
        layer = bm.loops.layers.uv.verify()
        # layer = bm.loops.layers.uv.get(layer_name)
        # if layer is None:
        #    layer = bm.loops.layers.uv.new(layer_name)

        if len(bm.faces) != len(uvs):
            raise RuntimeError("Faces uvs count mismatch")

        for uv, face in zip(uvs, bm.faces):
            if len(face.loops) != len(uv):
                raise RuntimeError("Uv for face count mismatch")

            for co, loop in zip(uv, face.loops):
                loop[layer].uv = co

    @staticmethod
    def _vertex_color(bm, colors, layer_name):
        vlay = bm.loops.layers.color.get(layer_name)
        if vlay is None:
            vlay = bm.loops.layers.color.new(layer_name)

        for color, face in zip(colors, bm.faces):
            for loop in face.loops:
                loop[vlay] = color

    @staticmethod
    def _verts(bm, verts):
        for i, v in enumerate(verts):
            bm.verts[i].co = v
    
    @classmethod
    def emptymesh(cls, o):
        bm = cls._start(o)
        bm.clear()
        cls.ensure_bmesh(bm)
        cls._end(bm, o)
        
    @classmethod
    def buildmesh(cls, o, verts, faces,
            matids=None, uvs=None, vcolors=None, edges=None, uvs_layer="Archipack", color_layer="Archipack", weld=False,
            clean=False, temporary=False, ensure_uvs=False):
        
        tim = time.time()
        # logger.debug("BmeshEdit.buildmesh() %s start", o.name)

        prefs = get_prefs(bpy.context)

        if temporary:
            bm = bmesh.new(use_operators=True)
        else:
            bm = cls._start(o)
            bm.clear()

        # logger.debug("BmeshEdit.buildmesh() %s :%.2f seconds", o.name, time.time() - tim)

        # BmeshEdit.ensure_bmesh(bm)
        _verts = bm.verts
        _faces = bm.faces
        _edges = bm.edges

        _new_vert = _verts.new
        _new_face = _faces.new
        _new_edge = _edges.new

        for v in verts:
            _new_vert(v)
        
        _verts.ensure_lookup_table()
        _verts.index_update()

        # logger.debug("BmeshEdit.buildmesh() verts :%.2f seconds", time.time() - tim)
        if edges is not None:
            for ed in edges:
                v0, v1 = ed
                _new_edge((_verts[v0], _verts[v1]))

        for f in faces:
            _new_face([_verts[i] for i in f])
        
        # bm.edges.ensure_lookup_table()
        _faces.ensure_lookup_table()
        _faces.index_update()
        # logger.debug("BmeshEdit.buildmesh() faces :%.2f seconds", time.time() - tim)

        if matids is not None:
            cls._matids(bm, matids)
            # logger.debug("BmeshEdit.buildmesh() _matids :%.2f seconds", time.time() - tim)

        if ensure_uvs:
            cls.ensure_uvs(bm)

        if uvs is not None:
            cls._uvs(bm, uvs, uvs_layer)

        if prefs.enable_vertex_colors and vcolors is not None:
            cls._vertex_color(bm, vcolors, color_layer)

        if weld:
            # logger.debug("BmeshEdit.buildmesh() weld :%.2f seconds", time.time() - tim)
            bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.001)

        if clean:
            # logger.debug("BmeshEdit.buildmesh() clean :%.2f seconds", time.time() - tim)
            bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=0.001)

        if temporary:
            cls.ensure_bmesh(bm)
            bm.normal_update()
            # return a temporary bmesh
            return bm

        cls._end(bm, o)
        # logger.debug("BmeshEdit.buildmesh() _end :%.2f seconds", time.time() - tim)
        # logger.debug("BmeshEdit.buildmesh() mesh ops :%.2f seconds", time.time() - tim)

    @classmethod
    def surface_from_vertex(cls, o, verts, matids=None, temporary=False):
        #
        # bm = bmesh.new()
        # for v in verts:
        #     bm.verts.new(v)
        # bm.verts.ensure_lookup_table()
        # for i in range(1, len(verts)):
        #     bm.edges.new((bm.verts[i - 1], bm.verts[i]))
        # bm.edges.new((bm.verts[-1], bm.verts[0]))
        # bm.edges.ensure_lookup_table()
        # bmesh.ops.contextual_create(bm, geom=bm.edges)

        # for f in bm.faces:
        #     f.material_index = mat_index
        # bm.to_mesh(c.data)
        # bm.free()

        return cls.buildmesh(o, verts, [tuple(range(len(verts)))], matids=matids, temporary=temporary)

    @classmethod
    def contour_from_vertex(cls, o, verts, temporary=False):
        return cls.buildmesh(o, verts, [], edges=[(i - 1, i) for i in range(len(verts))], temporary=temporary)

    @staticmethod
    def _vertex_groups_from_obj(o, offset=0):
        # create vertex group lookup dictionary for names
        if o.type == "MESH":
            me = o.data
            vg = o.vertex_groups
            vgroup_names = {vgroup.index: vgroup.name for vgroup in vg}
            # create dictionary of vertex group assignments per vertex
            vertex_groups = {name: {} for name in vgroup_names.values()}
            for v in me.vertices:
                for g in v.groups:
                    vertex_groups[vgroup_names[g.group]][offset + v.index] = vg[g.group].weight(v.index)
            return vertex_groups
        return {}

    @classmethod
    def vertex_groups_from_obj(cls, o, offset=0, hierarchy=False, filter_hierarchy=None):
        """Create a dictionnary of vertex groups weights for vertices"""
        vertex_groups = cls._vertex_groups_from_obj(o, offset)
        if hierarchy:
            # Recursive call so we get whole hieerarchy
            for c in o.children:
                if c.type == "MESH" and (filter_hierarchy is None or filter_hierarchy(c)):
                    offset = len(c.data.verts)
                    _vertex_groups = cls.vertex_groups_from_obj(c, offset, hierarchy, filter_hierarchy)
                    vertex_groups.update(_vertex_groups)
        return vertex_groups

    @staticmethod
    def set_vertex_groups(o, vertex_groups):
        # set vertex groups
        for group_name, vert_idx_weight in vertex_groups.items():
            vg = o.vertex_groups.get(group_name)
            if vg is None:
                vg = o.vertex_groups.new()
                vg.name = group_name
            else:
                vg.remove([v.index for v in o.data.vertices])

            for i, w in vert_idx_weight.items():
                vg.add([i], w, 'REPLACE')

    @staticmethod
    def _mesh_data_from_obj(o, offset, idmat, transform, flip_normals):
        m = o.data

        if transform is None:
            verts = [v.co for v in m.vertices]
        else:
            verts = [transform @ v.co for v in m.vertices]

        if flip_normals:
            faces = [tuple([offset + i for i in reversed(p.vertices)]) for p in m.polygons]
        else:
            faces = [tuple([offset + i for i in p.vertices]) for p in m.polygons]

        uvs = None
        uv_act = m.uv_layers.active
        if uv_act is not None:
            uv_layer = uv_act.data
            if flip_normals:
                uvs = [[uv_layer[li].uv for li in reversed(p.loop_indices)] for p in m.polygons]
            else:
                uvs = [[uv_layer[li].uv for li in p.loop_indices] for p in m.polygons]

        if idmat is None:
            idmats = [p.material_index for p in m.polygons]
        else:
            idmats = [idmat for p in m.polygons]

        return verts, faces, uvs, idmats

    @classmethod
    def bmesh_from_obj(
        cls, o, idmat=None, normalize=False, transform=None, hierarchy=False,
        base_bmesh=None, flip_normals=False, filter_hierarchy=None,
        offset=0
    ):
        """returns temporary bmesh from object"""
        if o.type != "MESH":
            return None

        verts, faces, uvs, idmats = cls.mesh_data_from_obj(
            o, idmat, normalize, transform, hierarchy,
            flip_normals, filter_hierarchy, offset
        )
        bm = cls.buildmesh(o, verts, faces, idmats, uvs, temporary=True)
        if base_bmesh is None:
            return bm

        cls.bmesh_join(o, [bm], base_bmesh=base_bmesh, temporary=True)
        return base_bmesh

    @classmethod
    def mesh_data_from_obj(
            cls, o, idmat=None, normalize=False, transform=None, hierarchy=False,
            flip_normals=False, filter_hierarchy=None,
            offset=0
    ):
        """
        :param o:
        :param idmat: force material index when not none
        :param normalize: normalize vertex
        :param transform: transform vertex using that matrix
        :return: vertex faces uvs idmat
        """
        if o.type != "MESH":
            return [], [], None, []

        if normalize:
            x = o.bound_box[6][0] - o.bound_box[0][0]
            y = o.bound_box[6][1] - o.bound_box[0][1]
            z = o.bound_box[6][2] - o.bound_box[0][2]

            # Prevent 0 division error on objects with single vertex
            scale = Matrix()
            if x != 0:
                scale[0][0] = 1 / x
            if y != 0:
                scale[1][1] = 1 / y
            if z != 0:
                scale[2][2] = 1 / z

            if transform is None:
                transform = scale
            else:
                transform = scale @ transform

        verts, faces, uvs, idmats = \
            cls._mesh_data_from_obj(
                o, offset, idmat, transform, flip_normals
            )

        skip_uvs = uvs is None
        if hierarchy:
            if transform is None:
                itM = o.matrix_world.inverted()
            else:
                itM = transform @ o.matrix_world.inverted()

            for c in o.children:
                # recursive call for childrens so we get whole hierarchy
                if c.type == "MESH" and filter_hierarchy is None or filter_hierarchy(c):
                    offset = len(verts)
                    _verts, _faces, _uvs, _idmats = \
                        cls.mesh_data_from_obj(
                            c, idmat, False, itM @ c.matrix_world, hierarchy,
                            flip_normals, filter_hierarchy, offset
                        )
                    verts.extend(_verts)
                    faces.extend(_faces)
                    if _uvs is None:
                        skip_uvs = True
                    else:
                        uvs.extend(_uvs)
                    idmats.extend(_idmats)
        if skip_uvs:
            uvs = None
        return verts, faces, uvs, idmats

    @classmethod
    def bevel(cls, context, o,
            offset,
            offset_type='OFFSET',
            segments=1,
            profile=0.5,
            affect='EDGES',
            clamp_overlap=True,
            material=-1,
            use_selection=True):
        """
        /* Bevel offset_type slot values */
        enum {
          BEVEL_AMT_OFFSET,
          BEVEL_AMT_WIDTH,
          BEVEL_AMT_DEPTH,
          BEVEL_AMT_PERCENT
        };
        """
        bm = bmesh.new()
        bm.from_mesh(o.data)
        cls.ensure_bmesh(bm)
        if use_selection:
            geom = [v for v in bm.verts if v.select]
            geom.extend([ed for ed in bm.edges if ed.select])
        else:
            geom = bm.verts[:]
            geom.extend(bm.edges[:])
        bmesh.ops.bevel(bm,
            geom=geom,
            offset=offset,
            offset_type=offset_type,
            segments=segments,
            profile=profile,
            affect=affect,
            # vertex_only=vertex_only,
            clamp_overlap=clamp_overlap,
            material=material)

        bm.to_mesh(o.data)
        bm.free()

    @staticmethod
    def translate(bm, vec, space=Matrix(), verts=None):
        if verts is None:
            verts = bm.verts[:]
        bmesh.ops.translate(bm, vec=vec, space=space, verts=verts)

    @staticmethod
    def scale(bm, vec, space=Matrix(), verts=None):
        if verts is None:
            verts = bm.verts[:]
        bmesh.ops.scale(bm, vec=vec, space=space, verts=verts, use_shapekey=False)

    @staticmethod
    def flip_normals(bm):
        for f in bm.faces:
            f.normal_flip()

    @classmethod
    def mirror(cls, bm, space=Matrix(), axis='XYZ'):
        vec = Vector((1, 1, 1))
        flip = False
        _axis = axis.lower()
        for a in 'xyz':
            if a in _axis:
                setattr(vec, a, -1)
                flip = not flip
        cls.scale(bm, vec=vec, space=space)
        if flip:
            cls.flip_normals(bm)
            cls.ensure_bmesh(bm)
            bm.normal_update()

    @staticmethod
    def rotate(bm, angle, pivot, space=Matrix()):
        bmesh.ops.rotate(
            bm,
            verts=bm.verts[:],
            cent=pivot,
            matrix=Matrix.Rotation(angle, 3, 'Z'),
            space=space
        )

    @classmethod
    def solidify(cls, context, o, amt, floor_bottom=False, altitude=0):
        bm = bmesh.new()
        bm.from_mesh(o.data)
        cls.ensure_bmesh(bm)
        
        geom = bm.faces[:]
        bmesh.ops.solidify(bm, geom=geom, thickness=amt)
        if floor_bottom:
            for v in bm.verts:
                if not v.select:
                    v.co.z = altitude
        bm.to_mesh(o.data)
        bm.free()

    @staticmethod
    def bisect(bm,
            plane_co,
            plane_no,
            dist=1e-6,
            use_snap_center=False,
            clear_outer=False,
            clear_inner=False,
            geom=None
            ):
        _geom = geom
        if _geom is None:
            _geom = bm.verts[:]
            _geom.extend(bm.edges[:])
            _geom.extend(bm.faces[:])

        bmesh.ops.bisect_plane(bm,
            geom=_geom,
            dist=dist,
            plane_co=plane_co,
            plane_no=plane_no,
            use_snap_center=use_snap_center,
            clear_outer=clear_outer,
            clear_inner=clear_inner
            )