# -*- coding:utf-8 -*-

# Easyref Add-on
# Copyright (C) 2018 Cedric Lepiller aka Pitiwazou & Legigan Jeremy AKA Pistiwique and Stephen Leger
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

bl_info = {
    "name": "Easyref",
    "description": "Add references Images and annotations to the 3Dview",
    "author": "Cedric Lepiller aka pitiwazou, with the help of Pistiwique and Stephen-I",
    "version": (0, 2, 3),
    "blender": (4, 3, 2),
    "location": "Property Panel, Press N in the 3DView",
    "wiki_url": "",
    "category": "Tools",
    "doc_url": "https://blscripts.notion.site/EASYREF-decf03ec04cd48cf8e4003eac6fe036a",}

########################################
# IMPORTS
########################################

# Import des modules
if "bpy" in locals():
    import importlib
    reloadable_modules =   ["cameras",
                            "empties_refs",
                            "modal",
                            "ui",
                            ]
    for module in reloadable_modules:
        if module in locals():
            importlib.reload(locals()[module])

import bpy
from bpy.types import   Panel, \
                        Operator, \
                        PropertyGroup,\
                        Menu,\
                        AddonPreferences

from bpy.props import  (BoolProperty,
                        EnumProperty,
                        FloatProperty,
                        CollectionProperty,
                        IntProperty,
                        PointerProperty,
                        StringProperty,
                        FloatVectorProperty
                        )
import urllib.request
import json
from . import  (cameras,
                empties_refs,
                modal,
                ui,
                )

from .icons.icons import load_icons
from .properties import *
from bpy.app.handlers import persistent
from mathutils import Quaternion
import bpy.app.handlers
from .properties import _handle_dict

########################################
# UPDATE UI
########################################
def update_catagory(self, context):
    is_panel = hasattr(bpy.types, 'PANEL_PT_easyref')

    if is_panel:
        try:
            bpy.utils.unregister_class(bpy.types.PANEL_PT_easyref)
        except:
            pass
    ui.PANEL_PT_easyref.bl_category = self.category
    bpy.utils.register_class(ui.PANEL_PT_easyref)

########################################
# PREFERENCES
########################################
def check_for_updates_and_notify():
    # Define the addon name; usually, this should be dynamically set to __name__ in real scenarios
    addon_idname = __name__

    # URL where the JSON file is hosted
    url = 'https://www.blscripts.com/blscripts_addons_updates.json'
    response = urllib.request.urlopen(url)
    data = json.load(response)

    # Get local version from bl_info directly
    local_version = bl_info['version']
    local_version_str = '.'.join(map(str, local_version))  # Convert tuple to string for comparison

    update_message = ""

    # Check for update specific to this addon
    if addon_idname in data:
        addon_data = data[addon_idname]
        if local_version_str != addon_data['version'] and addon_data['version'] > local_version_str:
            update_message = f"New version available: {addon_data['version']} (current: {local_version_str})\n"
            print(addon_idname + " New Version Available: " + addon_data['version'])
        else:
            update_message = "No updates available."
            print(addon_idname + ": No Update Available")
    else:
        update_message = "No updates available."
        print(addon_idname + ": No Update Available")

    # Set the update message in preferences
    preferences = bpy.context.preferences.addons[addon_idname].preferences
    preferences.update_available = update_message

    return update_message

class EASYREF_OT_check_updates(Operator):
    bl_idname = "wm.easyref_check_updates"
    bl_label = "Check for Updates"

    def execute(self, context):
        check_for_updates_and_notify()
        update_message = check_for_updates_and_notify()
        self.report({'INFO'}, update_message)
        return {'FINISHED'}

class EASYREF_MT_PREFERENCES(AddonPreferences):
    bl_idname = __name__

    prefs_tabs: EnumProperty(
        items=(('info', "Info", "Info"),
               ('options', 'Options', 'Options'),
               ('documentation', 'Documentation', 'Documentation'),
               ('links', "Links", "Links")),
        default='info') # type: ignore

    category : StringProperty(
        name="Category",
        description="Choose a name for the category of the panel",
        default="Easyref",
        update=update_catagory) # type: ignore

    ref_view_bg_color: FloatVectorProperty(
        name="Reference View Background Color",
        subtype='COLOR',
        default=(0.0061, 0.0062, 0.0063),
        min=0.0, max=1.0,
        size=3,
        description="Background color for the reference view") # type: ignore

    focus_modal_speed: FloatProperty(name="", default=1.0, min=0.001, max=1000,description="Speed to change the Focus of the Camera") # type: ignore
    refs_modal_speed: FloatProperty(name="", default=1.0, min=0.001, max=1000, description="Speed to move the references") # type: ignore


    # EMPTIES REFERENCES
    add_ref_transparency: BoolProperty(name="",default=True, description="Add References Transparency") # type: ignore
    ref_transparency: FloatProperty(name="",default=0.3,min=0.01, max=1,precision=3,description="Reference Transparency") # type: ignore
    ref_show_in_ortho: BoolProperty(name="",default=True, description="Show References in Orthographic View") # type: ignore
    ref_show_in_persp: BoolProperty(name="",default=True, description="Show References in Perspective View") # type: ignore
    # ref_size: FloatProperty(name="",default=5,min=0.01, max=100000,precision=3,description="Reference Size") # type: ignore
    ref_size: FloatProperty(name="",default=5,description="Reference Size") # type: ignore
    ref_only_axis_aligned: BoolProperty(name="",default=False, description="Display image only when ligned with the view") # type: ignore
    ref_aligned_to_view: BoolProperty(name="",default=False, description="Align the reference with the view") # type: ignore
    prefs_refs_distance: FloatProperty(name="",default=100,min=-10000, max=10000,precision=3,description="Distance of the Reference in the 3D View") # type: ignore

    ref_depth : EnumProperty(
        items=(('FRONT', "FRONT", ""),
               ('DEFAULT', "DEFAULT","",),
               ('BACK', "BACK","",)),
        default='FRONT') # type: ignore

    ref_side : EnumProperty(
        items=(('BOTH', "BOTH", ""),
               ('FRONT', "FRONT","",),
               ('BACK', "BACK","",)),
        default='FRONT') # type: ignore

    show_cameras_references_settings: BoolProperty(default=False, description="Cameras References Settings") # type: ignore
    show_empties_references_settings: BoolProperty(default=False, description="Empties References Settings") # type: ignore
    show_references_view_settings: BoolProperty(default=False, description="References View Settings") # type: ignore
    
    info: BoolProperty(
        name="",
        default=False,
        description="INFO") # type: ignore

    update_available: StringProperty(
        name="Update Available",
        description="Message indicating if there is an update available.",
        default="") # type: ignore

    # REFERENCE VIEW
    toggle_ref_view_side: EnumProperty(
        items=(("LEFT", "LEFT", ""),
               ("RIGHT", "RIGHT", ""),
               ("TOP", "TOP", ""),
               ("BOTTOM", "BOTTOM", "")),
        default="LEFT",
        description="Position of the Editor",
    )# type: ignore 

    toggle_ref_view_factor: IntProperty(
        name="Factor 3D View Editor",
        default=50,
        min=0,
        max=100,
        subtype='PERCENTAGE',
        description="Percentage of the area",
    )# type: ignore
    
    ref_view_position: FloatProperty(name="",default=1000,precision=3,description="Reference View Position in the 3D View") # type: ignore

    check_for_updates: BoolProperty(name="Check for Updates",description="Check for Updates",default=False)# type: ignore
    def draw(self, context):
        layout = self.layout
        wm = bpy.context.window_manager
        icons = ui.load_icons()

        row = layout.row(align=True)
        row.scale_y = 1.5
        row.prop(self, "prefs_tabs", expand=True)
        if self.prefs_tabs == 'info':
            box = layout.box()  
            row = box.row(align=True)
            row.scale_y = 1.5
            row.prop(self, "check_for_updates")
            if self.check_for_updates:
                # UPDATE
                show_update = False
                if bpy.app.version < (4, 1, 0):
                    show_update = True
                elif bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
                        show_update = True
                
                # box = layout.box()
                if show_update:
                    row = box.row(align=True)
                    update = True if self.update_available == "No updates available." else False
                    row.alert = update
                    row.label(text=self.update_available if self.update_available else "No updates available.")
                    row.alert = False
                    row.operator("wm.easyref_check_updates", text="Check for Updates", icon='FILE_REFRESH')
                
                if bpy.app.version >= (4, 2, 0):
                    if not bpy.context.preferences.system.use_online_access:
                        row = box.row(align=True)
                        row.alert = True
                        row.label(text="Activate Allow Online Acess in the System/Network to check for updates", icon="ERROR")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="BLENDER MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/easyref"
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/l/easyref"
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/marketplace/p/xmoOJ/easyref"
            icon = icons.get("icon_flipped_normals")
            row.operator("wm.url_open", text="FLIPPED NORMALS",
                         icon_value=icon.icon_id).url = "https://flippednormals.com/product/easyref-a-blender-addon-89?dst=kQBFV9Uv"

            # CUSTOMERS
            box = layout.box()
            icon = icons.get("icon_discord")
            row = box.row(align=True)
            row.scale_y = 2
            row.operator("wm.url_open", text="SUPPORT ON DISCORD FOR CUSTOMERS",
                         icon_value=icon.icon_id).url = "https://discord.gg/8M8mFVegZ8"
            row.scale_x = 2
            row.prop(self, 'info', icon='INFO')
            if self.info:
                box = layout.box()
                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(
                    text="Join our Discord community for customer support! As a valued customer, you’ll gain access to exclusive benefits:")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(
                    text="1. Add-on Support Channel: To access this channel, simply send us a copy of your receipt to our email address below.")
                row = col.row(align=True)
                row.label(text="2. Latest Builds: Stay up-to-date with the latest builds of our add-ons.")
                row = col.row(align=True)
                row.label(text="3. Feature Requests: Have a feature in mind? Feel free to ask—we’re here to listen!")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="🔗 Discord Invite Link: https://discord.gg/8M8mFVegZ8")
                row = col.row(align=True)
                row.label(text="📧 Email: mail.blscripts@gmail.com")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="Thank you for supporting our work! If you haven’t purchased the add-on yet, ")
                row = col.row(align=True)
                row.label(text="consider doing so it helps sustain years of effort and support for all our add-ons.")

            box = layout.box()
            box.label(text="This addon allows you to add references to work on your projects")
            box.label(text="You have 3 ways to add References:")
            box.label(text="1. Add References to Cameras")
            box.label(text="    You can add Cameras with references inside")
            box.label(text="    You can add as many references as you want per camera")
            box.separator()
            box.label(text="2. Add References to Ortho Views")
            box.label(text="    You can add References for Ortho Views (Front, Right, Left, Back)")
            box.label(text="    You are not limited to one reference per Ortho View")
            box.separator()
            box.label(text="3. Add References to the Reference View")
            box.label(text="    You can add as many References as you want in the Reference View")
            box.label(text="    You can create Collections of References to concentrate to a particular part of your work")

        if self.prefs_tabs == 'options':
            box = layout.box()
            split = box.split()
            col = split.column()
            col.label(text="Panel Category:")
            col = split.column(align=True)
            col.prop(self, "category", text="")
            col.separator()

            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_cam_active")
            row.prop(self, "show_cameras_references_settings", text="CAMERAS REFERENCES", icon_value=icon.icon_id)

            if self.show_cameras_references_settings:
                row = box.row(align=True)
                row.label(text="References Modal Speed")
                row.prop(self, "refs_modal_speed")

                row = box.row(align=True)
                row.label(text="Camera Focus Modal Speed")
                row.prop(self, "focus_modal_speed")

            # ----- EMPTIES REFERENCES
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_easyref_cams")
            row.prop(self, "show_empties_references_settings", text="EMPTIES REFERENCES", icon_value=icon.icon_id)

            if self.show_empties_references_settings:

                split = box.split()
                col = split.column()
                col.label(text="Add Transparency")
                col = split.column(align=True)
                col.prop(self, "add_ref_transparency")

                if self.add_ref_transparency:
                    split = box.split()
                    col = split.column()
                    col.label(text="Transparency Value")
                    col = split.column(align=True)
                    col.prop(self, "ref_transparency", text="")

                split = box.split()
                col = split.column()
                col.label(text="Depth")
                col = split.column(align=True)
                col.prop(self, 'ref_depth', expand=True)

                split = box.split()
                col = split.column()
                col.label(text="Side")
                col = split.column(align=True)
                col.prop(self, 'ref_side', expand=True)

                split = box.split()
                col = split.column()
                col.label(text="Show in Orthographic Mode")
                col = split.column(align=True)
                col.prop(self, "ref_show_in_ortho")

                split = box.split()
                col = split.column()
                col.label(text="Show in Perspective Mode")
                col = split.column(align=True)
                col.prop(self, "ref_show_in_persp")

                split = box.split()
                col = split.column()
                col.label(text="Visible when Aligned to View")
                col = split.column(align=True)
                col.prop(self, "ref_only_axis_aligned")

                split = box.split()
                col = split.column()
                col.label(text="Size")
                col = split.column(align=True)
                col.prop(self, "ref_size")

                split = box.split()
                col = split.column()
                col.label(text="Distance")
                col = split.column(align=True)
                col.prop(self, "prefs_refs_distance")

            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_add_ref_view")
            row.prop(self, "show_references_view_settings", text="REFERENCES VIEW", icon_value=icon.icon_id)


            if self.show_references_view_settings:
                split = box.split()
                col = split.column()

                row = col.row()
                row.label(text="Background Color ")
                row.prop(self, "ref_view_bg_color", text="")
                row = col.row()
                row.separator()
                row = col.row()
                row.label(text="Position ")
                row.prop(self, "ref_view_position", text="")
                row = col.row()
                row.separator()
                row = col.row()
                row.label(text="Reference View Position")
                row.prop(self, "toggle_ref_view_side", text="")
                row = col.row()
                row.label(text="Reference View Size")
                row.prop(self, "toggle_ref_view_factor", text="")

        if self.prefs_tabs == 'documentation':
            icon = icons.get("icon_easyref")
            row = layout.row(align=True)
            row.scale_y = 1.5
            row.operator("wm.url_open", text="DOCUMENTATION PAGE",
                         icon_value=icon.icon_id).url = "https://blscripts.notion.site/EASYREF-decf03ec04cd48cf8e4003eac6fe036a"

            icon = icons.get("icon_youtube")
            row.scale_y = 1.5
            row.operator("wm.url_open", text="YOUTUBE TUTORIAL",
                         icon_value=icon.icon_id).url = "https://youtu.be/Sy8J1qgA6bU"
            
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_cam_active")
            row.prop(self, "show_cameras_references_settings", text="CAMERAS REFERENCES", icon_value=icon.icon_id)

            if self.show_cameras_references_settings:
                box.label(text="You can set up your camera with references inside.")
                box.label(text="You can add as many references as you want in each camera.")
                box.label(text="This is useful if you want to always have a reference to work on,")
                box.label(text="or to fit a Reference.")
                box.label(text="When you add a Camera, you will select one or more images.")
                box.label(text="Once the images are loaded, you can Edit them.")
                box.label(text="Move them, Rotate them, Scale them, Flip them, etc...")
                box.label(text="The Keys are visible at the left of the view.")
                box.separator()
                box.label(text="You can also use a Camera to fit a Reference.")
                box.label(text="Place the Camera in the right position and place the cursor on the Mesh.")
                box.label(text="Press Q to fit the Reference and Edit the Camera Lens.")
                box.separator()
                box.label(text="If you want to work on a specific part of your model.")
                box.label(text="You can create a Camera with Specific images,")
                box.label(text="and place it in the right position.")
                box.separator()

            # icon = icons.get("icon_easyref_refs")
            # layout.label(text="ORTHO REFERENCES", icon_value=icon.icon_id) 
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_easyref_cams")
            row.prop(self, "show_empties_references_settings", text="EMPTIES REFERENCES", icon_value=icon.icon_id)

            if self.show_empties_references_settings:
                box.label(text="You can add References for Ortho Views (Front, Right, Left, Back).")
                box.label(text="Or just a simple Reference by clicking on 'Add Reference Image'.")
                box.label(text="You can add as many references as you want in each Ortho View.")
                box.separator()
                box.label(text="For Each Reference, you can set the Size, Depth, Side, etc... in it's Settings.")
                box.label(text="If you select a Reference, you will see it's settings.")
                box.label(text="If you select something else, you will see all the References,")
                box.label(text="and you will be able to edit all the References at once.")


            # row = layout.row(align=True)
            # icon = icons.get("icon_add_ref_view")
            # row.label(text="REFERENCE VIEW", icon_value=icon.icon_id)
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_add_ref_view")
            row.prop(self, "show_references_view_settings", text="REFERENCES VIEW", icon_value=icon.icon_id)

            if self.show_references_view_settings:
                box.label(text="To add References to the Reference View, click on 'Add Reference'.")
                box.label(text="You will select the References you want and it will open the Reference View.")
                box.label(text="At this point, you will be able to move, rotate, scale, flip the References.")
                box.separator()
                box.label(text="You can add as many References as you want in the Reference View.")
                box.label(text="You can create Collections of References")
                box.label(text="to concentrate to a particular part of your work.")
                box.separator()
                box.label(text="You can import other References and put them in a new Collection")
                box.label(text="or select an existing Collection to add References to it.")
                box.label(text="When you select one or more References, you can add them to a new Collection.")
                box.label(text="Or move them to an existing Collection.")
                box.separator()
                box.label(text="The References View will list the available Collections.")
                box.label(text="You can Select, Frame, Hide or Delete a Collection.")
                box.separator()
                box.label(text="If you have a Selection of References, you can add Grid them.")
                box.label(text="You can also Center the view when necessary.")
                box.separator()
                box.label(text="You can close and open the Reference View as much as you want.")
                box.separator()
                box.label(text="In the Preferences, you can set the size and the side of the Reference View.")

        # Links
        if self.prefs_tabs == 'links':

            # TUTORIALS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="TUTORIALS & ADD-ONS")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="MY ADDONS",
                         icon_value=icon.icon_id).url = "https://blscripts.notion.site/MY-BLENDER-ADD-ONS-177b22ccb5a080bfa87aef5fa7392697"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator("wm.url_open", text="GUMROAD - SPEEDFLOW",
                         icon_value=icon.icon_id).url = "https://pitiwazou.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/creators/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651436"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_flipped_normals")
            row.operator("wm.url_open", text="FLIPPED NORMALS",
                         icon_value=icon.icon_id).url = "https://flippednormals.com/creator/pitiwazou?tagIds=1"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="YOUTUBE",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/user/pitiwazou"

            # LINKS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SOCIAL")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="PITIWAZOU.COM",
                         icon_value=icon.icon_id).url = "http://www.pitiwazou.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/artist/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_twitter")
            row.operator("wm.url_open", text="TWITTER",
                         icon_value=icon.icon_id).url = "https://twitter.com/#!/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_facebook")
            row.operator("wm.url_open", text="FACEBOOK",
                         icon_value=icon.icon_id).url = "https://www.facebook.com/Pitiwazou-C%C3%A9dric-Lepiller-120591657966584/"

# -----------------------------------------------------
# PROPERTY GROUPS
# -----------------------------------------------------
class EASYREF_ViewSettings_PropertyGroup(PropertyGroup):
    show_region_toolbar: BoolProperty(default=True)# type: ignore
    show_ortho_grid: BoolProperty(default=True)# type: ignore
    show_text: BoolProperty(default=True)# type: ignore
    show_cursor: BoolProperty(default=True)# type: ignore
    show_outline_selected: BoolProperty(default=True)# type: ignore
    show_bones: BoolProperty(default=True)# type: ignore
    show_motion_paths: BoolProperty(default=True)# type: ignore
    show_object_origins: BoolProperty(default=True)# type: ignore
    show_viewer_attribute: BoolProperty(default=True)# type: ignore
    show_floor: BoolProperty(default=True)# type: ignore
    show_axis_x: BoolProperty(default=True)# type: ignore
    show_axis_y: BoolProperty(default=True)# type: ignore
    show_axis_z: BoolProperty(default=True)# type: ignore
    show_relationship_lines: BoolProperty(default=True)# type: ignore
    background_type: StringProperty(default='VIEWPORT')# type: ignore   
    background_color: FloatVectorProperty(
        size=3,
        default=(0.05, 0.05, 0.05),
        subtype='COLOR',
        min=0.0, max=1.0
    )# type: ignore 

class EASYREF_Scene_PropertyGroup(PropertyGroup):
    has_ref_view: BoolProperty(
        name="Has Reference View",
        default=False
    ) # type: ignore
    
    ref_view_side: StringProperty(
        name="Reference View Side",
        default=""
    ) # type: ignore

    ref_view_area_index: IntProperty(
        name="Reference View Area Index",
        default=-1
    ) # type: ignore
    
    stored_view_location: FloatVectorProperty(
        name="Stored View Location",
        subtype='TRANSLATION'
    ) # type: ignore
    
    stored_view_rotation: FloatVectorProperty(
        name="Stored View Rotation",
        subtype='QUATERNION',
        size=4
    ) # type: ignore
    
    stored_view_distance: FloatProperty(
        name="Stored View Distance"
    ) # type: ignore

    view_settings: PointerProperty(type=EASYREF_ViewSettings_PropertyGroup)# type: ignore

    create_new_collection: BoolProperty(
        name="Create New Collection",
        default=False
    ) # type: ignore
    
    new_collection_name: StringProperty(
        name="New Collection Name",
        default="New_References"
    ) # type: ignore

    # Ajout des propriétés ici plutôt que dans register()
    create_new_collection: BoolProperty(
        name="Create New Collection",
        default=False
    ) # type: ignore
    
    new_collection_name: StringProperty(
        name="New Collection Name",
        default="New_References"
    ) # type: ignore

    existing_collection: StringProperty(
        name="Existing Collection",
        default="",
        description="Select an existing RV_ collection"
    ) # type: ignore

class EASYREF_Settings_PropertyGroup(PropertyGroup):
    show_ref_view_panel : BoolProperty(default=False, description="Show References View Panel") # type: ignore
    show_cam_ref_panel : BoolProperty(default=False, description="Show Camera References Panel") # type: ignore
    show_empties_ref_panel : BoolProperty(default=False, description="Show Ortho References Panel") # type: ignore

class EASYREF_Cameras_PropertyGroup(PropertyGroup):
    show_camera_settings : BoolProperty(default=False,description="Show the Camera Settings to edit the camera (Focal, Resolutions, etc...)") # type: ignore
    only_cam : BoolProperty(default=False,description="create only Camera") # type: ignore
    show_refs : BoolProperty(default=True,description="Annotations Visibility") # type: ignore
    showhide_background_images : BoolProperty(default=True,description="References Visibility") # type: ignore
    show_camera_resolution_etc : BoolProperty(default=False, description="Show Camera Resolution and othe Settings") # type: ignore
    show_images : BoolProperty(default=False, description="Show Images Settings") # type: ignore
    ortho_view: BoolProperty(default=False,description="References Visibility") # type: ignore

class EASYREF_Empties_PropertyGroup(PropertyGroup):

    show_hide_ref_settings : BoolProperty(default=False, description="Show Reference Settings") # type: ignore
    show_hide_all_refs_settings : BoolProperty(default=False, description="Show all Reference Settings") # type: ignore
    all_refs_opacity : FloatProperty(min=0, max=1, default=0.3, description="", update =easyref_all_references_opacity) # type: ignore
    all_refs_depth : EnumProperty(
        items=(('DEFAULT', "DEFAULT", "DEFAULT"),
               ('FRONT', "FRONT", "FRONT"),
               ('BACK', "BACK", "BACK")),
        default='FRONT',
        update=easyref_all_references_depth) # type: ignore

    all_refs_side : EnumProperty(
        items=(('DOUBLE_SIDED', "BOTH", "BOTH"),
               ('FRONT', "FRONT", "FRONT"),
               ('BACK', "BACK", "BACK")),
        default='FRONT',
        update=easyref_all_references_side) # type: ignore

    all_refs_size : FloatProperty(min=0, max=100000, default=5, description="Change the size of visible references", update=easyref_all_references_size) # type: ignore
    all_refs_ortho : BoolProperty(default=True, description="Show in Orthographic", update=easyref_all_references_ortho) # type: ignore
    all_refs_persp : BoolProperty(default=True, description="Show in Perspective", update=easyref_all_references_persp) # type: ignore
    all_refs_only_axis_aligned : BoolProperty(default=True, description="Only Axis Aligned", update=easyref_all_references_only_axis_aligned) # type: ignore
    # all_refs_distance : FloatProperty(name="",default=0,min=-10000, max=10000,precision=3,description="Distance of the Reference in the 3D View", update = easyref_all_references_distance) # type: ignore
    all_refs_distance_y : FloatProperty(name="Y",default=20,min=-10000, max=10000,precision=3,description="Transforms Y", update = easyref_all_references_distance_y) # type: ignore
    all_refs_distance_z : FloatProperty(name="Z",default=0,min=-10000, max=10000,precision=3,description="Transforms Z", update = easyref_all_references_distance_z) # type: ignore
    empty_image_offset_x : FloatProperty(name="Empty Image Offset X", default=0, min=-10000, max=10000, precision=3, description="Empty Image Offset X", update = easyref_empty_image_offset_x) # type: ignore
    empty_image_offset_y : FloatProperty(name="Empty Image Offset Y", default=0, min=-10000, max=10000, precision=3, description="Empty Image Offset Y", update = easyref_empty_image_offset_y) # type: ignore
    all_refs_distance: FloatProperty(
        name="Distance",
        description="Distance from center for all references",
        default=1.0,
        min=0.0,
        update=easyref_all_references_distance
    )# type: ignore


# Gestionnaires pour nettoyer le handler lors des changements de scène
@persistent
def cleanup_lock_view_handler(dummy):
    """Nettoie le handler quand une nouvelle scène est chargée"""
    if _handle_dict["handle"] and _handle_dict["space"]:
        try:
            _handle_dict["space"].draw_handler_remove(_handle_dict["handle"], 'WINDOW')
        except:
            pass
        _handle_dict["handle"] = None
        _handle_dict["space"] = None

CLASSES = [
    EASYREF_MT_PREFERENCES,
    EASYREF_OT_check_updates,
    EASYREF_ViewSettings_PropertyGroup,
    EASYREF_Scene_PropertyGroup,         
    EASYREF_Settings_PropertyGroup,
    EASYREF_Cameras_PropertyGroup,
    EASYREF_Empties_PropertyGroup,
]

def register():
    cameras.register()
    empties_refs.register()
    modal.register()
    ui.register()

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

    prefs = bpy.context.preferences.addons[__name__].preferences
    update_catagory(prefs, bpy.context)

    bpy.types.Scene.easyref_settings = PointerProperty(type=EASYREF_Settings_PropertyGroup)
    bpy.types.Object.easyref = CollectionProperty(type=EASYREF_Cameras_PropertyGroup)
    bpy.types.Scene.easyref_empties = PointerProperty(type=EASYREF_Empties_PropertyGroup)
    bpy.types.Scene.easyref_props = PointerProperty(type=EASYREF_Scene_PropertyGroup)

    bpy.types.WindowManager.modal_ON = BoolProperty(default=False,description="Modal ON")
    bpy.types.WindowManager.annotations_ON = BoolProperty(default=False,description="Annotations ON")
    bpy.types.WindowManager.no_ref = BoolProperty(default=False,description="No reference")
    bpy.types.Camera.easyref_image_active = IntProperty()
    bpy.types.Camera.easyref_cam_active_expand = BoolProperty()
    bpy.types.WindowManager.timer_on = BoolProperty(default=False,description="Timer ON")

    bpy.app.handlers.load_pre.append(cleanup_lock_view_handler)

    # CHECK FOR UPDATE
    if prefs.check_for_updates:
        check_update = False
        if bpy.app.version < (4, 2, 0):
            check_update = True

        if bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
            check_update = True
            
        if check_update:
            check_for_updates_and_notify()


def unregister():
    cameras.unregister()
    empties_refs.unregister()
    modal.unregister()
    ui.unregister()

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

    if cleanup_lock_view_handler in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(cleanup_lock_view_handler)