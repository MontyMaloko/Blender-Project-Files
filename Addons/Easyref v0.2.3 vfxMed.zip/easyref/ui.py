'''-*- coding:utf-8 -*-

Easyref Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

import bpy
from bpy.types import Panel, Operator, PropertyGroup, Menu
from .properties import *
from .icons.icons import load_icons

def EasyRef_Cam(self, context, layout, WM):
    icons = load_icons()
    prefs = get_addon_preferences()
    camref_list = [cam for cam in context.scene.objects if "easyref" in cam]

    for j, cam in enumerate(camref_list):
        cam_prop = cam.easyref[0]
        self.cam = cam

        # if not WM.annotations_ON:
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)

        # Set Active Cam
        row.scale_y = 1.3
        icon = icons.get("icon_cam_active")
        if cam == context.space_data.camera:
            row.operator("easyref.select_camref", text=cam.name, icon_value=icon.icon_id).camref = cam.name
        else:
            row.operator("easyref.select_camref", text=cam.name, icon='OUTLINER_DATA_CAMERA').camref = cam.name
        row.operator('easyref.setup_for_focus', text='', icon='VIEW_PERSPECTIVE').camref = cam.name

        # Lock cam
        lock_cam = "LOCKED" if cam.lock_rotation[0] else "UNLOCKED"
        row.operator("easyref.lock_camera_transforms", icon=lock_cam, text="").camref = cam.name

        # Cam Settings PREFERENCES
        icon = icons.get("icon_arrow_up") if cam_prop.show_camera_settings else icons.get("icon_options")
        row.prop(cam_prop, "show_camera_settings", text="",icon_value=icon.icon_id)

        # Delete camref
        op = row.operator("easyref.delete_camref", text="", icon='X')
        op.camref = cam.name
        op.juste_empty = False

        # Camera Settings	
        if any(cam.data.background_images):
            # Edit Ref
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = 1.2
            op = row.operator("easyref.images_refs_actions", icon='IMAGE_DATA', text="Edit Reference(s)")
            op.camref = cam.name
            op.add_cam_and_ref = False
            op.add_ref = False
            op.launch_modal = True

            # Add New Ref
            op = row.operator("easyref.images_refs_actions", icon='ADD', text="")
            op.camref = cam.name
            op.add_cam_and_ref = False
            op.add_ref = True
            op.launch_modal = False
            if cam_prop.showhide_background_images:
                row.operator("easyref.show_hide_background_images", text="", icon='RESTRICT_VIEW_OFF').camref = cam.name
            else:
                row.operator("easyref.show_hide_background_images", text="", icon='RESTRICT_VIEW_ON').camref = cam.name

            # Delete Ref
            row.operator("easyref.delete_all_refs", text="", icon='X').camref = cam.name

            # Camera Settings
            if cam_prop.show_camera_settings:
                # CAMERA
                row = col.row()
                header, panel = row.panel_prop(cam_prop, "show_camera_resolution_etc")
                header.label(text="Camera Settings", icon='CAMERA_DATA')
                if panel:
                    row = col.row()
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Camera Settings:")

                    if cam.data.type == 'ORTHO':
                        row = col.row(align=True)
                        row.prop(cam.data, "ortho_scale", text="Ortho Scale")
                    else:
                        row = col.row(align=True)
                        row.prop(cam.data, "lens", text="Focal")
                        row = col.row(align=True)
                        row.prop(cam.data, "sensor_width", text="Sensor")
                    row = col.row()
                    row.separator()
                    row = col.row()
                    row.prop(cam.data, "shift_x", text="Shift X")
                    row = col.row(align=True)
                    row.prop(cam.data, "shift_y", text="Shift Y")
                    row = col.row()
                    row.separator()
                    row = col.row()
                    row.prop(cam.data, "clip_start", text="Clip Start")
                    row = col.row(align=True)
                    row.prop(cam.data, "clip_end", text="Clip End")
                    row = col.row(align=True)
                    row.label(text="Viewport Display:")
                    row = col.row(align=True)
                    row.prop(cam.data, "show_name", text="Show Name")
                    row = col.row(align=True)
                    row.prop(cam.data, "show_composition_center", text="Center")
                    row = col.row(align=True)
                    row.prop(cam.data, "show_composition_thirds", text="Third")
                    row = col.row(align=True)
                    row.prop(cam.data, "show_passepartout", text="Show Passepartout")
                    if cam.data.show_passepartout:
                        row = col.row(align=True)
                        row.prop(cam.data, "passepartout_alpha", text="Opacity", slider=True)
                
                # IMAGES
                row = col.row()
                header, panel = row.panel_prop(cam_prop, "show_images")
                header.label(text="Images Settings", icon='IMAGE_PLANE')
                if panel:
                    # opacity for each image
                    for i, bg in enumerate(cam.data.background_images):
                        
                        row = col.row(align=True)
                        row.prop(bg, "show_expanded", text="", emboss=False)
                        if bg.source == 'IMAGE' and bg.image:
                            row.prop(bg.image, "name", text="", emboss=False)
                        elif bg.source == 'MOVIE_CLIP' and bg.clip:
                            row.prop(bg.clip, "name", text="", emboss=False)
                        elif bg.source and bg.use_camera_clip:
                            row.label(text="Active Clip")
                        else:
                            row.label(text="Not Set")

                        row.prop(bg,"show_background_image",text="",emboss=False,icon='RESTRICT_VIEW_OFF' if bg.show_background_image else 'RESTRICT_VIEW_ON')
                        op = row.operator("easyref.delete_ref", text="", emboss=False, icon='X')
                        op.camref = cam.name
                        op.index = i

                        row = col.row(align=True)
                        row.prop(bg, "alpha", slider=True)

                        
                        if bg.show_expanded:
                            col.row().prop(bg, "display_depth", expand=True)
                            col.row().label(text='Offset')
                            col.row().prop(bg, "offset", text="")

                            col.row().prop(bg, "rotation", text="Rotation")
                            col.row().prop(bg, "scale", text="Size")

                            row = col.row(align = True)
                            row.prop(bg, "use_flip_x", text="Flip H",
                                        icon='RADIOBUT_ON' if bg.use_flip_x else 'RADIOBUT_OFF')
                            row.prop(bg, "use_flip_y", text="Flip V",
                                        icon='RADIOBUT_ON' if bg.use_flip_y else 'RADIOBUT_OFF')
                            
        else:
            # Add New Ref
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = 1.2
            op = row.operator("easyref.images_refs_actions", icon='ADD', text="Add Reference(s)")
            op.camref = cam.name
            op.add_cam_and_ref = False
            op.add_ref = True
            op.launch_modal = False

def EasyRef_Empties(self, context):
    layout = self.layout
    icons = load_icons()
    prefs = get_addon_preferences()
    easyref_empties = context.scene.easyref_empties
    easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]
    selected_ref = context.active_object

    # ADD REFERENCE
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    if context.object is not None and context.object.type == 'EMPTY' and context.object.empty_display_type == 'IMAGE' and len(context.selected_objects) == 1:
        icon = icons.get("icon_easyref_edit")
        row.label(text="Edit Reference",icon_value=icon.icon_id)
    else:
        icon = icons.get("icon_easyref_cams")
        row.scale_y = 1.3
        row.operator('object.easyref_add_image_ref', text="Add Image Reference",icon_value=icon.icon_id)
        # row.operator('object.easyref_load_ref', text="Add Image Reference",icon_value=icon.icon_id).empties_refs = 'named'

    # ORTHO 
    row = col.row()
    row.label(text="Orthographic")
    if context.object is not None and context.object.type == 'EMPTY' and context.object.empty_display_type == 'IMAGE' and len(context.selected_objects) == 1 and not selected_ref.get("easyref_empty_ref_view"):
        row = col.row(align=True)
        row.operator('object.easyref_set_reference', text="Front").empties_set_refs = 'front'
        row.operator('object.easyref_set_reference', text="Back").empties_set_refs = 'back'
        row = col.row(align=True)
        row.operator('object.easyref_set_reference', text="Left").empties_set_refs = 'left'
        row.operator('object.easyref_set_reference', text="Right").empties_set_refs = 'right'
        row = col.row(align=True)
        row.operator('object.easyref_set_reference', text="Top").empties_set_refs = 'top'
        row.operator('object.easyref_set_reference', text="Bottom").empties_set_refs = 'bottom'
        row = col.row(align=True)
        row.label(text="Perspective")
        row = col.row(align=True)
        row.operator('object.easyref_set_reference', text="Aligned To View").empties_set_refs = 'aligned'

        box = layout.box()
        split = box.split(align=True)
        col = split.column(align=True)
        row=col.row(align=True)

        row.label(text=selected_ref.name, icon='IMAGE_PLANE')
        row.operator("object.easyref_flip_references", text="", icon='CENTER_ONLY').ref = selected_ref.name

        if selected_ref.get("easyref_empty_ref_visible"):
            icon = icons.get("icon_arrow_up") if easyref_empties.show_hide_ref_settings else icons.get("icon_options")
            row.operator("object.easyref_hide_refs_settings", text="", icon_value=icon.icon_id).ref = selected_ref.name
        else:
            icon = icons.get("icon_arrow_up") if easyref_empties.show_hide_ref_settings else icons.get("icon_options")
            row.operator("object.easyref_show_refs_settings", text="", icon_value=icon.icon_id).ref = selected_ref.name
        
        row.operator("object.easyref_delete_ref", text="", icon='X').ref = selected_ref.name

        if selected_ref.get("easyref_empty_ref_visible") :
            row = col.row()
            row.separator()
            if not selected_ref.use_empty_image_alpha:
                row = col.row()
                row.prop(selected_ref, "use_empty_image_alpha", text="Opacity")
            else:
                row = col.row()
                row.prop(selected_ref, "use_empty_image_alpha", text="")
                row.prop(selected_ref, "color", text="Opacity", index=3, slider=True)

            # DEPTH
            row = col.row(align=True)
            row.label(text="Detph")
            row = col.row(align=True)
            row.prop(selected_ref, "empty_image_depth", text="Depth", expand=True)

            # SIDE
            row = col.row(align=True)
            row.label(text="Side")
            row = col.row(align=True)
            row.prop(selected_ref, "empty_image_side", text="Side", expand=True)

            # ORTHO/PERSP
            row = col.row(align=True)
            row.label(text="Show In")
            row = col.row(align=True)
            row.prop(selected_ref, "show_empty_image_orthographic", text="Orthographic")
            row = col.row(align=True)
            row.prop(selected_ref, "show_empty_image_perspective", text="Perspective")
            row = col.row(align=True)
            row.prop(selected_ref, "show_empty_image_only_axis_aligned", text="Only Axis Aligned")

            row = col.row(align=True)
            row.prop(selected_ref, "empty_display_size", text="Size")
            row = col.row(align=True)
            row.prop(selected_ref, "empty_image_offset", text="Offset X", index=0)
            row = col.row(align=True)
            row.prop(selected_ref, "empty_image_offset", text="Offset Y", index=1)
            row = col.row()
            row.label(text="Path")
            row = col.row()
            row.template_ID(selected_ref, "data", open="image.open", unlink="ref.unlink_data")

            row = col.row(align=True)
            row.label(text="Transforms")
            row = col.row(align=True)
            row.prop(selected_ref, "location", index=0, text='X')
            row = col.row(align=True)
            row.prop(selected_ref, "location", index=1, text='Y')
            row = col.row(align=True)
            row.prop(selected_ref, "location", index=2, text='Z')

    else:
        row = col.row(align=True)
        row.operator('object.easyref_load_ref', text="Front").empties_refs = 'front'
        row.operator('object.easyref_load_ref', text="Back").empties_refs = 'back'
        row = col.row(align=True)
        row.operator('object.easyref_load_ref', text="Left").empties_refs = 'left'
        row.operator('object.easyref_load_ref', text="Right").empties_refs = 'right'
        row = col.row(align=True)
        row.operator('object.easyref_load_ref', text="Top").empties_refs = 'top'
        row.operator('object.easyref_load_ref', text="Bottom").empties_refs = 'bottom'
        row = col.row(align=True)
        row.label(text="Perspective")
        row = col.row(align=True)
        row.operator('object.easyref_load_ref', text="Aligned To View").empties_refs = 'aligned'

        # ALL REFERENCES
        if easyref_ref_list and len(easyref_ref_list)>1:
            self.first_ref = easyref_ref_list[0]
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_easyref_cams")
            row.label(text="ALL REFERENCES", icon_value=icon.icon_id)
            ref_coll = bpy.data.collections.get("IMAGES_REFERENCES")

            if not ref_coll:
                if self.first_ref.hide_viewport:
                    row.operator("object.easyref_show_all_refs", text="", icon='RESTRICT_VIEW_ON')
                else:
                    row.operator("object.easyref_hide_all_refs", text="", icon='RESTRICT_VIEW_OFF')

            else:
                row.prop(ref_coll, 'hide_viewport', icon='RESTRICT_VIEW_OFF', text="")
            
            icon = icons.get("icon_arrow_up") if easyref_empties.show_hide_all_refs_settings else icons.get("icon_options")
            row.prop(easyref_empties, "show_hide_all_refs_settings", text="", icon_value=icon.icon_id)

            row.operator("object.easyref_delete_all_refs", text="", icon='X')
            
            if easyref_empties.show_hide_all_refs_settings:
                row = col.row()
                row.separator()
                row = col.row()
                row.prop(easyref_empties, "all_refs_opacity",text="Opacity", index=3, slider=True)
                row = col.row(align=True)
                row.label(text="Depth")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_depth", expand=True)
                row = col.row(align=True)
                row.label(text="Depth")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_side", expand=True)
                row = col.row(align=True)
                row.label(text="Show In")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_ortho", text="Orthographic")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_persp", text="Perspective")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_only_axis_aligned", text="Only Axis Aligned")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_size", text="Size")
                row = col.row(align=True)
                row.label(text="Transforms")
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_distance", text='Depth')
                row = col.row(align=True)
                row.prop(easyref_empties, "all_refs_distance_z", text='Vertical')

        for j, ref in enumerate(easyref_ref_list):
            box = layout.box()
            split = box.split(align=True)
            col = split.column(align=True)
            row=col.row(align=True)
            icon = icons.get("icon_easyref_cams")
            row.operator("object.easyref_set_ref_view", text=ref.name, icon_value=icon.icon_id).ref = ref.name
            
            if ref.get("easyref_empty_is_hidden"):
                row.operator("object.easyref_show_ref", text="", icon='RESTRICT_VIEW_ON').ref = ref.name
            else:
                row.operator("object.easyref_hide_ref", text="", icon='RESTRICT_VIEW_OFF').ref = ref.name

            row.operator("object.easyref_lock_empty", text="", icon='LOCKED' if ref.hide_select else 'UNLOCKED').ref = ref.name

            row.operator("object.easyref_flip_references", text="", icon='CENTER_ONLY').ref = ref.name

            if not ref.get("easyref_empty_ref_visible"):
                icon = icons.get("icon_options")
                row.operator("object.easyref_show_refs_settings", text="", icon_value=icon.icon_id).ref = ref.name
            else:
                icon = icons.get("icon_arrow_up")
                row.operator("object.easyref_hide_refs_settings", text="", icon_value=icon.icon_id).ref = ref.name
            
            row.operator("object.easyref_delete_ref", text="", icon='X').ref = ref.name

            if ref.get("easyref_empty_ref_visible"):
                row = col.row()
                row.separator()
                if not ref.use_empty_image_alpha:
                    row = col.row()
                    row.prop(ref, "use_empty_image_alpha", text="Opacity")
                else:
                    row = col.row()
                    row.prop(ref, "use_empty_image_alpha", text="")
                    row.prop(ref, "color", text="Opacity", index=3, slider=True)

                # DEPTH
                row = col.row(align=True)
                row.label(text="Detph")
                row = col.row(align=True)
                row.prop(ref, "empty_image_depth", text="Depth", expand=True)

                # SIDE
                row = col.row(align=True)
                row.label(text="Side")
                row = col.row(align=True)
                row.prop(ref, "empty_image_side", text="Side", expand=True)

                # ORTHO/PERSP
                row = col.row(align=True)
                row.label(text="Show In")
                row = col.row(align=True)
                row.prop(ref, "show_empty_image_orthographic", text="Orthographic")
                row = col.row(align=True)
                row.prop(ref, "show_empty_image_perspective", text="Perspective")
                row = col.row(align=True)
                row.prop(ref, "show_empty_image_only_axis_aligned", text="Only Axis Aligned")

                row = col.row(align=True)
                row.prop(ref, "empty_display_size", text="Size")
                row = col.row(align=True)
                row.prop(ref, "empty_image_offset", text="Offset X", index=0)
                row = col.row(align=True)
                row.prop(ref, "empty_image_offset", text="Offset Y", index=1)
                row = col.row()
                row.label(text="Path")
                row = col.row()
                row.template_ID(ref, "data", open="image.open", unlink="ref.unlink_data")

                row = col.row(align=True)
                row.label(text="Transforms")
                row = col.row(align=True)
                row.prop(ref, "location", index=0, text='X')
                row = col.row(align=True)
                row.prop(ref, "location", index=1, text='Y')
                row = col.row(align=True)
                row.prop(ref, "location", index=2, text='Z')

def ref_view(self, context):
    layout = self.layout
    icons = load_icons()
    easyref_props = context.scene.easyref_props
    easyref_empties = context.scene.easyref_empties
    ref_view_collection = next((col for col in bpy.data.collections if col.name.startswith("RV")), None)
    ref_view_collections = [col for col in bpy.data.collections if col.name.startswith("RV") or col.name.startswith("RV_")]
    ref_view_area = get_ref_view_area(context)
    has_empties = ref_view_collection and any(obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE' for obj in ref_view_collection.objects)
    has_ref_view = easyref_props.has_ref_view
    
    # Si pas de ref view pas d'empties
    if not ref_view_area and not has_ref_view and not has_empties:
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.5
        icon = icons.get("icon_add_ref_view")
        row.operator("object.easyref_load_multiple_refs_popup", text="Add References", icon_value=icon.icon_id).create_or_add_new_references = "CREATE"

    # Si ref view et d'empties
    elif ref_view_area and has_ref_view and has_empties:

        if context.area == ref_view_area:
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_set_ref_view")
            row.operator("object.easyref_load_multiple_refs_popup", text="Add New References", icon_value=icon.icon_id).create_or_add_new_references = "ADD"

            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            if has_empties:
                row.operator("object.easyref_center_ref_view", text="Center View", icon='SNAP_FACE_CENTER')
            else:
                row.operator("object.easyref_center_ref_view", text="Frame References", icon='SEQ_STRIP_META')
            
            if len(context.selected_objects) > 1:
                row.scale_y = 1.5
                row.operator("object.easyref_grid_refs", text="Grid Selected", icon='MESH_GRID')

            # All Collections
            if len(ref_view_collections) > 1:
                box = layout.box()
                row = box.row(align=True)
                icon = icons.get("icon_easyref_edit")
                row.scale_y = 1.5
                row.operator("object.easyref_select_all_refview_objects", text="ALL REFERENCES", icon_value=icon.icon_id)
                row.operator("object.easyref_center_ref_view", text="", icon='SNAP_FACE_CENTER')
                row.operator("object.easyref_toggle_all_refview_collections", text="", icon='RESTRICT_VIEW_OFF')
                row.operator("object.easyref_delete_all_refview", text="", icon='X')
            
            # Collections
            if ref_view_collections:
                for collection in ref_view_collections:
                    box = layout.box()
                    row = box.row(align=True)
                    icon = icons.get("icon_easyref_edit")
                    row.operator("object.easyref_select_collection_objects", text=collection.name, icon_value=icon.icon_id).collection_name = collection.name
                    row.operator("object.easyref_frame_collection_objects", text="", icon='SNAP_FACE_CENTER').collection_name = collection.name
                    row.prop(collection, "hide_viewport", text="")
                    row.operator("object.easyref_delete_collection", text="", icon='X').collection_name = collection.name

            if ref_view_collections and context.selected_objects and context.selected_objects[0].type == 'EMPTY':
                box = layout.box()
                row = box.row(align=True)
                row.scale_y = 1.5
                row.operator("object.easyref_add_to_new_collection", text="Add to New Collection", icon='OUTLINER_COLLECTION')
                if len(ref_view_collections) > 1:
                    row = box.row(align=True)
                    row.scale_y = 1.5
                    row.operator("object.easyref_move_to_collection", text="Move to Collection", icon='OUTLINER_COLLECTION')
                
                row = box.row(align=True)
                row.operator("object.easyref_flip_references_horizontal", text="Flip Horizontal", icon='TRIA_RIGHT')
                row.operator("object.easyref_flip_references_vertical", text="Flip Vertical", icon='TRIA_UP')
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.prop(easyref_empties, "empty_image_offset_x", text="Offset X")
                row = col.row(align=True)
                row.prop(easyref_empties, "empty_image_offset_y", text="Offset Y")


        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.5
        icon = icons.get("icon_remove_ref_view")
        row.operator("object.easyref_close_ref_view", text="Close Ref View", icon_value=icon.icon_id)

    # Si ref view pas d'empties
    elif ref_view_area and has_ref_view  and not has_empties:
        
        if context.area == ref_view_area:
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_set_ref_view")
            row.operator("object.easyref_load_multiple_refs_popup", text="Add New References", icon_value=icon.icon_id).create_or_add_new_references = "ADD"

        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.5
        icon = icons.get("icon_remove_ref_view")
        row.operator("object.easyref_close_ref_view", text="Close Ref View", icon_value=icon.icon_id)

    # Si pas de ref view mais d'empties
    elif not ref_view_area and not has_ref_view  and has_empties:
        
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.5
        icon = icons.get("icon_add_ref_view")
        row.operator("object.easyref_show_ref_view", text="Show Refererence View", icon_value=icon.icon_id)

    # Si pas de ref view et pas d'empties
    # elif get_ref_view_area(context) is None and has_empties:
    else:
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.5
        icon = icons.get("icon_add_ref_view")
        row.operator("object.easyref_show_ref_view", text="Show Refererence View", icon_value=icon.icon_id)

def Easyref_UI_Menu(self, context):
    WM = context.window_manager
    layout = self.layout
    cam = context.scene.camera
    icons = load_icons()
    camref_list = [cam for cam in context.scene.objects if "easyref" in cam]
    easyref_settings = context.scene.easyref_settings
    ref_view_area = get_ref_view_area(context)

    if context.area != ref_view_area:
        header, panel = layout.panel_prop(easyref_settings, "show_cam_ref_panel")
        icon = icons.get("icon_cam_active")
        header.label(text="CAMERA REFERENCES", icon_value=icon.icon_id)
        if panel:
            if not WM.modal_ON:
                if not WM.annotations_ON:
                    box = layout.box()
                    row = box.row(align=True)
                    row.scale_y = 1.5
                    icon = icons.get("icon_cam_active")
                    op = row.operator("easyref.images_refs_actions", text="Add Cam Reference", icon_value=icon.icon_id)
                    op.add_cam_and_ref = True
                    op.add_ref = False
                    op.launch_modal = False
                    if camref_list:
                        row.operator("easyref.remove_all_cam_ref", text="", icon='X')

            EasyRef_Cam(self, context, layout, WM)

        header, panel = layout.panel_prop(easyref_settings, "show_empties_ref_panel")
        icon = icons.get("icon_easyref_cams")
        header.label(text="IMAGES REFERENCES",icon_value=icon.icon_id)
        if panel:
            EasyRef_Empties(self, context)
    
    header, panel = layout.panel_prop(easyref_settings, "show_ref_view_panel")
    icon = icons.get("icon_add_ref_view")
    header.label(text="REFERENCES VIEW",icon_value=icon.icon_id)
    if panel:
        ref_view(self, context)

class PANEL_PT_easyref(Panel):
    bl_label = "EASYREF"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Easyref"

    def draw_header(self, context):
        layout = self.layout
        icons = load_icons()
        icon = icons.get("icon_easyref")
        layout.label(text="", icon_value=icon.icon_id)

    def draw(self, context):
        Easyref_UI_Menu(self, context)

CLASSES =  [PANEL_PT_easyref]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass