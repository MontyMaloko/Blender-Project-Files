This directory is a convenient place to put
fonts where Reportlab will find them. If running
in a server environment, this is a good place to
put Type 1 fonts needed by your application. If
in a desktop environment, you might prefer to add
your font directories to the T1SearchPath in
reportlab/rl_config.py instead.

