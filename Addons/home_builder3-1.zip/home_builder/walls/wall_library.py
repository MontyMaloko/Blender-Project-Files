from . import data_walls

class Wall(data_walls.Mesh_Wall):
    show_in_library = True

    def __init__(self):
        pass


# class Wall_Framed(data_walls.Wall_Framed):
#     show_in_library = True

#     def __init__(self):
#         pass


# class Die_Wall(data_walls.Mesh_Wall):
#     show_in_library = True
#     category_name = "Walls"

#     def __init__(self):
#         pass


# class Wall_Brick(data_walls.Wall_Brick):
#     show_in_library = True

#     def __init__(self):
#         pass


# class Stone_Wall(data_walls.Mesh_Wall):
#     show_in_library = True

#     def __init__(self):
#         pass