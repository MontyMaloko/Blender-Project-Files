# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
# noinspection PyUnresolvedReferences
import bpy
major, minor, rev = bpy.app.version

# noinspection PyUnresolvedReferences
from bpy.props import (
    BoolProperty,
    StringProperty,
    EnumProperty,
    IntVectorProperty,
    IntProperty,
    FloatProperty
)
from mathutils import Vector, Matrix
from math import floor, atan2, pi, radians, sin, cos, degrees
from bpy_extras import view3d_utils
from .archipack_iconmanager import icons
from .archipack_abstraction import (
    Callbacks,
    ArchipackObjectsManager,
    context_override,
    X_AXIS,
    Z_AXIS
)

from .archipack_gl import (
    GlPolygon, GlPolyline,
    GlLine, GlText
    )
from .archipack_snap import (
    FREEMOVE,
    CREATE,
    USE_SLCADSNAP,
    ARCHIPACK_OT_snap
)

from random import seed, uniform
from .archipack_prefs import get_prefs

objman = ArchipackObjectsManager()
version = (0, 0, 0)


import logging
import time
logger = logging.getLogger(__package__)


FAR_AWAY = Vector((1e32, 1e32, 1e32))


def get_enum(self, context):
    return icons.enum(context, self.__class__.__name__, "json")


def preset_operator(self, context):
    import os
    base_preset, ext = os.path.splitext(self.preset)
    bpy.ops.archipack.preset_loader(filepath="{}.json".format(base_preset))


def update_source(self, context):
    self.update_source(context)
    self.update(context)
    self.cleanup_user_defined_objects(context, bpy.data.objects)


class ArchipackPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Archipack'
    bl_translation_context = "archipack"

    def draw_common(self, context, layout, draw_animation=True, draw_manipulate=True):
        if hasattr(context.window_manager, "archipack"):
            wm = context.window_manager.archipack
            self.draw_translate(context, layout)

            row = layout.row(align=True)
            if draw_manipulate:
                self.draw_prop(context, layout, row, wm, "auto_manipulate", icon='AUTO', emboss=True)
            if not wm.auto_manipulate:
                self.draw_op(context, layout, row, "archipack.manipulate", icon='VIEW_PAN')
            self.draw_op(context, layout, layout, "archipack.delete", icon="TRASH")

        # support for animation -> disabled as there is no context available while rendering
        prefs = get_prefs(context)
        if prefs.support_animation and draw_animation:
            o = context.active_object
            if o is not None and hasattr(context.scene, "archipack_animation"):
                row = layout.row(align=True)
                self.draw_prop(context, layout, row, o, "archipack_animation", icon="ACTION", emboss=True)
                icon = "HIDE_ON"
                if context.scene.archipack_animation:
                    icon = "HIDE_OFF"
                self.draw_prop(context, layout, row, context.scene, "archipack_animation", icon=icon)


class ArchipackGenericOperator(ArchipackObjectsManager):
    """
     Generic operator working on any archipack object
     Provide generic datablock accessor
     Polling for selected and active archipack objects
    """
    bl_category = 'Archipack'
    bl_options = {'INTERNAL', 'UNDO'}
    translation_context = "archipack"

    @classmethod
    def poll(cls, context):
        o = cls.get_active_object(context)
        return o and ArchipackObjectsManager.is_selected(o) and cls.filter(o)

    @classmethod
    def filter(cls, o):
        return cls.archipack_filter(o)

    def datablock(self, o):
        """
         Return archipack datablock from object
        """
        return self.archipack_datablock(o)


class ArchipackObject(ArchipackObjectsManager):
    """
        Shared property of archipack's objects PropertyGroup
        provide basic support for copy to selected
        and datablock access / filtering by object
    """
    bl_translation_context = "archipack"

    version: IntVectorProperty(
        size=3,
        default=(0, 0, 0)
    )

    def __init__(self):
        # self.previously_selected = []
        # self.previously_active = None
        self.auto_manipulate_state = True
        # flag to allow manipulate mode change
        self.auto_manipulate_flag = True

    @property
    def random_color(self):
        return Vector((uniform(0.0, 1.0), uniform(0.0, 1.0), uniform(0.0, 1.0), 1))

    def iskindof(self, o, typ):
        """
            return true if object contains databloc of typ name
        """
        return o.data is not None and typ in o.data

    @property
    def category(self):
        return self.__class__.__name__[10::]

    @classmethod
    def filter(cls, o):
        """
            Filter object with this class in data
            return
            True when object contains this datablock
            False otherwhise
            usage:
            class_name.filter(object) from outside world
            self.__class__.filter(object) from instance
        """
        res = False
        try:
            a = getattr(o.data, cls.__name__)[0]
            res = True
        except:
            pass
        if not res:
            try:
                a = getattr(o, cls.__name__)[0]
                res = True
            except:
                pass
        return res

    @classmethod
    def poll(cls, o):
        """
            Filter object with this class in data
            return
            True when object contains this datablock
            False otherwhise
            usage:
            class_name.filter(object) from outside world
            self.__class__.filter(object) from instance
        """
        res = False
        try:
            res = ArchipackObjectsManager.is_selected(o) and cls.filter(o)
        except:
            pass
        return res

    @classmethod
    def datablock(cls, o):
        """
            Retrieve datablock from base object
            return
                datablock when found
                None when not found
            usage:
                class_name.datablock(object) from outside world
                self.__class__.datablock(object) from instance
        """
        d = None
        try:
            d = getattr(o.data, cls.__name__)[0]
        except:
            pass

        if d is None:
            try:
                d = getattr(o, cls.__name__)[0]
            except:
                pass

        return d

    def on_copy(self, context, obj):
        """ On create handler
                Usage : Register handlers on global dict
                :param context:
                :param obj:
                :return:
                """
        Callbacks.call("copy", context, obj, self)

    def _delete_callback(self, context, obj):
        # print("%s.on_delete(%s)" % (self.__class__.__name__.capitalize(), obj.name))
        Callbacks.call("delete", context, obj, self)

    def ifc_representation(self, context, o, representation_id="FootPrint"):
        return None

    def update_source(self, context):
        return

    def on_delete(self, context, obj):
        """ Default on_delete, delete selected objects of same kind
        :param context:
        :param obj:
        :return:
        NOTE: In a perfect world, each object should delete her own relationships, but ..
        each object must handle other ones of same kind to prevent infinite loop calls.
        """
        self._delete_callback(context, obj)
        logger.debug("%s.on_delete(%s)" % (self.__class__.__name__.capitalize(), obj.name))
        for o in context.selected_objects:
            if self.filter(o) and o.name != obj.name:
                self.delete_object(context, o)
        # cleanup pointer based preset object's childs not linked to scene
        self.cleanup_user_defined_objects(context)

    def disable_auto_manipulate(self, context):
        try:
            if self.auto_manipulate_flag:
                # print("disable_auto_manipulate")
                wm = self.get_context_value(context, "window_manager").archipack
                # 2nd call on instances ??
                self.auto_manipulate_flag = False
                self.auto_manipulate_state = wm.auto_manipulate
                wm.auto_manipulate = False
        except:
            # raise Exception("disable_auto_manipulate")
            pass
        try:
            wm = self.get_context_value(context, "window_manager").archipack
            # fails at render time
            if wm.update_cursor:
                context.window.cursor_set("WAIT")
        except:
            pass

    def restore_auto_manipulate(self, context):
        try:
            if not self.auto_manipulate_flag:
                # print("restore_auto_manipulate")
                self.auto_manipulate_flag = True
                wm = self.get_context_value(context, "window_manager").archipack
                if self.auto_manipulate_state:
                    wm.auto_manipulate = self.auto_manipulate_state
        except:
            # raise Exception("restore_auto_manipulate")
            pass
        try:
            wm = self.get_context_value(context, "window_manager").archipack
            if wm.update_cursor:
                context.window.cursor_set("DEFAULT")
        except:
            pass

    def find_in_selection(self, context, auto_update=True):
        """
            find witch selected object this datablock instance belongs to
            provide support for "copy to selected"
            XXX provide support for "context.object" override and preserve active one
            return
            object or None when instance not found in selected objects
            
            context.active_object is None when object's layer is hidden
            context.object does work in any case

            In render context there is no selection available
        """
        if auto_update is False:
            return None

        o = self.get_active_object(context)

        if self.__class__.datablock(o) == self:
            self.disable_auto_manipulate(context)
            Callbacks.call("update", context, o, self)

            return o

        selected = self.get_context_value(context, "selected_objects")

        for o in selected:
            if self.__class__.datablock(o) == self:
                self.disable_auto_manipulate(context)
                Callbacks.call("update", context, o, self)
                return o

        return None

    def restore_context(self, context):
        """
         restore context
        """
        # context.view_layer.update()
        logger.debug("restore_context")

        # bpy.ops.object.select_all(action="DESELECT")
        #
        # try:
        #     for o in self.previously_selected:
        #         self.select_object(context, o)
        # except:
        #     pass
        #
        # if self.previously_active is not None:
        #     logger.debug("restore_context: %s", self.previously_active.name)
        #
        # self.select_object(context, self.previously_active, True)

        self.restore_auto_manipulate(context)
        # self.previously_selected = None
        # self.previously_active = None

    def id_mat(self, index, source=None):
        """ Limit material index to number of materials
        :param index:
        :param source: source obj with .idmat array, allow override on parent from childs
        :return:
        """
        if source is None:
            _source = self
        else:
            _source = source
        _idx = _source.idmat[index]
        if _idx < len(self.id_data.materials):
            return _idx
        return 0

    def shade_smooth(self, context, o, smooth_angle):
        m = o.data
        # t = time.time()
        if self.minimum_blender_version(4, 1, 0):

            with context_override(context, o, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.object.shade_smooth_by_angle, {
                    "angle": smooth_angle
                })

        elif self.minimum_blender_version(3, 3, 0):
            # fix shade issue in 3.3+
            if not m.use_auto_smooth or m.auto_smooth_angle != smooth_angle:
                with context_override(context, o, [o]) as ctx:
                    self.call_operator(context, ctx, bpy.ops.object.shade_smooth, {
                        "use_auto_smooth": True,
                        "auto_smooth_angle": smooth_angle
                    })

                    # if bpy.ops.object.shade_smooth.poll(ctx):
                    #    bpy.ops.object.shade_smooth(ctx, use_auto_smooth=True, auto_smooth_angle=smooth_angle)
        else:
            if not m.use_auto_smooth or m.auto_smooth_angle != smooth_angle:
                m.use_auto_smooth = True
                m.auto_smooth_angle = smooth_angle
            with context_override(context, o, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.object.shade_smooth)
                # if bpy.ops.object.shade_smooth.poll(ctx):
                #    bpy.ops.object.shade_smooth(ctx)
        # logger.debug("bpy.ops.object.shade_smooth %.4f" % (time.time() - t))

    def bevel_modifier(self, o, width=0.0005):
        mod = self.find_modifier_by_type(o, "BEVEL")
        if mod is None:
            mod = o.modifiers.new("Bevel", "BEVEL")
        mod.limit_method = 'ANGLE'
        mod.offset_type = 'WIDTH'
        mod.width = width
        mod.harden_normals = True
        mod.segments = 4
        mod.use_clamp_overlap = False


class ArchipackCreateTool(ArchipackObjectsManager):
    """
        Shared property of archipack's create tool Operator
    """
    bl_category = 'Archipack'
    bl_options = {'INTERNAL', 'UNDO'}

    filepath: StringProperty(
        options={'SKIP_SAVE'},
        name="Preset",
        description="Full filename of python preset to load at create time",
        default=""
    )

    act = None

    @property
    def archipack_category(self):
        """
            return target object name from ARCHIPACK_OT_object_name
        """
        return self.bl_idname[13:]

    def load_preset(self, context, o, d, auto_update=True):
        """
            Load python preset
            d: archipack object datablock
            preset: full filename.py with path
        """

        d.auto_update = False

        # print("ArchipackCreateTool.Load preset")

        if self.filepath != "":
            try:
                #
                bpy.ops.archipack.preset_loader(filepath=self.filepath)
                # print("ArchipackCreateTool.Load preset success")
            except:
                logger.debug("Archipack unable to load preset file : %s" % self.filepath)
                pass

        d.auto_update = auto_update

        global version
        d.version = version

        Callbacks.call("create", context, o, d)

    def add_material(self, context, o, material='', category=None):
        # skip if preset allready add material
        if "archipack_material" in o:
            logger.debug("add_material for %s on %s already exists" % (self.archipack_category, o.name))
            return
        # enable viewport transparency
        o.show_transparent = True
        try:
            if category is None:
                category = self.archipack_category
            with context_override(context, o, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.archipack.material, {
                    "category":category,
                    "material":material
                })
                return
        except Exception as ex:
            import traceback
            traceback.print_exc()
            logger.debug("Archipack %s materials not found" % self.archipack_category)
            pass

    def invoke(self, context, event):
        o = self.get_active_object(context)
        if self.archipack_filter(o):
            self.act = o
        return self.execute(context)

    def add_to_reference(self, context, o):
        # no reference when rendering in background
        if bpy.app.background:
            return

        ref = self.get_reference_point(self.act)
        if ref is None:
            ref = o
        with context_override(context, ref, [o]) as ctx:
            self.call_operator(context, ctx, bpy.ops.archipack.add_reference_point)


class ArchipackDrawTool(ArchipackObjectsManager):
    """
        Draw tools
    """
    bl_category = 'Archipack'
    bl_options = {'INTERNAL', 'UNDO'}

    disabled_walls = {}
    optimize_walls = True
    snap_threshold = 0.5
    rotate_90 = 0

    use_small_steps = False
    use_constraint = True
    _angle = 0

    o = None
    state = FREEMOVE
    flag_create = False
    flag_next = False
    takemat = None
    takeloc = Vector((0, 0, 0))

    feedback = None
    sel = []
    act = None

    parent = None

    quick_edit_state = False

    wall_part1 = None
    wall_line1 = None
    line = None
    label = None
    label_a = None

    def closest_point_on_ray(self, vec, ray):
        dl = ray.length_squared
        if dl == 0:
            return 0
        t = vec.dot(ray) / dl
        return t

    def round_to_step(self, value, step):
        remain = (value % step)
        value -= remain
        if remain > 0.5 * step:
            value += step
        return value

    def constraint(self, context, sp, delta, constraint):
        """
        :delta: direction
        :constraint: constraint direction
        """
        # signed angle between constraint and vec
        prefs = get_prefs(context)

        if not self.use_constraint or not prefs.draw_tool_ortho:
            # if USE_SLCADSNAP and ARCHIPACK_OT_snap.is_snapping():
            #    return ARCHIPACK_OT_snap.apply_constraint(sp.takeloc, delta)
            return delta

        angle = float(prefs.step_angle)
        dist, fac = map(float, prefs.step_dist.split(","))

        if self.use_small_steps:
            dist /= fac

        u, v = constraint, delta
        a = degrees(atan2(u.x * v.y - u.y * v.x, u.x * v.x + u.y * v.y))
        a = self.round_to_step(a, angle)
        self._angle = radians(a)
        a = atan2(u.y, u.x) + radians(a)
        d = Vector((cos(a), sin(a), 0))

        t = self.closest_point_on_ray(v, d)
        t = self.round_to_step(t, dist)

        if USE_SLCADSNAP and ARCHIPACK_OT_snap.is_snapping():
            return ARCHIPACK_OT_snap.apply_constraint(sp.takeloc, t * d)

        return t * d

    def region_2d_to_orig_and_vect(self, context, event):

        region = context.region
        rv3d = context.region_data
        coord = (event.mouse_region_x, event.mouse_region_y)
        vec = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        orig = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

        return rv3d.is_perspective, orig, vec

    def isect_vec_plane(self, p0, vec, p_co, p_no, epsilon=1e-6):
        """
        p0, vec: define the line
        p_co, p_no: define the plane:
            p_co is a point on the plane (plane coordinate).
            p_no is a normal vector defining the plane direction;
                 (does not need to be normalized).
        return a Vector or None (when the intersection can't be found).
        """
        u = vec
        d = p_no.dot(u)

        if abs(d) > epsilon:
            w = p0 - p_co
            t = -p_no.dot(w) / d
            return p0 + t * u
        else:
            # The segment is parallel to plane
            return None

    def mouse_to_plane(self, context, event, origin=Vector((0, 0, 0)), normal=Vector((0, 0, 1))):
        """
            convert mouse pos to 3d point over plane defined by origin and normal
            return None if the point is behind camera view
        """
        is_perspective, orig, vec = self.region_2d_to_orig_and_vect(context, event)
        # pt = intersect_line_plane(orig, orig + vec, origin, normal, False)
        pt = self.isect_vec_plane(orig, vec, origin, normal)

        # fix issue with parallel plane (front or left ortho view)
        if pt is None:
            pt = self.isect_vec_plane(orig, vec, origin, Vector((0, 1, 0)))

        if pt is None:
            pt = self.isect_vec_plane(orig, vec, origin, Vector((1, 0, 0)))
            # pt = intersect_line_plane(orig, orig + vec, origin, vec, False)

        if pt is None:
            return None

        if is_perspective:
            # Check if point is behind point of view (mouse over horizon)
            y = Vector((0, 0, 1))
            # x = vec.cross(y)
            x = y.cross(vec)
            itM = Matrix([
                [x.x, y.x, vec.x, orig.x],
                [x.y, y.y, vec.y, orig.y],
                [x.z, y.z, vec.z, orig.z],
                [0, 0, 0, 1]
                ]).inverted()
            res = itM @ pt

            if res.z < 0:
                return None

        return pt

    def is_snapping(self, context, event, pt):
        """
        :param context:
        :param event:
        :param pt: point in world space
        :return:
        """
        if USE_SLCADSNAP:
            return ARCHIPACK_OT_snap.is_snapping()

        is_perspective, orig, vec = self.region_2d_to_orig_and_vect(context, event)
        if vec.x != 0 and vec.y != 0:
            x = vec.cross(Vector((0, 0, 1)))
        else:
            x = vec.cross(Vector((1, 0, 0)))
        y = x.cross(vec)
        sp = Matrix([
            [x.x, y.x, vec.x, orig.x],
            [x.y, y.y, vec.y, orig.y],
            [x.z, y.z, vec.z, orig.z],
            [0, 0, 0, 1]
        ]).inverted() @ pt
        return abs(sp.x) > 0.001 or abs(sp.y) > 0.001

    def mouse_to_scene_raycast(self, context, event):
        """
            convert mouse pos to 3d point over plane defined by origin and normal
        """
        is_perspective, orig, vec = self.region_2d_to_orig_and_vect(context, event)
        res, pos, normal, face_index, obj, matrix_world = self.scene_ray_cast(
            context,
            orig,
            vec)

        return res, pos, normal, face_index, obj, matrix_world

    def restore_walls(self, context):
        """
         Enable finish on wall
        """
        for name in self.disabled_walls.keys():
            # print("restore_walls ", name)
            o = self.get_scene_object(context, name.strip())
            if o is not None:
                d = o.data.archipack_wall2[0]
                with context_override(context, o, [o]) as ctx:
                    d.finish_enable = True
                    d.update(ctx)
        self.disabled_walls.clear()

    def mouse_hover_wall(self, context, event):
        """
            convert mouse pos to matrix at bottom of surrounded wall, y oriented outside wall
        """
        res = False
        o = None

        if USE_SLCADSNAP and ARCHIPACK_OT_snap.is_snapping():
            snapitem = ARCHIPACK_OT_snap.get_active_snapitem()
            o = snapitem.target
            pt = ARCHIPACK_OT_snap.get_placeloc()
            y = snapitem.normal
            res = o is not None and hasattr(o, "data")
            # print("ARCHIPACK_OT_snap.is_snapping()")

        else:
            # print("ArchipackObject.mouse_to_scene_raycast()")
            res, pt, y, i, o, tM = self.mouse_to_scene_raycast(context, event)

        # print("ArchipackObject.mouse_hover_wall(%s)" % res)

        if res and o.data is not None:

            z = Vector((0, 0, 1))

            width = 0
            z_offset = 0
            res = False
            if 'archipack_wall2' in o.data:

                res = True

                d = o.data.archipack_wall2[0]
                width = d.width
                z_offset = d.z_offset
                g = d.get_generator(o)
                g.segs = g.axis.segs
                index, t = g.find_closest_segment(pt, width)
                s0 = g.segs[index]
                n = s0.normal(t, 1)
                pt = n.p0

                # Fix regression door always look outside
                # x = s0.v_normalized
                # y = -n.v_normalized
                y = -y
                x = y.cross(z)

                if self.optimize_walls and d.finish_enable and (len(d.finish) > 0 or len(d.finish2) > 0):
                    with context_override(context, o, [o]) as ctx:
                        d.finish_enable = False
                        d.update(ctx)
                    self.disabled_walls[o.name] = o

            elif ('archipack_wall' in o.data or self.has_flag(o, "custom_wall")):
                y = -y
                x = y.cross(z)
                # one point on the opposite to raycast side (1 unit (meter) inside)
                p0 = pt + y.normalized()
                # direction
                dp = -y.normalized()
                # cast another ray to find wall depth
                attempt = 0
                while res is False and attempt < 5:
                    res, pos, normal, face_index, obj, matrix_world = self.scene_ray_cast(context, p0, dp)
                    # must hit another face or another object
                    res = res and (i != face_index or obj.name != o.name)
                    p0 -= dp
                    attempt += 1

                if res:
                    width = (pt - pos).to_2d().length
                    pt += (0.5 * width) * y.normalized()

            if res:
                # pt += (0.5 * width) * y.normalized()
                return True, Matrix([
                    [x.x, y.x, z.x, pt.x],
                    [x.y, y.y, z.y, pt.y],
                    [x.z, y.z, z.z, o.matrix_world.translation.z],
                    [0, 0, 0, 1]
                ]), o, width, y, z_offset

        return False, Matrix(), None, 0, Vector(), 0

    def _snap_dist(self, context, origin, direction, ref, snap_inverse):
        res, p, normal, face_index, obj, matrix_world = \
            self.scene_ray_cast(context, origin, direction)
        if res:
            # p is in world space, turn into local one
            return (snap_inverse @ p) - ref, normal
        return FAR_AWAY, Vector()

    def snap(self, context, center, mini, maxi, snap_matrix, normal_matrix):
        """
        Snap objects to neighbors
        """
        snap_inverse = snap_matrix.inverted()
        snap = False
        dp = Vector()
        x_axis = snap_matrix.col[0].to_3d()
        x = [
            self._snap_dist(context, center, x_axis, maxi, snap_inverse),
            self._snap_dist(context, center, -x_axis, mini, snap_inverse)
        ]
        x.sort(key=lambda i: abs(i[0].x))
        px, nx = x[0]
        minx = abs(px.x)
        if minx < self.snap_threshold:
            dp.x = px.x
            snap = True

        y_axis = snap_matrix.col[1].to_3d()
        y = [
            self._snap_dist(context, center, y_axis, maxi, snap_inverse),
            self._snap_dist(context, center, -y_axis, mini, snap_inverse)
        ]
        y.sort(key=lambda i: abs(i[0].y))
        py, ny = y[0]
        miny = abs(py.y)
        if miny < self.snap_threshold:
            dp.y = py.y
            snap = True

        #               x
        #     \         |\
        #    / \ wall   | \ min/max x
        #  n/   \      n| |\ px
        #  x_ |__\      |_|_\
        #      p.x       wall
        if minx < miny:
            # normal in rotation inverse space
            nx = normal_matrix @ nx
            # always use positive normal
            if nx.x < 0:
                nx = -nx
            # rotate so x is perpendicular to face
            angle = atan2(nx.y, nx.x)
            dmin = minx
        else:
            ny = normal_matrix @ ny
            # always use positive normal
            if ny.y < 0:
                ny = -ny
            # rotate so x is parallel to face
            angle = atan2(-ny.x, ny.y)
            dmin = miny

        return snap, angle, dp, dmin

    def bound_box(self, o, space=None):
        """returns mini, maxi, size center of components in local parent object space or in given space"""
        if space is not None:
            itM = space @ o.matrix_world.inverted()
        else:
            itM = o.matrix_world.inverted()
        objs = []
        self.rec_get_childrens(o, objs)
        x, y, z = list(zip(*[itM @ c.matrix_world @ Vector(p) for c in objs for p in c.bound_box]))
        mini, maxi = Vector((min(x), min(y), min(z))), Vector((max(x), max(y), max(z)))
        size = maxi - mini
        center = 0.5 * (mini + maxi)
        return mini, maxi, size, center

    def handle_mouse_hover_floor(self, context, event, o, d, pt, normal, obj, tM):
        rM = Matrix.Rotation(self.rotate_90, 4, "Z")
        if event.ctrl:
            irM = rM.inverted()
            space = Matrix.Translation(pt)
            mini, maxi, size, _center = self.bound_box(o)
            # self.snap_threshold = 0.25 * min([size.x, size.y])
            center = space @ _center
            snap, angle, dp, dmin = self.snap(context, center, mini, maxi, space @ rM, irM)
            # recast along snapped face normal
            if angle != 0 and dmin < 1e32:
                space = space @ Matrix.Rotation(self.rotate_90 + angle, 4, "Z")
                snap, angle, dp, dmin = self.snap(context, center, mini, maxi, space, irM)
                return space @ Matrix.Translation(dp)
            elif snap:
                return Matrix.Translation(pt + dp) @ rM
        return Matrix.Translation(pt) @ rM

    def mouse_hover_floor(self, context, event, o, d):
        """
            convert mouse pos to matrix at bottom of surrounded wall, y oriented outside wall
        """
        res, pt, normal, face_index, obj, tM = self.mouse_to_scene_raycast(context, event)

        if res and obj.data is not None:
            if "archipack_floor" in obj.data or "archipack_slab" in obj.data:
                tM = self.handle_mouse_hover_floor(context, event, o, d, pt, normal, obj, tM)
                return True, tM, obj, 0, normal, 0

        return False, Matrix(), None, 0, Vector(), 0

    def get_datablock(self, o):
        raise NotImplementedError

    @property
    def z(self):
        return 0.1

    def init_gl(self):
        self.wall_part1 = GlPolygon((0.5, 0, 0, 0.2))
        self.wall_line1 = GlPolyline((0.5, 0, 0, 0.8))
        self.line = GlLine()
        self.label = GlText()
        self.label_a = GlText(unit_type="ANGLE")

    def sp_draw(self, sp, context):

        if self.state == CREATE:
            p0 = self.takeloc
        else:
            p0 = sp.takeloc

        p1 = sp.placeloc
        delta = p1 - p0
        # print("sp_draw state:%s delta:%s p0:%s p1:%s" % (self.state, delta.length, p0, p1))
        if delta.length == 0:
            return

        o = self.o
        d = self.get_datablock(o)
        if d is not None:
            if hasattr(d, "z"):
                z = d.z
            else:
                z = self.z
            g = d.get_generator()
            w = g.segs[-2]
            constraint = o.matrix_world.to_3x3() @ w.v
        else:
            z = self.z
            constraint = X_AXIS

        delta = self.constraint(context, sp, delta, constraint)
        p1 = p0 + delta

        logger.debug("ARCHIPACK_OT_wall2_draw.sp_draw")
        self.wall_part1.set_pos([p0, Vector((p0.x, p0.y, p0.z + z)), p1, Vector((p1.x, p1.y, p1.z + z))])
        self.wall_line1.set_pos([p0, p1, Vector((p1.x, p1.y, p1.z + z)), Vector((p0.x, p0.y, p0.z + z))])
        self.wall_part1.draw(context)
        self.wall_line1.draw(context)
        self.line.p = p0
        self.line.v = delta

        self.label.set_pos(context, self.line.length, self.line.lerp(0.5), self.line.v, normal=Vector((0, 0, 1)))
        self.label.draw(context)

        if self.use_constraint:
            prefs = get_prefs(context)
            if prefs.draw_tool_ortho:
                self.label_a.set_pos(context, self._angle, self.line.lerp(1), self.line.v, normal=Vector((0, 0, 1)))
                self.label_a.draw(context)

        self.line.draw(context)

    """
    
    
    def copy_material(self, context, o, d, _int, _ext):
        if _ext is not None:
            if _ext.material_override:
                id_mat = _ext.id_mat(MAT_PART_OUTSIDE)
            else:
                id_mat = d.id_mat(MAT_PART_OUTSIDE)
            self.mat_name = o.data.materials[id_mat].name
        if _int is not None:
            if _int.material_override:
                id_mat = _int.id_mat(MAT_PART_INSIDE)
            else:
                id_mat = d.id_mat(MAT_PART_INSIDE)
            self.mat_name = o.data.materials[id_mat].name
        
    def paste_material(self, context, o, d, _int, _ext):
        
        # Find if material is on the wall
        id_mat = None
        for i, mat in o.data.materials:
            if mat is not None and mat.name == self.mat_name:
                id_mat = i
                break
                
        if id_mat is None:
            id_mat = len(o.data.materials)
            o.data.materials.append(bpy.data.materials[self.mat_name])
            
        if _ext is not None:
            if not _int.override_material:
                _int.idmat[MAT_PART_INSIDE] = d.idmat[MAT_INSIDE]
            _ext.idmat[MAT_PART_OUTSIDE] = id_mat
            _ext.override_material = True
          
        if _int is not None:
            if not _ext.override_material:
                _ext.idmat[MAT_PART_OUTSIDE] = d.idmat[MAT_OUTSIDE]
            _int.idmat[MAT_PART_INSIDE] = id_mat
            _int.override_material = True
     
    def wall_material(self, context, event):
    
        o, d, _int, _ext, _seg, _t = self.wall_segment_under_mouse(self, context, event)
        if o is not None:
            if event.alt:
                self.copy_material(context, o, d, _int, _ext)
            else:
                self.paste_material(context, o, d, _int, _ext)
           
    def wall_segment_under_mouse(self, context, event):
    
        # Paste a material index over wall
        res, pt, y, i, o, tM = self.mouse_to_scene_raycast(context, event)

        if res and o.data is not None:

            # When pasting over other object, use face material index to identify slot

            if 'archipack_wall2' in o.data:

                d = o.data.archipack_wall2[0]
                g = d.get_generator(o)
                last = 1e32
                _seg = None
                id_mat = -1
                _ext = None
                _int = None
                _t = -1
                for _k, part in zip(g.outside.valid_segs, d.parts):
                    res, dist, t = _k.point_sur_segment(pt)
                    if res and abs(dist) < last:
                        last = abs(dist)
                        _seg = _k
                        _ext = part
                        _t = t
                  
                if last > 0.001:
                    for _k, part in zip(g.inside.valid_segs, d.parts):
                        res, dist, t = _k.point_sur_segment(pt)
                        if res and abs(dist) < last:
                            last = abs(dist)
                            _seg = _k
                            _int = part
                            _t = t
                            
                return o, d, _int, _ext, _seg, _t
                
            elif ('archipack_wall' in o.data or
                  'archipack_custom_wall' in o):
        
        return None, None, None, None, None, None
    """


class ArchipackArrayTool(ArchipackCreateTool):

    x: FloatProperty(
        name='Spacing',
        unit='LENGTH', subtype='DISTANCE',
        default=2.0, precision=5,
        description='Spacing, positive on the left'
    )
    count: IntProperty(
        name="Duplicates",
        min=1,
        default=2
    )
    first_location: FloatProperty(
        name='Offset',
        unit='LENGTH', subtype='DISTANCE',
        default=0.0, precision=5,
        description='Current offset from segment start'
    )
    objects_size: FloatProperty(
        name='Overall width',
        unit='LENGTH', subtype='DISTANCE',
        default=0.0, precision=5,
        description='Overall width of objects on segment'
    )
    available_space: FloatProperty(
        name='Avaliable',
        unit='LENGTH', subtype='DISTANCE',
        default=0.0, precision=5,
        description='Spacing, positive on the left'
    )
    gap_start: FloatProperty(
        name='Gap start',
        unit='LENGTH', subtype='DISTANCE',
        default=0.0, precision=5,
        description='Spacing, positive on the left'
    )
    gap_end: FloatProperty(
        name='Gap end',
        unit='LENGTH', subtype='DISTANCE',
        default=0.0, precision=5,
        description='Spacing, positive on the left'
    )
    limit_count: BoolProperty(
        name="Limit count",
        default=True
    )
    mode: EnumProperty(
        name="Mode",
        items=(
            ("START_END_COUNT", "(Auto) Start - End - Count", "Auto equal spacing"),
            ("COUNT", "(Auto) Count", "Equal space, half space on borders"),
            ("SPACING", "(Border) Spacing", "Auto equal space on borders"),
            ("START_COUNT_SPACING", "(Border) Start - Spacing - Count", ""),
            ("END_COUNT_SPACING", "(Border) End - Spacing - Count", ""),
            ("CUR_COUNT_SPACING", "(Current, Border) Spacing - Count", "About current location"),
            ("AXIS_SPACING", "(Axis) Spacing", "Auto equal space on borders"),
            ("AXIS_START_COUNT_SPACING", "(Axis) Start - Spacing- Count", ""),
            ("AXIS_END_COUNT_SPACING", "(Axis) End - Spacing - Count ", ""),
            ("AXIS_CUR_COUNT_SPACING", "(Current, Axis) Spacing - Count", "About current location")
        )
    )

    distance_from_top: FloatProperty(
        min=0.0,
        name="Distance from top of wall",
        description="Space to keep at top of wall",
        default=0.5
    )

    levels_mode: EnumProperty(
        name="Levels Mode",
        items=(
            ("COUNT", "Count", "Fill available height using n rows"),
            ("SPACING", "Spacing", "Fill using spacing"),
            ("COUNT_SPACING", "Count and spacing", "Fill using count and spacing")
        ),
        default="COUNT_SPACING"
    )

    levels: IntProperty(
        min=1,
        name="Levels",
        description="Duplicate along z axis",
        default=1
    )
    levels_spacing: FloatProperty(
        min=0.1,
        name="Level height",
        description="Space between levels",
        default=3.0
    )

    altitudes = {}
    available_vertical = 0
    max_height = 0

    def filter_object(self, o):
        raise NotImplementedError

    def get_object_datablock(self, o):
        raise NotImplementedError

    def make_array(self, context, sel):
        startplace, spacing, count = self.distribute_objects()
        if count < 1:
            return
        link = len(self.segment_t) < 2

        if self.levels_mode == 'COUNT':
            max_rows = max(1, int(self.available_vertical / self.max_height))
            rows = min(max_rows, self.levels)
            row_spacing = self.available_vertical / rows
        elif self.levels_mode == 'SPACING':
            rows = int(self.available_vertical / self.levels_spacing)
            row_spacing = self.levels_spacing
        else:
            min_height = max(self.max_height, self.levels_spacing)
            max_rows = max(1, int(self.available_vertical / min_height))
            rows = min(max_rows, self.levels)
            row_spacing = min_height

        # base wall
        wall = self.get_scene_object(context, self.wall_name)
        itM = wall.matrix_world.inverted()

        for o in sel:

            d = self.get_object_datablock(o)
            if d is not None:

                base_altitude = (o.matrix_world.translation).z

                # find walls this hole belong
                if "archipack_assembly" in o.data:
                    for c in o.children:
                        cd = self.get_object_datablock(c)
                        hole = cd.find_hole(c)
                        if hole is not None:
                            break
                else:
                    hole = d.find_hole(o)

                ref = self.get_reference_point(o)
                # get custom wall, wall and wall2
                objs = self.filter_selection_loose(ref.children)

                # Boolan modifier
                walls_holes = set()
                # Geometry nodes
                walls_nodes = set()

                for key, walls in objs.items():
                    if "wall" in key:
                        for name in walls:
                            c = self.get_scene_object(context, name)
                            m = self.get_archipack_bool_modifier(c)
                            if m is not None:
                                if m.type == "BOOLEAN":
                                    if m.object is not None:
                                        basis = m.object
                                        for h_mod in basis.modifiers:
                                            if h_mod.type == "BOOLEAN" and h_mod.object == hole:
                                                walls_holes.add(basis)

                                elif m.type == "NODES":
                                    for n in m.node_group.nodes:
                                        if n.type == "OBJECT_INFO" and n.inputs[0].default_value == hole:
                                            walls_nodes.add(c)
                for j in range(rows):

                    altitude = j * row_spacing + base_altitude
                    skip = 0
                    if j == 0:
                        # skip current object
                        skip = 1

                    for i in range(count - skip):

                        c = self.duplicate_object(context, o, link)

                        d = self.archipack_datablock(c)
                        d.on_copy(context, c)

                        tM = self._interp(startplace + (i + skip) * spacing, altitude)
                        c.parent = ref
                        c.matrix_world = tM
                        holes = []
                        if "archipack_assembly" in c.data:
                            for c2 in c.children:
                                cd = self.archipack_datablock(c2)
                                holes.append(cd.find_hole(c2))
                        else:
                            holes.append(d.find_hole(c))

                        for hole in holes:
                            self.add_hole_to_wall(hole, walls_holes, walls_nodes)

                tM = self._interp(startplace, base_altitude)
                o.matrix_world = tM

    def add_hole_to_wall(self, hole, walls_holes, walls_nodes):
        if hole is not None:
            # unlink hole
            hole.data = hole.data.copy()

            for basis in walls_holes:
                # Boolean modifier
                m = basis.modifiers.new('AutoMerge', 'BOOLEAN')
                m.operation = 'UNION'
                m.object = hole

            for wall in walls_nodes:
                # Geometry nodes
                m = self.get_archipack_bool_modifier(wall)
                self.add_node_boolean_hole(m, hole)
                nodes = m.node_group.nodes
                nodes.update()

            self.hide_object(hole)
            self.hide_for_render_engines(hole)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Horizontal", text_ctxt="archipack")

        layout.prop(self, "mode", text_ctxt="archipack")

        if "START" in self.mode:
            layout.prop(self, "gap_start", text_ctxt="archipack")

        if "END" in self.mode:
            layout.prop(self, "gap_end", text_ctxt="archipack")

        if "COUNT" in self.mode:
            layout.prop(self, "count", text_ctxt="archipack")
            layout.prop(self, "limit_count", text_ctxt="archipack")

        if "SPACING" in self.mode:
            layout.prop(self, "x", text_ctxt="archipack")

        layout.separator()
        layout.label(text="Vertical", text_ctxt="archipack")

        layout.prop(self, "levels_mode", text_ctxt="archipack")

        if "COUNT" in self.levels_mode:
            layout.prop(self, "levels", text_ctxt="archipack")

        if "SPACING" in self.levels_mode:
            layout.prop(self, "levels_spacing", text_ctxt="archipack")

        layout.prop(self, "distance_from_top", text_ctxt="archipack")

    # -----------------------------------------------------
    # Execute
    # -----------------------------------------------------
    def execute(self, context):
        if context.mode == "OBJECT":
            # select and make active
            bpy.ops.archipack.disable_manipulate()
            sel = context.selected_objects[:]
            o = context.active_object
            with context_override(context, o, sel) as ctx:
                self.make_array(ctx, sel)
            wall = self.get_scene_object(context, self.wall_name)
            with context_override(context, wall, [wall]) as ctx:
                wd = wall.data.archipack_wall2[0]
                wd.update(ctx, setup_childs=True, relocate_childs=True, allow_throttle=False)

            self.select_object(context, o, True)

            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}

    def distribute_objects(self):

        startplace, spacing, count = 0, self.x, self.count

        if self.mode == "START_END_COUNT":
            startplace = self.gap_start + self.first_location
            available = self.available_space - (self.gap_end + self.gap_start)
            max_count = floor(available / self.objects_size)
            if self.limit_count:
                count = min(count, max_count)
            emptyspace = available - (count * self.objects_size)
            if count > 1:
                gap = emptyspace / (count - 1)
            else:
                gap = 0
            spacing = self.objects_size + gap

        elif self.mode == "AXIS_SPACING":
            n_spaces = floor((self.available_space - self.objects_size) / spacing)
            startplace = self.first_location + 0.5 * (self.available_space - n_spaces * spacing - self.objects_size)
            count = n_spaces + 1

        elif self.mode == "SPACING":
            spacing = self.objects_size + self.x
            n_spaces = floor((self.available_space - self.objects_size) / spacing)
            count = n_spaces + 1
            gap = self.available_space - (n_spaces * spacing + self.objects_size)
            startplace = self.first_location + 0.5 * gap

        elif self.mode == "COUNT":
            max_count = floor(self.available_space / self.objects_size)
            if self.limit_count:
                count = min(count, max_count)
            emptyspace = self.available_space - (count * self.objects_size)
            if count > 0:
                gap = emptyspace / count
                spacing = self.objects_size + gap
                startplace = self.first_location + 0.5 * gap

        elif self.mode == "AXIS_START_COUNT_SPACING":
            startplace = self.gap_start + self.first_location - 0.5 * self.objects_size
            n_spaces = floor((self.available_space - self.objects_size - self.gap_start) / spacing)
            if self.limit_count:
                count = min(count, n_spaces + 1)

        elif self.mode == "START_COUNT_SPACING":
            spacing = self.objects_size + self.x
            startplace = self.gap_start + self.first_location
            available = self.available_space - self.gap_start
            max_count = floor(available / spacing)
            if self.limit_count:
                count = min(count, max_count)

        elif self.mode == "AXIS_END_COUNT_SPACING":
            n_spaces = floor((self.available_space - self.objects_size - self.gap_end) / spacing)
            if self.limit_count:
                count = min(count, n_spaces + 1)
            startplace = self.available_space + self.first_location - count * spacing - 0.5 * self.objects_size

        elif self.mode == "END_COUNT_SPACING":
            spacing = self.objects_size + self.x
            available = self.available_space - self.gap_end
            max_count = floor(available / spacing)
            if self.limit_count:
                count = min(count, max_count)
            startplace = self.available_space + self.first_location - count * spacing

        elif self.mode == "AXIS_CUR_COUNT_SPACING":
            n_spaces = floor((self.available_space + self.first_location - self.objects_size) / spacing)
            if self.limit_count:
                count = min(count, n_spaces + 1)

        elif self.mode == "CUR_COUNT_SPACING":
            spacing = self.objects_size + self.x
            available = self.available_space
            max_count = floor(available / spacing)
            if self.limit_count:
                count = min(count, max_count)

        # print(startplace, spacing, count)

        return startplace, spacing, count

    def _interp(self, x, z):
        x0, _s = self.segment_t[-1]
        j = len(self.segment_t) - 1
        while x < x0 and j > 0:
            j -= 1
            x0, _s = self.segment_t[j]

        sx = x - x0
        dx = _s.length
        if dx > 0:
            t = sx / dx
        else:
            t = 0
        p = _s.lerp(t)
        vx = -_s.v_normalized
        vy = vx.cross(Z_AXIS)
        p += vy * self.y
        return Matrix([
            [-vx.x, vy.x, 0, p.x],
            [-vx.y, vy.y, 0, p.y],
            [-vx.z, vy.z, 1, z],
            [0, 0, 0, 1]
        ])

    def find_wall_child(self, wd, o):
        for c in wd.childs:
            if c.child_name == o.name:
                return c
        return None

    def find_wall(self, context, o):
        ref = self.get_reference_point(o)
        if ref is not None:
            objs = self.filter_selection_loose(ref.children)
            if "archipack_wall2" in objs:
                for name in objs['archipack_wall2']:
                    wall = self.get_scene_object(context, name)
                    wd = wall.data.archipack_wall2[0]
                    wg = wd.get_generator(wall)
                    child = self.find_wall_child(wd, o)
                    if child is not None:
                        return wall, wd, wg, child

        return None, None, None, -1

    def invoke(self, context, event):
        o = context.active_object
        d = self.get_object_datablock(o)
        # use assembly child to find wall's segment as assembly itself is not in wall childs
        o_wall = o
        if o.data and "archipack_assembly" in o.data:
            sel = [c for c in o.children if self.filter_object(c)]
            sel.insert(0, o)
            if len(sel) > 1:
                o_wall = sel[1]
        else:
            sel = [c for c in context.selected_objects if self.filter_object(c)]

        # find wall segment for the active object
        wall, wd, wg, child = self.find_wall(context, o_wall)
        if wall is not None:
            self.wall_name = wall.name
            self.y = 0.5 * wd.width
            _seg_idx = child.wall_idx

            # handle multiple collinear segments - curved segments < ~15 deg
            _seg = wg.outside.segs[_seg_idx]
            # find first seg on left side
            while _seg.has_last and _seg_idx > 0 and abs(_seg.delta_angle(_seg._last)) < 0.2:
                _seg_idx -= 1
                _seg = _seg._last
            first_segment = _seg_idx

            # print("first_segment", first_segment)

            # find last seg on right part
            _segs_idx = set()
            _segs_idx.add(_seg_idx)
            available_space = _seg.length
            # absolute distance from wall start
            segment_len = 0
            segment_param_t = {0: 0}
            for i, _s in enumerate(wg.outside.valid_segs):
                segment_len += _s.length
                segment_param_t[i + 1] = segment_len
            # store segment dist map
            segment_t = []
            segment_t.append((segment_param_t[_seg_idx], _seg))
            n_segs = len(wg.outside.valid_segs) - 1
            while _seg.has_next and _seg_idx < n_segs and abs(
                    _seg._next.delta_angle(_seg)) < 0.2:
                available_space += _seg.length
                _seg_idx += 1
                # segment_param_t[_seg_idx] = available_space
                _segs_idx.add(_seg_idx)
                _seg = _seg._next
                segment_t.append((segment_param_t[_seg_idx], _seg))

            self.segment_t = segment_t

            logger.debug("available_space %s" % available_space)

            logger.debug("segment_param_t %s" % segment_param_t)

            logger.debug("segment_t %s" % segment_t)

            childs = []
            height = child.pos.z
            if hasattr(d, "z"):
                height += d.z
            if hasattr(d, "altitude"):
                height += d.altitude
            x = 0
            if hasattr(d, "x"):
                x += d.x

            childs.append((o_wall, segment_param_t[child.wall_idx] + child.pos.x, x, height))

            for c in sel:
                # ensure other objects are on same segment
                if c.name != o_wall.name and c.name != o.name:
                    child = self.find_wall_child(wd, c)
                    if child is not None:
                        if child.wall_idx in _segs_idx:
                            d = self.get_object_datablock(c)
                            t = segment_param_t[child.wall_idx] + child.pos.x
                            height = child.pos.z
                            if hasattr(d, "z"):
                                height += d.z
                            if hasattr(d, "altitude"):
                                height += d.altitude
                            x = 0
                            if hasattr(d, "x"):
                                x += d.x
                            childs.append((c, t, x, height))
            # sort by distance from start
            childs.sort(key=lambda x: x[1])

            # offset so the first border is at wall segment start
            # self.first_location = (0.5 * childs[0][2]) - childs[0][1]
            self.first_location = segment_param_t[first_segment] + (0.5 * childs[0][2])
            # max distance between childs border - border

            self.objects_size = childs[-1][1] - childs[0][1] + 0.5 * (childs[0][2] + childs[-1][2])
            self.available_space = available_space

            self.available_vertical = wd.z - self.distance_from_top

            childs.sort(key=lambda x: x[3])
            self.max_height = childs[-1][3]

            return context.window_manager.invoke_props_dialog(self)
        else:
            self.report({'WARNING'}, "Must draw object over wall before using array")
        return {'CANCELLED'}

