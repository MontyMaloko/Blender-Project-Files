# -*- coding:utf-8 -*-

# EASYREF Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)

from .properties import *
from math import radians
import bpy
import os
from bpy.types import Operator
from bpy.props import StringProperty, CollectionProperty
from bpy_extras.io_utils import ImportHelper
from .all_operators import Freezer
import time
from mathutils import Quaternion
import blf
from gpu_extras.batch import batch_for_shader
from .properties import _handle_dict


class EASYREF_OT_set_reference(Operator):
    bl_idname = 'object.easyref_set_reference'
    bl_label = "Set Reference"
    bl_description = "Set the current Emptie whith the chosen direction\n\nFront, Left, Right, etc."
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object.type == 'EMPTY' and context.object.empty_display_type == 'IMAGE'

    empties_set_refs : EnumProperty(
        items=(('front', "Front", "Front Reference"),
               ('back', "Back", "Back Reference"),
               ('left', "Left", "Left Reference"),
               ('right', "Right", "Right Reference"),
               ('top', "Top", "Top Reference"),
               ('bottom', "Bottom", "Bottom Reference"),
               ('aligned', "Aligned", "Aligned To View")),
        default='front'
    ) # type: ignore

    def execute(self, context):
        prefs = get_addon_preferences()
        easyref_empties = context.scene.easyref_empties
        self.ref = context.active_object

        if not self.ref.get("easyref_empty_ref"):
            self.ref["easyref_empty_ref"] = True

        # RENAME EMPTY
        strings_to_remove = ["REF_FRONT_", "REF_BACK_", "REF_TOP_", "REF_BOTTOM_", "REF_LEFT_", "REF_RIGHT_", "REF_ALIGNED_"]
        for s in strings_to_remove:
            self.ref.name = self.ref.name.replace(s, "")

        self.curent_name = self.ref.name

        # SETTINGS
        self.ref.use_empty_image_alpha = prefs.add_ref_transparency
        self.ref.color[3] = prefs.ref_transparency
        self.ref.empty_image_depth = prefs.ref_depth
        self.ref.empty_image_side = prefs.ref_side
        self.ref.show_empty_image_orthographic = prefs.ref_show_in_ortho
        self.ref.show_empty_image_perspective = prefs.ref_show_in_persp
        self.ref.show_empty_image_only_axis_aligned = prefs.ref_only_axis_aligned
        self.ref.empty_display_size = prefs.ref_size

        # GET VERTICAL VALUE
        self.current_vertical = 0
        self.current_depth = 0

        # DEL CUSTOM PROPS
        properties_to_remove = ["easyref_front", "easyref_back", "easyref_left", "easyref_right", "easyref_top", "easyref_bottom", "easyref_aligned"]
        for p in properties_to_remove:
            if p in self.ref.keys():
                del self.ref[p]

        # CLEAR TRANSFORMS
        self.ref.location = (0, 0, 0)
        self.ref.rotation_euler = (0, 0, 0)
        self.ref.scale = (1, 1, 1)

        # ROTATE - DISTANCE
        if self.empties_set_refs == 'front':
            self.ref["easyref_front"] = True
            self.ref.name = "FRONT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                self.ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                self.ref.rotation_euler[0] = radians(90)
                self.ref.location[1] = prefs.prefs_refs_distance

        elif self.empties_set_refs == 'back':
            self.ref["easyref_back"] = True
            self.ref.name = "BACK"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                self.ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                self.ref.rotation_euler[0] = radians(90)
                self.ref.rotation_euler[2] = radians(180)
                self.ref.location[1] = - prefs.prefs_refs_distance

        elif self.empties_set_refs == 'left':
            self.ref["easyref_left"] = True
            self.ref.name = "LEFT"
            # self.ref.name = "REF_LEFT" + "_" + self.curent_name
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                self.ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                self.ref.rotation_euler[0] = radians(90)
                self.ref.rotation_euler[2] = radians(-90)
                self.ref.location[0] = prefs.prefs_refs_distance


        elif self.empties_set_refs == 'right':
            self.ref["easyref_right"] = True
            self.ref.name = "RIGHT"
            # self.ref.name = "REF_RIGHT" + "_" + self.curent_name
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                self.ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                self.ref.rotation_euler[0] = radians(90)
                self.ref.rotation_euler[2] = radians(90)
                self.ref.location[0] = - prefs.prefs_refs_distance

        elif self.empties_set_refs == 'bottom':
            self.ref["easyref_bottom"] = True
            self.ref.name = "BOTTOM"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                self.ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                self.ref.rotation_euler[0] = radians(180)
                self.ref.location[2] = prefs.prefs_refs_distance


        elif self.empties_set_refs == 'top':
            self.ref["easyref_top"] = True
            self.ref.name = "TOP"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                self.ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                self.ref.location[2] = - prefs.prefs_refs_distance

        elif self.empties_set_refs == 'aligned':
            self.ref["easyref_aligned"] = True
            self.ref.name = "ALIGNED"
            r3d, rv3d, v3d = view3d_find()
            self.ref.rotation_euler = rv3d.view_rotation.to_euler()

        #COLLECTION
        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            # Create REFERENCES collection if it doesn't exist
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)
            
            # Create RV collection inside REFERENCES
            ref_ortho_views_collection = bpy.data.collections.new("IMAGES_REFERENCES") 
            ref_collection.children.link(ref_ortho_views_collection)
        else:
            # Get or create RV collection inside REFERENCES
            ref_ortho_views_collection = bpy.data.collections.get("IMAGES_REFERENCES")
            if not ref_ortho_views_collection:
                ref_ortho_views_collection = bpy.data.collections.new("IMAGES_REFERENCES")
                ref_collection.children.link(ref_ortho_views_collection)
            
        # Move all created empties to RV collection
        # Move the reference object to the REF_ORTHO_VIEWS collection
        empty_name = self.ref.name
        if empty_name in bpy.data.objects:
            empty = bpy.data.objects[empty_name]
            # Unlink from current collection
            for col in empty.users_collection:
                col.objects.unlink(empty)
            # Link to REF_ORTHO_VIEWS collection
            ref_ortho_views_collection.objects.link(empty)
            
        return {'FINISHED'}

class EASYREF_OT_add_image_ref(Freezer, Operator, ImportHelper):
    bl_idname = "object.easyref_add_image_ref"
    bl_label = "Add Image Reference" 
    bl_description = "Add an image as reference\n\n This is a simple empty that will be added to the REFERENCES collection"
    bl_options = {'REGISTER', 'UNDO'}

    filter_glob : StringProperty(
        default="*.exr;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.tga;*.bmp;*.webp;*.gif;*.psd;*.psb;*.hdr;*.svg",
        options={'HIDDEN'},
    ) # type: ignore

    def execute(self, context):

        if context.object:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

        # Load the image
        image = bpy.data.images.load(self.filepath, check_existing=True)
        
        # Add empty image object
        bpy.ops.object.empty_add(type='IMAGE')
        empty = context.active_object
        
        # Set image to empty
        empty.data = image
        
        # Set empty properties
        empty.empty_display_size = 5
        # empty["easyref_empty_ref"] = True
        empty.name = image.name

        # Clear rotation and rotate 90 degrees on X
        empty.rotation_euler = (0, 0, 0)
        empty.rotation_euler.x = radians(90)
        
        #COLLECTION
        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            # Create REFERENCES collection if it doesn't exist
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)

        # Move empty to REFERENCES collection
        empty_name = empty.name
        if empty_name in bpy.data.objects:
            empty = bpy.data.objects[empty_name]
            # Unlink from current collection
            for coll in empty.users_collection:
                coll.objects.unlink(empty)
            # Link to REFERENCES collection
            ref_collection.objects.link(empty)
        
        return {'FINISHED'}

class EASYREF_OT_load_ref(Operator):
    bl_idname = 'object.easyref_load_ref'
    bl_label = "Load Reference"
    bl_description = "Load the selected reference"
    bl_options = {'REGISTER', 'UNDO'}

    empties_refs: EnumProperty(
        items=(('front', "Front", "Front Reference"),
               ('back', "Back", "Back Reference"),
               ('left', "Left", "Left Reference"),
               ('right', "Right", "Right Reference"),
               ('top', "Top", "Top Reference"),
               ('bottom', "Bottom", "Bottom Reference"),
               ('aligned', "Aligned", "Aligned To View"),
               ('named', "named", "Named References")),
        default='front'
    )  # type: ignore

    filepath: StringProperty(
        subtype='FILE_PATH'
    )  # type: ignore

    filter_image: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore
    filter_folder: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore

    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )  # type: ignore

    directory: StringProperty(
        subtype='DIR_PATH'
    )  # type: ignore

    @classmethod
    def description(cls, context, properties):
        return (f"Add an Empty as Reference and set it to the {properties.empties_refs} view\n\n"
                "You will be able to edit the settings and change the direction of the reference")

    def invoke(self, context, event):
        # If there are selected objects with easyref_empty_ref_view, bypass the file selector.
        selected_view_refs = [obj for obj in context.selected_objects if obj.get("easyref_empty_ref_view")]
        if selected_view_refs:
            return self.execute(context)
        else:
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

    def create_reference(self, context, filepath, ref_type):
        # Get preferences and current empties
        prefs = get_addon_preferences()
        easyref_empties = context.scene.easyref_empties
        easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref and not ref.hide_viewport]

        # Load image from filepath and create an empty
        image = bpy.data.images.load(filepath, check_existing=True)
        bpy.ops.object.empty_add(type='IMAGE', location=(0, 0, 0))
        ref = context.active_object
        ref.data = image
        ref["easyref_empty_ref"] = True

        # Apply common settings
        ref.use_empty_image_alpha = prefs.add_ref_transparency
        ref.color[3] = prefs.ref_transparency
        ref.empty_image_depth = prefs.ref_depth
        ref.empty_image_side = prefs.ref_side
        ref.show_empty_image_orthographic = prefs.ref_show_in_ortho
        ref.show_empty_image_perspective = prefs.ref_show_in_persp
        ref.show_empty_image_only_axis_aligned = prefs.ref_only_axis_aligned

        distance = prefs.prefs_refs_distance
        ref.empty_display_size = prefs.ref_size

        # Set the initial name from the image file (no extension)
        self.first_name = os.path.splitext(os.path.basename(filepath))[0]

        # Apply orientation and position based on reference type
        if ref_type == 'front':
            ref["easyref_front"] = True
            ref.name = "FRONT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                ref.rotation_euler[0] = radians(90)
                ref.location[1] = distance

        elif ref_type == 'back':
            ref["easyref_back"] = True
            ref.name = "BACK"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                ref.rotation_euler[0] = radians(90)
                ref.rotation_euler[2] = radians(180)
                ref.location[1] = -distance

        elif ref_type == 'left':
            ref["easyref_left"] = True
            ref.name = "LEFT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                ref.rotation_euler[0] = radians(90)
                ref.rotation_euler[2] = radians(-90)
                ref.location[0] = distance

        elif ref_type == 'right':
            ref["easyref_right"] = True
            ref.name = "RIGHT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                ref.rotation_euler[0] = radians(90)
                ref.rotation_euler[2] = radians(90)
                ref.location[0] = -distance

        elif ref_type == 'bottom':
            ref["easyref_bottom"] = True
            ref.name = "BOTTOM"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                ref.rotation_euler[0] = radians(180)
                ref.location[2] = distance

        elif ref_type == 'top':
            ref["easyref_top"] = True
            ref.name = "TOP"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                ref.location[2] = -distance

        elif ref_type == 'aligned':
            ref["easyref_aligned"] = True
            ref.name = "ALIGNED"
            r3d, rv3d, v3d = view3d_find()
            ref.rotation_euler = rv3d.view_rotation.to_euler()

        elif ref_type == 'named':
            ref.name = self.first_name
            ref.rotation_euler[0] = radians(90)
            ref.rotation_euler[1] = 0
            ref.rotation_euler[2] = 0
            ref.location = (0, 0, 0)
            ref["easyref_empty_ref_visible"] = False

        return ref

    def create_reference_from_image(self, context, image, ref_type):
        """
        Create a new reference using an already loaded image.
        """
        prefs = get_addon_preferences()
        bpy.ops.object.empty_add(type='IMAGE', location=(0, 0, 0))
        new_ref = context.active_object
        new_ref.data = image
        new_ref["easyref_empty_ref"] = True

        # Apply common settings
        new_ref.use_empty_image_alpha = prefs.add_ref_transparency
        new_ref.color[3] = prefs.ref_transparency
        new_ref.empty_image_depth = prefs.ref_depth
        new_ref.empty_image_side = prefs.ref_side
        new_ref.show_empty_image_orthographic = prefs.ref_show_in_ortho
        new_ref.show_empty_image_perspective = prefs.ref_show_in_persp
        new_ref.show_empty_image_only_axis_aligned = prefs.ref_only_axis_aligned

        distance = prefs.prefs_refs_distance
        new_ref.empty_display_size = prefs.ref_size

        # Use the name of the image (without extension)
        self.first_name = image.name

        # Apply orientation and position based on reference type
        if ref_type == 'front':
            new_ref["easyref_front"] = True
            new_ref.name = "FRONT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.location[1] = distance

        elif ref_type == 'back':
            new_ref["easyref_back"] = True
            new_ref.name = "BACK"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.rotation_euler[2] = radians(180)
                new_ref.location[1] = -distance

        elif ref_type == 'left':
            new_ref["easyref_left"] = True
            new_ref.name = "LEFT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.rotation_euler[2] = radians(-90)
                new_ref.location[0] = distance

        elif ref_type == 'right':
            new_ref["easyref_right"] = True
            new_ref.name = "RIGHT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.rotation_euler[2] = radians(90)
                new_ref.location[0] = -distance

        elif ref_type == 'bottom':
            new_ref["easyref_bottom"] = True
            new_ref.name = "BOTTOM"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(180)
                new_ref.location[2] = distance

        elif ref_type == 'top':
            new_ref["easyref_top"] = True
            new_ref.name = "TOP"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.location[2] = -distance

        elif ref_type == 'aligned':
            new_ref["easyref_aligned"] = True
            new_ref.name = "ALIGNED"
            r3d, rv3d, v3d = view3d_find()
            new_ref.rotation_euler = rv3d.view_rotation.to_euler()

        elif ref_type == 'named':
            new_ref.name = self.first_name
            new_ref.rotation_euler[0] = radians(90)
            new_ref.rotation_euler[1] = 0
            new_ref.rotation_euler[2] = 0
            new_ref.location = (0, 0, 0)
            new_ref["easyref_empty_ref_visible"] = False

        return new_ref

    def create_reference_from_empty(self, context, ref_type):
        """
        Create a new reference from selected empty.
        """
        prefs = get_addon_preferences()
        new_ref = context.active_object
        new_ref["easyref_empty_ref"] = True

        # Apply common settings
        new_ref.use_empty_image_alpha = prefs.add_ref_transparency
        new_ref.color[3] = prefs.ref_transparency
        new_ref.empty_image_depth = prefs.ref_depth
        new_ref.empty_image_side = prefs.ref_side
        new_ref.show_empty_image_orthographic = prefs.ref_show_in_ortho
        new_ref.show_empty_image_perspective = prefs.ref_show_in_persp
        new_ref.show_empty_image_only_axis_aligned = prefs.ref_only_axis_aligned

        distance = prefs.prefs_refs_distance
        new_ref.empty_display_size = prefs.ref_size

        # Use the name of the image (without extension)
        self.first_name = new_ref.name

        # Apply orientation and position based on reference type
        if ref_type == 'front':
            new_ref["easyref_front"] = True
            new_ref.name = "FRONT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.location[1] = distance

        elif ref_type == 'back':
            new_ref["easyref_back"] = True
            new_ref.name = "BACK"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.rotation_euler[2] = radians(180)
                new_ref.location[1] = -distance

        elif ref_type == 'left':
            new_ref["easyref_left"] = True
            new_ref.name = "LEFT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.rotation_euler[2] = radians(-90)
                new_ref.location[0] = distance

        elif ref_type == 'right':
            new_ref["easyref_right"] = True
            new_ref.name = "RIGHT"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(90)
                new_ref.rotation_euler[2] = radians(90)
                new_ref.location[0] = -distance

        elif ref_type == 'bottom':
            new_ref["easyref_bottom"] = True
            new_ref.name = "BOTTOM"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.rotation_euler[0] = radians(180)
                new_ref.location[2] = distance

        elif ref_type == 'top':
            new_ref["easyref_top"] = True
            new_ref.name = "TOP"
            if prefs.ref_aligned_to_view:
                r3d, rv3d, v3d = view3d_find()
                new_ref.rotation_euler = rv3d.view_rotation.to_euler()
            else:
                new_ref.location[2] = -distance

        elif ref_type == 'aligned':
            new_ref["easyref_aligned"] = True
            new_ref.name = "ALIGNED"
            r3d, rv3d, v3d = view3d_find()
            new_ref.rotation_euler = rv3d.view_rotation.to_euler()

        elif ref_type == 'named':
            new_ref.name = self.first_name
            new_ref.rotation_euler[0] = radians(90)
            new_ref.rotation_euler[1] = 0
            new_ref.rotation_euler[2] = 0
            new_ref.location = (0, 0, 0)
            new_ref["easyref_empty_ref_visible"] = False

        return new_ref
    
    def execute(self, context):
        prefs = get_addon_preferences()
        act_obj = context.object
        selected_view_refs = [obj for obj in context.selected_objects if obj.get("easyref_empty_ref_view")]
        selected_empty_refs = [obj for obj in context.selected_objects if obj.get("easyref_empty_ref")]
        

        if act_obj and act_obj.type != 'EMPTY':
            current_mode = act_obj.mode
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

        # IF REF VIEW IS SELECTED
        if selected_view_refs or selected_empty_refs:
            for obj in selected_view_refs:

                if obj.data:
                    # Get the object name in lowercase for comparison
                    obj_name = obj.name.lower()
                    
                    # Determine reference type based on name
                    ref_type = self.empties_refs  # Default to selected type
                    if 'front' in obj_name:
                        ref_type = 'front'
                    elif 'back' in obj_name:
                        ref_type = 'back'
                    elif 'left' in obj_name:
                        ref_type = 'left'
                    elif 'right' in obj_name:
                        ref_type = 'right'
                    elif 'top' in obj_name:
                        ref_type = 'top'
                    elif 'bottom' in obj_name:
                        ref_type = 'bottom'
                        
                    # Create reference with determined type
                    new_ref = self.create_reference_from_image(context, obj.data, ref_type)
                    self.move_to_collection(context, new_ref)

        else:
            # --- Existing behavior: file import handling
            if hasattr(self, 'files') and len(self.files) > 1:
                for f in self.files:
                    filepath = os.path.join(self.directory, f.name)
                    filename = f.name.lower()

                    if 'front' in filename:
                        ref = self.create_reference(context, filepath, 'front')
                    elif 'back' in filename:
                        ref = self.create_reference(context, filepath, 'back')
                    elif 'left' in filename:
                        ref = self.create_reference(context, filepath, 'left')
                    elif 'right' in filename:
                        ref = self.create_reference(context, filepath, 'right')
                    elif 'top' in filename:
                        ref = self.create_reference(context, filepath, 'top')
                    elif 'bottom' in filename:
                        ref = self.create_reference(context, filepath, 'bottom')
                    else:
                        ref = self.create_reference(context, filepath, self.empties_refs)

                    self.move_to_collection(context, ref)
            else:
                if self.filepath:
                    ref = self.create_reference(context, self.filepath, self.empties_refs)
                    self.move_to_collection(context, ref)

        bpy.ops.object.select_all(action='DESELECT')
        if act_obj:
            act_obj.select_set(state=True)
            context.view_layer.objects.active = act_obj
            if act_obj.type != 'EMPTY':
                bpy.ops.object.mode_set(mode=current_mode)


        return {'FINISHED'}

    def move_to_collection(self, context, ref):
        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)
            # Create IMAGES_REFERENCES collection inside REFERENCES
            ref_ortho_views_collection = bpy.data.collections.new("IMAGES_REFERENCES")
            ref_collection.children.link(ref_ortho_views_collection)
        else:
            # Get or create IMAGES_REFERENCES collection
            ref_ortho_views_collection = bpy.data.collections.get("IMAGES_REFERENCES")
            if not ref_ortho_views_collection:
                ref_ortho_views_collection = bpy.data.collections.new("IMAGES_REFERENCES")
                ref_collection.children.link(ref_ortho_views_collection)
        # Move reference to collection
        for col in ref.users_collection:
            col.objects.unlink(ref)
        ref_ortho_views_collection.objects.link(ref)

    def set_settings(self, context, obj):
        pass

class EASYREF_OT_flip_references(Operator):
    bl_idname = 'object.easyref_flip_references'
    bl_label = "Flip Reference"
    bl_description = "Flip the selected reference horizontally"
    bl_options = {'REGISTER'}

    ref: StringProperty() # type: ignore

    def execute(self, context):
        obj = bpy.data.objects.get(self.ref)
        if obj:
            obj.scale[0] = -obj.scale[0]
        return {'FINISHED'}

class EASYREF_OT_flip_references_horizontal(Operator):
    bl_idname = 'object.easyref_flip_references_horizontal'
    bl_label = "Flip Reference Horizontal"
    bl_description = "Flip the selected reference horizontally"
    bl_options = {'REGISTER'}

    ref: StringProperty() # type: ignore

    def execute(self, context):
        for obj in context.selected_objects:
            obj.scale[0] = -obj.scale[0]
        return {'FINISHED'}

class EASYREF_OT_flip_references_vertical(Operator):
    bl_idname = 'object.easyref_flip_references_vertical'
    bl_label = "Flip Reference Vertical"
    bl_description = "Flip the selected reference vertically"
    bl_options = {'REGISTER'}

    ref: StringProperty() # type: ignore

    def execute(self, context):
        for obj in context.selected_objects:
            obj.scale[1] = -obj.scale[1]
        return {'FINISHED'}

class EASYREF_OT_delete_ref(Operator):
    bl_idname = "object.easyref_delete_ref"
    bl_label = "Delete Reference"
    bl_description = "Delete the selected reference"
    bl_options = {"REGISTER"}

    ref: StringProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Get the reference object
        ref_obj = context.scene.objects[self.ref]
        
        # Get the REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        
        # Remove object from collection before deleting
        if ref_collection and ref_obj.name in ref_collection.objects:
            ref_collection.objects.unlink(ref_obj)
            
        # Delete the object
        bpy.data.objects.remove(ref_obj, do_unlink=True)
        
        return {"FINISHED"}

class EASYREF_OT_show_refs_settings(Operator):
    bl_idname = "object.easyref_show_refs_settings"
    bl_label = "Showthe References Settings"
    bl_description = "Show the References Settings to edit the image (Opacity, Depth, Side, etc...)"

    ref: StringProperty() # type: ignore

    def execute(self, context):
        context.scene.objects[self.ref]["easyref_empty_ref_visible"] = True
        return {"FINISHED"}

class EASYREF_OT_hide_refs_settings(Operator):
    bl_idname = "object.easyref_hide_refs_settings"
    bl_label = "Hide References"
    bl_description = "Hide the References Settings"

    ref: StringProperty() # type: ignore

    def execute(self, context):
        if context.scene.objects[self.ref].get("easyref_empty_ref_visible"):
            del context.scene.objects[self.ref]["easyref_empty_ref_visible"]
        return {"FINISHED"}

class EASYREF_OT_show_ref(Operator):
    bl_idname = 'object.easyref_show_ref'
    bl_label = "Show Selected Reference"
    bl_description = "Show Selected Reference"
    bl_options = {'REGISTER', 'UNDO'}

    ref: StringProperty() # type: ignore

    def execute(self, context):
        if context.scene.objects[self.ref].get("easyref_empty_is_hidden"):
            context.scene.objects[self.ref].hide_viewport = False
            del context.scene.objects[self.ref]["easyref_empty_is_hidden"]

        return {'FINISHED'}

class EASYREF_OT_hide_ref(Operator):
    bl_idname = 'object.easyref_hide_ref'
    bl_label = "Hide Selected Reference"
    bl_description = "Hide Selected Reference"
    bl_options = {'REGISTER', 'UNDO'}

    ref: StringProperty() # type: ignore

    def execute(self, context):
        if not context.scene.objects[self.ref].get("easyref_empty_is_hidden"):
            context.scene.objects[self.ref].hide_viewport = True
            context.scene.objects[self.ref]["easyref_empty_is_hidden"] = True
        return {'FINISHED'}

class EASYREF_OT_show_all_refs(Operator):
    bl_idname = 'object.easyref_show_all_refs'
    bl_label = "Show All References"
    bl_description = "Show All References in the Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

        for ref in easyref_ref_list:
            ref.hide_viewport = False

        return {'FINISHED'}

class EASYREF_OT_hide_all_refs(Operator):
    bl_idname = 'object.easyref_hide_all_refs'
    bl_label = "Hide All References"
    bl_description = "Hide All References from the Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

        for ref in easyref_ref_list:
            ref.hide_viewport = True

        return {'FINISHED'}

class EASYREF_OT_delete_all_refs(Operator):
    bl_idname = 'object.easyref_delete_all_refs'
    bl_label = "Delete All References"
    bl_description = "This will delete all references from the Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]

        for j, ref in enumerate(easyref_ref_list):
            bpy.data.objects.remove(context.scene.objects[ref.name], do_unlink = True)
        return {'FINISHED'}

class EASYREF_OT_lock_empty(Operator):
    bl_idname = "object.easyref_lock_empty"
    bl_label = "Lock Empty"
    bl_description = "Lock/Unlock the selected reference"
    bl_options = {'REGISTER', 'UNDO'}

    ref: StringProperty() # type: ignore
    
    def execute(self, context):
        obj = bpy.data.objects.get(self.ref)    
        if obj:
            obj.hide_select = not obj.hide_select
        return {'FINISHED'}
    
class EASYREF_OT_lock_all_empty(Operator):
    bl_idname = "object.easyref_lock_all_empty"
    bl_label = "Lock All References"
    bl_description = "Lock/Unlock all References from the Scene"
    bl_options = {'REGISTER', 'UNDO'}

    ref: StringProperty() # type: ignore
    
    def execute(self, context):
        easyref_ref_list = [ref for ref in context.scene.objects if "easyref_empty_ref" in ref]
        
        # Get the state from the clicked reference
        clicked_obj = bpy.data.objects.get(self.ref)
        if clicked_obj:
            new_state = not clicked_obj.hide_select
            
            # Apply to all references
            for ref in easyref_ref_list:
                ref.hide_select = new_state
                
        return {'FINISHED'}

class EASYREF_OT_set_ref_view(Operator):
    bl_idname = "object.easyref_set_ref_view"
    bl_label = "Set Reference View"
    bl_description = "Set the 3D view according to the reference type (Front, Top, etc)\n\nShift + Click to rename the reference"
    bl_options = {'REGISTER', 'UNDO'}

    ref: StringProperty() # type: ignore
    new_name: StringProperty(name="Name") # type: ignore
    rename_mode: BoolProperty(default=False) # type: ignore

    def invoke(self, context, event):
        # Si shift est pressé, on renomme
        if event.shift:
            obj = bpy.data.objects.get(self.ref)
            if obj:
                self.new_name = obj.name
                self.rename_mode = True
            return context.window_manager.invoke_props_dialog(self)
        # Sinon on change la vue
        self.rename_mode = False
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "new_name")

    def execute(self, context):
        obj = bpy.data.objects.get(self.ref)
        if obj:
            # Renommage uniquement si on est en mode renommage
            if self.rename_mode and self.new_name:
                obj.name = self.new_name
                return {'FINISHED'}
                
            # Changement de vue
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    if "easyref_front" in obj:
                        bpy.ops.view3d.view_axis(type='FRONT')
                    elif "easyref_back" in obj:
                        bpy.ops.view3d.view_axis(type='BACK') 
                    elif "easyref_left" in obj:
                        bpy.ops.view3d.view_axis(type='LEFT')
                    elif "easyref_right" in obj:
                        bpy.ops.view3d.view_axis(type='RIGHT')
                    elif "easyref_top" in obj:
                        bpy.ops.view3d.view_axis(type='TOP')
                    elif "easyref_bottom" in obj:
                        bpy.ops.view3d.view_axis(type='BOTTOM')
                    break

        return {'FINISHED'}

# ------------------------------------------------------------------------------------------------
# REF VIEW
# ------------------------------------------------------------------------------------------------
ref_view_area_hash = None
active_lock_view_modal = None

class EASYREF_OT_set_tools_category(Operator):
    bl_idname = "object.easyref_set_tools_category"
    bl_label = "Set Tools Category"
    
    def execute(self, context):
        area = context.area
        for region in area.regions:
            if region.type == 'UI':
                region.active_panel_category = 'Tools'
        area.tag_redraw()
        return {'FINISHED'}

def set_tools_category(context):
    prefs = get_addon_preferences()
    # Parcourir toutes les zones de l'écran
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            # Pour chaque vue 3D, trouver la région UI
            for region in area.regions:
                if region.type == 'UI':
                    # Définir la catégorie active sur 'Tools'
                    region.active_panel_category = prefs.category
                    # Forcer le rafraîchissement de la zone
                    area.tag_redraw()
                    break

class EASYREF_OT_show_ref_view(Freezer, Operator):
    bl_idname = "object.easyref_show_ref_view"
    bl_label = "Show Reference View"
    bl_description = "Show Reference View\n\nThat will Split the 3D view and add reference/s"
    bl_options = {'REGISTER', 'UNDO'}
            
    def execute(self, context):
        
        # Get all RV collections
        ref_view_collections = [col for col in bpy.data.collections if col.name.startswith("RV") or col.name.startswith("RV_")]

        self.save_selection(context)
        bpy.ops.object.select_all(action='DESELECT')

        prefs = get_addon_preferences()
        side = prefs.toggle_ref_view_side
        pref_factor = prefs.toggle_ref_view_factor
        editor_type = 'IMAGE_EDITOR'
        editor_ui_type = 'IMAGE_EDITOR'
        split_area(self, context, editor_type, editor_ui_type, side, pref_factor)

        bpy.ops.object.easyref_check_ref_view_area('INVOKE_DEFAULT')

        # Process all RV collections
        if ref_view_collections:
            # Select all image empties in all RV collections
            for collection in ref_view_collections:
                for obj in collection.objects:
                    if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE':
                        obj.select_set(True)
                        context.view_layer.objects.active = obj

            # Get reference view area
            ref_view_area = get_ref_view_area(context)
            if ref_view_area:
                # Get the 3D view region
                region = None
                for r in ref_view_area.regions:
                    if r.type == 'WINDOW':
                        region = r
                        break
                        
                if region:
                    # Only proceed if we're in the reference view
                    with context.temp_override(area=ref_view_area, region=region):
                        bpy.ops.view3d.view_selected(use_all_regions=False)
                        self.report({'INFO'},"Reference View Opened")

                        
                        

        self.restore_selection(context)

        return {'FINISHED'}
    
# class EASYREF_OT_close_ref_view(Operator):
#     bl_idname = "object.easyref_close_ref_view"
#     bl_label = "Close Reference View"
#     bl_description = "Close the reference view area"
#     bl_options = {'REGISTER', 'UNDO'}

#     def execute(self, context):
#         prefs = get_addon_preferences()
#         easyref_props = context.scene.easyref_props

#         # Désactiver le modal operator en premier
#         easyref_props.has_ref_view = False

#         for i, area in enumerate(context.screen.areas):
#             if area.type == 'VIEW_3D':
#                 space = area.spaces.active
#                 color = space.shading.background_color
                
#                 # Vérifier si c'est notre vue de référence
#                 if (abs(color[0] - prefs.ref_view_bg_color[0]) < 0.0001 and 
#                     abs(color[1] - prefs.ref_view_bg_color[1]) < 0.0001 and 
#                     abs(color[2] - prefs.ref_view_bg_color[2]) < 0.0001):
#                     ref_area = area

#                     # Store view location and rotation before closing
#                     view3d = ref_area.spaces[0]
#                     easyref_props.stored_view_location = view3d.region_3d.view_location.copy()
#                     easyref_props.stored_view_rotation = view3d.region_3d.view_rotation.copy()
#                     easyref_props.stored_view_distance = view3d.region_3d.view_distance
                    
#                     try:
#                         # Utiliser temp_override au lieu d'un override manuel
#                         with context.temp_override(window=context.window,
#                                                 screen=context.screen, 
#                                                 area=ref_area):
#                             bpy.ops.screen.area_close()
                        
#                         # Réinitialiser les propriétés
#                         # easyref_props.has_ref_view = False
#                         easyref_props.ref_view_side = ""
                        
#                         self.report({'INFO'}, "References View Closed")
#                         return {'FINISHED'}
                        
#                     except Exception as e:
#                         self.report({'ERROR'}, f"Error on Closing: {str(e)}")
#                         return {'CANCELLED'}
        

#         self.report({'WARNING'}, "No reference view found")
#         return {'CANCELLED'}


class EASYREF_OT_close_ref_view(Operator):
    bl_idname = "object.easyref_close_ref_view"
    bl_label = "Close Reference View"
    bl_description = "Close the reference view area"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # On spécifie qu'on utilise la variable globale
        global _handle_dict
        
        prefs = get_addon_preferences()
        easyref_props = context.scene.easyref_props

        # Désactiver le modal operator en premier
        easyref_props.has_ref_view = False
        
        # Nettoyer manuellement le handler
        if _handle_dict["handle"] and _handle_dict["space"]:
            try:
                _handle_dict["space"].draw_handler_remove(_handle_dict["handle"], 'WINDOW')
            except:
                pass
            _handle_dict["handle"] = None
            _handle_dict["space"] = None

        for i, area in enumerate(context.screen.areas):
            if area.type == 'VIEW_3D':
                space = area.spaces.active
                color = space.shading.background_color
                
                # Vérifier si c'est notre vue de référence
                if (abs(color[0] - prefs.ref_view_bg_color[0]) < 0.0001 and 
                    abs(color[1] - prefs.ref_view_bg_color[1]) < 0.0001 and 
                    abs(color[2] - prefs.ref_view_bg_color[2]) < 0.0001):
                    ref_area = area

                    # Store view location and rotation before closing
                    view3d = ref_area.spaces[0]
                    easyref_props.stored_view_location = view3d.region_3d.view_location.copy()
                    easyref_props.stored_view_rotation = view3d.region_3d.view_rotation.copy()
                    easyref_props.stored_view_distance = view3d.region_3d.view_distance
                    
                    try:
                        # Utiliser temp_override au lieu d'un override manuel
                        with context.temp_override(window=context.window,
                                                screen=context.screen, 
                                                area=ref_area):
                            bpy.ops.screen.area_close()
                        
                        # Réinitialiser les propriétés
                        easyref_props.ref_view_side = ""
                        
                        self.report({'INFO'}, "References View Closed")
                        return {'FINISHED'}
                        
                    except Exception as e:
                        self.report({'ERROR'}, f"Error on Closing: {str(e)}")
                        return {'CANCELLED'}
        
        self.report({'WARNING'}, "No reference view found")
        return {'CANCELLED'}
    
# class EASYREF_OT_lock_ref_view(Operator):
#     bl_idname = "view3d.lock_ref_view"
#     bl_label = "Lock Reference View"
#     bl_description = "Lock reference view rotation"
#     bl_options = {'REGISTER'}

#     _handle = None
#     _timer = None
#     _initial_rotation = None
#     _ref_view_area = None

#     def is_mouse_in_ref_view(self, context, event):
#         """Vérifie si la souris est dans la vue de référence"""
#         if not self._ref_view_area:
#             return False
            
#         x, y = event.mouse_x, event.mouse_y
#         return (self._ref_view_area.x <= x <= self._ref_view_area.x + self._ref_view_area.width and
#                 self._ref_view_area.y <= y <= self._ref_view_area.y + self._ref_view_area.height)

#     def draw_callback_px(self, context):
#         """N'affiche le texte que dans la vue de référence"""
#         if context.area == self._ref_view_area:
#             font_id = 0
#             blf.position(font_id, 15, 30, 0)
#             blf.size(font_id, 20)
#             blf.color(font_id, 1, 0, 0, 1)
#             blf.draw(font_id, "VIEW LOCKED")

#     def modal(self, context, event):
#         if not context.scene.easyref_props.has_ref_view or not self._ref_view_area:
#             if self._handle:
#                 context.space_data.draw_handler_remove(self._handle, 'WINDOW')
#             if self._timer:
#                 context.window_manager.event_timer_remove(self._timer)
#             self.report({'INFO'}, "Modal stopping")
#             return {'CANCELLED'}

#         if event.type == 'TIMER':
#             # Force la vue orthographique et maintient la rotation
#             if self._ref_view_area:
#                 with context.temp_override(area=self._ref_view_area):
#                     if context.space_data.region_3d.view_perspective != 'ORTHO':
#                         context.space_data.region_3d.view_perspective = 'ORTHO'
#                     if self._initial_rotation:
#                         context.space_data.region_3d.view_rotation = self._initial_rotation
            
#             # Rafraîchir les vues
#             for area in context.screen.areas:
#                 if area.type == 'VIEW_3D':
#                     area.tag_redraw()

#         # Bloc spécifiquement MIDDLE MOUSE (rotation classique) ou ALT+LEFT MOUSE (industry standard)
#         # mais seulement quand la souris est dans la vue de référence
#         if self.is_mouse_in_ref_view(context, event):
#             # Cas 1: Middle mouse sans modificateurs (rotation standard)
#             if event.type == 'MIDDLEMOUSE' and event.value == 'PRESS' and not (event.shift or event.ctrl or event.alt):
#                 return {'RUNNING_MODAL'}
                
#             # Cas 2: Alt + Left Mouse (industry standard keymap)
#             if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt and not (event.shift or event.ctrl):
#                 return {'RUNNING_MODAL'}

#         return {'PASS_THROUGH'}

#     def execute(self, context):
#         self.report({'INFO'}, "Lock view executed")
        
#         # Trouve et stocke la vue de référence
#         prefs = get_addon_preferences()
#         for area in context.screen.areas:
#             if (area.type == 'VIEW_3D' and 
#                 hasattr(area.spaces[0].shading, 'background_color') and 
#                 area.spaces[0].shading.background_color == prefs.ref_view_bg_color):
#                 self._ref_view_area = area
#                 break
        
#         # Si nous avons trouvé la vue de référence, stocke sa rotation
#         if self._ref_view_area:
#             with context.temp_override(area=self._ref_view_area):
#                 self._initial_rotation = context.space_data.region_3d.view_rotation.copy()
#                 context.space_data.region_3d.view_perspective = 'ORTHO'
#         else:
#             self.report({'WARNING'}, "Reference view not found")
#             return {'CANCELLED'}
        
#         # Lancement du modal
#         args = (context,)
#         self._handle = context.space_data.draw_handler_add(
#             self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
        
#         self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
#         context.window_manager.modal_handler_add(self)
        
#         self.report({'INFO'}, "Modal operator started")
#         return {'RUNNING_MODAL'}

class EASYREF_OT_lock_ref_view(Operator):
    bl_idname = "view3d.lock_ref_view"
    bl_label = "Lock Reference View"
    bl_description = "Lock reference view rotation"
    bl_options = {'REGISTER'}

    _timer = None
    _initial_rotation = None
    _ref_view_area = None

    def is_mouse_in_ref_view(self, context, event):
        """Vérifie si la souris est dans la vue de référence"""
        if not self._ref_view_area:
            return False
            
        x, y = event.mouse_x, event.mouse_y
        return (self._ref_view_area.x <= x <= self._ref_view_area.x + self._ref_view_area.width and
                self._ref_view_area.y <= y <= self._ref_view_area.y + self._ref_view_area.height)

    @staticmethod
    def draw_callback_px(context):
        """Version statique du callback qui utilise les variables globales"""
        # Protection contre les erreurs
        try:
            # Trouver la vue de référence
            prefs = get_addon_preferences()
            ref_view_area = None
            for area in context.screen.areas:
                if (area.type == 'VIEW_3D' and 
                    hasattr(area.spaces[0].shading, 'background_color') and 
                    area.spaces[0].shading.background_color == prefs.ref_view_bg_color):
                    ref_view_area = area
                    break
            
            if context.area == ref_view_area:
                font_id = 0
                blf.position(font_id, 15, 30, 0)
                blf.size(font_id, 20)
                blf.color(font_id, 1, 0, 0, 1)
                blf.draw(font_id, "ROTATION LOCKED")
        except:
            # Ne rien faire en cas d'erreur
            pass

    def modal(self, context, event):
        # On spécifie qu'on utilise la variable globale
        global _handle_dict
    
        if not context.scene.easyref_props.has_ref_view:
            # Le nettoyage sera fait dans EASYREF_OT_close_ref_view
            return {'CANCELLED'}

        if event.type == 'TIMER':
            # Vérifier si la vue de référence existe toujours
            area_exists = False
            if self._ref_view_area:
                for area in context.screen.areas:
                    if area == self._ref_view_area:
                        area_exists = True
                        break
            
            # Force la vue orthographique et maintient la rotation
            if self._ref_view_area and area_exists:
                try:
                    with context.temp_override(area=self._ref_view_area):
                        if context.space_data.region_3d.view_perspective != 'ORTHO':
                            context.space_data.region_3d.view_perspective = 'ORTHO'
                        if self._initial_rotation:
                            context.space_data.region_3d.view_rotation = self._initial_rotation
                except:
                    pass
            
            # Rafraîchir les vues
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        # Bloc spécifiquement MIDDLE MOUSE ou ALT+LEFT MOUSE
        if self.is_mouse_in_ref_view(context, event):
            # Cas 1: Middle mouse sans modificateurs
            if event.type == 'MIDDLEMOUSE' and event.value == 'PRESS' and not (event.shift or event.ctrl or event.alt):
                return {'RUNNING_MODAL'}
                
            # Cas 2: Alt + Left Mouse
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt and not (event.shift or event.ctrl):
                return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def execute(self, context):
        # On spécifie qu'on utilise la variable globale
        global _handle_dict
        
        self.report({'INFO'}, "Lock view executed")
        
        # Trouve et stocke la vue de référence
        prefs = get_addon_preferences()
        for area in context.screen.areas:
            if (area.type == 'VIEW_3D' and 
                hasattr(area.spaces[0].shading, 'background_color') and 
                area.spaces[0].shading.background_color == prefs.ref_view_bg_color):
                self._ref_view_area = area
                break
        
        # Si nous avons trouvé la vue de référence, stocke sa rotation
        if self._ref_view_area:
            with context.temp_override(area=self._ref_view_area):
                self._initial_rotation = context.space_data.region_3d.view_rotation.copy()
                context.space_data.region_3d.view_perspective = 'ORTHO'
                
                # Nettoie l'ancien handler s'il existe
                if _handle_dict["handle"] and _handle_dict["space"]:
                    try:
                        _handle_dict["space"].draw_handler_remove(_handle_dict["handle"], 'WINDOW')
                    except:
                        pass
                    _handle_dict["handle"] = None
                    _handle_dict["space"] = None
                
                # Stocke le nouveau handler dans le dictionnaire global
                args = (context,)
                _handle_dict["space"] = context.space_data
                _handle_dict["handle"] = context.space_data.draw_handler_add(
                    EASYREF_OT_lock_ref_view.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
        else:
            self.report({'WARNING'}, "Reference view not found")
            return {'CANCELLED'}
        
        # Ajoute le timer
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        
        self.report({'INFO'}, "Modal operator started")
        return {'RUNNING_MODAL'}


    
class EASYREF_OT_load_multiple_refs_popup(Operator):
    bl_idname = "object.easyref_load_multiple_refs_popup"
    bl_label = "Add References"
    bl_description = "Add Reference View & Load Reference/s"
    bl_options = {'REGISTER'}

    create_or_add_new_references: EnumProperty(
            items=(("CREATE", "CREATE", ""),
                   ("ADD", "ADD", "")),
                   default="CREATE",
                   description="Create a new collection for these references or add references to the current collection") # type: ignore
    
    create_collection: BoolProperty(
        name="Create a new References View Collection",
        description="Create a new References View collection for these references",
        default=False
    ) # type: ignore

    collection_name: StringProperty(
        name="Name",
        description="Name of the new References View collection",
        default="New_References"
    ) # type: ignore

    def get_collections(self, context):
        return [(col.name, col.name.replace("RV", ""), "") 
                for col in bpy.data.collections 
                if col.name.startswith("RV")]

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "create_collection")
        
        if self.create_collection:
            layout.prop(self, "collection_name")
        else:
            # Vérifie s'il existe des collections RV_
            collections = self.get_collections(context)
            if collections:
                layout.prop_search(context.scene.easyref_props, "existing_collection", 
                                 bpy.data, "collections", 
                                 text="Collections")
            else:
                layout.label(text="No existing RV collections found")
                layout.label(text="Default RV collection will be used")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        # Store properties in scene for access by load_multiple_refs
        context.scene.easyref_props.create_new_collection = self.create_collection
        
        if self.create_collection:
            context.scene.easyref_props.new_collection_name = self.collection_name
        else:
            # Si une collection existante est sélectionnée, utilise celle-ci
            selected_collection = context.scene.easyref_props.existing_collection
            if selected_collection:
                context.scene.easyref_props.new_collection_name = selected_collection.replace("RV_", "")
            else:
                # Sinon, utilise la collection RV par défaut
                context.scene.easyref_props.new_collection_name = "RV"

        # Launch the file browser
        if self.create_or_add_new_references == "CREATE":
            bpy.ops.object.easyref_load_multiple_refs('INVOKE_DEFAULT')
            
            # time.sleep(0.1)
            # bpy.ops.object.easyref_set_tools_category()
        elif self.create_or_add_new_references == "ADD":
            bpy.ops.object.easyref_add_new_references('INVOKE_DEFAULT')
        return {'FINISHED'}

class EASYREF_OT_load_multiple_refs(Operator, ImportHelper):
    bl_idname = "object.easyref_load_multiple_refs"
    bl_label = "Add Reference View & Load Reference/s"
    bl_description = "Add Reference View & Load Reference/s\n\nThat will Split the 3D view and add reference/s"
    bl_options = {'REGISTER', 'UNDO'}

    files: bpy.props.CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )# type: ignore

    filter_glob : StringProperty(
        default="*.exr;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.tga;*.bmp;*.webp;*.gif;*.psd;*.psb;*.hdr;*.svg",
        options={'HIDDEN'},
    ) # type: ignore

    def execute(self, context):
        prefs = get_addon_preferences()
        directory = os.path.dirname(self.filepath)
        spacing = 0.2  # Space between empties

        active_obj = context.view_layer.objects.active

        if active_obj:
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
            bpy.ops.object.select_all(action='DESELECT')
        
        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)
        
        # Determine target collection based on user choice
        if context.scene.easyref_props.create_new_collection:
            # Create new collection with RV_ prefix
            collection_name = "RV_" + context.scene.easyref_props.new_collection_name
            target_collection = bpy.data.collections.new(collection_name)
            ref_collection.children.link(target_collection)
        else:
            # Use existing collection or create default RV
            selected_collection = context.scene.easyref_props.existing_collection
            if selected_collection:
                target_collection = bpy.data.collections.get(selected_collection)
            else:
                # Create/get default RV collection
                ref_view_collection = bpy.data.collections.get("RV")
                if not ref_view_collection:
                    ref_view_collection = bpy.data.collections.new("RV")
                    ref_collection.children.link(ref_view_collection)
                target_collection = ref_view_collection
        
        # ADD IMAGES
        for i, file_elem in enumerate(self.files):
            filepath = os.path.join(directory, file_elem.name)
            
            # Create empty
            empty = bpy.data.objects.new(name=file_elem.name, object_data=None)
            empty["easyref_empty_ref_view"] = True
            target_collection.objects.link(empty)
            
            # Set empty properties
            empty.empty_display_type = 'IMAGE'
            empty.empty_display_size = 5
            
            # Load and assign image
            img = bpy.data.images.load(filepath)
            empty.data = img
            
            # Position empty at 500,500 with offset based on index
            # Calculate grid dimensions based on number of files
            num_files = len(self.files)
            grid_size = int(num_files ** 0.5) + (1 if num_files ** 0.5 % 1 > 0 else 0)
            
            # Calculate row and column for current index
            row = i // grid_size 
            col = i % grid_size
            
            # Position in grid with spacing
            empty.location.x = 0 + (col * (empty.empty_display_size + spacing))
            # empty.location.y = 1000 + (row * (empty.empty_display_size + spacing))
            empty.location.y = prefs.ref_view_position + (row * (empty.empty_display_size + spacing))
            empty.location.z = 0

            empty.lock_location[2] = True
            empty.lock_rotation[0] = True
            empty.lock_rotation[1] = True
            empty.lock_rotation[2] = True

            empty.show_empty_image_perspective = False

        bpy.ops.object.select_all(action='DESELECT')

        
        side = prefs.toggle_ref_view_side
        pref_factor = prefs.toggle_ref_view_factor
        editor_type = 'IMAGE_EDITOR'
        editor_ui_type = 'IMAGE_EDITOR'
        split_area(self, context, editor_type, editor_ui_type, side, pref_factor)

        bpy.ops.object.easyref_check_ref_view_area('INVOKE_DEFAULT')

        return {'FINISHED'}

class EASYREF_OT_add_new_references(Freezer, Operator, ImportHelper):
    bl_idname = "object.easyref_add_new_references"
    bl_label = "Add New References"
    bl_description = "Add New References to the References View"
    bl_options = {'REGISTER', 'UNDO'}

    files: bpy.props.CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )# type: ignore

    filter_glob : StringProperty(
        default="*.exr;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.tga;*.bmp;*.webp;*.gif;*.psd;*.psb;*.hdr;*.svg",
        options={'HIDDEN'},
    ) # type: ignore

    def execute(self, context):
        prefs = get_addon_preferences()
        directory = os.path.dirname(self.filepath)
        spacing = 0.2  # Space between empties

        active_obj = context.view_layer.objects.active

        if active_obj:
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
            bpy.ops.object.select_all(action='DESELECT')

        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)
        
        # Determine target collection based on user choice
        if context.scene.easyref_props.create_new_collection:
            # Create new collection with RV_ prefix
            collection_name = "RV_" + context.scene.easyref_props.new_collection_name
            target_collection = bpy.data.collections.new(collection_name)
            ref_collection.children.link(target_collection)
        else:
            # Use existing collection or create default RV
            selected_collection = context.scene.easyref_props.existing_collection
            if selected_collection:
                target_collection = bpy.data.collections.get(selected_collection)
            else:
                # Create/get default RV collection
                ref_view_collection = bpy.data.collections.get("RV")
                if not ref_view_collection:
                    ref_view_collection = bpy.data.collections.new("RV")
                    ref_collection.children.link(ref_view_collection)
                target_collection = ref_view_collection

        created_empties = []
        for i, file_elem in enumerate(self.files):
            filepath = os.path.join(directory, file_elem.name)
            
            # Generate unique name for empty
            base_name = file_elem.name
            empty_name = base_name
            counter = 1
            while empty_name in bpy.data.objects:
                empty_name = f"{os.path.splitext(base_name)[0]}_{counter}{os.path.splitext(base_name)[1]}"
                counter += 1
            
            # Create empty and link directly to target collection
            empty = bpy.data.objects.new(name=empty_name, object_data=None)
            empty["easyref_empty_ref_view"] = True
            empty.show_empty_image_perspective = False
            target_collection.objects.link(empty)
            created_empties.append(empty)
            
            # Set empty properties
            empty.empty_display_type = 'IMAGE'
            empty.empty_display_size = 5
            
            # Load and assign image
            img = bpy.data.images.load(filepath)
            empty.data = img
            
            # Position empty at 500,500 with offset based on index
            num_files = len(self.files)
            grid_size = int(num_files ** 0.5) + (1 if num_files ** 0.5 % 1 > 0 else 0)
            
            row = i // grid_size 
            col = i % grid_size
            
            empty.location.x = 0 + (col * (empty.empty_display_size + spacing))
            # empty.location.y = 1000 + (row * (empty.empty_display_size + spacing))
            empty.location.y = prefs.ref_view_position + (row * (empty.empty_display_size + spacing))
            empty.location.z = 0

            empty.lock_location[2] = True
            empty.lock_rotation[0] = True
            empty.lock_rotation[1] = True
            empty.lock_rotation[2] = True

        # Select all created empties to frame them
        if created_empties:
            bpy.ops.object.select_all(action='DESELECT')
            for empty in created_empties:
                empty.select_set(True)
            
            # Frame selected empties
            bpy.ops.view3d.view_selected(use_all_regions=False)
        
        return {'FINISHED'}

class EASYREF_OT_set_current_view_as_ref_view(Operator):
    bl_idname = "object.easyref_set_current_view_as_ref_view"
    bl_label = "Set Current View as Reference View"
    bl_description = "Set Current View as Reference View"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global ref_view_area_hash
        prefs = get_addon_preferences()

        # Get the active 3D view
        active_area = None
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                if area == context.area:
                    active_area = area
                    break

        if active_area:
            space = active_area.spaces.active
            view_settings = context.scene.easyref_props.view_settings

            # Store toolbar and overlay settings
            view_settings.show_region_toolbar = space.show_region_toolbar
            view_settings.show_ortho_grid = space.overlay.show_ortho_grid
            view_settings.show_text = space.overlay.show_text
            view_settings.show_cursor = space.overlay.show_cursor
            view_settings.show_outline_selected = space.overlay.show_outline_selected
            view_settings.show_bones = space.overlay.show_bones
            view_settings.show_motion_paths = space.overlay.show_motion_paths
            view_settings.show_object_origins = space.overlay.show_object_origins
            view_settings.show_viewer_attribute = space.overlay.show_viewer_attribute
            view_settings.show_floor = space.overlay.show_floor
            view_settings.show_axis_x = space.overlay.show_axis_x
            view_settings.show_axis_y = space.overlay.show_axis_y
            view_settings.show_axis_z = space.overlay.show_axis_z
            view_settings.show_relationship_lines = space.overlay.show_relationship_lines
            view_settings.background_type = space.shading.background_type
            view_settings.background_color = space.shading.background_color.copy()

            # Store view location, rotation and distance
            view3d = space.region_3d
            view_settings.view_location = view3d.view_location.copy()
            view_settings.view_rotation = view3d.view_rotation.copy()
            view_settings.view_distance = view3d.view_distance
            
            # Configure 3D view
            space.show_region_toolbar = False
            space.overlay.show_ortho_grid = False
            space.shading.background_type = 'VIEWPORT'
            space.shading.background_color = prefs.ref_view_bg_color
            space.overlay.show_text = False
            space.overlay.show_cursor = False
            space.overlay.show_outline_selected = True
            space.overlay.show_bones = False
            space.overlay.show_motion_paths = False
            space.overlay.show_object_origins = False
            space.overlay.show_viewer_attribute = False
            space.overlay.show_floor = False
            space.overlay.show_axis_x = False
            space.overlay.show_axis_y = False
            space.overlay.show_axis_z = False
            space.overlay.show_relationship_lines = False

            # Switch to top view
            with context.temp_override(area=active_area, 
                                    region=[r for r in active_area.regions if r.type == 'WINDOW'][0]):
                bpy.ops.view3d.view_axis(type='TOP')
            
            # Move view to reference location
            # space.region_3d.view_location = (0, 1000, 0)
            space.region_3d.view_location = (0, prefs.ref_view_position, 0)

            # Store area hash
            ref_view_area_hash = hash(active_area)
            
            context.scene.easyref_props.has_ref_view = True
            context.scene.easyref_props.ref_view_side = prefs.toggle_ref_view_side

        return {'FINISHED'}

class EASYREF_OT_restore_view_settings(Operator):
    bl_idname = "object.easyref_restore_view_settings"
    bl_label = "Restore View Settings"
    bl_description = "Restore the original view settings"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = get_addon_preferences()
        view_settings = context.scene.easyref_props.view_settings
        
        # Get the active 3D view
        active_area = None
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                if area == context.area:
                    active_area = area
                    break

        if active_area and (hasattr(active_area.spaces[0].shading, 'background_color') and 
                active_area.spaces[0].shading.background_color == prefs.ref_view_bg_color):
            space = active_area.spaces.active
            
            # Restore all settings
            space.show_region_toolbar = view_settings.show_region_toolbar
            space.overlay.show_ortho_grid = view_settings.show_ortho_grid
            space.overlay.show_text = view_settings.show_text
            space.overlay.show_cursor = view_settings.show_cursor
            space.overlay.show_outline_selected = view_settings.show_outline_selected
            space.overlay.show_bones = view_settings.show_bones
            space.overlay.show_motion_paths = view_settings.show_motion_paths
            space.overlay.show_object_origins = view_settings.show_object_origins
            space.overlay.show_viewer_attribute = view_settings.show_viewer_attribute
            space.overlay.show_floor = view_settings.show_floor
            space.overlay.show_axis_x = view_settings.show_axis_x
            space.overlay.show_axis_y = view_settings.show_axis_y
            space.overlay.show_axis_z = view_settings.show_axis_z
            space.overlay.show_relationship_lines = view_settings.show_relationship_lines
            space.shading.background_type = view_settings.background_type
            space.shading.background_color = view_settings.background_color

            # Restore view location, rotation and distance
            view3d = space.region_3d
            view3d.view_location = view_settings.view_location
            view3d.view_rotation = view_settings.view_rotation 
            view3d.view_distance = view_settings.view_distance

        return {'FINISHED'}
    
class EASYREF_OT_grid_refs(Operator):
    bl_idname = "object.easyref_grid_refs"
    bl_label = "Grid the Selected References"
    bl_options = {'REGISTER', 'UNDO'}

    columns: IntProperty(
        name="Columns",
        description="Number of columns in the grid",
        default=3,
        min=1
    ) # type: ignore

    spacing: FloatProperty(
        name="Spacing",
        description="Space between references",
        default=2.5,
        min=0.0
    ) # type: ignore

    @classmethod
    def poll(cls, context):
        return context.selected_objects and all(obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE' for obj in context.selected_objects)

    def execute(self, context):
        selected_refs = [obj for obj in context.selected_objects if obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE']
        
        if not selected_refs:
            self.report({'WARNING'}, "No image reference empties selected")
            return {'CANCELLED'}

        # Get bounding box center of selection
        min_x = min(ref.location.x for ref in selected_refs)
        min_y = min(ref.location.y for ref in selected_refs)
        
        num_refs = len(selected_refs)
        grid_size = int(num_refs ** 0.5) + (1 if num_refs ** 0.5 % 1 > 0 else 0)
        spacing = 0.05  # Same spacing as in load_multiple_refs

        for i, ref in enumerate(selected_refs):
            # Calculate row and column for current index
            row = i // grid_size 
            col = i % grid_size
            
            # Position in grid with spacing, exactly like in load_multiple_refs
            ref.location.x = min_x + (col * (ref.empty_display_size + spacing))
            ref.location.y = min_y + (row * (ref.empty_display_size + spacing))
            ref.location.z = ref.location.z  # Keep original Z position

        return {'FINISHED'}

class EASYREF_OT_center_ref_view(Freezer, Operator):
    bl_idname = "object.easyref_center_ref_view"
    bl_label = "Center Reference View"
    bl_description = "Center the view on the References"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = get_addon_preferences()
        # Check if we're in the reference view
        ref_view_area = get_ref_view_area(context)
        if not ref_view_area or context.area != ref_view_area:
            self.report({'WARNING'}, "This operator only works in the reference view")
            return {'CANCELLED'}
            
        self.save_selection(context)

        # Switch to top view
        bpy.ops.view3d.view_axis(type='TOP')
        
        # Get all RV collections
        ref_view_collections = [col for col in bpy.data.collections if col.name.startswith("RV")]
        
        if ref_view_collections:
            # Select all objects in RV collections
            bpy.ops.object.select_all(action='DESELECT')
            for collection in ref_view_collections:
                for obj in collection.objects:
                    obj.select_set(True)
                    context.view_layer.objects.active = obj
            
            # Center view on selection
            bpy.ops.view3d.view_selected(use_all_regions=False)
        else:
            # If no references, center at default position
            # ref_view_area.spaces[0].region_3d.view_location = (0, 1000, 0)
            ref_view_area.spaces[0].region_3d.view_location = (0, prefs.ref_view_position, 0)

        # Restore original selection
        bpy.ops.object.select_all(action='DESELECT')
        self.restore_selection(context)

        return {'FINISHED'}
    
class EASYREF_OT_remove_ref_view_references(Operator):
    bl_idname = "object.easyref_remove_ref_view_references" 
    bl_label = "Remove the References from the Reference View"
    bl_description = "Remove the References from the Reference View\n\nthis will Delete the References and the Collection"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Get all empties tagged as reference view
        ref_empties = [obj for obj in bpy.data.objects if obj.type == 'EMPTY' 
                      and obj.get("easyref_empty_ref_view")]
        
        # Delete all reference empties
        for empty in ref_empties:
            # Delete the image data if it exists
            if empty.data:
                bpy.data.images.remove(empty.data)
            # Delete the empty object    
            bpy.data.objects.remove(empty, do_unlink=True)

        # Find and remove all RV collections
        ref_view_collections = [col for col in bpy.data.collections if col.name.startswith("RV") or col.name.startswith("RV_")]
        for ref_view_collection in ref_view_collections:
            bpy.data.collections.remove(ref_view_collection, do_unlink=True)

        return {'FINISHED'}

class EditorProperties:
    def __init__(self):
        self.view_settings = {}
        self.selection = []
        self.view_location = None
        self.show_options = {}

def split_area(self, context, editor_type, editor_ui_type, side, pref_factor):
    global ref_view_area_hash
    prefs = get_addon_preferences()
    # Sauvegarde de la vue courante avant de sortir du mode maximisé
    current_area = context.area
    area_type = current_area.type
    ui_type = current_area.ui_type 
    easyref_props = context.scene.easyref_props

    # Convert editor type to display name
    if editor_ui_type == 'IMAGE_EDITOR':
        editor_name = 'Image Editor'

    # On vérifie si on est en mode maximisé
    if context.screen.show_fullscreen:
        bpy.ops.screen.screen_full_area()
        
        # On retrouve la zone correspondante après être sorti du mode maximisé
        for area in context.screen.areas:
            if area.type == area_type:
                current_area = area
                break

    with context.temp_override(area=current_area):
        # Calculer le facteur selon le côté (0-1)
        factor = pref_factor / 100
        
        # Forcer un léger décalage du factor pour éviter les ambiguïtés à 50%
        if factor == 0.5:
            if side in ["RIGHT", "TOP"]:
                factor = 0.51
            else:
                factor = 0.49

        # Déterminer la direction du split
        split_direction = "VERTICAL" if side in ["LEFT", "RIGHT"] else "HORIZONTAL"

        if side in ["RIGHT", "TOP"]:
            factor = 1 - factor
        
        # Effectuer le split avec le facteur original
        bpy.ops.screen.area_split(direction=split_direction, factor=factor)
        
        # Identifier les deux zones résultantes
        original_area = current_area  
        new_area = context.screen.areas[-1]  
        
        # Initialiser les variables target_width et target_height
        target_width = target_height = 0
        
        # Déterminer quelle zone doit contenir l'éditeur en fonction du facteur et du côté
        if split_direction == "VERTICAL":
            original_width = original_area.width
            new_width = new_area.width
            total_width = original_width + new_width
            
            target_width = factor * total_width
            if side == "RIGHT":
                target_width = (1 - factor) * total_width
                    
            editor = original_area if abs(original_width - target_width) < abs(new_width - target_width) else new_area
            view3d_area = new_area if editor == original_area else original_area
        else:
            original_height = original_area.height
            new_height = new_area.height
            total_height = original_height + new_height
            
            target_height = factor * total_height
            if side == "TOP":
                target_height = (1 - factor) * total_height
                    
            editor = original_area if abs(original_height - target_height) < abs(new_height - target_height) else new_area
            view3d_area = new_area if editor == original_area else original_area
        
        # Configurer l'éditeur dans la zone appropriée
        editor.type = editor_type
        editor.ui_type = editor_ui_type

        

        # Stocker le hash de l'area créée
        ref_view_area_hash = hash(editor)

        # Trouver la vue 3D active en utilisant le hash stocké
        for area in context.screen.areas:
            if area.type == 'IMAGE_EDITOR':
                if hash(area) == ref_view_area_hash:
                    # Convertir l'IMAGE_EDITOR en VIEW_3D
                    area.type = 'VIEW_3D'
                    area.ui_type = 'VIEW_3D'

                    # Configurer la vue 3D
                    space = area.spaces[0]
                    space.show_region_toolbar = False
                    space.overlay.show_ortho_grid = False
                    space.shading.background_type = 'VIEWPORT'
                    space.shading.background_color = prefs.ref_view_bg_color
                    space.overlay.show_text = False
                    space.overlay.show_cursor = False
                    space.overlay.show_outline_selected = True
                    space.overlay.show_bones = False
                    space.overlay.show_motion_paths = False
                    space.overlay.show_object_origins = False
                    space.overlay.show_viewer_attribute = False
                    space.overlay.show_floor = False
                    space.overlay.show_axis_x = False
                    space.overlay.show_axis_y = False
                    space.overlay.show_axis_z = False
                    space.overlay.show_relationship_lines = False

                    # Créer un override de contexte correct
                    override = context.copy()
                    override['window'] = context.window
                    override['screen'] = context.screen
                    override['area'] = area
                    override['region'] = [r for r in area.regions if r.type == 'WINDOW'][0]
                    override['space_data'] = space

                    with context.temp_override(**override):
                        bpy.ops.view3d.view_axis(type='TOP')
                        # space.region_3d.view_location = (0, 1000, 0)
                        space.region_3d.view_location = (0, prefs.ref_view_position, 0)
                        

                    if hasattr(self, 'files') and self.files:
                        # Sélectionner toutes les références
                        for file_elem in self.files:
                            empty_name = file_elem.name
                            if empty_name in bpy.data.objects:
                                empty = bpy.data.objects[empty_name]
                                empty.select_set(True)
                                context.view_layer.objects.active = empty
            
                        # Frame la sélection
                        with context.temp_override(**override):
                            bpy.ops.view3d.view_selected(use_all_regions=False)

                    break
        
        # Après avoir créé la nouvelle area, enregistrer son hash
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                if (hasattr(area.spaces[0].shading, 'background_color') and 
                    area.spaces[0].shading.background_color == prefs.ref_view_bg_color):
                    ref_view_area_hash = hash(area) 

                    break
        
        # Get index of the reference view area
        # ref_view_index = -1
        # for i, area in enumerate(context.screen.areas):
        #     if (area.type == 'VIEW_3D' and 
        #         hasattr(area.spaces[0].shading, 'background_color') and
        #         area.spaces[0].shading.background_color == (0.0061, 0.0062, 0.0063)):
        #         ref_view_index = i
        #         break

        easyref_props.has_ref_view = True
        easyref_props.ref_view_side = prefs.toggle_ref_view_side

        self.report({'INFO'}, "References View opened")

class EASYREF_OT_select_collection_objects(Operator):
    bl_idname = "object.easyref_select_collection_objects"
    bl_label = "Select Collection Objects"
    bl_description = "Select all objects in the collection\n\nSHIFT: Rename the collection"
    bl_options = {'REGISTER', 'UNDO'}
    
    collection_name: StringProperty() # type: ignore
    new_name: StringProperty(name="New Name") # type: ignore
    rename_mode: BoolProperty(default=False) # type: ignore

    def invoke(self, context, event):
        if event.shift:
            # Ouvre le popup pour renommer
            self.new_name = ""
            self.rename_mode = True
            return context.window_manager.invoke_props_dialog(self)
        self.rename_mode = False
        return self.execute(context)

    def draw(self, context):
        if self.new_name is not None:
            layout = self.layout
            layout.prop(self, "new_name")

    def execute(self, context):
        # Renomme la collection si en mode renommage
        if self.rename_mode and self.new_name:
            collection = bpy.data.collections.get(self.collection_name)
            if collection and collection.name.startswith("RV"):
                collection.name = f"RV_{self.new_name}"
            return {'FINISHED'}
            
        # Désélectionne tous les objets
        bpy.ops.object.select_all(action='DESELECT')
        
        # Récupère la collection
        collection = bpy.data.collections.get(self.collection_name)
        if collection:
            # Sélectionne tous les objets de la collection
            for obj in collection.objects:
                obj.select_set(True)
                
            # Définit le dernier objet comme actif
            if collection.objects:
                context.view_layer.objects.active = collection.objects[-1]
                
        return {'FINISHED'}

class EASYREF_OT_delete_collection(Operator):
    """Supprime la collection et tous ses objets"""
    bl_idname = "object.easyref_delete_collection" 
    bl_label = "Delete Collection"
    bl_options = {'REGISTER', 'UNDO'}
    
    collection_name: StringProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Récupère la collection
        collection = bpy.data.collections.get(self.collection_name)
        if collection:
            # Supprime tous les objets de la collection
            for obj in collection.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
            
            # Supprime la collection
            bpy.data.collections.remove(collection)
            
        return {'FINISHED'}

class EASYREF_OT_select_all_refview_objects(Operator):
    """Sélectionne tous les objets des collections RV"""
    bl_idname = "object.easyref_select_all_refview_objects"
    bl_label = "Select All References in the References View"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Désélectionne tous les objets
        bpy.ops.object.select_all(action='DESELECT')
        
        # Parcourt toutes les collections
        last_obj = None
        for collection in bpy.data.collections:
            if collection.name.startswith("RV"):
                # Sélectionne tous les objets de la collection
                for obj in collection.objects:
                    obj.select_set(True)
                    last_obj = obj
                    
        # Définit le dernier objet comme actif
        if last_obj:
            context.view_layer.objects.active = last_obj
                
        return {'FINISHED'}

class EASYREF_OT_delete_all_refview(Operator):
    bl_idname = "object.easyref_delete_all_refview"
    bl_label = "Delete All References and theirCollections"
    bl_description = "Delete all References and the their collection"
    bl_options = {'REGISTER', 'UNDO'}
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="This will delete all References View collections")
        layout.label(text="and their objects. This cannot be undone!")
        
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
        
    def execute(self, context):
        # Liste pour stocker les collections à supprimer
        collections_to_remove = []
        
        # Parcourt toutes les collections
        for collection in bpy.data.collections:
            if collection.name.startswith("RV"):
                collections_to_remove.append(collection)
                
        # Supprime les collections et leurs objets
        for collection in collections_to_remove:
            # Supprime tous les objets de la collection
            for obj in collection.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
            
            # Supprime la collection
            bpy.data.collections.remove(collection)
            
        self.report({'INFO'}, f"Deleted {len(collections_to_remove)} collections")
        return {'FINISHED'}

class EASYREF_OT_toggle_all_refview_collections(Operator):
    bl_idname = "object.easyref_toggle_all_refview_collections"
    bl_label = "Show/Hide All References View Collections"
    bl_description = "Toggle visibility of all References View Collections"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Get all RV collections
        ref_view_collections = [col for col in bpy.data.collections if col.name.startswith("RV")]
        
        if not ref_view_collections:
            self.report({'INFO'}, "No References View collections found")
            return {'CANCELLED'}
            
        # Check if any collection is visible to determine action
        any_visible = False
        for collection in ref_view_collections:
            if not collection.hide_viewport:
                any_visible = True
                break
                
        # Toggle visibility based on any_visible
        for collection in ref_view_collections:
            collection.hide_viewport = any_visible
            
        action = "Hidden" if any_visible else "Shown"
        self.report({'INFO'}, f"{action} {len(ref_view_collections)} References View collections")
        
        return {'FINISHED'}

class EASYREF_OT_frame_collection_objects(Freezer, Operator):
    """Frame the empties in the collection"""
    bl_idname = "object.easyref_frame_collection_objects"
    bl_label = "Frame Collection Objects"
    bl_description = "Frame all References in the selected collection"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection Name",
        description="Name of the collection to frame",
        default=""
    ) # type: ignore

    def execute(self, context):

        bpy.ops.view3d.view_axis(type='TOP')

        # Get the collection
        collection = bpy.data.collections.get(self.collection_name)
        if not collection:
            self.report({'WARNING'}, f"Collection {self.collection_name} not found")
            return {'CANCELLED'}

        self.save_selection(context)

        # Deselect all
        bpy.ops.object.select_all(action='DESELECT')

        # Select objects in collection
        for obj in collection.objects:
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.view3d.view_selected(use_all_regions=False)

        bpy.ops.object.select_all(action='DESELECT')
        self.restore_selection(context)

        return {'FINISHED'}

class EASYREF_OT_move_to_collection(Operator):
    bl_idname = "object.easyref_move_to_collection"
    bl_label = "Move to Collection"
    bl_description = "Move selected objects to specified collection"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection",
        description="Target collection to move objects to",
        default=""
    ) # type: ignore

    def get_collections(self, context):
        collections = []
        for collection in bpy.data.collections:
            collections.append((collection.name, collection.name, ""))
        return collections

    def draw(self, context):
        layout = self.layout
        layout.prop_search(self, "collection_name", bpy.data, "collections", text="Collection")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        # Get target collection
        target_collection = bpy.data.collections.get(self.collection_name)
        if not target_collection:
            self.report({'WARNING'}, f"Collection {self.collection_name} not found")
            return {'CANCELLED'}

        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Move each selected object to target collection
        for obj in selected_objects:
            # Remove from current collections
            for collection in obj.users_collection:
                collection.objects.unlink(obj)
            
            # Link to target collection
            target_collection.objects.link(obj)

        self.report({'INFO'}, f"Moved {len(selected_objects)} objects to {self.collection_name}")
        return {'FINISHED'}

class EASYREF_OT_add_to_new_collection(Operator):
    bl_idname = "object.easyref_add_to_new_collection"
    bl_label = "Add to New Collection" 
    bl_description = "Create a new collection and move selected objects to it"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collection Name",
        description="Name of the new collection",
        default="New Collection"
    ) # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "collection_name")

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Get or create REFERENCES collection
        ref_collection = bpy.data.collections.get("REFERENCES")
        if not ref_collection:
            ref_collection = bpy.data.collections.new("REFERENCES")
            context.scene.collection.children.link(ref_collection)

        # Create new collection with RV_ prefix
        collection_name = "RV_" + self.collection_name
        new_collection = bpy.data.collections.new(collection_name)
        ref_collection.children.link(new_collection)

        # Move selected objects to new collection
        for obj in selected_objects:
            # Remove from current collections
            for collection in obj.users_collection:
                collection.objects.unlink(obj)
            
            # Link to new collection
            new_collection.objects.link(obj)

        self.report({'INFO'}, f"Created collection '{collection_name}' with {len(selected_objects)} objects")
        return {'FINISHED'}

# class EASYREF_OT_check_ref_view_area(Operator):
#     bl_idname = "object.easyref_check_ref_view_area"
#     bl_label = "Check Reference View Area"
#     bl_description = "Check if reference view area exists and set tools category"
    
#     _timer = None
    
#     def modal(self, context, event):
#         if event.type == 'TIMER':
#             ref_view_area = get_ref_view_area(context)
            
#             if ref_view_area:
#                 # Reference view area found, set tools category and finish
#                 set_tools_category(context)

#                 context.window_manager.event_timer_remove(self._timer)

#                 return {'FINISHED'}
                
#         return {'PASS_THROUGH'}
        
#     def execute(self, context):
#         wm = context.window_manager
#         self._timer = wm.event_timer_add(0.01, window=context.window)
#         wm.modal_handler_add(self)
#         return {'RUNNING_MODAL'}
class EASYREF_OT_check_ref_view_area(Operator):
    bl_idname = "object.easyref_check_ref_view_area"
    bl_label = "Check Reference View Area"
    bl_description = "Check if reference view area exists and set tools category"
    
    _timer = None
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            ref_view_area = get_ref_view_area(context)
            
            if ref_view_area:
                # Reference view area found, set tools category
                set_tools_category(context)
                
                # Active le flag has_ref_view
                context.scene.easyref_props.has_ref_view = True
                
                # Lance le modal de verrouillage avec un override correct
                with context.temp_override(area=ref_view_area):
                    self.report({'INFO'}, "Launching lock_ref_view")
                    bpy.ops.view3d.lock_ref_view()
                
                context.window_manager.event_timer_remove(self._timer)
                self.report({'INFO'}, "Reference view checked and modal launched")
                return {'FINISHED'}
                
        return {'PASS_THROUGH'}
        
    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        self.report({'INFO'}, "Check ref view area started")
        return {'RUNNING_MODAL'}
    
CLASSES =  [EASYREF_OT_lock_ref_view,
            EASYREF_OT_flip_references_vertical,
            EASYREF_OT_flip_references_horizontal,
            EASYREF_OT_check_ref_view_area,
            EASYREF_OT_add_to_new_collection,
            EASYREF_OT_move_to_collection,
            EASYREF_OT_set_tools_category,
            EASYREF_OT_frame_collection_objects,
            EASYREF_OT_toggle_all_refview_collections,
            EASYREF_OT_select_all_refview_objects,
            EASYREF_OT_delete_all_refview,
            EASYREF_OT_select_collection_objects,
            EASYREF_OT_delete_collection,
            EASYREF_OT_load_multiple_refs_popup,
            EASYREF_OT_add_image_ref,
            EASYREF_OT_set_current_view_as_ref_view,
            EASYREF_OT_restore_view_settings,
            EASYREF_OT_show_ref_view,
            EASYREF_OT_close_ref_view,
            EASYREF_OT_set_ref_view,
            EASYREF_OT_remove_ref_view_references,
            EASYREF_OT_center_ref_view,
            EASYREF_OT_add_new_references,
            EASYREF_OT_grid_refs,
            EASYREF_OT_load_multiple_refs,
            # EASYREF_OT_lock_all_empty,
            EASYREF_OT_lock_empty,
            EASYREF_OT_load_ref,
            EASYREF_OT_delete_ref,
            EASYREF_OT_show_refs_settings,
            EASYREF_OT_hide_refs_settings,
            EASYREF_OT_flip_references,
            EASYREF_OT_hide_all_refs,
            EASYREF_OT_show_all_refs,
            EASYREF_OT_delete_all_refs,
            EASYREF_OT_hide_ref,
            EASYREF_OT_show_ref,
            EASYREF_OT_set_reference
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")
    
    

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES:
    #     bpy.utils.unregister_class(cls)