# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
#
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------
import bpy
import json
import sys
import os


def log(str):
    print("[log]{}\n".format("\n[log]".join(str.split("\n"))))

def save_objects(src_file, dst_file, objects, prefix, clean):
    """Save a list of objects
        :param src_file: source file full name
        :param objects: json array of materials names
        :return:
        """

    # Cleanup scene
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()

    log("\n******************************\nArchipack save objects:\n   %s\n" % "\n   ".join(objects))

    try:
        with bpy.data.libraries.load(src_file, link=False, relative=False) as (data_from, data_to):
            data_to.objects = objects

        for obj in objects:

            o_name = "%s%s"[0:60] % (prefix, obj.name)

            if not obj.name.startswith(prefix):
                # prefix to prevent naming collisions at load time
                obj.name = o_name

            if obj.name != o_name:
                raise ValueError("Name collision, ensure preset name + object name are less than 60 chars and unique")

            obj.use_fake_user = True

        log("save object to %s" % dst_file)
        bpy.ops.file.pack_all()
        bpy.ops.wm.save_as_mainfile(filepath=dst_file, copy=True, check_existing=False, compress=True)

    except Exception as ex:
        log("Archipack: Error while saving objects %s" % ex)
        pass

    try:
        # remove .blend1
        os.remove("%s1" % dst_file)
    except:
        pass

    log("******************************")
    # return
    if clean:
        try:
            os.remove(src_file)
        except:
            pass


def wait(src_file, timestamp, max):
    import time
    attempts = 0
    while os.path.getmtime(src_file) < timestamp and attempts < max:
        time.sleep(1)
        attempts += 1
        log("Wait object temp file attempts %s" % attempts)
    return attempts < max


if __name__ == "__main__":

    for arg in sys.argv:
        if arg.startswith("file:"):
            src_file = arg[5:]
        if arg.startswith("target:"):
            dst_file = arg[7:]
        if arg.startswith("name:"):
            # reformat json
            print("arg:", arg[5::])
            fstr = arg[5::].strip().replace("[", "").replace("]", "").replace("'", "").replace("\"", "")
            print("fstr:", fstr)
            jstr = '["{}"]'.format('","'.join(fstr.split(",")))
            print("jstr:", jstr)
            objects = json.loads(jstr)
            print(objects)
        if arg.startswith("clean:"):
            clean = int(arg[6:]) == 1
        if arg.startswith("prefix:"):
            prefix = arg[7:]
        if arg.startswith("stime:"):
            timestamp = float(arg[6:])

    for arg in sys.argv:
        log(arg)

    # saving file might be delayed, so wait for it max 30 sec
    res = wait(src_file, timestamp, 30)
    if res:
        save_objects(src_file, dst_file, objects, prefix, clean)
    else:
        log("Archipack: Error while saving object temp file not found")