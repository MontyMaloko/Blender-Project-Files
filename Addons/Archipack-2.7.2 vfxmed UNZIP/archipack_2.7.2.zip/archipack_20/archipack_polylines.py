# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------

import time
import bpy
from math import cos, sin, pi, atan2, radians
import bmesh
from .bmesh_utils import BmeshEdit as bmed
from mathutils import Vector, Matrix
from mathutils.geometry import intersect_line_plane, interpolate_bezier
from bpy_extras import view3d_utils
from bpy.types import Operator, PropertyGroup
from bpy.props import (
    FloatProperty,
    PointerProperty,
    EnumProperty,
    IntProperty,
    BoolProperty
    )
from bpy.app.handlers import persistent
from .bitarray import BitArray
from .pyqtree import _QuadTree
from .archipack_gl import (
    FeedbackPanel,
    GlCursorFence,
    GlCursorArea,
    GlLine,
    GlPolyline
    )
from .archipack_object import objman
from .archipack_viewmanager import ViewManager
from .archipack_abstraction import (
    ArchipackObjectsManager, ensure_select_and_restore, stop_auto_manipulate, context_override,
    X_AXIS, Z_AXIS
)

from .pygeos.op_polygonize import PolygonizeOp
from .pygeos.geom import GeometryFactory
from .pygeos.geom import Point as GeosPoint
from .pygeos.shared import (
    Coordinate,
    CoordinateSequence,
    Envelope,
    TopologyException
    )
from .pygeos.prepared import PreparedGeometryFactory
from .pygeos.op_polygonsunion import PolygonsUnionOp
from .archipack_generator import Generator, Line
from .polyskel import polyskel

# from .archipack_logging import logger
import logging
logger = logging.getLogger(__name__)

# use cookie cut to extract geometry from plane
USE_COOKIE_CUT = False

# enable poly to wall debug
DEBUG = False
DEBUG_SKELETON = False
DEBUG_MONOTONIZE = False


class Debug_skeleton:
    def __init__(self, prefix=""):
        self.prefix = prefix

    def line(self, *args, **kwargs):
        _prefix = kwargs['fill']
        if 'prefix' in kwargs:
            _prefix = kwargs['prefix']
        iteration = kwargs['iteration']
        dx = 30 * iteration
        x0, y0, x1, y1 = args[0]
        Debug.line(
            [Vector((dx + x0, y0, 0)), Vector((dx + x1, y1, 0))],
            "poly-%s-iter-%s-%s" % (self.prefix, kwargs['iteration'], _prefix)
        )

    def rectangle(self, *args, **kwargs):
        pass

    def show(self):
        pass


# Experimental (not so :( ) "Fast" snap
USE_FAST_SNAP = False


class Debug:

    @staticmethod
    def circle(p, name, radius):
        pts = [p + radius * Vector((sin(radians(a)), cos(radians(a)), 0)) for a in range(0, 360, 20)]
        pts.append(pts[0])
        Debug.line(pts, name)

    @staticmethod
    def line(coords, name):
        curve = bpy.data.curves.new(name, type='CURVE')
        spline = curve.splines.new('POLY')
        spline.use_endpoint_u = False
        spline.use_cyclic_u = coords[0] == coords[-1]
        if coords[0] == coords[-1]:
            coords.pop()
        spline.points.add(count=len(coords)-1)
        for i, p in enumerate(coords):
            spline.points[i].co = p.to_4d()
        curve_obj = bpy.data.objects.new(name, curve)
        objman.link_object_to_scene(bpy.context, curve_obj, layer_name="2d")

    @staticmethod
    def point(p, name, r=0.05):
        Debug.circle(p.to_3d(), name, r)

    @staticmethod
    def points(points, name="Point", r=0.05):
        for i, p in enumerate(points):
            Debug.point(p, "%s_%s" % (name, i), r)

    @staticmethod
    def segment(s, name):
        Debug.line([s.c0.to_3d(), s.c1.to_3d()], name)

    @staticmethod
    def segments(segments, name="Segment"):
        for i, s in enumerate(segments):
            Debug.segment(s, "%s_%s" % (name, i))


def debugTree(context, coordsys, tree):
    coords = [[seg.c0.to_3d(), seg.c1.to_3d()] for seg in tree._geoms if seg.users > 1]
    io = Io(context, context.scene, coordsys)
    geoms = io.coords_to_linestring(Matrix(), coords, False)
    io.to_curve(context.scene, coordsys, geoms)



# module shared
# precision 1e-4 = 0.1mm
EPSILON = 1.0e-4
# Qtree params
MAX_ITEMS = 10
MAX_DEPTH = 20


# module globals vars dict
vars_dict = {
    # keep track of shapely geometry selection sets
    'select_polygons': None,
    'select_lines': None,
    'select_points': None
    }


# load custom tool settings
def settings_load(self):
    params = bpy.context.window_manager.archipack.polylib
    tool = type(self).__name__.split("_")[-1].lower()
    keys = self.as_keywords().keys()
    for key in keys:
        if tool + "_" + key in params:
            setattr(self, key, getattr(params, tool + "_" + key))


# store custom tool settings
def settings_write(self):
    params = bpy.context.window_manager.archipack.polylib
    tool = type(self).__name__.split("_")[-1].lower()
    keys = self.as_keywords().keys()
    for key in keys:
        if tool + "_" + key in params:
            setattr(params, tool + "_" + key, getattr(self, key))


class Selectable(ArchipackObjectsManager):

    """ selectable shapely geoms """
    def __init__(self, geoms, coordsys):
        # selection sets (bitArray)
        self.selections = []
        # selected objects on screen representation
        self.curves = []
        # Rtree to speedup region selections
        self.tree = Qtree(coordsys)
        self.tree.build(geoms)
        # BitArray ids of selected geoms
        self.ba = BitArray(self.ngeoms)
        self.cursor_fence = GlCursorFence()
        self.cursor_fence.enable()
        self.cursor_area = GlCursorArea()
        self.feedback = FeedbackPanel()
        self.action = None
        self.store_index = 0
        self.gf = GeometryFactory()

    @property
    def coordsys(self):
        return self.tree.coordsys

    @property
    def geoms(self):
        return self.tree._geoms

    @property
    def ngeoms(self):
        return self.tree.ngeoms

    @property
    def nsets(self):
        return len(self.selections)

    def build_display_mat(self, name, color=(0.2, 0.2, 0, 1)):
        mat = bpy.data.materials.get(name)
        if mat is None:
            mat = bpy.data.materials.new(name)
            mat.diffuse_color = color
        return mat

    def _unselect(self, selection):
        t = time.time()
        for i in selection:
            self.ba.clear(i)
        logger.debug("Selectable._unselect() :%.2f seconds" % (time.time() - t))

    def _select(self, selection):
        t = time.time()
        for i in selection:
            self.ba.set(i)
        logger.debug("Selectable._select() :%.2f seconds" % (time.time() - t))

    def _position_3d_from_coord(self, context, coord):
        """return point in local input coordsys
        """
        region = context.region
        rv3d = context.region_data
        view_vector_mouse = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin_mouse = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        loc = intersect_line_plane(ray_origin_mouse, ray_origin_mouse + view_vector_mouse,
                                   Vector((0, 0, 0)), Vector((0, 0, 1)), False)
        x, y, z = self.coordsys.invert @ loc
        return Vector((x, y, z))

    def _position_2d_from_coord(self, context, coord):
        """ coord given in local input coordsys
        """
        region = context.region
        rv3d = context.region_data
        loc = view3d_utils.location_3d_to_region_2d(region, rv3d, self.coordsys.world @ coord)
        x, y = loc
        return Vector((x, y))

    def _contains(self, context, coord, event):
        t = time.time()
        point = self._position_3d_from_coord(context, coord)
        selection = []
        pt = self.gf.createPoint(point)
        prepared_pt = PreparedGeometryFactory.prepare(pt)
        count, gids = self.tree.intersects(pt)
        selection = [i for i in gids if prepared_pt.intersects(self.geoms[i])]
        logger.debug("Selectable._contains() :%.2f seconds selected:%s" % (time.time() - t, len(selection)))
        if event.shift:
            self._unselect(selection)
        else:
            self._select(selection)
        self._draw(context)

    def _intersects(self, context, coord, event):
        t = time.time()
        c0 = self._position_3d_from_coord(context, coord)
        c1 = self._position_3d_from_coord(context, (coord[0], event.mouse_region_y))
        c2 = self._position_3d_from_coord(context, (event.mouse_region_x, event.mouse_region_y))
        c3 = self._position_3d_from_coord(context, (event.mouse_region_x, coord[1]))
        cs = [self.gf.createCoordinate(pt) for pt in [c0, c1, c2, c3, c0]]
        try:
            ring = self.gf.createLinearRing(cs)
            if not ring.is_ccw:
                ring = self.gf.createLinearRing(list(reversed(cs)))
            poly = self.gf.createPolygon(ring)
        except ValueError:
            poly = self.gf.createGeometryCollection()
            pass

        prepared_poly = PreparedGeometryFactory.prepare(poly)
        count, gids = self.tree.intersects(poly)

        if event.ctrl:
            selection = [i for i in gids if prepared_poly.contains(self.geoms[i])]
        else:
            selection = [i for i in gids if prepared_poly.intersects(self.geoms[i])]
        logger.debug("Selectable._intersects() :%.2f seconds selected:%s" % (time.time() - t, len(selection)))
        if event.shift:
            self._unselect(selection)
        else:
            self._select(selection)
        self._draw(context)

    def _hide(self, context):
        t = time.time()
        if len(self.curves) > 0:
            try:
                for curve in self.curves:
                    self.delete_object(context, curve)
            except:
                pass
            self.curves = []
        logger.debug("Selectable._hide() :%.2f seconds" % (time.time() - t))

    def _draw(self, context):
        logger.debug("Selectable._draw() %s" % self.coordsys.world)
        t = time.time()
        self._hide(context)
        selection = [self.geoms[i] for i in self.ba.list]
        if len(selection) > 1000:
            self.curves = [Io.to_curve(context.scene, self.coordsys, selection, 'selection', '3D')]
        else:
            self.curves = Io.to_curves(context.scene, self.coordsys, selection, 'selection', '2D')
        # fix issue on undo
        r, g, b = context.preferences.themes[0].view_3d.object_selected[0:3]
        mat = self.build_display_mat("Selected", color=(r, g, b, 1))
        for curve in self.curves:
            curve.color = (1, 1, 0, 1)
            if len(curve.data.materials) < 1:
                curve.data.materials.append(mat)
                curve.active_material = mat
            self.select_object(context, curve)
        logger.debug("Selectable._draw() :%.2f seconds" % (time.time() - t))

    def store(self):
        self.selections.append(self.ba.copy)
        self.store_index = self.nsets

    def recall(self):
        if self.nsets > 0:
            if self.store_index < 1:
                self.store_index = self.nsets
            self.store_index -= 1
            self.ba = self.selections[self.store_index].copy

    def select(self, context, coord, event):
        if abs(event.mouse_region_x - coord[0]) > 2 and abs(event.mouse_region_y - coord[1]) > 2:
            self._intersects(context, coord, event)
        else:
            self._contains(context, (event.mouse_region_x, event.mouse_region_y), event)

    def init(self, pick_tool, context, action):
        raise NotImplementedError("Selectable must implement init(self, pick_tool, context, action)")

    def keyboard(self, context, event):
        """ keyboard events modal handler """
        raise NotImplementedError("Selectable must implement keyboard(self, context, event)")

    def complete(self, context):
        raise NotImplementedError("Selectable must implement complete(self, context)")

    def modal(self, context, event):
        """ modal handler """
        raise NotImplementedError("Selectable must implement modal(self, context, event)")

    def draw_callback(self, _self, context):
        """ a gl draw callback """
        raise NotImplementedError("Selectable must implement draw_callback(self, _self, context)")


class SelectPoints(Selectable):

    def __init__(self, geoms, coordsys):
        Selectable.__init__(self, geoms, coordsys)

    def _draw(self, context):
        """ override draw method """
        logger.debug("SelectPoints._draw()")
        t = time.time()
        self._hide(context)
        selection = list(self.geoms[i] for i in self.ba.list)
        if len(selection) < 2:
            return
        gf = GeometryFactory()
        geom = gf.buildGeometry(selection)
        # geom = ShapelyOps.union(selection)
        # if geom is None:
        #    return
        self.curves = [Io.to_curve(context.scene, self.coordsys, geom.convex_hull, 'selection', '3D')]
        for curve in self.curves:
            curve.color = (1, 1, 0, 1)
            self.select_object(context, curve)
        logger.debug("SelectPoints._draw() :%.2f seconds" % (time.time() - t))

    def init(self, pick_tool, context):
        # Post selection actions
        self.selectMode = True
        self.object_location = None
        self.startPoint = (0, 0)
        self.endPoint = (0, 0)
        self.drag = False
        self.feedback.instructions(context, "Select Points", "Click & Drag to select points in area", [
            ('SHIFT', 'deselect'),
            ('CTRL', 'contains'),
            ('A', 'All'),
            ('I', 'Inverse'),
            ('F', 'Create line around selection'),
            # ('W', 'Create window using selection'),
            # ('D', 'Create door using selection'),
            ('ALT+F', 'Create best fit rectangle'),
            ('R', 'Retrieve selection'),
            ('S', 'Store selection'),
            ('ESC or RIGHTMOUSE', 'exit when done')
        ])
        self.feedback.enable()
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
        self._draw(context)
        logger.info("SelectPoints.init()")

    def complete(self, context):
        self._hide(context)

    def keyboard(self, context, event):
        if event.type in {'A'}:
            if len(self.ba.list) > 0:
                self.ba.none()
            else:
                self.ba.all()
        elif event.type in {'I'}:
            self.ba.reverse()
        elif event.type in {'S'}:
            self.store()
        elif event.type in {'R'}:
            self.recall()
        elif event.type in {'F'}:
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                scene = context.scene
                gf = GeometryFactory()
                geom = gf.buildGeometry(sel)
                # geom = ShapelyOps.union(sel)
                if event.alt:
                    tM, w, h, poly, w_pts = ShapelyOps.min_bounding_rect(geom)
                    result = Io.to_curve(scene, self.coordsys, poly, 'points')
                    result.matrix_world = self.coordsys.world @ tM
                    self.select_object(context, result, True)
                else:
                    result = Io.to_curve(scene, self.coordsys, geom.convex_hull, 'points')
                    self.select_object(context, result, True)
            self.ba.none()
            self.complete(context)
        elif event.type in {'W'}:
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 2:
                scene = context.scene
                gf = GeometryFactory()
                geom = gf.buildGeometry(sel)
                if event.alt:
                    tM, w, h, poly, w_pts = ShapelyOps.min_bounding_rect(geom)
                    result = Io.to_curve(scene, self.coordsys, poly, 'points')
                    result.matrix_world = self.coordsys.world @ tM
                    self.select_object(context, result, True)
                else:
                    result = Io.to_curve(scene, self.coordsys, geom.convex_hull, 'points')
                    self.select_object(context, result, True)
            self.ba.none()
            self.complete(context)
        elif event.type in {'D'}:
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 2:
                scene = context.scene
                gf = GeometryFactory()
                geom = gf.buildGeometry(sel)
                # geom = ShapelyOps.union(sel)
                if event.alt:
                    tM, w, h, poly, w_pts = ShapelyOps.min_bounding_rect(geom)
                    result = Io.to_curve(scene, self.coordsys, poly, 'points')
                    result.matrix_world = self.coordsys.world @ tM
                    self.select_object(context, result, True)
                else:
                    result = Io.to_curve(scene, self.coordsys, geom.convex_hull, 'points')
                    self.select_object(context, result, True)
            self.ba.none()
            self.complete(context)
        self._draw(context)

    def modal(self, context, event):
        if event.type in {'I', 'A', 'S', 'R', 'F'} and event.value == 'PRESS':
            self.keyboard(context, event)
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.complete(context)
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self.feedback.disable()
            return {'FINISHED'}
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.drag = True
            self.cursor_area.enable()
            self.cursor_fence.disable()
            self.startPoint = (event.mouse_region_x, event.mouse_region_y)
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.drag = False
            self.cursor_area.disable()
            self.cursor_fence.enable()
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
            self.select(context, self.startPoint, event)
        elif event.type == 'MOUSEMOVE':
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
        return {'RUNNING_MODAL'}

    def draw_callback(self, _self, context):
        self.feedback.draw(context)
        self.cursor_area.set_location(context, self.startPoint, self.endPoint)
        self.cursor_fence.set_location(context, self.endPoint)
        self.cursor_area.draw(context)
        self.cursor_fence.draw(context)


class SelectLines(Selectable):

    def __init__(self, geoms, coordsys):
        Selectable.__init__(self, geoms, coordsys)

    def _draw(self, context):
        """ override draw method """
        logger.debug("SelectLines._draw()")
        t = time.time()
        self._hide(context)
        selection = list(self.geoms[i] for i in self.ba.list)
        self.curves = [Io.to_curve(context.scene, self.coordsys, selection, 'selection', '3D')]
        for curve in self.curves:
            curve.color = (1, 1, 0, 1)
            self.select_object(context, curve)
        logger.debug("SelectLines._draw() :%.2f seconds" % (time.time() - t))

    def init(self, pick_tool, context):
        # Post selection actions
        self.selectMode = True
        self.object_location = None
        self.startPoint = (0, 0)
        self.endPoint = (0, 0)
        self.drag = False
        self.feedback.instructions(context, "Select Lines", "Click & Drag to select lines in area", [
            ('SHIFT', 'deselect'),
            ('CTRL', 'contains'),
            ('A', 'All'),
            ('I', 'Inverse'),
            ('L', 'Retrieve selection'),
            ('S', 'Store selection'),
            ('F', 'Create lines from selection'),
            ('U', 'Union of lines from selection'),
            ('ESC or RIGHTMOUSE', 'exit when done')
        ])
        self.feedback.enable()
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
                self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
        self.action = 'select'
        self._draw(context)
        logger.debug("SelectLines.init()")

    def complete(self, context):
        logger.debug("SelectLines.complete()")
        t = time.time()
        self._hide(context)
        scene = context.scene
        selection = list(self.geoms[i] for i in self.ba.list)
        if len(selection) > 0:
            if self.action == 'select':
                result = Io.to_curve(scene, self.coordsys, selection, 'selection')
                self.select_object(context, result, True)
            elif self.action == 'union':
                gf = GeometryFactory()
                coll = gf.buildGeometry(selection)
                # merged = gf.buildGeometry(coll.line_merge())
                # resopt = merged.simplify(tolerance=0.001, preserve_topology=False)
                resopt = gf.buildGeometry(coll.line_merge())
                """
                shapes = Io.geoms_to_shapes(selection)
                merged = ShapeOps.merge(shapes)
                union = Io.shapes_to_geoms(merged)
                # union = self.ops.union(selection)
                resopt = ShapelyOps.optimize(union)
                """
                result = Io.to_curve(scene, self.coordsys, resopt, 'union')
                self.select_object(context, result, True)
        logger.info("SelectLines.complete() :%.2f seconds" % (time.time() - t))

    def keyboard(self, context, event):
        if event.type in {'A'}:
            if len(self.ba.list) > 0:
                self.ba.none()
            else:
                self.ba.all()
        elif event.type in {'I'}:
            self.ba.reverse()
        elif event.type in {'L'}:
            self.store()
        elif event.type in {'R'}:
            self.recall()
        elif event.type in {'F'}:
            self.action = 'select'
            self.complete(context)
        elif event.type in {'U'}:
            self.action = 'union'
            self.complete(context)
        self._draw(context)

    def modal(self, context, event):
        if event.type in {'I', 'A', 'L', 'R', 'F', 'U'} and event.value == 'PRESS':
            self.keyboard(context, event)
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self.feedback.disable()
            self._hide(context)
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'FINISHED'}
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.drag = True
            self.cursor_area.enable()
            self.cursor_fence.disable()
            self.startPoint = (event.mouse_region_x, event.mouse_region_y)
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.drag = False
            self.cursor_area.disable()
            self.cursor_fence.enable()
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
            self.select(context, self.startPoint, event)
        elif event.type == 'MOUSEMOVE':
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
        return {'RUNNING_MODAL'}

    def draw_callback(self, _self, context):
        self.feedback.draw(context)
        self.cursor_area.set_location(context, self.startPoint, self.endPoint)
        self.cursor_fence.set_location(context, self.endPoint)
        self.cursor_area.draw(context)
        self.cursor_fence.draw(context)


class SelectPolygons(Selectable):

    def __init__(self, geoms, coordsys):
        Selectable.__init__(self, geoms, coordsys)

    """
        pick_tools actions
    """
    def init(self, pick_tool, context):
        # Post selection actions
        self.need_rotation = False
        self.direction = 0
        self.object_location = None
        self.selectMode = True
        self.startPoint = (0, 0)
        self.endPoint = (0, 0)
        self.feedback.instructions(context, "Select Polygons", "Click & Drag to select polygons in area", [
            ('SHIFT', 'deselect'),
            ('CTRL', 'contains'),
            ('A', 'All'),
            ('I', 'Inverse'),
            ('B', 'Bigger than current'),
            ('S', 'Save selection'),
            ('L', 'Load selection'),
            ('R', 'Rectangle from selection'),
            ('D', 'Door from selection'),
            ('W', 'Window from selection'),
            ('U', 'Union of selection'),
            ('E', 'Wall from selection'),
            ('ALT+E', 'Extrude wall from selection'),
            ('F', 'Surface from selection'),
            ('O', 'Output selection'),
            ('ESC or RIGHTMOUSE', 'exit tool when done')
        ])
        self.gl_arc = GlPolyline((1.0, 1.0, 1.0, 0.5), d=3)
        self.gl_arc.width = 1
        # self.gl_arc.style = bgl.GL_LINE_STIPPLE
        self.gl_line = GlLine(d=3)
        self.gl_line.colour_inactive = (1.0, 1.0, 1.0, 0.5)
        self.gl_line.width = 2
        # self.gl_line.style = bgl.GL_LINE_STIPPLE
        self.gl_side = GlLine(d=2)
        self.gl_side.colour_inactive = (1.0, 1.0, 1.0, 0.5)
        self.gl_side.width = 2
        # self.gl_side.style = bgl.GL_LINE_STIPPLE
        self.feedback.enable()
        self.drag = False
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
                        self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
        self.action = 'select'
        self._draw(context)
        logger.debug("SelectPolygons.init()")

    @staticmethod
    def filter_touching_geom_using_mod2_rule(_geoms):
        """
            Filter nested geoms using a mod2 rule
            :param _geoms:
            :return:
            """
        _geoms.sort(key=lambda x: x.exterior_area)
        n_polys = len(_geoms)
        parents = [-1] * n_polys
        to_remove = []
        # filter polygon when inside another one
        for i, poly in enumerate(_geoms):
            for j in range(i + 1, n_polys):
                _g = _geoms[j]
                if _g.touches(poly):
                    parents[i] = j
                    to_remove.append(i)
                    break
        # remove holes
        for i in reversed(to_remove):
            depth = 0
            j = i
            while parents[j] > -1:
                depth += 1
                j = parents[j]
            if depth % 2 == 1:
                # print(i, depth)
                _geoms.pop(i)

    @staticmethod
    def filter_geom_using_mod2_rule( _geoms):
        """
        Filter nested geoms using a mod2 rule
        :param _geoms:
        :return:
        """
        _geoms.sort(key=lambda x: x.exterior_area)

        _geoms = [g for g in _geoms if len(g.exterior.coords) > 3]
        n_polys = len(_geoms)
        parents = [-1] * n_polys
        to_remove = []
        # filter polygon when inside another one
        for i, poly in enumerate(_geoms):
            for j in range(i + 1, n_polys):
                _g = _geoms[j]
                if _g.contains(poly):
                    parents[i] = j
                    _g.interiors.append(poly.exterior)
                    to_remove.append(i)
                    break

        # use a mod 2 rule to remove holes
        for i in reversed(to_remove):
            depth = 0
            j = i
            while parents[j] > -1:
                depth += 1
                j = parents[j]
            # print(i, depth)
            if depth % 2 == 1:
                _geoms.pop(i)

    def process_wall2(self, context, selection):
        tim = time.time()
        wm = context.window_manager

        gf = GeometryFactory()
        extend = wm.archipack.polylib.polygonize_thickness
        height = wm.archipack.polylib.polygonize_height
        ref = context.active_object

        bpy.ops.archipack.reference_point("INVOKE_DEFAULT")
        
        tim2 = time.time()
        # print("boundary")
        # boundary to be able  to orient exterior walls
        boundary = ShapelyOps.union(self.geoms)

        # "Monotonize walls" expect simplified union as input,
        # This is boundary of all walls
        polys = ShapelyOps.union(selection)
        # Simplify so only corners vertices are kept
        polys = [p.simplify_by_distance(0.001) for p in polys if p.area > 0.01]
        # Simplify may return GeometryCollection so filter out polygons
        polys = self.filter_polygons(polys)

        # keep a copy of merged walls boundary to skip polygons between walls
        limits = [p.clone() for p in polys]
        if DEBUG:
            Io.to_curve(context.scene, self.coordsys, limits, "Limits")

        # "Monotonize" walls so they are suitable for skeleton analysis
        # NOTE: generate complex polygon when touch itself once (P shaped)
        if len(polys) > 0:
            io = Io.add_polys(self.coordsys, polys)
            op = Polygonizer(self.coordsys)
            merged, polys, dangles, cuts, invalids = op._polygonize(
                gf, io.Q_points, io.Q_segs, extend=extend, use_monotonize_wall2=True
            )

        if len(polys) > 0:
            # Simplify so only corners vertices are kept
            polys = [p.simplify_by_distance(0.001) for p in polys if p.area > 0.01]
            # Simplify may return GeometryCollection so filter out polygons
            polys = self.filter_polygons(polys)
            if DEBUG:
                Io.to_curve(context.scene, self.coordsys, polys, "Monotone")

        n_polys = len(polys)

        if n_polys > 0:
            wm.progress_begin(0, 4 * n_polys)

            # Simplify P shaped closed polygons as monotone polygon
            for j, poly in enumerate(polys):
                if len(poly.interiors) == 1:
                    # should only have one interior polygon,
                    # when number of coords is not the same it is a P shaped polygon
                    if len(poly.interiors[0].coords) !=  len(poly.exterior.coords):
                        # find collinear intersection(s) between inside and outside (should be only one)
                        op.monotonize_closed_polygon(poly, extend=extend)
                        #
                        # Simplify so only corners vertices are kept
                        polys[j] = poly.simplify_by_distance(0.001)
                        if DEBUG:
                            Io.to_curve(context.scene, self.coordsys, [poly], "P shaped Monotone")

            g = Generator()
            walls = []

            logger.info("Simplify polygons %s : %.2f seconds" % (n_polys, time.time() - tim2))

            tim2 = time.time()
            # Create walls
            for j, poly in enumerate(polys):

                closed = len(poly.interiors) > 0

                # Preprocess polygon, 2 cases: open or closed wall (closed has interiors)
                if closed:
                    if DEBUG:
                        Io.to_curve(context.scene, self.coordsys, [poly], name="Has interiors")
                    res = [Vector(p.as_tuple()) for p in poly.exterior.coords]
                    # find width using space between biggest outer segment in inner
                    dist = [(i, p - res[i]) for i, p in enumerate(res[1:])]
                    dist.sort(key=lambda x: x[1])
                    biggest = dist[-1][0]
                    p0, p1 = res[biggest], res[biggest + 1]
                    n = Line(p0, p1=p1).normal(0.5, 1)
                    width = 1e32
                    for interior in poly.interiors:
                        coords = interior.coords
                        for i, co in enumerate(coords[1:]):
                            p0, p1 = coords[i].as_tuple(), co.as_tuple()
                            seg2 = Line(p0, p1=p1)
                            it, pt, u, v = n.intersect_ext(seg2)
                            if 0 < v < 1 and abs(u) < width:
                                width = abs(u)
                    res.pop(-1)
                    # width check here should remove inner spaces
                    # as long as max thickness is low enough
                    half_width = width / 2
                else:
                    # Open wall (poly has only exteriors)
                    # use skeleton to find axis
                    if DEBUG_SKELETON:
                        polyskel._debug = Debug_skeleton(prefix="%s-" % j)
                    skeleton = polyskel.skeletonize(poly.exterior.coords, [])
                    half_width, res = polyskel.as_axis(skeleton)
                    if len(res) > 0:
                        res = [Vector(p) for p in res]
                        # perform inside check for at least one point
                        # in order to skip anything not over a wall
                        p0 = gf.createPoint(Vector(res[0]))
                        is_inside = False
                        for _poly in limits:
                            if _poly.contains(p0):
                                is_inside = True
                                break
                        if not is_inside:
                            logger.debug("#####   Skip polygon (not a wall) %s" % (j + 1))
                            continue
                    width = 2 * half_width

                wm.progress_update(j)

                # Create wall
                if width > extend:
                    logger.debug("#####    Skip polygon (width > limit %.3f > %.3f) %s" % (width, extend, j + 1))
                elif  len(res) < 1:
                    logger.debug("#####    Skip polygon (empty axis geometry) %s" % (j + 1))
                else:
                    logger.debug("Processing wall %s of %s" % (j + 1, n_polys))

                    # Select reference before
                    self.select_object(context, ref, True)

                    tM = Matrix()
                    tM.translation = g.from_points(res, False, False, False, closed)

                    if g.numsegs < 1:
                        continue

                    # create wall
                    bpy.ops.archipack.wall2('INVOKE_DEFAULT')
                    w = context.active_object
                    walls.append(w)

                    d = w.data.archipack_wall2[0]
                    if USE_FAST_SNAP:
                        # Unselect ro prevent auto update
                        self.unselect_object(context, w)
                    else:
                        d.auto_update = False

                    d.width = width
                    d.z = height
                    d.base_line = 0

                    # location is delta between first coord and g


                    if closed:
                        # closed wall, axis from polygon outside
                        # by definition axis in outside (but reversed)
                        d.n_parts = g.numsegs - 1
                        g.reverse()

                    else:
                        # open wall move axis on side, and grow both ends
                        d.n_parts = g.numsegs

                        s0 = g.segs[0]
                        s1 = g.segs[-2]
                        # extend both ends
                        s0.p0 -= s0.v_normalized * half_width
                        s1.p1 += s1.v_normalized * half_width
                        # offset from axis to side
                        g.segs = g.make_offset(half_width).segs
                        tM.translation += g.reset_origin()

                        # Check outside wall orientation
                        n = g.segs[0].v_normal
                        pt = g.segs[0].lerp(0.5)
                        # 1 cm inside / outside from wall
                        p0 = gf.createPoint(tM @ (pt + n * 0.01))
                        p1 = gf.createPoint(tM @ (pt - n * (width + 0.01)))
                        for b in boundary:
                            if b.contains(p0) and not b.contains(p1):
                                g.reverse()
                                g.segs = g.make_offset(width).segs
                                tM.translation += g.reset_origin()

                    # setup location and update wall data from generator
                    tM.translation.z = 0
                    w.matrix_world = self.coordsys.world @ tM
                    g.update_parts(d)
                    d.closed = closed

            n_walls = len(walls)

            logger.info("Create walls %s from %s polygons : %.2f seconds" % (n_walls, n_polys, time.time() - tim2))

            tim2 = time.time()

            wm.progress_end()
            wm.progress_begin(0, n_polys + 3 * n_walls)

            # (not so) Faster snap all walls at once before any update
            if USE_FAST_SNAP and n_walls > 0:
                o = walls[0]
                walls_dict = {
                    c: c.data.archipack_wall2[0]
                    for c in walls
                }

                tree = Q_tree(self.coordsys, max_depth=8)

                o.data.archipack_wall2[0].fill_snap_tree(tree, walls_dict, self.coordsys.invert)

                for c, d in walls_dict.items():

                    g = d.get_generator(self.coordsys.invert @ c.matrix_world)
                    maxdist = d.width
                    s0 = g.axis.segs[0]
                    it, t, p, idx = d.snap_ext(
                        s0, tree, maxdist, near='START', whitelist={'outside', 'inside'}, exclude=c.name)
                    # snap base line (outside)
                    if it:
                        name, idx, seg, _type = tree._geoms[idx]
                        s0 = g.segs[0]
                        res, p, t = s0.intersect(seg)
                        s0.p0 = p
                        axis = g.make_offset(0.5 * d.width).segs[0]
                        res, p, t = axis.intersect(seg)
                        dist = (axis.p0 - p).length
                        if t < 0:
                            dist = -dist
                        d.extremes[0] = dist
                        d.extremes[2] = 0
                        inside = g.make_offset(d.width).segs[0]
                        res, p, t = inside.intersect(seg)
                        dist = (inside.p0 - p).length
                        if t < 0:
                            dist = -dist
                        d.extremes[4] = dist

                    s0 = g.axis.segs[-2]
                    it, t, p, idx = d.snap_ext(
                        s0, tree, maxdist, near='END', whitelist={'outside', 'inside'}, exclude=c.name
                    )
                    if it:
                        s0 = g.segs[-2]
                        name, idx, seg, _type = tree._geoms[idx]
                        res, p, t = s0.intersect(seg)
                        s0.p1 = p
                        axis = g.make_offset(0.5 * d.width).segs[-2]
                        res, p, t = axis.intersect(seg)
                        dist = (axis.p1 - p).length
                        if t < 0:
                            dist = -dist
                        d.extremes[1] = dist
                        d.extremes[3] = 0
                        inside = g.make_offset(d.width).segs[-2]
                        res, p, t = inside.intersect(seg)
                        dist = (inside.p1 - p).length
                        if t < 0:
                            dist = -dist
                        d.extremes[5] = dist

                    # tM = self.coordsys.invert @ c.matrix_world
                    # c.matrix_world.translation += g.reset_origin()
                    # c.matrix_world = self.coordsys.world @ tM
                    g.update_parts(d)

            # Update, will snap once
            for i, w in enumerate(walls):
                wm.progress_update(n_polys + i)
                logger.debug("Update step 1 of 3 wall %s of %s" % (i + 1, n_walls) )
                self.select_object(context, w, True)
                d = w.data.archipack_wall2[0]
                # update geometry
                if USE_FAST_SNAP:
                    d.update(
                        context,
                        setup_childs=False,
                        update_childs=False,
                        relocate_childs=False,
                        allow_throttle=False,
                        snap_sides=False
                    )
                else:
                    d.auto_update = True

            logger.info("Update step 1 of 3 snap walls : %.2f seconds" % (time.time() - tim2))

            tim2 = time.time()
            wm.progress_end()

            # Auto boolean
            if n_walls > 0:
                logger.debug("Update step 2 of 3 auto boolean")
                bpy.ops.archipack.auto_boolean(
                    progress_offset=n_polys + n_walls,
                    progress_end=n_polys + 3 * n_walls
                )

            wm.progress_begin(0, n_polys + 3 * n_walls)

            logger.info("Update step 2 of 3 auto boolean : %.2f seconds" % (time.time() - tim2))
            tim2 = time.time()

            # Relocate childs / orient windows / finalize snap
            for i, w in enumerate(walls):
                wm.progress_update(n_polys + 2 * n_walls + i)
                logger.debug("Update step 3 of 3 wall %s of %s" % (i + 1, n_walls))
                self.select_object(context, w, True)
                d = w.data.archipack_wall2[0]
                update_childs = len(d.childs) > 0
                d.update(
                    context,
                    setup_childs=update_childs,
                    update_childs=update_childs,
                    relocate_childs=update_childs,
                    allow_throttle=False,
                    snap_sides=False
                )

            logger.info("Update step 3 of 3 update openings : %.2f seconds" % (time.time() - tim2))

            # done (hopefully)
            wm.progress_end()

        logger.info("SelectPolygons.process_wall2() :%.2f seconds" % (time.time() - tim))

    def complete(self, context):
        # logger.info("SelectPolygons.complete()")
        t = time.time()
        scene = context.scene
        self._hide(context)
        wm = context.window_manager.archipack
        selection = list(self.geoms[i] for i in self.ba.list)
        if len(selection) > 0:
            if self.action == 'select':
                result = Io.to_curve(scene, self.coordsys, selection, 'selection')
                self.select_object(context, result, True)
            elif self.action == 'union':
                union = ShapelyOps.union(selection)
                # union = ShapelyOps.optimize(union)
                result = Io.to_curve(scene, self.coordsys, union, 'union')
                self.select_object(context, result, True)
            elif self.action == 'surface':
                union = ShapelyOps.union(selection)
                # union = ShapelyOps.optimize(union)
                res = []
                bpy.ops.object.select_all(action='DESELECT')
                Io.to_surface(context, self.coordsys, union, 'surface', res)
                if len(res) > 0:
                    for surf in res:
                        self.select_object(context, surf)
                    self.select_object(context, res[0], True)
                    if len(res) > 1:
                        bpy.ops.object.join()

            elif self.action == 'wall':
                union = ShapelyOps.union(selection)
                # union = ShapelyOps.optimize(union)
                res = []
                bpy.ops.object.select_all(action='DESELECT')
                z = wm.polylib.polygonize_height
                Io.to_wall(context, self.coordsys, union, z, 'wall', res)
                Io.merge_walls(context, self.coordsys, res, z)

            elif self.action == 'wall2':
                # maximum wall thickness
                from .archipack_prefs import get_prefs
                prefs = get_prefs(context)
                last_state = prefs.throttle_enable
                prefs.throttle_enable = False
                # prevent "wait cursor" as we use progress
                wm.update_cursor = False
                try:
                    # disable auto manipulate
                    with stop_auto_manipulate(context):
                        self.process_wall2(context, selection)

                except:
                    import traceback
                    traceback.print_exc()
                    logger.warning("Fails to process wall2")
                    pass
                prefs.throttle_enable = last_state
                wm.update_cursor = True

                return True

            elif self.action == 'rectangle':
                # currently only output a best fitted rectangle
                # over selection
                if self.object_location is not None:
                    tM, w, h, poly, w_rect = self.object_location
                    result = Io.to_curve(scene, self.coordsys, poly, 'rectangle')
                    result.matrix_world = self.coordsys.world @ tM
                    self.select_object(context, result, True)
                self.ba.none()
            elif self.action == 'window':
                if self.object_location is not None:

                    tM, w, h, l_pts, w_pts = self.object_location

                    if self.need_rotation:
                        rM = Matrix([
                            [-1, 0, 0, 0],
                            [0, -1, 0, 0],
                            [0, 0, 1, 0],
                            [0, 0, 0, 1],
                        ])
                    else:
                        rM = Matrix()

                    if w > 1.8:
                        z = 2.2
                        altitude = 0.0
                        handle_alt = 1.2
                    else:
                        z = 1.2
                        altitude = 1.0
                        handle_alt = 1.5

                    bpy.ops.archipack.window(x=w, y=h, z=z, altitude=altitude, standalone=False)
                    result = context.object
                    result.matrix_world = self.coordsys.world @ tM @ rM
                    d = result.data.archipack_window[0]
                    d.handle_altitude = handle_alt
                    d.hole_margin = 0.02
                self.ba.none()
            elif self.action == 'door':
                if self.object_location is not None:

                    tM, w, h, l_pts, w_pts = self.object_location

                    if self.need_rotation:
                        rM = Matrix([
                            [-1, 0, 0, 0],
                            [0, -1, 0, 0],
                            [0, 0, 1, 0],
                            [0, 0, 0, 1],
                        ])
                    else:
                        rM = Matrix()

                    if w < 1.5:
                        n_panels = 1
                    else:
                        n_panels = 2

                    bpy.ops.archipack.door(x=w, y=h, z=2.0, n_panels=n_panels,
                                direction=self.direction, standalone=False)
                    result = context.object
                    result.matrix_world = self.coordsys.world @ tM @ rM
                    result.data.archipack_door[0].hole_margin = max(0.02, result.data.archipack_door[0].frame_y)
                self.ba.none()

        logger.debug("SelectPolygons.complete() :%.2f seconds" % (time.time() - t))
        # Exit modal when true
        return False

    def keyboard(self, context, event):
        if event.type in {'A'}:
            if len(self.ba.list) > 0:
                self.ba.none()
            else:
                self.ba.all()
        elif event.type in {'I'}:
            self.ba.reverse()
        elif event.type in {'S'}:
            self.store()
        elif event.type in {'L'}:
            self.recall()
        elif event.type in {'B'}:
            areas = [self.geoms[i].area for i in self.ba.list]
            if len(areas) > 0:
                area = max(areas)
                self.ba.none()
                for i, geom in enumerate(self.geoms):
                    if geom.area > area:
                        self.ba.set(i)

        elif event.type in {'W'}:
            self.action = 'window'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                self.feedback.instructions(context,
                    "Select Polygons", "Click & Drag to select polygons in area", [
                    ('CLICK & DRAG', 'Set window orientation'),
                    ('RELEASE', 'Create window'),
                    ('ESC or RIGHTMOUSE', 'Return to select mode')
                ])
                self.selectMode = not self.selectMode
                gf = GeometryFactory()
                geom = gf.buildGeometry(sel)
                # geom = ShapelyOps.union(sel)
                tM, w, h, poly, w_pts = ShapelyOps.min_bounding_rect(geom)
                self.object_location = (tM, w, h, poly, w_pts)
                self.startPoint = self._position_2d_from_coord(context, tM.translation)

        elif event.type in {'D'}:
            self.action = 'door'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                self.feedback.instructions(context,
                    "Select Polygons", "Click & Drag to select polygons in area", [
                    ('CLICK & DRAG', 'Set door orientation'),
                    ('RELEASE', 'Create door'),
                    ('F', 'Return to select mode'),
                    ('ESC or RIGHTMOUSE', 'exit tool when done')
                ])
                self.selectMode = not self.selectMode
                gf = GeometryFactory()
                geom = gf.buildGeometry(sel)
                # geom = ShapelyOps.union(sel)
                tM, w, h, poly, w_pts = ShapelyOps.min_bounding_rect(geom)
                self.object_location = (tM, w, h, poly, w_pts)
                self.startPoint = self._position_2d_from_coord(context, tM.translation)

        elif event.type in {'R'}:
            self.action = 'rectangle'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                self.selectMode = not self.selectMode
                gf = GeometryFactory()
                geom = gf.buildGeometry(sel)
                # geom = ShapelyOps.union(sel)
                tM, w, h, poly, w_pts = ShapelyOps.min_bounding_rect(geom)
                self.object_location = (tM, w, h, poly, w_pts)
                self.startPoint = self._position_2d_from_coord(context, tM.translation)
                self.complete(context)

        elif event.type in {'E'}:
            if event.alt:
                self.action = 'wall'
            else:
                self.action = 'wall2'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                return self.complete(context)

        elif event.type in {'F'}:
            self.action = 'surface'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                self.complete(context)

        elif event.type in {'U'}:
            self.action = 'union'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                self.complete(context)

        elif event.type in {'O'}:
            self.action = 'select'
            sel = [self.geoms[i] for i in self.ba.list]
            if len(sel) > 0:
                self.complete(context)

        self._draw(context)

        return False


    def exit(self, context):
        self.feedback.disable()
        self._hide(context)
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):
        if event.type in {'I', 'A', 'S', 'L', 'R', 'E', 'F', 'B', 'W', 'D', 'U', 'O'} and event.value == 'PRESS':
            if self.keyboard(context, event):
                self.exit(context)
                return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if not self.selectMode:
                self.selectMode = True
            else:
                self.exit(context)
                return {'FINISHED'}
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.drag = True
            self.cursor_area.enable()
            self.cursor_fence.disable()
            if self.selectMode:
                self.startPoint = (event.mouse_region_x, event.mouse_region_y)
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.drag = False
            self.cursor_area.disable()
            self.cursor_fence.enable()
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
            if self.selectMode:
                self.select(context, self.startPoint, event)
            else:
                if self.complete(context):
                    return {'FINISHED'}
                self.feedback.instructions(context, "Select Polygons", "Click & Drag to select polygons in area", [
                    ('SHIFT', 'Deselect'),
                    ('CTRL', 'Contains'),
                    ('A', 'All'),
                    ('I', 'Inverse'),
                    ('B', 'Bigger than current'),
                    ('S', 'Save selection'),
                    ('L', 'Load selection'),
                    ('R', 'Rectangle from selection'),
                    ('D', 'Door from selection'),
                    ('W', 'Window from selection'),
                    ('U', 'Union of selection'),
                    ('E', 'Wall from selection'),
                    ('F', 'Surface from selection'),
                    ('O', 'Output selection'),
                    ('ESC or RIGHTMOUSE', 'exit tool when done')
                ])
            self.selectMode = True
        if event.type == 'MOUSEMOVE':
            self.endPoint = (event.mouse_region_x, event.mouse_region_y)
        return {'RUNNING_MODAL'}

    def _draw_2d_arc(self, context, c, p0, p1):
        """
            draw projection of 3d arc in 2d space
        """
        d0 = c - p0
        d1 = p1 - c
        a0 = atan2(d0.y, d0.x)
        a1 = atan2(d1.y, d1.x)
        da = a1 - a0
        if da < pi:
            da += 2 * pi
        if da > pi:
            da -= 2 * pi
        da = da / 12
        r = d1.length
        _c = Vector((c.x, c.y, c.z))
        pts = []
        for i in range(13):
            a = a0 + da * i
            p3d = _c + Vector((cos(a) * r, sin(a) * r, 0))
            pts.append(self.coordsys.world @ p3d)

        self.gl_arc.set_pos(pts)
        self.gl_arc.draw(context)
        self.gl_line.p = self.coordsys.world @ _c
        self.gl_line.v = pts[0] - self.gl_line.p
        self.gl_line.draw(context)

    def draw_callback(self, _self, context):
        """
            draw on screen feedback using gl.
        """
        self.feedback.draw(context)

        if self.selectMode:
            self.cursor_area.set_location(context, self.startPoint, self.endPoint)
            self.cursor_fence.set_location(context, self.endPoint)
            self.cursor_area.draw(context)
            self.cursor_fence.draw(context)
        else:
            # Dragging for Windows and Doors
            if self.drag:
                x0, y0 = self.startPoint
                x1, y1 = self.endPoint
                # draw 2d line marker
                # self.gl.Line(x0, y0, x1, y1, self.gl.line_colour)

                # 2d line
                self.gl_side.p = Vector(self.startPoint)
                self.gl_side.v = Vector(self.endPoint) - Vector(self.startPoint)
                self.gl_side.draw(context)

                tM, w, h, l_pts, w_pts = self.object_location
                pt = self._position_3d_from_coord(context, self.endPoint)
                pt = tM.inverted() @ Vector(pt)
                self.need_rotation = pt.y < 0
                """
                 0  1
                 2  3
                """
                p0 = tM @ Vector((-0.5 * w, -0.5 * h, 0))
                p1 = tM @ Vector((0.5 * w, -0.5 * h, 0))
                p2 = tM @ Vector((-0.5 * w, 0.5 * h, 0))
                p3 = tM @ Vector((0.5 * w, 0.5 * h, 0))

                if self.action == 'door':
                    # Door symbol

                    if pt.x > 0:
                        if pt.y > 0:
                            self.direction = 1
                            p0, p1, p2 = p1, p3, p2
                        else:
                            self.direction = 0
                            p0, p1, p2 = p3, p1, p0
                    else:
                        if pt.y > 0:
                            self.direction = 0
                            p0, p1, p2 = p0, p2, p3
                        else:
                            self.direction = 1
                            p0, p1, p2 = p2, p0, p1

                    self._draw_2d_arc(context, p1, p0, p2)

                elif self.action == 'window':
                    # Window symbol

                    if pt.y > 0:
                        p0, p1, p2, p3 = p3, p2, p1, p0

                    pc = p0 + (p1 - p0) * 0.5
                    self._draw_2d_arc(context, p0, p2, pc)
                    self._draw_2d_arc(context, p1, p3, pc)


class CoordSys(object):
    """
        reference coordsys
        world : matrix from local to world
        invert: matrix from world to local
        width, height: bonding region size
    """
    __slots__ = ('world', 'invert', 'width', 'height', 'transform_output')

    def _world_bounding_box(self, tM, o, minx, miny, maxx, maxy):
        itM = tM @ o.matrix_world
        x, y, z = list(zip(*[itM @ Vector(b) for b in o.bound_box]))
        return min(minx, min(x)), min(miny, min(y)), max(maxx, max(x)), max(maxy, max(y))

    def __init__(self, objs, itM=None, generator=None):
        x0, y0, x1, y1 = 1e32, 1e32, -1e32, -1e32
        _itM = itM
        if _itM is None:
            _itM = Matrix()
        if generator is not None:
            x0, y0, x1, y1 = generator.bounding_rect(_itM)
        elif len(objs) > 0:
            for obj in objs:
                x0, y0, x1, y1 = self._world_bounding_box(_itM, obj, x0, y0, x1, y1)
        else:
            raise Exception("CoordSys require at least one object to initialize bounds")
        width, height = x1 - x0, y1 - y0
        midx, midy = x0 + 0.5 * width, y0 + 0.5 * height
        # reference coordsys bounding box center
        self.world = Matrix([
            [1, 0, 0, midx],
            [0, 1, 0, midy],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
            ])
        self.transform_output = Matrix()
        self.invert = self.world.inverted()
        self.width = width
        self.height = height

    def __str__(self):
        return "Coordsys center:{} x:{} y:{}  \nworld:{} \ninvert:{}".format(self.world.translation, self.width, self.height, self.world, self.invert)


class Prolongement:
    """ intersection of two segments outside segment (projection)
        c0 = point on current segment
        c1 = intersection point on opposite segment
        d = distance from ends to segment
        it = intersection validity
    """
    __slots__ = ('c0', 'c1', 'd', 'it')

    def __init__(self, c0, c1, d, it):
        self.c0 = c0
        self.c1 = c1
        self.d = d
        self.it = it

    def __str__(self):
        return "d:{0} valid:{1}".format(self.d, self.it)


class Intersection:

    __slots__ = ('valid', 'is_collinear', 'opposite')

    def __init__(self, is_collinear=False, opposite=-1):
        self.valid = True
        self.is_collinear = is_collinear
        self.opposite = opposite


class Point(GeosPoint):
    """
     * A point class compatible with pygeos Coordinates
    """
    __slots__ = ('users', 'index')

    def __init__(self, coord, factory):
        GeosPoint.__init__(self, coord, factory)
        self.users = 0
        self.index = 0

    def distance(self, point):
        """ euclidian distance between points """
        return self.coord.distance(point.coord)

    def to_3d(self):
        return Vector((self.coord.x, self.coord.y, self.coord.z))

    def to_2d(self):
        return Vector((self.coord.x, self.coord.y))

    def add_user(self):
        self.users += 1

    def __str__(self):
        return "Point [i=%s, u=%s, x=%s, y=%s, z=%s]" % (
            self.index,
            self.users,
            round(self.coord.x, 3),
            round(self.coord.y, 3),
            round(self.coord.z, 3)
        )


class Segment:

    __slots__ = ('c0', 'c1', 'p', 'v', 'shapeId', '_splits', 'available', 'envelope', 'users')

    def __init__(self, c0, c1):

        # c0 c1 are Points
        self.c0 = c0
        self.c1 = c1

        self.users = 1

        self.p = c0.to_2d()
        self.v = c1.to_2d() - self.p

        self.shapeId = 0

        self._splits = []

        self.available = True

        self.envelope = Envelope(c0.coord, c1.coord)

    @property
    def length(self):
        """
            3d length
        """
        return self.v.length

    @property
    def cross_z(self):
        """
            2d Vector perpendicular on plane xy
            lie on the right side
            p1
            |--x
            p0
        """
        return Vector((self.v.y, -self.v.x))

    @property
    def splits(self):
        """
         splits occuring in the segment
         return points over segment
         sorted by parameter t
         filter valid ones
         remove dups
        """
        _s = sorted(self._splits, key=lambda s: s[0])
        _s = [s[1] for s in _s]
        return [s for i, s in enumerate(_s) if i == 0 or _s[i - 1] is not s]

    @property
    def vect(self):
        """ vector p0-p1"""
        return self.v

    def lerp(self, t):
        """
            2d interpolation
        """
        return self.p + self.v * t

    def _point_sur_seg(self, point):
        dp = point.to_2d() - self.p
        dl = self.length
        t = 0
        if dl > 0:
            t = self.v.dot(dp) / (dl * dl)
        return dp.length, t

    def _distance_point_seg(self, point):
        dp = point.to_2d() - self.p
        dl = self.length
        d = 0
        if dl > 0:
            d = (self.v.x * dp.y - self.v.y * dp.x) / dl
        return d

    def _intersect_seg(self, segment, collinear_limit=0):
        """ point_sur_segment return
            p: point d'intersection
            u: param t de l'intersection sur le segment courant
            v: param t de l'intersection sur le segment segment
            d: perpendicular distance of segment.p
        """
        c = segment.cross_z
        d = self.v.dot(c)
        if abs(d) <= collinear_limit:
            d = self._distance_point_seg(segment.p)
            return False, 0, 0, 0, abs(d)
        dp = segment.p - self.p
        c2 = self.cross_z
        u = c.dot(dp) / d
        v = c2.dot(dp) / d
        return True, self.lerp(u).to_3d(), u, v, 0

    def is_end(self, point):
        return point is self.c0 or point is self.c1

    def min_intersect_dist(self, t, point):
        """ distance intersection nearest end
            t: param t of intersection on segment
            point: intersection point
            return d: distance
        """
        if t > 0.5:
            return self.c1.distance(point)
        else:
            return self.c0.distance(point)

    def _append_splits(self, t, point):
        """
            append a unique split point
        """
        if point is self.c0 or point is self.c1:
            return
        self._splits.append((t, point))

    def slice(self, t, point):
        """
            t: param t on segment
            p: intersection point
            keep track of splits on segment
        """
        self._append_splits(t, point)

    def add_user(self):
        self.c0.add_user()
        self.c1.add_user()

    def consume(self):
        self.available = False

    def add_points(self, Q_segs):
        self._splits.append((0, self.c0))
        self._splits.append((1, self.c1))
        _splits = self.splits
        nSplits = len(_splits)
        if nSplits > 2:
            # kill sliced / extended segments
            self.consume()
            # build new segments
            """
            start = 0
            while _splits[start] is not self.c0:
                start += 1
            start += 1

            end = nSplits
            while _splits[end - 1] is not self.c1:
                end -= 1
            """
            for i in range(1, nSplits):
                seg = Q_segs.newSegment(_splits[i - 1], _splits[i])
                seg.shapeId = self.shapeId
                seg.available = True


class Io:

    def __init__(self, context=None, scene=None, coordsys=None, Q_segs=None, Q_points=None):
        self.context = context
        self.scene = scene
        self.coordsys = coordsys
        self.Q_segs = Q_segs
        self.Q_points = Q_points

    @staticmethod
    def factory(context, objs, itM=None, generator=None):
        _objs = Io.ensure_iterable(objs)
        coordsys = CoordSys(_objs, itM=itM, generator=generator)
        Q_segs = Qtree(coordsys)
        Q_points = Qtree(coordsys)
        return Io(context, context.scene, coordsys, Q_segs, Q_points)

    @staticmethod
    def ensure_iterable(obj):
        try:
            iter(obj)
        except TypeError:
            obj = [obj]
            pass
        return obj

    # Input methods
    def _add_segs(self, points):
        [self.Q_segs.newSegment(points[i], points[i + 1])
         for i in range(len(points) - 1)
         if points[i] is not points[i + 1]]

    def _add_wall_pts(self, axis, segs, points, reverse):
        _segs = segs
        _axis = axis
        if reverse:
            _segs = reversed(segs)
            _axis = reversed(axis)
        for w, seg in zip(_axis, _segs):
            if hasattr(seg, '_r'):
                last_t = -1
                enum = w.slices
                if reverse:
                    enum = reversed(w.slices)

                for j, s in enumerate(enum):
                    t, z, a = s
                    if last_t == t:
                        continue
                    last_t = t
                    if 1 > t > 0:
                        n = w.normal(t).rotate(a)
                        res, p, u, tl = n.intersect_ext(seg, side="INSIDE")
                        res = 1 > tl > 0

                    else:
                        tl = t
                        res = True

                    if res:
                        points.append(self.Q_points.newPoint(seg.lerp(tl)))

            else:
                points.append(self.Q_points.newPoint(seg.p0))

    def _add_wall(self, g) -> None:
        """
         * Add a curve as segments and points in a tree
        """
        points = []
        self._add_wall_pts(g.segs, g.outside.segs, points, False)

        if g.closed:
            points.append(points[0])
            self._add_segs(points)
            points = []
            self._add_wall_pts(g.segs, g.inside.segs, points, False)
        else:
            # open walls
            self._add_wall_pts(g.segs, g.inside.segs, points, True)

        points.append(points[0])
        self._add_segs(points)

    def _add_generic_pts(self, segs, points):
        for seg in segs:
            points.append(self.Q_points.newPoint(seg.p0))

    def _add_generic(self, g) -> None:
        """
         * Add a curve as segments and points in a tree
        """
        points = []
        self._add_generic_pts(g.outside.segs, points)
        self._add_generic_pts(reversed(g.inside.segs), points)
        points.append(points[0])
        self._add_segs(points)

    @staticmethod
    def add_walls(Q_points, Q_segs, coordsys, walls: list) -> None:
        """
            @generators: wall generators
            Return coordsys for outputs
        """
        t = time.time()

        io = Io(Q_points=Q_points, Q_segs=Q_segs, coordsys=coordsys)

        for w in walls:
            if w.data:
                if "archipack_wall2" in w.data:
                    d = w.data.archipack_wall2[0]
                    d.snap(w)
                    g = d.get_generator(coordsys.invert @ w.matrix_world)
                    io._add_wall(g)
                else:
                    for key in {'archipack_window', 'archipack_door', 'archipack_beam'}:
                        if key in w.data:
                            d = getattr(w.data, key)[0]
                            d.snap(w)
                            g = d.get_snap_generator(coordsys.invert @ w.matrix_world)
                            io._add_generic(g)
                # TODO: add support for fences

        logger.debug("Io.add_walls() :%.2f seconds", time.time() - t)

    def _interpolate_bezier(self, pts: list, wM, p0, p1, resolution: int=12) -> None:
        # straight segment, worth testing here
        # since this can lower points count by a resolution factor
        # use normalized to handle non linear t
        if resolution == 0:
            pts.append(wM @ p0.co.to_3d())
        else:
            v = (p1.co - p0.co).normalized()
            d1 = (p0.handle_right - p0.co).normalized()
            d2 = (p1.co - p1.handle_left).normalized()
            if d1 == v and d2 == v:
                pts.append(wM @ p0.co.to_3d())
            else:
                seg = interpolate_bezier(wM @ p0.co,
                    wM @ p0.handle_right,
                    wM @ p1.handle_left,
                    wM @ p1.co,
                    resolution)
                for i in range(resolution - 1):
                    pts.append(seg[i].to_3d())

    def _coords_from_spline(self, wM, spline, resolution: int=12):
        pts = []
        if spline.type == 'POLY':
            pts = [wM @ p.co.to_3d() for p in spline.points]
        elif spline.type == 'BEZIER':
            points = spline.bezier_points
            for i in range(1, len(points)):
                p0 = points[i - 1]
                p1 = points[i]
                self._interpolate_bezier(pts, wM, p0, p1, resolution)
            pts.append(wM @ points[-1].co)
            if spline.use_cyclic_u:
                p0 = points[-1]
                p1 = points[0]
                self._interpolate_bezier(pts, wM, p0, p1, resolution)
        # filter dup coords
        return CoordinateSequence._removeRepeatedPoints(pts)

    def _coords_from_bmesh(self, wM, bm):
        pts = [wM @ p.co for p in bm.verts]
        # keep all points in order to keep synch with edge indexes
        return pts  # CoordinateSequence._removeRepeatedPoints(pts)

    def _add_object(
            self, o, resolution: int=12, evaluate: bool=False, sharpness: float=0, skip_backfaces: bool=False
    ) -> None:
        """
         * Add a curve as segments and points in a tree
        """
        wM = self.coordsys.invert @ o.matrix_world
        if o.type == "MESH":
            context = None
            if evaluate:

                if self.context is None:
                    context = bpy.context
                else:
                    context = self.context

            bm = bmed._start(o, context)
            bm.normal_update()

            # should fix index error on mesh stored in poor state
            bmed.ensure_bmesh(bm)
            bmed.index_update(bm)

            top = self.coordsys.world @ Z_AXIS

            frontfaces = set([f for f in bm.faces if top.dot(f.normal) > 0])

            if sharpness == 0:
                if skip_backfaces:
                    def _filter(ed):
                        return any([f in frontfaces for f in ed.link_faces])
                else:
                    def _filter(ed):
                        return True

            elif not skip_backfaces:
                def _filter(ed):
                    return ed.calc_face_angle(120) > sharpness

            else:
                def _filter(ed):
                    return ed.calc_face_angle(120) > sharpness and any([f in frontfaces for f in ed.link_faces])

            pts = self._coords_from_bmesh(wM, bm)
            points = [self.Q_points.newPoint(pt) for pt in pts]
            [
                self.Q_segs.newSegment(points[ed.verts[0].index], points[ed.verts[1].index])
                for ed in bm.edges
                if points[ed.verts[0].index] is not points[ed.verts[1].index] and _filter(ed)
            ]
            bm.free()

        elif o.type == "CURVE":
            for spline in o.data.splines:
                pts = self._coords_from_spline(wM, spline, resolution)
                points = [self.Q_points.newPoint(pt) for pt in pts]
                # Ensure not unique
                if spline.use_cyclic_u:
                    points.append(points[0])
                self._add_segs(points)

    def _object_as_geom(
            self, gf, o, resolution: int=12, evaluate: bool=False, sharpness: float=0, skip_backfaces: bool=False,
            geoms: list=[]
    ) -> None:
        """
         * Input a curve as geom
        """
        wM = self.coordsys.invert @ o.matrix_world
        if o.type == 'CURVE':
            for spline in o.data.splines:
                pts = self._coords_from_spline(wM, spline, resolution)
                # Ensure uniqueness of last point
                points = [self.Q_points.newPoint(pt).coord for pt in pts]
                if spline.use_cyclic_u:
                    points.append(points[0].clone())
                # filter invalid inputs
                if len(points) < 2 or (len(points) == 2 and points[0] == points[-1]):
                    continue
                geom = gf.createLineString(points)
                geoms.append(geom)

        elif o.type == 'MESH':

            top = self.coordsys.world @ Z_AXIS
            context = None
            if evaluate:
                if self.context is None:
                    context = bpy.context
                else:
                    context = self.context

            bm = bmed._start(o, context)
            bm.normal_update()

            frontfaces = set([f for f in bm.faces if top.dot(f.normal) > 0])

            for ed in bm.edges:

                if sharpness > 0 and ed.calc_face_angle(0) < sharpness:
                    continue

                if skip_backfaces and not any([f in frontfaces for f in ed.link_faces]):
                    continue

                pts = self._coords_from_bmesh_edge(wM, ed)

                # Ensure uniqueness of last point
                points = [self.Q_points.newPoint(pt).coord for pt in pts]

                # filter invalid inputs
                if points[0] == points[-1]:
                    continue

                geom = gf.createLineString(points)
                geoms.append(geom)
            bm.free()

    def _coords_from_bmesh_edge(self, wM, edge):
        return [wM @ v.co for v in edge.verts]

    def _add_linearRing(self, lr):
        points = [self.Q_points.newPoint(pt) for pt in lr.coords]
        self._add_segs(points)

    def _add_poly(self, poly):
        self._add_linearRing(poly.exterior)
        for interior in poly.interiors:
            self._add_linearRing(interior)

    @staticmethod
    def add_polys(coordsys, polys):
        t = time.time()
        Q_points = Qtree(coordsys)
        Q_segs = Qtree(coordsys)
        io = Io(Q_points=Q_points, Q_segs=Q_segs, coordsys=coordsys)
        for poly in polys:
            io._add_poly(poly)
        logger.debug("Io.add_polys() :%.2f seconds", time.time() - t)
        return io

    @staticmethod
    def add_objects(Q_points, Q_segs, coordsys, objects: list, resolution: int=12,
                    evaluate: bool=False, sharpness: float=0, skip_backfaces: bool=False)->None:
        """
            @curves : blender curves collection
            Return coordsys for outputs
        """
        t = time.time()

        io = Io(Q_points=Q_points, Q_segs=Q_segs, coordsys=coordsys)
        for o in objects:
            io._add_object(o, resolution, evaluate, sharpness, skip_backfaces)

        logger.debug("Io.add_objects() :%.2f seconds", time.time() - t)

    @staticmethod
    def getCoordsys(curves):
        return CoordSys(curves)

    @staticmethod
    def curves_to_geomcollection(curves, resolution: int=12, coordsys=None, homogeneous=True):
        """
         * Create lineStrings from curves
         * ensure points uniqueness using a Tree
        """
        t = time.time()
        gf = GeometryFactory()
        curves = [o for o in Io.ensure_iterable(curves) if o.type in {"MESH", "CURVE"}]

        if coordsys is None:
            coordsys = CoordSys(curves)

        Q_points = Qtree(coordsys)
        io = Io(Q_points=Q_points, coordsys=coordsys)

        geoms = []
        for curve in curves:
            io._object_as_geom(gf, curve, resolution=resolution, geoms=geoms)

        # detect geometry type
        polys, dangles, cuts, invalids = PolygonizeOp.polygonize_full(geoms)

        # filter out nested touching holes
        PolygonsUnionOp.filter_nested(polys)

        # degenerate heterogeneous collection so the result is homogeneous collection
        if homogeneous and len(dangles) + len(cuts) > 0 and len(polys) + len(invalids) > 0:
            geoms = dangles + cuts + invalids
            for poly in polys:
                geoms.append(gf.createLineString(poly.exterior.coords))
                for hole in poly.interiors:
                    geoms.append(gf.createLineString(hole.coords))
            geom = gf.buildGeometry(geoms)
        else:
            geom = gf.buildGeometry(polys + dangles + cuts + invalids)

        logger.debug("Io.curves_to_geomcollection() :%.2f seconds", time.time() - t)
        return geom

    @staticmethod
    def generator_to_geom(context, o, generator, coordsys=None):
        """
         * Create lineStrings from curves
         * ensure points uniqueness using a Tree
        """
        t = time.time()
        scene = objman.get_context_value(context, "scene")
        if coordsys is None:
            coordsys = CoordSys([o], generator=generator)

        io = Io(scene=scene, coordsys=coordsys)

        coords = []
        generator.get_pts(coords)
        if generator.closed:
            coords.append(coords[0])
        geom = io.coords_to_linestring(Matrix(), [coords], force_2d=False)
        logger.debug("Io.generator_to_geom() :%.2f seconds", time.time() - t)
        return io, geom

    @staticmethod
    def objects_to_geoms(
            objects, resolution: int=12, evaluate: bool=False, sharpness: float=0, skip_backfaces: bool=False,
            geoms: list=[], coordsys=None
    ):
        """
         * Create lineStrings from mesh edges and curves
         * ensure points uniqueness using a Tree
        """
        t = time.time()
        gf = GeometryFactory()

        objs = [o for o in Io.ensure_iterable(objects) if o.type in {"MESH", "CURVE"}]

        if coordsys is None:
            coordsys = CoordSys(objs)

        Q_points = Qtree(coordsys)
        io = Io(Q_points=Q_points, coordsys=coordsys)
        for o in objs:
            io._object_as_geom(gf, o, resolution, evaluate, sharpness, skip_backfaces, geoms)

        logger.debug("Io.meshes_to_geoms() :%.2f seconds", time.time() - t)
        return coordsys

    def coords_to_linestring(self, tM, lines_coords, force_2d=False):
        """
         * Create linestrings from arrays of coords
         * shell: array of tuple xyz
         * holes: array of array of tuple xyz
         * Coords are ment to be local to object
         @ tM is object matrix_world
         * must init coordsys with objects before
        """
        # t = time.time()
        gf = GeometryFactory()
        itM = self.coordsys.invert @ tM
        coords = [[itM @ Vector(co) for co in coords] for coords in lines_coords]

        if force_2d:
            for co in coords:
                # make coords planar
                for p in co:
                    p.z = 0

        out = []
        for i, co in enumerate(coords):
            co = CoordinateSequence._removeRepeatedPoints(co)
            # if co[0] != co[-1]:
            #    co.append(co[0])
            if len(co) != 1:
                cs = gf.coordinateSequenceFactory.create([
                    gf.createCoordinate(pt) for pt in co
                ])
                out.append(gf.createLineString(cs))
        return gf.buildGeometry(out)

    def coord_to_point(self, tM, p):
        gf = GeometryFactory()
        itM = self.coordsys.invert @ tM
        pt = itM @ Vector(p)
        c = gf.createCoordinate(pt)
        return gf.createPoint(c)

    def coords_to_polygon(self, tM, shell, holes=None, force_2d=False):
        """
         * Create polygon from shell and holes
         * shell: array of tuple xyz
         * holes: array of array of tuple xyz
         * Coords are ment to be local to object
         @ tM is object matrix_world
         * must init coordsys with objects before
        """
        # t = time.time()
        gf = GeometryFactory()
        exterior = None
        interiors = []
        itM = self.coordsys.invert @ tM
        shell = [itM @ Vector(co) for co in shell]
        coords = [shell]
        if holes is not None:
            coords.extend([[itM @ Vector(co) for co in hole] for hole in holes])

        if force_2d:
            for co in coords:
                # make coords planar
                for p in co:
                    p.z = 0

        for i, co in enumerate(coords):
            # does not take z into account
            co = CoordinateSequence._removeRepeatedPoints(co)
            if co[0] != co[-1]:
                co.append(co[0])

            cs = gf.coordinateSequenceFactory.create([
                gf.createCoordinate(pt) for pt in co
                ])

            try:
                ring = gf.createLinearRing(cs)

            except ValueError:
                # less than 3 points found
                if i == 0:
                    # return empty geometry for invalid exterior
                    return gf.createGeometryCollection()
                # otherwise skip invalid interior
                continue

            if i == 0:
                if not ring.is_ccw:
                    ring = gf.createLinearRing(list(reversed(cs)))
                exterior = ring
            else:
                if ring.is_ccw:
                    ring = gf.createLinearRing(list(reversed(cs)))
                interiors.append(ring)

        return gf.createPolygon(exterior, interiors)

    def _slice_poly(self, bm, coords):
        _coords = coords[:]
        _coords.pop()
        co = _coords[-1]
        last = Vector((co.x, co.y, co.z))
        for _co in _coords:
            co = Vector((_co.x, _co.y, _co.z))
            no = (last - co).cross(Z_AXIS)
            if no.length > 0:
                bmed.bisect(bm, co, no)
            last = co

    def _face_inside_poly(self, poly, face):
        center = poly._factory.createCoordinate(face.calc_center_median())
        _c = poly._factory.createPoint(center)
        return poly.contains(_c)

    @staticmethod
    def _cleanup_mesh(bm, clean):
        if clean:
            bmesh.ops.dissolve_limit(bm,
                                     angle_limit=0.015708,
                                     use_dissolve_boundaries=False,
                                     verts=bm.verts,
                                     edges=bm.edges,
                                     delimit={'NORMAL'})

        bmesh.ops.dissolve_degenerate(bm,
                                      dist=0.001,
                                      edges=bm.edges)
        bmesh.ops.triangulate(bm,
                              faces=bm.faces,
                              quad_method='BEAUTY',
                              ngon_method='BEAUTY')

        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    def _poly_to_surface(self, context, poly, name: str = "Surface"):
        context.window.cursor_set("WAIT")
        # create a plane to cut

        location = Vector()
        poly.envelope.centre(location)
        radius = max(poly.envelope.width, poly.envelope.height)

        # linked by hand to scene collection to ensure object is visible
        m = bpy.data.meshes.new(name)
        surf = bpy.data.objects.new(name, m)
        context.scene.collection.objects.link(surf)

        x, y, z = location
        verts = [Vector((x + _x * radius, y + _y * radius, z)) for _x, _y in [(-1, -1), (-1, 1), (1, 1), (1, -1)]]
        faces = [(0, 1, 2, 3)]
        bmed.buildmesh(surf, verts, faces)

        int, ext = [], []
        coordsys = CoordSys([surf])
        coordsys.width, coordsys.height = 2 * radius, 2 * radius
        tree = Qtree(coordsys, max_depth=8)

        bm = bmed._start(surf)

        self._slice_poly(bm, poly.exterior.coords)

        for interior in poly.interiors:
            self._slice_poly(bm, interior.coords)

        _factory = poly._factory
        f_geom = [f for f in bm.faces
                  if not self._face_inside_poly(poly, f)]

        if len(f_geom) > 0:
            bmesh.ops.delete(bm, geom=f_geom, context='FACES')

        bmesh.ops.dissolve_limit(bm,
             angle_limit=0.01,
             use_dissolve_boundaries=False,
             verts=bm.verts,
             edges=bm.edges,
             delimit={'MATERIAL'})

        for co in poly.exterior.coords:
            tree.newPoint(co)

        for v in bm.verts:
            count, sel = tree.intersects_co(v.co)
            v.select = count > 0

        self._cleanup_mesh(bm, True)

        bmed._end(bm, surf)

        surf.matrix_world = self.coordsys.world.copy()
        # surf.location = self.coordsys.world @ location

        context.window.cursor_set("DEFAULT")
        return len(int), len(ext), surf

    def _cookie_cut_poly_to_surface(self, context, vm, poly, name: str="Surface"):
        """
        :param context:
        :param vm:
        :param poly:
        :param name:
        :return:
        """

        # create Exterior line
        curve = bpy.data.curves.new(name, type='CURVE')
        curve.dimensions = "3D"
        self._add_spline(curve, poly.exterior)
        exterior = bpy.data.objects.new(name, curve)

        objman.link_object_to_scene(context, exterior, layer_name="2d")
        exterior.matrix_world = self.coordsys.world.copy()

        # create a plane to cut
        location = Vector()
        poly.envelope.centre(location)
        radius = max(poly.envelope.width, poly.envelope.height)

        bpy.ops.mesh.primitive_plane_add(
            size=radius,
            enter_editmode=True,
            location=self.coordsys.world @ location
            )
        bpy.ops.mesh.select_mode(type="FACE")
        surf = context.active_object
        surf.name = name
        # exterior.select_set(state=True)

        # ensure view point is safe for knife_project
        vm.safe_knife_project(radius, self.coordsys.world @ location)

        # cut plane
        sel = [surf, exterior]
        ctx = context.copy()
        ctx['object'] = surf
        ctx['selected_objects'] = sel
        # ctx['selected_editable_objects'] = sel
        if bpy.app.version[0] > 3:
            with context.temp_override(**ctx):
                bpy.ops.mesh.knife_project()
        else:
            bpy.ops.mesh.knife_project(ctx)
        # bpy.ops.mesh.knife_project()

        # exterior.select_set(state=False)
        objman.unlink_object_from_scene(context, exterior)
        bpy.data.curves.remove(curve)

        # remove outside parts
        bpy.ops.mesh.select_all(action='INVERT')
        bpy.ops.mesh.intersect_boolean()
        bpy.ops.object.mode_set(mode='OBJECT')

        # remember number of polygons for each part
        # order is : bottom - top - exterior - interior
        n_ext = len(poly.exterior.coords) - 1
        n_int = 0

        # Store exteriors vertices
        ext = [v.index for v in surf.data.vertices]
        vg = surf.vertex_groups.new(name="Exterior")
        vg.add(ext, 1.0, 'ADD')

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')

        if len(poly.interiors) > 0:
            curve = bpy.data.curves.new(name, type='CURVE')
            curve.dimensions = "3D"
            for geom in poly.interiors:
                n_int += len(geom.coords) - 1
                self._add_spline(curve, geom)
            interiors = bpy.data.objects.new(name, curve)
            objman.link_object_to_scene(context, interiors, layer_name="2d")
            interiors.matrix_world = self.coordsys.world.copy()

            interiors.select_set(state=True)
            surf.select_set(state=True)

            bpy.ops.mesh.knife_project()
            objman.unlink_object_from_scene(context, interiors)

            bpy.ops.object.mode_set(mode='OBJECT')
            int = [v.index for v in surf.data.vertices if v.index not in ext]
            vg = surf.vertex_groups.new(name="Interior")
            vg.add(int, 1.0, 'ADD')
            bpy.ops.object.mode_set(mode='EDIT')

            bpy.ops.mesh.intersect_boolean()

        bpy.ops.object.mode_set(mode='OBJECT')

        surf.select_set(state=True)

        return n_int, n_ext, surf

    # Output methods
    def _poly_to_wall(self, context, vm, poly, clean, height: float, name: str="Wall"):
        """
         use knife project to cut a plane
         produce a better geometry than curve
        """

        if USE_COOKIE_CUT:
            n_int, n_ext, wall = self._cookie_cut_poly_to_surface(context, vm, poly, name=name)
        else:
            n_int, n_ext, wall = self._poly_to_surface(context, poly, name=name)

        # use bmesh to extrude to fix collection visibility issue
        bm = bmed._start(wall)
        bmesh.ops.extrude_face_region(bm, geom=bm.faces,
                                      edges_exclude=set(),
                                      use_keep_orig=False,
                                      use_normal_flip=False,
                                      use_normal_from_adjacent=False,
                                      use_select_history=False)

        # Material indexes
        inside_mat = 0
        outside_mat = 1
        cut_mat = 2

        if len(poly.interiors) > 0:
            mat_index = outside_mat
        else:
            mat_index = inside_mat

        layer = bm.loops.layers.uv.verify()

        for i, f in enumerate(bm.faces):

            # material indexes

            if all([loop.vert.select for loop in f.loops]):
                f.material_index = mat_index
            elif any([loop.vert.select for loop in f.loops]):
                f.material_index = outside_mat


            n = f.normal
            # axis to get face matrix from normal
            axis = Z_AXIS

            if n.z > 0.95:
                for loop in f.loops:
                    loop.vert.co.z = height
                f.material_index = cut_mat
                axis = X_AXIS

            elif n.z < -0.95:
                f.material_index = cut_mat
                axis = X_AXIS

            f.normal_update()
            n = f.normal

            # uv unwrap
            if n.length < 0.5:
                # fallback for faces with null normal
                tM = Matrix()
            else:
                x = n.cross(axis)
                y = x.cross(n)
                tM = Matrix([
                    [x.x, y.x, n.x, 0],
                    [x.y, y.y, n.y, 0],
                    [x.z, y.z, n.z, 0],
                    [0, 0, 0, 1]
                ])

            itM = tM.inverted()

            for loop in f.loops:
                loop[layer].uv = (itM @ loop.vert.co).to_2d()

        # cleanup mesh
        self._cleanup_mesh(bm, clean)

        faces = [f for f in bm.faces if f.normal.z > 0.95]
        edges = set()
        for f in faces:
            edges.union(f.edges[:])
        edges = list(edges)
        bmesh.ops.beautify_fill(bm, faces=faces, edges=edges, use_restrict_tag=False, method='ANGLE')

        faces = [f for f in bm.faces if f.normal.z < -0.95]
        edges = set()
        for f in faces:
            edges.union(f.edges[:])
        edges = list(edges)
        bmesh.ops.beautify_fill(bm, faces=faces, edges=edges, use_restrict_tag=False, method='ANGLE')

        bmed._end(bm, wall)

        return n_int, n_ext, wall

    def _add_spline(self, curve, geometry):

        coords = list(geometry.coords)
        if len(coords) < 2:
            logger.debug("Spline without points found")
            return
        spline = curve.splines.new('POLY')
        spline.use_endpoint_u = False
        spline.use_cyclic_u = coords[0] == coords[-1]
        if spline.use_cyclic_u:
            coords.pop()
        spline.points.add(count=len(coords) - 1)
        for i, coord in enumerate(coords):
            x, y, z = coord.x, coord.y, coord.z
            spline.points[i].co = self.coordsys.transform_output @ Vector((x, y, z, 1))

    def _as_spline(self, curve, geometry):
        """
            add a spline into a blender curve
            @curve : blender curve
        """
        if geometry is None:
            logger.warning("Io._as_spline() Null geometry given")
            return
        if hasattr(geometry, 'exterior'):
            # Polygon
            self._add_spline(curve, geometry.exterior)
            for geom in geometry.interiors:
                self._add_spline(curve, geom)
        elif hasattr(geometry, 'geoms'):
            # Multi and Collections
            for geom in geometry.geoms:
                self._as_spline(curve, geom)
        else:
            # LinearRing, LineString and Shape
            self._add_spline(curve, geometry)

    def _to_curve(self, geoms, name: str, dimensions: str='3D'):
        geoms = Io.ensure_iterable(geoms)
        curve = bpy.data.curves.new(name, type='CURVE')
        for geom in geoms:
            self._as_spline(curve, geom)
        curve.dimensions = dimensions
        if dimensions == "2D":
            curve.fill_mode = "BOTH"
        curve_obj = bpy.data.objects.new(name, curve)
        curve_obj.matrix_world = self.coordsys.world.copy()
        objman.link_object_to_scene(bpy.context, curve_obj, layer_name="2d")
        # self.scene.collection.objects.link(curve_obj)
        curve_obj.select_set(state=True)
        return curve_obj

    @staticmethod
    def to_surface(context, coordsys, geoms, name: str, surfaces: list=[]):
        """
            use curve extrude as it does respect vertices number and is not removing doubles
            so it is easy to set material index
            cap faces are tri, sides faces are quads
        """
        t = time.time()
        vm = ViewManager(context)

        if USE_COOKIE_CUT:
            vm.save()
        scene = objman.get_context_value(context, "scene")
        io = Io(scene=scene, coordsys=coordsys)
        bpy.ops.object.select_all(action='DESELECT')

        geoms = Io.ensure_iterable(geoms)

        for poly in geoms:
            if hasattr(poly, 'exterior'):
                if USE_COOKIE_CUT:
                    n_int, n_ext, obj = io._cookie_cut_poly_to_surface(context, vm, poly, name=name)
                else:
                    n_int, n_ext, obj = io._poly_to_surface(context, poly, name=name)

                obj.select_set(state=True)
                context.view_layer.objects.active = obj

                if bpy.ops.object.shade_flat.poll():
                    bpy.ops.object.shade_flat()

                # MaterialUtils.add_wall_materials(obj)
                surfaces.append(obj)
            else:
                logger.debug("Io.to_surface() :skip %s", type(poly).__name__)

        if USE_COOKIE_CUT:
            vm.restore()

        logger.debug("Io.to_surface(%s) :%.2f seconds", len(surfaces), time.time() - t)
        return surfaces

    @staticmethod
    def assign_matindex_to_wall(context, obj):
        """
            Use vertex groups to assign materials
        """
        inside_mat = 0
        outside_mat = 1
        cut_mat = 2
        me = obj.data

        vgroup_names = {vgroup.name: vgroup.index for vgroup in obj.vertex_groups}
        if obj.vertex_groups.get('Interior') is not None:
            mat_index = outside_mat
        else:
            mat_index = inside_mat

        with ensure_select_and_restore(context, obj, [obj], object_mode="EDIT"):
            # bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type="FACE")
            bpy.ops.mesh.select_all(action='DESELECT')
            obj.vertex_groups.active_index = vgroup_names['Exterior']
            bpy.ops.object.vertex_group_select()
            Io.assign_matindex_to_selected(me, mat_index, True)
            Io.assign_matindex_to_selected(me, inside_mat, False)

            bm = bmesh.from_edit_mesh(me)
            bm.verts.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            for poly in bm.faces:
                if abs(poly.normal.z) > 0.5:
                    poly.material_index = cut_mat
            bmesh.update_edit_mesh(me)
            # bpy.ops.object.mode_set(mode='OBJECT')

    @staticmethod
    def assign_matindex_to_selected(me, index, selected):
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        for poly in bm.faces:
            if poly.select == selected:
                poly.material_index = index
        bmesh.update_edit_mesh(me)

    @staticmethod
    def merge_walls(context, coordsys, walls, height):
        """
         Merge wall meshes
         add archipack_wall parameters
         perform autoboolean
        """
        wall_0 = None
        if len(walls) > 0:
            wall_0 = walls.pop(0)

            loc = wall_0.matrix_world.translation

            to_merge = []
            for wall in walls:

                bm = bmed._start(wall)
                bmed.ensure_bmesh(bm)
                if USE_COOKIE_CUT:
                    vb = wall.matrix_world.translation - loc
                    bmesh.ops.translate(bm, vec=vb, space=Matrix(), verts=bm.verts[:])
                to_merge.append(bm)

            if len(to_merge) > 0:
                bmed.bmesh_join(wall_0, to_merge)

            for wall in walls:
                objman.delete_object(context, wall)

            wall_0.select_set(state=True)
            Io.assign_matindex_to_wall(context, wall_0)
            ctx = context.copy()
            ctx['object'] = wall_0
            ctx['active_object'] = wall_0
            if bpy.app.version[0] > 3:
                with context.temp_override(**ctx):
                    bpy.ops.archipack.wall(z=height)
            else:
                bpy.ops.archipack.wall(ctx, z=height)
            objman.unlink_object_from_scene(context, wall_0)
            objman.link_object_to_scene(context, wall_0, layer_name="Walls")
            # autoboolean
            if bpy.ops.archipack.auto_boolean.poll():
                bpy.ops.archipack.auto_boolean()
        return wall_0

    @staticmethod
    def to_wall(context, coordsys, geoms, height, name: str, walls: list=[], clean: bool=True):
        """
         use cookie cut to make walls mesh from pygoes.geoms
        """
        t = time.time()
        vm = ViewManager(context)
        if USE_COOKIE_CUT:
            vm.save()
        scene = objman.get_context_value(context, "scene")
        io = Io(scene=scene, coordsys=coordsys)
        bpy.ops.object.select_all(action='DESELECT')

        geoms = Io.ensure_iterable(geoms)

        for poly in geoms:
            if hasattr(poly, 'exterior'):
                n_int, n_ext, obj = io._poly_to_wall(context, vm, poly, clean, height, name)

                if bpy.app.version[0] < 4 and bpy.ops.object.shade_flat.poll():
                    bpy.ops.object.shade_flat()

                # define "Top" vertex group
                half_height = 0.5 * height
                me = obj.data
                top = [i for i, v in enumerate(me.vertices) if v.co.z > half_height]
                vg = obj.vertex_groups.new(name="Top")
                vg.add(top, 1.0, 'ADD')

                walls.append(obj)
            else:
                logger.debug("Io.to_wall() :skip %s", type(poly).__name__)

        if USE_COOKIE_CUT:
            vm.restore()

        logger.debug("Io.to_wall(%s) :%.2f seconds", len(walls), time.time() - t)

        return walls

    @staticmethod
    def to_curve(scene, coordsys, geoms, name: str="output", dimensions: str='3D'):
        t = time.time()
        io = Io(scene=scene, coordsys=coordsys)
        curve_obj = io._to_curve(geoms, name, dimensions)
        logger.debug("Io.to_curve() :%.2f seconds", time.time() - t)
        return curve_obj

    @staticmethod
    def to_curves(scene, coordsys, geoms, name: str="output", dimensions: str='3D'):
        t = time.time()
        io = Io(scene=scene, coordsys=coordsys)
        geoms = Io.ensure_iterable(geoms)
        curves = [io._to_curve(geom, name, dimensions) for geom in geoms]
        logger.debug("Io.to_curves() :%.2f seconds", time.time() - t)
        return curves

    def output(self, geoms, name: str="output", multiple: bool=True, dimensions: str='3D'):
        """
         * GeometryFactory.outputFactory use this method to
         * ouptut lines mostly for debug purposes
        """
        geoms = Io.ensure_iterable(geoms)

        if multiple:
            return [self._to_curve(geom, name, dimensions) for geom in geoms]

        if len(geoms) > 0:
            curve = self._to_curve(geoms, name, dimensions)
            return curve

    def outputCoord(self, coord, name: str="Error") -> None:
        target = bpy.data.objects.new(name, None)
        target.empty_draw_size = 1
        target.empty_draw_type = 'PLAIN_AXES'
        target.location = self.coordsys.world @ Vector((coord.x, coord.y, 0))
        self.scene.collection.objects.link(target)


class ShapelyOps:

    @staticmethod
    def min_bounding_rect(geom):
        """ min_bounding_rect
            minimum area oriented bounding rect
        """
        rect, transf_rect, inv_matrix = geom.computeMinimumRotatedRectangle()
        if rect is None:
            logger.debug("rect is None")
            return None

        w = transf_rect.envelope.width
        h = transf_rect.envelope.height
        centre = Coordinate()
        rect.envelope.centre(centre)
        ux, vx, uy, vy, px, py = inv_matrix

        if h > w:
            w, h = h, w
            ux, uy, vx, vy = vx, vy, -ux, -uy

        x = w / 2
        y = h / 2

        cs = geom._factory.coordinateSequenceFactory.create(
            [Coordinate(co[0], co[1]) for co in [(-x, -y), (-x, y), (x, y), (x, -y), (-x, -y)]])

        # might raise ValueError when points are the same on z axis
        centered_rect = geom._factory.createLinearRing(cs)

        tM = Matrix([
            [ux, vx, 0, centre.x],
            [uy, vy, 0, centre.y],
            [0, 0, 1, 0],
            [0, 0, 0, 1]])

        return tM, w, h, centered_rect, rect.coords

    @staticmethod
    def detect_polygons(geoms):
        """ detect_polygons
        """
        logger.info("Ops.detect_polygons()")
        t = time.time()
        result, dangles, cuts, invalids = PolygonizeOp.polygonize_full(geoms)
        logger.info("Ops.detect_polygons() :%.2f seconds" % (time.time() - t))
        return result, dangles, cuts, invalids

    @staticmethod
    def optimize(geoms, tolerance=0.001, preserve_topology=False):
        """ optimize
        """
        t = time.time()
        geoms = Io.ensure_iterable(geoms)
        if preserve_topology:
            optimized = [geom.simplify(tolerance, preserve_topology) for geom in geoms]
        else:
            optimized = [geom.simplify_by_distance(tolerance) for geom in geoms]
        logger.info("Ops.optimize() :%.2f seconds" % (time.time() - t))
        return optimized

    @staticmethod
    def union(geoms):
        """ fast union
            cascaded union - may require snap before use to fix precision issues
        """
        t = time.time()
        geoms = Io.ensure_iterable(geoms)
        union = PolygonsUnionOp.union(geoms)
        logger.info("Ops.union() :%.2f seconds" % (time.time() - t))
        return union

    @staticmethod
    def boolean(a, b, opCode):
        if opCode == 1:
            return a.intersection(b)
        elif opCode == 2:
            return a.union(b)
        elif opCode == 3:
            return a.difference(b)
        elif opCode == 4:
            return a.symmetric_difference(b)


class Qtree(_QuadTree):
    """
        The top spatial index to be created by the user. Once created it can be
        populated with geographically placed members that can later be tested for
        intersection with a user inputted geographic bounding box.
    """
    __slots__ = ('_extend', '_geoms', 'coordsys', '_factory')

    def __init__(self, coordsys, extend=EPSILON, max_items=MAX_ITEMS, max_depth=MAX_DEPTH):
        """
            objs may be blender objects or shapely geoms
            extend: how much seek arround
        """
        self._extend = extend
        self._geoms = []

        # store input coordsys
        self.coordsys = coordsys

        _QuadTree.__init__(self, 0, 0, coordsys.width, coordsys.height, max_items, max_depth)

        self._factory = GeometryFactory()

    @property
    def ngeoms(self):
        return len(self._geoms)

    def build(self, geoms):
        """
            Build a spacial index from shapely geoms
        """
        t = time.time()
        self._geoms = geoms
        for i, geom in enumerate(geoms):
            self._insert(i, self.getbounds(geom))
        logger.debug("Qtree.build() :%.2f seconds", time.time() - t)

    def insert(self, id, geom):
        self._geoms.append(geom)
        self._insert(id, self.getbounds(geom))

    def newPoint(self, co, threshold=EPSILON):
        found = self._intersect((co.x - threshold, co.y - threshold, co.x + threshold, co.y + threshold))
        for id in found:
            return self._geoms[id]
        point = Point(Coordinate(co.x, co.y, co.z), self._factory)
        self.insert(self.ngeoms, point)
        return point

    def newSegment(self, c0, c1):
        x0, y0 = c0.coord.x, c0.coord.y
        x1, y1 = c1.coord.x, c1.coord.y
        if x1 < x0:
            x1, x0 = x0, x1
        if y1 < y0:
            y1, y0 = y0, y1
        found = self._intersect((x0 - EPSILON, y0 - EPSILON, x1 + EPSILON, y1 + EPSILON))
        for id in found:
            old_seg = self._geoms[id]
            if old_seg.c0 is c0 and old_seg.c1 is c1:
                old_seg.users += 1
                return old_seg
            if old_seg.c0 is c1 and old_seg.c1 is c0:
                old_seg.users += 1
                return old_seg

        new_seg = Segment(c0, c1)
        self.insert(self.ngeoms, new_seg)
        return new_seg

    def getbounds(self, geom, extend=EPSILON):
        env = geom.envelope
        return (env.minx - extend,
            env.miny - extend,
            env.maxx + extend,
            env.maxy + extend)

    def intersects(self, geom, extend=EPSILON):
        bounds = self.getbounds(geom, extend=extend)
        selection = list(self._intersect(bounds))
        count = len(selection)
        return count, sorted(selection)

    def intersects_co(self, co, extend=EPSILON):
        x, y, z = co
        bounds = (x - extend, y - extend, x + extend, y + extend)
        selection = list(self._intersect(bounds))
        count = len(selection)
        return count, sorted(selection)


class Q_tree(Qtree):
    """
     A quadtree compatible with generators to minimize relocate intersections
    """
    def _rec_str(self, child, depth):
        if len(child.children) > 0:
            _s = "\n".join([self._rec_str(c, depth+1) for c in child.children])
        else:
            _s = "\n".join(["depth:{} i:{} name:{} idx:{} seg:{} _type:{}".format(
                depth,
                n.item,
                self._geoms[n.item][0],
                self._geoms[n.item][1],
                str(self._geoms[n.item][2]),
                self._geoms[n.item][3]
                ) for i, n in enumerate(child.nodes)])
        return _s

    def __str__(self):
        return "Q_tree\n{}".format(self._rec_str(self, 0))

    def _extend_bounds(self, x0, y0, x1, y1, extend):
        return (min(x0, x1) - extend,
                min(y0, y1) - extend,
                max(x0, x1) + extend,
                max(y0, y1) + extend)

    def _getbounds_pts(self, p0, p1):
        x0, y0 = p0.x, p0.y
        x1, y1 = p1.x, p1.y
        return x0, y0, x1, y1

    def _getbounds_arc(self, c, r):
        x0, y0 = c.x - r, c.y - r
        x1, y1 = c.x + r, c.y + r
        return x0, y0, x1, y1

    def getbounds_seg(self, seg, extend=0):
        if hasattr(seg, "_r"):
            x0, y0, x1, y1 = self._getbounds_arc(seg.c, seg._r)
        else:
            x0, y0, x1, y1 = self._getbounds_pts(seg.p0, seg.p1)
        return self._extend_bounds(x0, y0, x1, y1, extend)

    def getbounds_pts(self, p0, p1, extend):
        x0, y0, x1, y1 = self._getbounds_pts(p0, p1)
        return self._extend_bounds(x0, y0, x1, y1, extend)

    def getbounds_pt(self, pt, extend=0):
        x, y = pt.x, pt.y
        return (x - extend,
                  y - extend,
                  x + extend,
                  y + extend)

    def intersects_seg(self, seg, extend):
        bounds = self.getbounds_seg(seg, extend)
        selection = list(self._intersect(bounds))
        count = len(selection)
        return count, sorted(selection)

    def intersects_pts(self, p0, p1, extend):
        bounds = self.getbounds_pts(p0, p1, extend)
        selection = list(self._intersect(bounds))
        count = len(selection)
        return count, sorted(selection)

    def intersects_pt(self, pt, extend):
        bounds = self.getbounds_pt(pt, extend)
        selection = list(self._intersect(bounds))
        count = len(selection)
        return count, sorted(selection)

    def insert_seg(self, seg, data):
        idx = self.ngeoms
        self._geoms.append(data)
        bounds = self.getbounds_seg(seg)
        self._insert(idx, bounds)

    def insert_point(self, pt, data):
        idx = self.ngeoms
        self._geoms.append(data)
        bounds = self.getbounds_pt(pt)
        self._insert(idx, bounds)


"""

from archipack28.archipack_polylines import Polygonizer
context = C
o = C.selected_objects

io, geom = Polygonizer.object_to_symbol2d(context, o, 
split=False, 
selected=False, 
outlines=False, 
resolution=12, 
sharpness=0)
# outlines only
# 
curve_obj = io._to_curve(geom, "symbol-{}".format(o[0].name), "2D")
context.scene.collection.objects.link(curve_obj)

"""


class Polygonizer:
    """
        Define collection of shapes as polylines and polygons
        detect polygons and classify boundary / interiors
        equivalent to Shapely one
    """
    def __init__(self, coordsys, extend=EPSILON):

        self.extend = extend

        self.coordsys = coordsys

        # Errors (shapes without left boundarys)
        self.err = []

        # points under walls
        self.inside_wall = []

    def _intersection_point(self, d, t, point, seg):
        if d > EPSILON:
            return point
        elif t > 0.5:
            return seg.c1
        else:
            return seg.c0

    def test_split(self, Q_points, Q_segs, extend=0.01, extend_seg=0.01, collinear=True):
        """ _split
            detect intersections between segments and create segments according
            is able to project segment ends on closest segment
            use point_tree and seg_tree
            assume merged segments on beforehand
        """
        t = time.time()

        # debug
        processed = 0
        process_collinear = 0
        process_point = 0

        segs = Q_segs._geoms

        # points with 1 user are "extendable"
        for seg in Q_segs._geoms:
            seg.c0.add_user()
            seg.c1.add_user()

        for s, seg in enumerate(segs):

            # enlarge seek box for "extendable" segments
            if seg.c0.users < 2 or seg.c1.users < 2:
                _extend = extend
            else:
                _extend = extend_seg

            count, idx = Q_segs.intersects(seg, _extend)

            for id in idx:

                if id > s:
                    # can't check for side determinant here
                    # as intersect may enlarge segment to nearest
                    # neighboor

                    _seg = segs[id]

                    # enlarge seek box for "extendable" segments
                    if _seg.c0.users < 2 or _seg.c1.users < 2:
                        _extend_other = extend
                    else:
                        _extend_other = extend_seg

                    intersect, co, u, v, d = seg._intersect_seg(_seg)

                    processed += 1

                    # POINT_INTERSECTION
                    if intersect:

                        process_point += 1

                        # store intersection state
                        # to be able to disable invalid ones
                        # it = [Intersection()]

                        point = Q_points.newPoint(co)

                        # distance of nearest segment endpoint and intersection
                        du = seg.min_intersect_dist(u, point)
                        dv = _seg.min_intersect_dist(v, point)

                        # print("s:%s id:%s u:%7f v:%7f du:%7f dv:%7f" % (s, id, u, v, du, dv))

                        # does intersect realy occurs ?
                        if (((v <= 0 and dv < _extend_other) or
                                (0 <= v < 1) or
                                (v >= 1 and dv < _extend_other)) and
                                ((u <= 0 and du < _extend) or
                                (0 <= u < 1) or
                                (u >= 1 and du < _extend))):

                            # intersection point on segment id,
                            # segment end when distance is under precision

                            pt = self._intersection_point(dv, v, point, _seg)
                            seg.slice(u, pt)

                            # intersection point on segment seg,
                            # segment end when distance is under precision
                            pt = self._intersection_point(du, u, point, seg)
                            _seg.slice(v, pt)

                    # COLLINEAR_INTERSECTION
                    elif collinear and d < EPSILON:
                        # parallel segments, endpoint on segment
                        # skip NON_COLLINEAR aka when d > EPSILON
                        process_collinear += 1

                        # point _seg.c0 on segment seg
                        pt = _seg.c0
                        du, u = seg._point_sur_seg(pt)

                        if 0 <= u < 1:
                            seg.slice(u, pt)

                        # point _seg.c1 on segment seg
                        pt = _seg.c1
                        du, u = seg._point_sur_seg(pt)

                        if 0 <= u < 1:
                            seg.slice(u, pt)

                        # point seg.c0 on segment _seg
                        pt = seg.c0
                        du, u = _seg._point_sur_seg(pt)

                        if 0 <= u < 1:
                            _seg.slice(u, pt)

                        # point seg.c1 on segment _seg
                        pt = seg.c1
                        du, u = _seg._point_sur_seg(pt)

                        if 0 <= u < 1:
                            _seg.slice(u, pt)

        logger.debug("Polygonizer.split() intersect (all:%s, points:%s, collinear:%s) :%.4f seconds",
            processed,
            process_point,
            process_collinear,
            (time.time() - t))

        t = time.time()
        _geoms = Q_segs._geoms
        for seg in _geoms:
            seg.add_points(Q_segs)

        logger.debug("Polygonizer.split() slice :%.4f seconds", (time.time() - t))

    def find_segment(self, Q_segs, c):
        # return segment index of segment starting at point c
        res = None
        segs = Q_segs._geoms
        count, idx = Q_segs.intersects_co(c.to_3d())
        for i in idx:
            if segs[i].c0 is c:
                return i
        return res

    def _intersection(self, inters, i, c0, c1, d, it):
        last = inters[i]
        if last is None:
            inters[i] = Prolongement(c0, c1, d, it)
        else:
            # when last is collinear and new is not, keep collinear
            if last.it.is_collinear and not it.is_collinear:
                return
            # force replace when last is not collinear and new is collinear
            elif d < last.d or (it.is_collinear and not last.it.is_collinear):
                last.it.valid = False
                last.d = d
                last.c0 = c0
                last.c1 = c1
                last.it = it

    def monotonize_closed_polygon(self, poly, extend=1.0):
        """ Turn P shaped polygon into a simple one
            use point_tree and seg_tree
            assume merged segments on beforehand
        """
        t = time.time()
        io = Io.add_polys(self.coordsys, [poly])

        if DEBUG_MONOTONIZE: Io.to_curve(bpy.context.scene, self.coordsys, [poly], "P shaped poly")

        # debug
        processed = 0
        process_collinear = 0

        segs = io.Q_segs._geoms
        nbsegs = io.Q_segs.ngeoms

        if DEBUG_MONOTONIZE: Debug.points(io.Q_points._geoms, name="Pt", r=0.02)
        if DEBUG_MONOTONIZE: Debug.segments(io.Q_segs._geoms, name="Seg")

        # store coordinate index for each point
        for i, p in enumerate(io.Q_points._geoms):
            p.users = i

        # distance tolerance
        tolerance = 0.002
        angular_tol = radians(0.5)

        min_d = extend
        p0, p1 = -1, -1

        for s, seg in enumerate(segs):
            # enlarge seek box for "extendable" segments
            count, idx = io.Q_segs.intersects(seg, extend)
            for _id in idx:

                if _id > s:
                    # can't check for side determinant here
                    # as intersect may enlarge segment to nearest
                    # neighboor

                    _seg = segs[_id]
                    intersect, co, u, v, d = seg._intersect_seg(_seg, angular_tol)

                    processed += 1

                    if not intersect and d < tolerance:
                        # parallel segments, endpoint on segment
                        # skip NON_COLLINEAR aka when d > EPSILON
                        process_collinear += 1
                        # print("collinear %s %s" % (s, _id))

                        # 4 cases
                        d0 = seg.c0.distance(_seg.c0)
                        d1 = seg.c0.distance(_seg.c1)
                        d2 = seg.c1.distance(_seg.c0)
                        d3 = seg.c1.distance(_seg.c1)
                        d = min(d0, d1, d2, d3)
                        if d < min_d:
                            min_d = d
                            l0 = seg.c0.distance(seg.c1)
                            if d == d0:
                                # intersect before segment
                                if d2 > l0:
                                    # c0 -> _c0
                                    p0 = seg.c0.users
                                    p1 = _seg.c0.users

                                    if DEBUG_MONOTONIZE:
                                        Debug.line([seg.c0.to_3d(), _seg.c0.to_3d()], "c0 %s -> _c0 %s %s-%s" % (s, _id, p0, p1))
                            elif d == d1:
                                if d3 > l0:
                                    # c0 -> _c1
                                    p0 = seg.c0.users
                                    p1 = _seg.c1.users
                                    if DEBUG_MONOTONIZE:
                                        Debug.line([seg.c0.to_3d(), _seg.c1.to_3d()], "c0 %s -> _c1 %s %s-%s" % (s, _id, p0, p1))

                            elif d == d2:
                                if d0 > l0:
                                    # c1 -> _c0
                                    p0 = seg.c1.users
                                    p1 = _seg.c0.users
                                    if DEBUG_MONOTONIZE:
                                        Debug.line([seg.c1.to_3d(), _seg.c0.to_3d()], "c1 %s -> _c0 %s %s-%s" % (s, _id, p0, p1))

                            elif d == d3:
                                if d1 > l0:
                                    # c1 -> _c1
                                    p0 = seg.c1.users
                                    p1 = _seg.c1.users
                                if DEBUG_MONOTONIZE:
                                    Debug.line([seg.c1.to_3d(), _seg.c1.to_3d()], "c1 %s -> _c1 %s %s-%s" % (s, _id, p0, p1))

        if p0 != -1:
            # without repeated closing vertex
            exterior = poly.exterior.coords[:-1]
            interior = poly.interiors[0].coords[:-1]
            # found coordinate indexes
            len_ext = len(exterior)
            len_int = len(interior)
            if p0 > len_ext:
                p1, p0 = p0, p1

            # keeps both "pivot" points
            interior = interior[p1 - len_ext:len_int] + interior[0:p1 - len_ext + 1]

            # slice ext in 2 parts
            coords = exterior[0:p0 + 1] + interior + exterior[p0:len_ext]
            coords.append(coords[0])
            poly.exterior.coords =  coords
            poly.interiors = []

    def monotonize_wall2(self, Q_points, Q_segs, extend=1.0):
        """ _split
            Process wall schema to "monotonize" in small polygons so simple skeleton algorithm may extract axis
            detect intersections between segments and create segments according
            is able to project segment ends on closest segment
            use point_tree and seg_tree
            assume merged segments on beforehand
            use_projection allow segment to extend over projection of neighboor
        """
        t = time.time()
        # debug
        processed = 0
        process_collinear = 0
        process_point = 0

        segs = Q_segs._geoms
        nbsegs = Q_segs.ngeoms
        it_start = [None] * nbsegs
        it_end = [None] * nbsegs

        if DEBUG: Debug.points(Q_points._geoms, name="Pt", r=0.02)
        if DEBUG: Debug.segments(Q_segs._geoms, name="Seg")

        # points with 1 user are "extendable"
        for seg in Q_segs._geoms:
            seg.c0.users = 1
            seg.c1.users = 1

        # distance tolerance
        tolerance = 0.002
        angular_tol = radians(0.5)

        for s, seg in enumerate(segs):

            # enlarge seek box for "extendable" segments
            count, idx = Q_segs.intersects(seg, extend)

            for _id in idx:

                if _id > s:
                    # can't check for side determinant here
                    # as intersect may enlarge segment to nearest
                    # neighboor

                    _seg = segs[_id]
                    intersect, co, u, v, d = seg._intersect_seg(_seg, angular_tol)

                    processed += 1

                    # POINT_INTERSECTION check for nearby points -> intersect on point
                    if intersect:

                        process_point += 1

                        point = Q_points.newPoint(co, threshold=tolerance)

                        # Skip when collinear
                        collinear = seg.is_end(point) or _seg.is_end(point)

                        if collinear:
                            continue

                        # store intersection state
                        # to be able to disable invalid ones

                        it0 = Intersection(opposite=_id,is_collinear=collinear)
                        it1 = Intersection(opposite=s,  is_collinear=collinear)

                        # distance of nearest segment endpoint and intersection
                        du = seg.min_intersect_dist(u, point)
                        dv = _seg.min_intersect_dist(v, point)

                        # print("s:%s _id:%s u:%7f v:%7f du:%7f dv:%7f" % (s, _id, u, v, du, dv))

                        # does intersect realy occurs ?
                        inside_u = (0 < u < 1)
                        extend_u = (u <= 0 or u >= 1) and du < extend
                        inside_v = (0 < v < 1)
                        extend_v = (v <= 0 or v >= 1) and dv < extend
                        if (
                            (inside_u and extend_v) or
                            (inside_v and extend_u) or
                            (inside_u and inside_v) or
                            collinear
                            ):

                            # intersection point on segment _id,
                            # segment end when distance is under precision
                            pt = self._intersection_point(dv, v, point, _seg)

                            # make last intersections invalid
                            # on both last and opposite segments
                            # prevent segment from being "extendable"
                            if seg.is_end(pt):
                                continue
                            elif u <= 0:
                                # enlarge segment s c0

                                self._intersection(it_start, s, seg.c0, pt, du, it0)
                                if collinear:
                                    if v < 0.5:
                                        self._intersection(it_start, _id, _seg.c0, seg.c0, dv, it1)
                                    else:
                                        self._intersection(it_end, _id, _seg.c1, seg.c0, dv, it1)

                            elif u < 1:
                                # intersection on segment s
                                seg.slice(u, pt)
                            else:
                                # enlarge segment s c1
                                self._intersection(it_end, s, seg.c1, pt, du, it0)
                                if collinear:
                                    if v < 0.5:
                                        self._intersection(it_start, _id, _seg.c0, seg.c1, dv, it1)
                                    else:
                                        self._intersection(it_end, _id, _seg.c1, seg.c1, dv, it1)

                            if DEBUG and collinear:
                                Debug.point(pt, name="Intersect_collinear_%s-%s" % (s, _id), r=0.03)

                            # intersection point on segment seg,
                            # segment end when distance is under precision
                            pt = self._intersection_point(du, u, point, seg)

                            # make last intersections invalid
                            # on opposite segment
                            if _seg.is_end(pt):
                                continue
                            elif v <= 0:
                                # enlarge segment _id c0
                                self._intersection(it_start, _id, _seg.c0, pt, dv, it1)
                                if collinear:
                                    if u < 0.5:
                                        self._intersection(it_start, s, seg.c0, _seg.c0, du, it0)
                                    else:
                                        self._intersection(it_end, s, seg.c1, _seg.c0, du, it0)
                            elif v < 1:
                                # intersection on segment _id
                                _seg.slice(v, pt)
                            else:
                                # enlarge segment _id c1
                                self._intersection(it_end, _id, _seg.c1, pt, dv, it1)
                                if collinear:
                                    if u < 0.5:
                                        self._intersection(it_start, s, seg.c0, _seg.c1, du, it0)
                                    else:
                                        self._intersection(it_end, s, seg.c1, _seg.c1, du, it0)

                    # COLLINEAR_INTERSECTION, including end points
                    elif d < tolerance:
                        # parallel segments, endpoint on segment
                        # skip NON_COLLINEAR aka when d > EPSILON
                        process_collinear += 1
                        # print("collinear %s %s" % (s, _id))

                        # 4 cases
                        d0 = seg.c0.distance(_seg.c0)
                        d1 = seg.c0.distance(_seg.c1)
                        d2 = seg.c1.distance(_seg.c0)
                        d3 = seg.c1.distance(_seg.c1)
                        d = min(d0, d1, d2, d3)
                        if d < extend:
                            l0 = seg.c0.distance(seg.c1)
                            # l1 = _seg.c0.distance(_seg.c1)
                            it0 = Intersection(opposite=_id, is_collinear=True)
                            it1 = Intersection(opposite=s,   is_collinear=True)
                            if d == d0:
                                # intersect before segment
                                if d2 > l0:
                                    # c0 -> _c0
                                    p0 = seg.c0
                                    p1 = _seg.c0
                                    self._intersection(it_start,   s, p0, p1, d, it0)
                                    self._intersection(it_start, _id, p1, p0, d, it1)

                            elif d == d1:
                                if d3 > l0:
                                    # c0 -> _c1
                                    p0 = seg.c0
                                    p1 = _seg.c1
                                    self._intersection(it_start,   s, p0, p1, d, it0)
                                    self._intersection(it_end,   _id, p1, p0, d, it1)

                            elif d == d2:
                                if d0 > l0:
                                    # c1 -> _c0
                                    p0 = seg.c1
                                    p1 = _seg.c0
                                    self._intersection(it_end,     s, p0, p1, d, it0)
                                    self._intersection(it_start, _id, p1, p0, d, it1)

                            elif d == d3:
                                if d1 > l0:
                                    # c1 -> _c1
                                    p0 = seg.c1
                                    p1 = _seg.c1
                                    self._intersection(it_end,   s, p0, p1, d, it0)
                                    self._intersection(it_end, _id, p1, p0, d, it1)

        # chain intersections, map start to end and inverese
        seg_end = [-1] * len(segs)
        seg_sta = [-1] * len(segs)
        for s, seg in enumerate(segs):
            count, idx = Q_segs.intersects_co(seg.c0.to_3d())
            for i in idx:
                if i != s and segs[i].c1 is seg.c0:
                    seg_end[s] = i
                    seg_sta[i] = s
                    break

        # sort intersections by size for each knot
        # keep only smallest, when equal skip both
        for s0, ps in enumerate(it_start):
            e0 = seg_end[s0]
            pe = it_end[e0]
            if ps is not None and pe is not None:
                # 3 collinear situations
                # - T shaped intersection
                # - X shaped intersection
                # H shaped (degenerate x)
                # X shaped require both sides analysis so we do keep only thicker / largest segments
                # T shaped is a simple case, only discard any non collinear
                if ps.it.valid and pe.it.valid:
                    s1 = ps.it.opposite
                    e0 = seg_end[s0]
                    e1 = pe.it.opposite

                    # prefer collinear when found
                    if ps.it.is_collinear and pe.it.is_collinear:
                        # X shaped intersection
                        # find other sides (8 segments)
                        #    pe     e2
                        #  ps _|    |_  s1
                        #
                        #   s2_      _ s3
                        #      |    |
                        #     e1    e3
                        # 4 cases
                        # 1 True x intersection, all segs are collinear
                        #   find bigger side and close other sides

                        # 2 partial T on one corner, opposite is aligned on 1 side
                        #    - close ps and pe

                        # 3 H like
                        #          pe    e2
                        #       ps _|    |_  s1
                        #
                        #   s3_      _ s2
                        #      |    |
                        #           e1
                        # 4 H like
                        #          pe
                        #       ps _|
                        #                 e3
                        #       s2 _      |_  s3
                        #           |
                        #          e1      _ s1
                        #                 |
                        #                 e2

                        ps1 = None
                        pe1 = None
                        ps2 = None
                        pe2 = None
                        ps3 = None
                        pe3 = None

                        e2 = None
                        s2 = None
                        e3 = None
                        s3 = None
                        # find s1, s2, e1, e2
                        if segs[s1].c0 is ps.c1:
                            # s1 is on seg start
                            ps1 = it_start[s1]
                            e2 = seg_end[s1]
                            pe2 = it_end[e2]

                        elif segs[s1].c1 is ps.c1:
                            # s1 is on seg end
                            ps1 = it_end[s1]
                            e2 = seg_sta[s1]
                            pe2 = it_start[e2]

                        if segs[e1].c0 is pe.c1:
                            # e1 is on seg start
                            pe1 = it_start[e1]
                            s2 = seg_end[e1]
                            ps2 = it_end[s2]

                        elif segs[e1].c1 is pe.c1:
                            # e1 is on seg end
                            pe1 = it_end[e1]
                            s2 = seg_sta[e1]
                            ps2 = it_start[s2]

                        # find s3, e3
                        if pe2 is not None:
                            pe2.it.valid = False
                            if pe2.it.is_collinear:
                                e3 = pe2.it.opposite
                                # invalidate pe3
                                if segs[e3].c0 is pe2.c1:
                                    # ps3 is on seg start
                                    pe3 = it_start[e3]
                                elif segs[e3].c1 is pe2.c1:
                                    pe3 = it_end[e3]

                        if ps2 is not None:
                            ps2.it.valid = False
                            if ps2.it.is_collinear:
                                s3 = ps2.it.opposite
                                # invalidate ps3
                                if segs[s3].c0 is ps2.c1:
                                    # ps3 is on seg start
                                    ps3 = it_start[s3]
                                elif segs[s3].c1 is ps2.c1:
                                    ps3 = it_end[s3]

                        # invalidate ps1 ps3 pe1 and pe3 here, ps, pe, ps2 and pe2 already are invalid
                        if ps1 is not None:
                            ps1.it.valid = False

                        if ps3 is not None:
                            ps3.it.valid = False

                        if pe1 is not None:
                            pe1.it.valid = False

                        if pe3 is not None:
                            pe3.it.valid = False

                        e_collinear = e3 is not None
                        s_collinear = s3 is not None

                        # Thicker wall has priority
                        ls, le = ps.d, pe.d

                        if abs(ls - le) < EPSILON:
                            # if thickness is close, the longest will take precedence
                            if e_collinear:
                                le = segs[e0].length + segs[e1].length + segs[e2].length + segs[e3].length

                            if s_collinear:
                                ls = segs[s0].length + segs[s1].length + segs[s2].length + segs[s3].length

                        # are both s2 and e2 collinear this is a true X crossing
                        if s_collinear and e_collinear:
                            if ls < le:
                                # close on e side
                                if DEBUG: Debug.segment(pe, "Colinear(e-2)_%s-%s" % (e0, e1))
                                if DEBUG: Debug.segment(pe2, "Colinear(e-2)_%s-%s" % (e2, e3))
                                Q_segs.newSegment(pe.c0, pe.c1)
                                Q_segs.newSegment(pe2.c0, pe2.c1)
                            else:
                                # close on s side
                                if DEBUG: Debug.segment(ps, "Colinear(s-2)_%s-%s" % (s0, s1))
                                if DEBUG: Debug.segment(ps2, "Colinear(s-2)_%s-%s" % (s2, s3))
                                Q_segs.newSegment(ps.c0, ps.c1)
                                Q_segs.newSegment(ps2.c0, ps2.c1)

                        # H like
                        elif s_collinear:
                            # close s2 - s3 and ps - s1
                            if DEBUG: Debug.segment(ps, "Colinear(s-2)_%s-%s" % (s0, s1))
                            if DEBUG: Debug.segment(ps2, "Colinear(s-2)_%s-%s" % (s2, s3))
                            Q_segs.newSegment(ps.c0, ps.c1)
                            Q_segs.newSegment(ps2.c0, ps2.c1)

                        elif e_collinear:
                            # close e2 - e3 and ps - s1
                            if DEBUG: Debug.segment(pe, "Colinear(e-2)_%s-%s" % (e0, e1))
                            if DEBUG: Debug.segment(pe2, "Colinear(e-2)_%s-%s" % (e2, e3))
                            Q_segs.newSegment(pe.c0, pe.c1)
                            Q_segs.newSegment(pe2.c0, pe2.c1)
                        else:
                            # T on one side
                            # close pe - e1 and ps - s1
                            if DEBUG: Debug.segment(ps, "Colinear(s-2)_%s-%s" % (s0, s1))
                            if DEBUG: Debug.segment(pe, "Colinear(e-2)_%s-%s" % (e0, e1))
                            Q_segs.newSegment(ps.c0, ps.c1)
                            Q_segs.newSegment(pe.c0, pe.c1)

                    elif ps.it.is_collinear:
                        # T shaped
                        # find other sides (4 segments)
                        #    pe     e1
                        #  ps _|    |_s1
                        #
                        #     _________
                        #
                        # find other side and disable any intersection
                        s1 = ps.it.opposite
                        e1 = -1
                        ps1, pe1 = None, None
                        if segs[s1].c0 is ps.c1:
                            # collinear start at intersection
                            ps1 = it_start[s1]
                            e1 = seg_end[s1]
                            pe1 = it_end[e1]

                        elif segs[s1].c1 is ps.c1:
                            # collinear ends at intersection
                            ps1 = it_end[s1]
                            e1 = seg_sta[s1]
                            pe1 = it_start[e1]

                        if ps1 is not None:
                            ps1.it.valid = False
                        # else:
                        #    print("ps ps1 not found", s0, s1, ps.c0, ps.c1, segs[s1].c0, segs[s1].c1)
                        if pe1 is not None:
                            pe1.it.valid = False
                        # else:
                        #     print("ps pe1 not found", s0, e1, ps.c0, ps.c1, segs[s1].c0, segs[s1].c1)
                        Q_segs.newSegment(ps.c0, ps.c1)
                        if DEBUG: Debug.segment(ps, "Colinear(s)_%s-%s" % (s0, s1))

                    elif pe.it.is_collinear:
                        # T shaped
                        # find other sides (4 segments)
                        #     pe
                        #  ps _|   |
                        #          |
                        #  s1 _    |
                        #      |   |
                        #      e1
                        #  find other side and disable any intersection
                        s1 = -1
                        e1 = pe.it.opposite
                        ps1, pe1 = None, None
                        if segs[e1].c0 is pe.c1:
                            # collinear start at intersection
                            pe1 = it_start[e1]
                            s1 = seg_end[e1]
                            ps1 = it_end[s1]
                        elif segs[e1].c1 is pe.c1:
                            # collinear ends at intersection
                            pe1 = it_end[e1]
                            s1 = seg_sta[e1]
                            ps1 = it_start[s1]

                        if ps1 is not None:
                            ps1.it.valid = False
                        # else:
                        #    print("pe ps1 not found", s0, s1, pe.c1)
                        if pe1 is not None:
                            pe1.it.valid = False
                        # else:
                        #    print("pe pe1 not found", s0, e1, pe.c1)
                        Q_segs.newSegment(pe.c0, pe.c1)
                        if DEBUG: Debug.segment(pe, "Colinear(e)_%s-%s" % (e0, e1))

                    elif (ps.d - pe.d) < -EPSILON:
                        # L shaped
                        Q_segs.newSegment(ps.c0, ps.c1)
                        if DEBUG: Debug.segment(ps, "Prolonge2(s)_%s-%s" % (s0, s1))

                    elif (ps.d - pe.d) > EPSILON:
                        # L shaped
                        Q_segs.newSegment(pe.c0, pe.c1)
                        if DEBUG: Debug.segment(pe, "Prolonge2(e)_%s-%s" % (e0, e1))

                    ps.it.valid = False
                    pe.it.valid = False
                # else:
                #    print(s0, ps.it.valid, pe.it.valid)
                    
            elif ps is not None and ps.it.valid:
                ps.it.valid = False
                if DEBUG: Debug.segment(ps, "Prolonge1(s)_%s-%s" % (s0, ps.it.opposite))
                Q_segs.newSegment(ps.c0, ps.c1)

            elif pe is not None and pe.it.valid:
                pe.it.valid = False
                if DEBUG: Debug.segment(pe, "Prolonge1(e)_%s-%s" % (e0, pe.it.opposite))
                Q_segs.newSegment(pe.c0, pe.c1)

        # for p in it_start:
        #     if p.it.valid:
        #         Q_segs.newSegment(p.c0, p.c1)
        #
        # for p in it_end:
        #     if p.it.valid:
        #         Q_segs.newSegment(p.c0, p.c1)

        logger.debug("Polygonizer.monotonize_wall2() intersect (all:%s, points:%s, collinear:%s) :%.4f seconds",
            processed,
            process_point,
            process_collinear,
            (time.time() - t))

        t = time.time()
        _geoms = Q_segs._geoms
        for seg in _geoms:
            seg.add_points(Q_segs)

        logger.debug("Polygonizer.monotonize_wall2() slice :%.4f seconds", (time.time() - t))

    def split(self, Q_points, Q_segs, extend=0.01, all_segs=False):
        """ _split
            detect intersections between segments and create segments according
            is able to project segment ends on closest segment
            use point_tree and seg_tree
            assume merged segments on beforehand
            use_projection allow segment to extend over projection of neighboor
        """
        t = time.time()

        # debug
        processed = 0
        process_collinear = 0
        process_point = 0

        segs = Q_segs._geoms
        nbsegs = Q_segs.ngeoms
        it_start = [None] * nbsegs
        it_end = [None] * nbsegs

        # points with 1 user are "extendable"
        if all_segs:
            for seg in Q_segs._geoms:
                seg.c0.users = 1
                seg.c1.users = 1
        else:
            for seg in Q_segs._geoms:
                seg.c0.add_user()
                seg.c1.add_user()

        for s, seg in enumerate(segs):

            # enlarge seek box for "extendable" segments
            if seg.c0.users < 2 or seg.c1.users < 2:
                count, idx = Q_segs.intersects(seg, extend)
            else:
                count, idx = Q_segs.intersects(seg)

            for _id in idx:

                if _id > s:
                    # can't check for side determinant here
                    # as intersect may enlarge segment to nearest
                    # neighboor

                    _seg = segs[_id]
                    intersect, co, u, v, d = seg._intersect_seg(_seg)

                    processed += 1

                    # POINT_INTERSECTION
                    if intersect:

                        process_point += 1

                        # store intersection state
                        # to be able to disable invalid ones
                        it = Intersection()

                        point = Q_points.newPoint(co)

                        # distance of nearest segment endpoint and intersection
                        du = seg.min_intersect_dist(u, point)
                        dv = _seg.min_intersect_dist(v, point)

                        # print("s:%s _id:%s u:%7f v:%7f du:%7f dv:%7f" % (s, _id, u, v, du, dv))

                        # does intersect realy occurs ?
                        inside_u = (0 <= u < 1)
                        extend_u = (
                                (u <= 0 and seg.c0.users < 2 and du < extend) or
                                (u >= 1 and seg.c1.users < 2 and du < extend)
                        )
                        inside_v = (0 <= v < 1)
                        extend_v = (
                                (v <= 0 and _seg.c0.users < 2 and dv < extend) or
                                (v >= 1 and _seg.c1.users < 2 and dv < extend)
                        )
                        intersect_u = inside_u or extend_u
                        intersect_v = inside_v or extend_v

                        if intersect_u and intersect_v:

                            # intersection point on segment _id,
                            # segment end when distance is under precision

                            pt = self._intersection_point(dv, v, point, _seg)

                            # make last intersections invalid
                            # on both last and opposite segments
                            # prevent segment from being "extendable"
                            if pt is seg.c0:
                                if not all_segs and it_start[s] is not None:
                                    it_start[s].it.valid = False
                                    it_start[s].d = 0
                                
                            elif pt is seg.c1:
                                if not all_segs and it_end[s] is not None:
                                    it_end[s].it.valid = False
                                    it_end[s].d = 0
                                
                            elif u <= 0:
                                # enlarge segment s c0
                                self._intersection(it_start, s, seg.c0, pt, du, it)

                            elif u < 1:
                                # intersection on segment s
                                seg.slice(u, pt)
                            else:
                                # enlarge segment s c1
                                self._intersection(it_end, s, seg.c1, pt, du, it)


                            # intersection point on segment seg,
                            # segment end when distance is under precision
                            pt = self._intersection_point(du, u, point, seg)

                            # make last intersections invalid
                            # on opposite segment
                            if pt is _seg.c0:
                                if not all_segs and it_start[_id] is not None:
                                    it_start[_id].it.valid = False
                                    it_start[_id].d = 0
                                # _seg.c0.users = 2

                            elif pt is _seg.c1:
                                if not all_segs and it_end[_id] is not None:
                                    it_end[_id].it.valid = False
                                    it_end[_id].d = 0
                                # _seg.c1.users = 2

                            elif v <= 0:
                                # enlarge segment _id c0
                                self._intersection(it_start, _id, _seg.c0, pt, dv, it)

                            elif v < 1:
                                # intersection on segment _id
                                _seg.slice(v, pt)
                            else:
                                # enlarge segment _id c1
                                self._intersection(it_end, _id, _seg.c1, pt, dv, it)


                    # COLLINEAR_INTERSECTION
                    elif d < EPSILON:
                        # parallel segments, endpoint on segment
                        # skip NON_COLLINEAR aka when d > EPSILON
                        process_collinear += 1

                        # point _seg.c0 on segment seg
                        pt = _seg.c0
                        du, u = seg._point_sur_seg(pt)

                        if (((u <= 0 and seg.c0.users < 2 and du < extend) or
                                (0 <= u < 1) or
                                (u >= 1 and seg.c1.users < 2 and du < extend))):

                            it = Intersection()
                            if u <= 0:
                                # extend seg on c0 side
                                self._intersection(it_start, s, seg.c0, pt, du, it)

                            elif u < 1:
                                # occurs inside segment seg
                                seg.slice(u, pt)
                                if it_start[_id] is not None:
                                    it_start[_id].it.valid = False

                            else:
                                # extend seg on c1 side
                                self._intersection(it_end, s, seg.c1, pt, du, it)


                        # point _seg.c1 on segment seg
                        pt = _seg.c1
                        du, u = seg._point_sur_seg(pt)

                        if (((u <= 0 and seg.c0.users < 2 and du < extend) or
                                (0 <= u < 1) or
                                (u >= 1 and seg.c1.users < 2 and du < extend))):

                            it = Intersection()
                            if u <= 0:
                                # extend in c0 side
                                self._intersection(it_start, s, seg.c0, pt, du, it)

                            elif u < 1:
                                # occurs on segment seg
                                seg.slice(u, pt)
                                if it_end[_id] is not None:
                                    it_end[_id].it.valid = False

                            else:
                                # extend
                                self._intersection(it_end, s, seg.c1, pt, du, it)


                        # point seg.c0 on segment _seg
                        pt = seg.c0
                        du, u = _seg._point_sur_seg(pt)

                        if (((u <= 0 and _seg.c0.users < 2 and du < extend) or
                                (0 <= u < 1) or
                                (u >= 1 and _seg.c1.users < 2 and du < extend))):

                            it = Intersection()
                            if u <= 0:
                                # extend in c0 side
                                self._intersection(it_start, _id, _seg.c0, pt, du, it)

                            elif u < 1:
                                # occurs on segment _seg
                                # always occurs so intersection
                                # doesent need to be "removable"
                                _seg.slice(u, pt)
                                if it_start[s] is not None:
                                    it_start[s].it.valid = False

                            else:
                                # extend
                                self._intersection(it_end, _id, _seg.c1, pt, du, it)

                        # point seg.c1 on segment _seg
                        pt = seg.c1
                        du, u = _seg._point_sur_seg(pt)

                        if (((u <= 0 and _seg.c0.users < 2 and du < extend) or
                                (0 <= u < 1) or
                                (u >= 1 and _seg.c1.users < 2 and du < extend))):

                            it = Intersection()
                            if u <= 0:
                                self._intersection(it_start, _id, _seg.c0, pt, du, it)

                            elif u < 1:
                                # occurs on segment _seg
                                _seg.slice(u, pt)
                                if it_end[s] is not None:
                                    it_end[s].it.valid = False

                            else:
                                # extend _seg on c1 side
                                self._intersection(it_end, _id, _seg.c1, pt, du, it)

        for pro in it_start:
            if pro is not None and pro.it.valid:
                Q_segs.newSegment(pro.c0, pro.c1)

        for pro in it_end:
            if pro is not None and pro.it.valid:
                Q_segs.newSegment(pro.c0, pro.c1)

        logger.debug("Polygonizer.split() intersect (all:%s, points:%s, collinear:%s) :%.4f seconds",
            processed,
            process_point,
            process_collinear,
            (time.time() - t))

        t = time.time()
        _geoms = Q_segs._geoms
        for seg in _geoms:
            seg.add_points(Q_segs)

        logger.debug("Polygonizer.split() slice :%.4f seconds", (time.time() - t))

    def _polygonize(self, gf, Q_points, Q_segs, extend=0.0, all_segs=False, use_monotonize_wall2=False, skip_users=True):
        t = time.time()

        if use_monotonize_wall2:
            self.monotonize_wall2(Q_points, Q_segs, extend=extend)
        else:
            self.split(Q_points, Q_segs, extend=extend, all_segs=all_segs)

        lines = gf.buildGeometry([
            gf.createLineString([seg.c0.coord, seg.c1.coord])
            for seg in Q_segs._geoms
            if seg.available and (skip_users or seg.users < 2) and seg.c0 is not seg.c1
        ])
        merged = lines.line_merge()

        # skip validity test for polygons
        # May raise TopologyException
        polys, dangles, cuts, invalids = PolygonizeOp.polygonize_full(merged, skip_validity_check=True)

        logger.debug("Polygonizer._polygonize() :%.2f seconds polygons:%s invalids:%s",
                     time.time() - t,
                     len(polys),
                     len(invalids))
        return merged, polys, dangles, cuts, invalids

    @staticmethod
    def object_to_symbol2d(
            context,
            objects,
            resolution: int = 12,
            evaluate: bool=True,
            split: bool=False,
            outlines: bool=False,
            sharpness: float=0,
            skip_backfaces: bool=False,
            itM=None
        ):
        """
        Convert 3d objects (mesh and curve) into 2d symbol
        :context: blender's context
        :objects: blender's objects in curve or mesh
        :resolution: bezier curve evaluation steps
        :evaluate: use modifiers
        :split: split intersecting edges and optimize result (slow)
        :selected: use only selected edges of mesh
        :outlines: output outlines only (slow)
        :skip_backfaces: skip back faces
        :itM: project objects in specified space matrix, Z up by default
        return io, geom -> 2d symbol from curve(s) and evaluated mesh(s) edges
        """
        t = time.time()

        skip_users = True
        objs = Io.ensure_iterable(objects)
        coordsys = CoordSys(objs, itM=itM)

        scene = objman.get_context_value(context, "scene")
        gf = GeometryFactory()
        gf.outputFactory = Io(scene=scene, coordsys=coordsys)





        if split or outlines:
            op = Polygonizer(coordsys)
            # Ensure uniqueness of points and segments
            Q_segs = Qtree(coordsys)
            Q_points = Qtree(coordsys)

            Io.add_objects(Q_points, Q_segs, coordsys, objs, resolution, evaluate, sharpness, skip_backfaces)

            op.split(Q_points, Q_segs)

            if outlines:
                merged, polys, dangles, cuts, invalids = op._polygonize(
                    gf, Q_points, Q_segs, extend=False, all_segs=False, use_monotonize_wall2=False
                )
                geom = ShapelyOps.union(polys)

            else:
                lines = gf.buildGeometry([
                    gf.createLineString([seg.c0.coord, seg.c1.coord])
                    for seg in Q_segs._geoms
                    if seg.available and (skip_users or seg.users < 2) and seg.c0 is not seg.c1
                ])
                geom = lines.line_merge()

            return gf.outputFactory, geom
        else:
            lines = []
            Io.objects_to_geoms(objs, resolution, evaluate, sharpness, skip_backfaces, lines, coordsys=coordsys)
            return gf.outputFactory, lines

    @staticmethod
    def polygonize(context, curves, extend=0.0, all_segs=False, resolution=12, use_monotonize_wall2=False):
        """
            @extend: extend line ends to find intersections
            @extend_seg: extend line segments to find intersections
        """
        t = time.time()
        curves = Io.ensure_iterable(curves)
        coordsys = CoordSys(curves)

        logger.debug("Polygonizer.polygonize() extend:%s all_segs:%s", extend, all_segs)

        scene = objman.get_context_value(context, "scene")
        gf = GeometryFactory()
        gf.outputFactory = Io(scene=scene, coordsys=coordsys)

        op = Polygonizer(coordsys)
        # Ensure uniqueness of points and segments
        Q_segs = Qtree(coordsys)
        Q_points = Qtree(coordsys)

        Io.add_objects(Q_points, Q_segs, coordsys, curves, resolution, True)

        # May raise TopologyException
        merged, polys, dangles, cuts, invalids = op._polygonize(
            gf, Q_points, Q_segs, extend=extend, all_segs=all_segs, use_monotonize_wall2=use_monotonize_wall2
        )

        vars_dict['select_polygons'] = SelectPolygons(polys, coordsys)
        vars_dict['select_lines'] = SelectLines(merged, coordsys)
        vars_dict['select_points'] = SelectPoints(Q_points._geoms, coordsys)

        logger.debug("Polygonizer.polygonize() :%.2f seconds polygons:%s invalids:%s",
            time.time() - t,
            len(polys),
            len(invalids))

        return coordsys, polys, dangles, cuts, invalids

    @staticmethod
    def polygonize_walls(context, walls, extend=0.0, all_segs=False):
        """
            @extend: extend line ends to find intersections
            @extend_seg: extend line segments to find intersections
        """
        t = time.time()
        _walls = Io.ensure_iterable(walls)
        coordsys = CoordSys(_walls)

        logger.debug("Polygonizer.polygonize_walls() extend:%s all_segs:%s", extend, all_segs)

        gf = GeometryFactory()

        scene = objman.get_context_value(context, "scene")

        gf.outputFactory = Io(scene=scene, coordsys=coordsys)
        op = Polygonizer(coordsys)
        # Ensure uniqueness of points and segments
        Q_segs = Qtree(coordsys)
        Q_points = Qtree(coordsys)

        Io.add_walls(Q_points, Q_segs, coordsys, _walls)

        # May raise TopologyException
        merged, polys, dangles, cuts, invalids = op._polygonize(
            gf, Q_points, Q_segs, extend=extend, all_segs=all_segs, skip_users=False
        )

        # Io.to_curve(context.scene, coordsys, merged, "medged")
        # Io.to_curve(context.scene, coordsys, polys, "polys")
        # Io.to_curve(context.scene, coordsys, dangles, "dangles")
        # Io.to_curve(context.scene, coordsys, invalids, "invalids")

        logger.debug("Polygonizer.polygonize_walls() :%.2f seconds polygons:%s invalids:%s",
            time.time() - t,
            len(polys),
            len(invalids))
        geom = gf.buildGeometry(polys)
        return coordsys, geom


class ARCHIPACK_OP_PolyLib_Pick2DPoints(Operator):
    bl_idname = "archipack.polylib_pick_2d_points"
    bl_label = "Pick points"
    bl_description = "Select two or more points to create rectangle or convex hull"

    bl_options = {'REGISTER', 'UNDO'}
    pass_keys = ['NUMPAD_0', 'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_4',
                 'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8',
                 'NUMPAD_9', 'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE']

    @classmethod
    def poll(cls, context):
        global vars_dict
        return vars_dict['select_points'] is not None

    def modal(self, context, event):
        # Fix layout switch issue
        if context.area is None:
            return {'FINISHED'}
        global vars_dict
        context.area.tag_redraw()
        if event.type in self.pass_keys:
            return {'PASS_THROUGH'}
        return vars_dict['select_points'].modal(context, event)

    def invoke(self, context, event):
        global vars_dict
        if vars_dict['select_points'] is None:
            self.report({'WARNING'}, "Use detect before")
            return {'CANCELLED'}
        elif context.space_data.type == 'VIEW_3D':
            vars_dict['select_points'].init(self, context)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "PolyLib_Pick2DPoints Active space must be a View3d")
            return {'CANCELLED'}


class ARCHIPACK_OP_PolyLib_Pick2DLines(Operator):
    bl_idname = "archipack.polylib_pick_2d_lines"
    bl_label = "Pick lines"
    bl_description = "Create lines or merge lines"
    bl_options = {'REGISTER', 'UNDO'}
    pass_keys = ['NUMPAD_0', 'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_4',
                 'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8',
                 'NUMPAD_9', 'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE']

    @classmethod
    def poll(cls, context):
        global vars_dict
        return vars_dict['select_lines'] is not None

    def modal(self, context, event):
        global vars_dict
        # Fix layout switch issue
        if context.area is None:
            return {'FINISHED'}

        context.area.tag_redraw()
        if event.type in self.pass_keys:
            return {'PASS_THROUGH'}
        return vars_dict['select_lines'].modal(context, event)

    def invoke(self, context, event):
        global vars_dict
        if vars_dict['select_lines'] is None:
            self.report({'WARNING'}, "Use detect before")
            return {'CANCELLED'}
        elif context.space_data.type == 'VIEW_3D':
            vars_dict['select_lines'].init(self, context)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "PolyLib_Pick2DLines Active space must be a View3d")
            return {'CANCELLED'}


class ARCHIPACK_OP_PolyLib_Pick2DPolygons(Operator):
    bl_idname = "archipack.polylib_pick_2d_polygons"
    bl_label = "Pick 2d"
    bl_description = "Create Windows, Doors, Walls, Union, Polygons, Rectangles"
    bl_options = {'REGISTER', 'UNDO'}
    pass_keys = ['NUMPAD_0', 'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_4',
                 'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8',
                 'NUMPAD_9', 'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE']

    @classmethod
    def poll(cls, context):
        global vars_dict
        return vars_dict['select_polygons'] is not None

    def modal(self, context, event):
        global vars_dict
        # Fix layout switch issue
        if context.area is None:
            return {'FINISHED'}

        context.area.tag_redraw()

        if event.type in self.pass_keys:
            return {'PASS_THROUGH'}
        return vars_dict['select_polygons'].modal(context, event)

    def invoke(self, context, event):
        global vars_dict
        if vars_dict['select_polygons'] is None:
            self.report({'WARNING'}, "Use detect before")
            return {'CANCELLED'}
        elif context.space_data.type == 'VIEW_3D':
            """
            if not (context.space_data.region_3d and
                    context.space_data.region_3d.view_perspective == 'ORTHO'):
                self.report({'WARNING'}, "Polygon selection only work in ortho view")
                return {'CANCELLED'}
            """
            vars_dict['select_polygons'].init(self, context)
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "PolyLib_Pick2DPolygons Active space must be a View3d")
            return {'CANCELLED'}


class ARCHIPACK_OP_PolyLib_Polygonize(Operator):
    bl_idname = "archipack.polylib_polygonize"
    bl_label = "Detect"
    bl_description = "Detect polygons from unordered splines"
    bl_options = {'INTERNAL'}

    extend : FloatProperty(
            name="Extend end",
            description="Extend line ends to closest intersecting segment",
            default=0.01,
            subtype='DISTANCE', unit='LENGTH', min=0
            )
    all_segs : BoolProperty(
            name="Extend all segs",
            description="(slower but may be safer) Extend only line ends when not enabled",
            default=False
            )
    bezier_resolution : IntProperty(
            name="Bezier resolution", min=0, default=12
            )
    thickness : FloatProperty(
            name="Thickness",
            default=2.7,
            subtype='DISTANCE', unit='LENGTH', min=0
            )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return len(context.selected_objects) > 0 and o is not None and o.type == 'CURVE'

    def invoke(self, context, event):
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        settings_write(self)
        global vars_dict
        objs = [obj for obj in context.selected_objects if obj.type == 'CURVE']

        if len(objs) < 1:
            self.report({'WARNING'}, "Select a curve object before")
            return {'CANCELLED'}

        for obj in objs:
            obj.select_set(state=False)

        try:
            coordsys, polys, dangles, cuts, invalids = Polygonizer.polygonize(
                context,
                objs,
                extend=self.extend,
                all_segs=self.all_segs,
                resolution=self.bezier_resolution)

        except TopologyException as ex:
            self.report({'WARNING'}, "Topology error {}".format(ex))
            return {'CANCELLED'}
        except Exception as ex:
            self.report({'WARNING'}, "Unknown error {}".format(ex))
            return {'CANCELLED'}

        if len(invalids) > 0:
            errs = Io.to_curve(context.scene, coordsys, invalids, "invalid_polygons")
            err_mat = vars_dict['select_polygons'].build_display_mat("Invalid_polygon", (1, 0, 0, 1))
            errs.color = (1, 0, 0, 1)
            if len(errs.data.materials) < 1:
                errs.data.materials.append(err_mat)
                errs.active_material = err_mat
            errs.select_set(state=True)
            self.report({'WARNING'}, str(len(invalids)) + " invalid polygons detected")

        return {'FINISHED'}


class ARCHIPACK_OP_PolyLib_Offset(Operator):
    """Offset curves as separate objects
    """
    bl_idname = "archipack.polylib_offset"
    bl_label = "Offset"
    bl_description = "Offset lines (work best on open lines)"
    bl_options = {'REGISTER', 'PRESET', 'INTERNAL', 'UNDO'}

    bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )
    distance : FloatProperty(
            name="Distance",
            default=0.05,
            subtype='DISTANCE', unit='LENGTH', min=0.001
            )
    side : EnumProperty(
            name="Side", default='left',
            items=[('left', 'Left', 'Left'),
                ('right', 'Right', 'Right')]
            )
    resolution : IntProperty(
            name="Resolution", default=16, min=0
            )
    join_style : EnumProperty(
            name="Style", default='2',
            items=[('1', 'Round', 'Round'),
                    ('2', 'Mitre', 'Mitre'),
                    ('3', 'Bevel', 'Bevel')]
            )
    mitre_limit : FloatProperty(
            name="Mitre limit",
            default=10.0,
            subtype='DISTANCE',
            unit='LENGTH', min=0
            )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return len(context.selected_objects) > 0 and o is not None and o.type == 'CURVE'

    def invoke(self, context, event):
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        t = time.time()
        settings_write(self)

        objs = list(obj for obj in context.selected_objects if obj.type == 'CURVE')

        if len(objs) < 1:
            self.report({'WARNING'}, "Select a curve object before")
            return {'CANCELLED'}

        for obj in objs:
            obj.select_set(state=False)

        lines = []

        coordsys = Io.objects_to_geoms(objs, resolution=self.bezier_resolution, geoms=lines)
        gf = GeometryFactory()
        gf.outputFactory = Io(scene=context.scene, coordsys=coordsys)
        offset = []

        distance = self.distance

        if self.side == 'right':
            distance = -distance
        """
        offset = coll.parallel_offset(distance,
                    resolution=self.resolution,
                    join_style=int(self.join_style),
                    mitre_limit=self.mitre_limit)
        """

        for line in lines:
            try:
                res = line.parallel_offset(distance, resolution=self.resolution,
                        join_style=int(self.join_style), mitre_limit=self.mitre_limit)
            except TopologyException as ex:
                self.report({'WARNING'}, "Topology error {}".format(ex))
                return {'CANCELLED'}
            except Exception as ex:
                self.report({'WARNING'}, "Unknown error {}".format(ex))
                raise ex
                return {'CANCELLED'}
            offset.append(res)

        result = Io.to_curve(context.scene, coordsys, offset, 'offset')
        result.select_set(state=True)
        logger.info("Offset :%.2f seconds", time.time() - t)

        return {'FINISHED'}


class ARCHIPACK_OP_PolyLib_Buffer(Operator):
    bl_idname = "archipack.polylib_buffer"
    bl_label = "Buffer"
    bl_description = "Buffer lines (when single sided, no full support for closed lines)"
    bl_options = {'REGISTER', 'PRESET', 'INTERNAL', 'UNDO'}

    bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )
    distance : FloatProperty(
            name="Distance",
            default=0.05,
            subtype='DISTANCE', unit='LENGTH'
            )
    side : EnumProperty(
            name="Side", default='both',
            items=[('both', 'Both', 'Both'),
                ('left', 'Left', 'Left'),
                ('right', 'Right', 'Right')]
            )
    resolution : IntProperty(
            name="Resolution", default=16, min=0
            )
    join_style : EnumProperty(
            name="Join", default='2',
            items=[('1', 'Round', 'Round'),
                    ('2', 'Mitre', 'Mitre'),
                    ('3', 'Bevel', 'Bevel')]
            )
    cap_style : EnumProperty(
            name="Cap", default='3',
            items=[('1', 'Round', 'Round'),
                    ('2', 'Flat', 'Flat'),
                    ('3', 'Square', 'Square')]
            )
    mitre_limit : FloatProperty(
            name="Mitre limit",
            default=10.0,
            subtype='DISTANCE',
            unit='LENGTH', min=0
            )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return len(context.selected_objects) > 0 and o is not None and o.type == 'CURVE'

    def invoke(self, context, event):
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        t = time.time()

        if self.distance == 0:
            self.report({'WARNING'}, "Distance 0 invalid for buffer")
            return {'CANCELLED'}

        settings_write(self)

        objs = list(obj for obj in context.selected_objects if obj.type == 'CURVE')

        if len(objs) < 1:
            self.report({'WARNING'}, "Select a curve object before")
            return {'CANCELLED'}

        for obj in objs:
            obj.select_set(state=False)

        lines = []

        coordsys = Io.objects_to_geoms(objs, resolution=self.bezier_resolution, geoms=lines)
        gf = GeometryFactory()
        gf.outputFactory = Io(scene=context.scene, coordsys=coordsys)
        offset = []

        distance = self.distance

        if self.side == 'right':
            distance = -distance

        coll = gf.buildGeometry(lines)
        try:
            offset = coll.buffer(distance,
                        resolution=self.resolution,
                        join_style=int(self.join_style),
                        cap_style=int(self.cap_style),
                        mitre_limit=self.mitre_limit,
                        single_sided=self.side != 'both'
                        )
        except TopologyException as ex:
            self.report({'WARNING'}, "Topology error {}".format(ex))
            return {'CANCELLED'}
        except Exception as ex:
            self.report({'WARNING'}, "Unknown error {}".format(ex))
            raise ex
            return {'CANCELLED'}

        result = Io.to_curve(context.scene, coordsys, offset, 'buffer')
        result.select_set(state=True)
        logger.info("Buffer :%.2f seconds", time.time() - t)
        return {'FINISHED'}


opCodes = {
    'INTERSECTION': 1,
    'UNION': 2,
    'DIFFERENCE': 3,
    'SYMDIFFERENCE': 4,
    'REVDIFFERENCE': 13
}


class ARCHIPACK_OP_PolyLib_Boolean(Operator):
    bl_idname = "archipack.polylib_boolean"
    bl_label = "Boolean"
    bl_description = "Boolean operation (limited to 2 objects at once - use Detect for multiple inputs)"
    bl_options = {'REGISTER', 'INTERNAL', 'UNDO'}

    opCode : EnumProperty(
        name="Operation",
        description="Boolean operation type",
        items=(
            ('INTERSECTION', 'Intersection', 'Intersection', 0),
            ('UNION', 'Union', 'Union', 1),
            ('DIFFERENCE', 'Active - Selected', 'Active - Selected', 2),
            ('REVDIFFERENCE', 'Selected - Active', 'Selected - Active', 3),
            ('SYMDIFFERENCE', 'Symetrtic difference', 'Symetrtic difference', 4)
            ),
        default='UNION'
        )

    bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return len(context.selected_objects) > 0 and o is not None and o.type == 'CURVE'

    def invoke(self, context, event):
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        t = time.time()
        settings_write(self)

        a = context.active_object
        b = [obj for obj in context.selected_objects if obj.type == 'CURVE' and obj.name != a.name]

        if len(b) < 1:
            self.report({'WARNING'}, "Select a curve object before")
            return {'CANCELLED'}

        for obj in b:
            obj.select_set(state=False)

        a.select_set(state=False)

        coordsys = Io.getCoordsys([a] + b)

        # (1) intersection allow geometryCollection for geom_a
        # (2) union allow geometryCollection for geom_a and geom_b
        # other operations require homogeneous Multi* geometry
        opCode = opCodes[self.opCode]

        homogeneous_a = opCode > 2
        homogeneous_b = opCode != 2

        geom_a = Io.curves_to_geomcollection([a], self.bezier_resolution, coordsys=coordsys, homogeneous=homogeneous_a)
        geom_b = Io.curves_to_geomcollection(b, self.bezier_resolution, coordsys=coordsys, homogeneous=homogeneous_b)

        if opCode == 2 and (
                geom_a.geom_type == 'GeometryCollection' or
                geom_b.geom_type == 'GeometryCollection'):
            # use UnaryUnionOp to support GeometryCollection
            # require a single geom, geom_b must be None
            geom_a = Io.curves_to_geomcollection([a] + b, self.bezier_resolution, coordsys=coordsys, homogeneous=False)
            geom_b = None

        # for debug purposes
        """
        io = Io(scene=context.scene, coordsys=coordsys)
        geom_a._factory.outputFactory = io
        geom_b._factory.outputFactory = io

        geom_b._factory.output(geom_a, name="geom_a")
        geom_b._factory.output(geom_b, name="geom_b")
        """

        if opCode > 10:
            geom_a, geom_b = geom_b, geom_a
            opCode = opCode - 10

        try:
            # Might throw TopologyException
            res = ShapelyOps.boolean(geom_a, geom_b, opCode)

        except TopologyException as ex:
            self.report({'WARNING'}, "Topology error {}".format(ex))
            return {'CANCELLED'}
        except Exception as ex:
            self.report({'WARNING'}, "Can't perform operation {}".format(ex))
            raise ex
            return {'CANCELLED'}

        result = Io.to_curve(context.scene, coordsys, res, 'boolean')
        result.select_set(state=True)
        logger.info("Boolean :%.2f seconds", time.time() - t)

        return {'FINISHED'}


class ARCHIPACK_OP_PolyLib_Simplify(Operator):
    bl_idname = "archipack.polylib_simplify"
    bl_label = "Simplify"
    bl_description = "Simplify lines"
    bl_options = {'REGISTER', 'PRESET', 'INTERNAL', 'UNDO'}

    bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )
    tolerance : FloatProperty(
            name="Tolerance",
            default=0.01,
            subtype='DISTANCE', unit='LENGTH', min=0
            )
    preserve_topology : BoolProperty(
            name="Preserve topology",
            description="Preserve topology (fast without, but may introduce self crossing)",
            default=False
            )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return len(context.selected_objects) > 0 and o is not None and o.type == 'CURVE'

    def invoke(self, context, event):
        settings_load(self)
        return self.execute(context)

    def execute(self, context):
        t = time.time()
        settings_write(self)
        global vars_dict

        objs = [obj for obj in context.selected_objects if obj.type == 'CURVE']
        if len(objs) < 1:
            self.report({'WARNING'}, "Select a curve object before")
            return {'CANCELLED'}
        for obj in objs:
            obj.select_set(state=False)
        simple = []
        lines = []
        coordsys = Io.objects_to_geoms(objs, resolution=self.bezier_resolution, geoms=lines)
        for line in lines:
            if self.preserve_topology:
                res = line.simplify(self.tolerance, preserve_topology=self.preserve_topology)
            else:
                res = line.simplify_by_distance(self.tolerance)
            simple.append(res)
        result = Io.to_curve(context.scene, coordsys, simple, 'simplify')
        result.select_set(state=True)
        logger.info("Simplify :%.2f seconds", time.time() - t)
        return {'FINISHED'}


class ARCHIPACK_OP_PolyLib_OutputPolygons(Operator):
    bl_idname = "archipack.polylib_output_polygons"
    bl_label = "Output Polygons"
    bl_description = "Output all polygons"
    bl_options = {'REGISTER', 'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        global vars_dict
        return vars_dict['select_polygons'] is not None

    def execute(self, context):
        global vars_dict
        result = Io.to_curve(context.scene, vars_dict['select_polygons'].coordsys,
                                vars_dict['select_polygons'].geoms, 'polygons')
        result.select_set(state=True)
        return {'FINISHED'}


class ARCHIPACK_OP_PolyLib_OutputLines(Operator):
    bl_idname = "archipack.polylib_output_lines"
    bl_label = "Output lines"
    bl_description = "Output all lines"
    bl_options = {'REGISTER', 'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        global vars_dict
        return vars_dict['select_lines'] is not None

    def execute(self, context):
        global vars_dict
        result = Io.to_curve(context.scene, vars_dict['select_lines'].coordsys,
                                vars_dict['select_lines'].geoms, 'lines')
        result.select_set(state=True)
        return {'FINISHED'}


class archipack_polylib(PropertyGroup):
    bl_idname = 'archipack.polylib_parameters'
    polygonize_expand : BoolProperty(
            default=True,
            description="Display polygonize tools",
            options={'SKIP_SAVE'}
            )
    polygonize_extend : FloatProperty(
            name="Extend end",
            description="Extend line ends to closest intersecting segment",
            default=0.01,
            subtype='DISTANCE', unit='LENGTH', min=0
            )
    polygonize_all_segs : BoolProperty(
            name="Extend all segs",
            description="(slower but may be safer) Extend only line ends when not enabled",
            default=False
            )
    polygonize_bezier_resolution : IntProperty(
            name="Bezier resolution", min=0, default=12
            )
    polygonize_thickness : FloatProperty(
            name="Max thickness",
            description="Maximum thickness to consider lines as wall, should be lower as possible",
            default=0.7,
            subtype='DISTANCE', unit='LENGTH', min=0.01
            )
    polygonize_height: FloatProperty(
        name="Height",
        description="Wall height",
        default=2.7,
        subtype='DISTANCE', unit='LENGTH', min=0.01
    )
    offset_expand : BoolProperty(
            default=False,
            description="Display offset options",
            options={'SKIP_SAVE'}
            )
    offset_bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )
    offset_distance : FloatProperty(
            name="Distance",
            default=0.05,
            subtype='DISTANCE', unit='LENGTH', min=0.001
            )
    offset_side : EnumProperty(
            name="Side", default='left',
            items=[('left', 'Left', 'Left'),
                ('right', 'Right', 'Right')]
            )
    offset_resolution : IntProperty(
            name="Resolution", default=16, min=0
            )
    offset_join_style : EnumProperty(
            name="Style", default='2',
            items=[('1', 'Round', 'Round'),
                    ('2', 'Mitre', 'Mitre'),
                    ('3', 'Bevel', 'Bevel')]
            )
    offset_mitre_limit : FloatProperty(
            name="Mitre limit",
            default=10.0,
            subtype='DISTANCE',
            unit='LENGTH', min=0
            )

    buffer_expand : BoolProperty(
            default=False,
            description="Display buffer options",
            options={'SKIP_SAVE'}
            )
    buffer_bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )
    buffer_distance : FloatProperty(
            name="Distance",
            default=0.05,
            subtype='DISTANCE', unit='LENGTH'
            )
    buffer_side : EnumProperty(
            name="Side", default='both',
            items=[('both', 'Both', 'Both'),
                ('left', 'Left', 'Left'),
                ('right', 'Right', 'Right')]
            )
    buffer_resolution : IntProperty(
            name="Resolution",
            description="Cap and joints resolution",
            default=16, min=0
            )
    buffer_join_style : EnumProperty(
            name="Join", default='2',
            items=[('1', 'Round', 'Round'),
                    ('2', 'Mitre', 'Mitre'),
                    ('3', 'Bevel', 'Bevel')]
            )
    buffer_cap_style : EnumProperty(
            name="Cap", default='3',
            items=[('1', 'Round', 'Round'),
                    ('2', 'Flat', 'Flat'),
                    ('3', 'Square', 'Square')]
            )
    buffer_mitre_limit : FloatProperty(
            name="Mitre limit",
            default=10.0,
            subtype='DISTANCE',
            unit='LENGTH', min=0
            )

    simplify_expand : BoolProperty(
            default=False,
            description="Display simplify options",
            options={'SKIP_SAVE'}
            )
    simplify_bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )
    simplify_tolerance : FloatProperty(
            name="Tolerance",
            default=0.01,
            subtype='DISTANCE', unit='LENGTH', min=0
            )
    simplify_preserve_topology : BoolProperty(
            name="Preserve topology",
            description="Preserve topology (fast without, but may introduce self crossing)",
            default=False
            )

    boolean_expand : BoolProperty(
            default=False,
            description="Display 2d boolean tools",
            options={'SKIP_SAVE'}
            )
    boolean_bezier_resolution : IntProperty(
            name="Bezier resolution",
            description="Input resolution for bezier curves",
            min=0, default=12
            )


@persistent
def load_handler(dummy):
    global vars_dict
    vars_dict['select_polygons'] = None
    vars_dict['select_lines'] = None
    vars_dict['select_points'] = None


def register():
    global vars_dict
    vars_dict = {
        # keep track of shapely geometry selection sets
        'select_polygons': None,
        'select_lines': None,
        'select_points': None
        }
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Pick2DPolygons)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Pick2DLines)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Pick2DPoints)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_OutputPolygons)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_OutputLines)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Offset)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Buffer)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Boolean)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Simplify)
    bpy.utils.register_class(ARCHIPACK_OP_PolyLib_Polygonize)
    bpy.utils.register_class(archipack_polylib)
    # bpy.types.WindowManager.archipack_polylib = PointerProperty(type=archipack_polylib)
    bpy.app.handlers.load_post.append(load_handler)


def unregister():
    global vars_dict
    del vars_dict
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Pick2DPolygons)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Pick2DLines)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Pick2DPoints)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Polygonize)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_OutputPolygons)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_OutputLines)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Offset)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Buffer)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Boolean)
    bpy.utils.unregister_class(ARCHIPACK_OP_PolyLib_Simplify)
    bpy.utils.unregister_class(archipack_polylib)
    bpy.app.handlers.load_post.remove(load_handler)
    # del bpy.types.WindowManager.archipack_polylib


"""
        # x, y = pt
        # loc = p.coordsys.world @ Vector((x, y, 0))
        # bpy.ops.object.empty_add(type='PLAIN_AXES', radius=1,location=loc)


from archipack.archipack_polylines import Polygonizer
curves = C.selected_objects
coordsys, polys, dangles, cuts, invalids = Polygonizer.polygonize(C, curves, extend=0.0, resolution=12)


geoms = []
coords = Io.objects_to_geoms(C.selected_objects, resolution=12, geoms=geoms)
ls = geoms[0]


b = ls.buffer(0.05, join_style=JOIN_STYLE.mitre, cap_style=CAP_STYLE.flat, single_sided=False)
Io.to_curve(C.scene, coords, b, name="buffer")




import time
import logging
logger = logging.getLogger(__package__)

from archipack.pygeos.op_polygonize import PolygonizeOp
from archipack.pygeos.geom import GeometryFactory
from archipack.pygeos.prepared import PreparedGeometryFactory
from archipack.pygeos.op_linemerge import LineMerger
from archipack.pygeos.op_overlay import OverlayOp, SnapOverlayOp
from archipack.pygeos.op_union import UnaryUnionOp
from archipack.pygeos.op_buffer import BufferOp
from archipack.archipack_polylines import Io, CoordSys, Polygonizer
from archipack.pygeos.shared import JOIN_STYLE, CAP_STYLE

geoms = []
coords = Io.objects_to_geoms(C.selected_objects, resolution=12, geoms=geoms)

res = SnapOverlayOp.intersection(geoms[1], geoms[0])
Io.to_curve(C.scene, coords, res, name="res")

ls = geoms[0]
gf = GeometryFactory()
lr = gf.createLinearRing(ls.coords)
p = gf.createPolygon(lr)
b = p.buffer(0)

Io.to_curve(C.scene, coords, b, name="buffer")


walls = C.selected_objects
coords = CoordSys(walls)

gf = GeometryFactory()
gf.outputFactory = Io(scene=C.scene, coordsys=coords)

coordsys, poly1, dangles, cuts, invalids = Polygonizer.polygonize(C, walls[0], extend=0.0, resolution=12)
coordsys, poly2, dangles, cuts, invalids = Polygonizer.polygonize(C, walls[1], extend=0.0, resolution=12)

polys = poly1 + poly2

polys[0].intersects(polys[1])
polys[0].disjoint(polys[1])
polys[0].touches(polys[1])
polys[0].overlaps(polys[1])
polys[0].contains(polys[1])
polys[0].within(polys[1])
polys[0].crosses(polys[1])

prep = PreparedGeometryFactory.prepare(poly1[0])
prep.touches(poly2[0])

res = UnaryUnionOp.union(polys)
gf.output(res, name="cascaded_union", multiple=True)

opt = res.simplify_by_distance(0.001)
gf.output(opt, name="simple", multiple=True)

buf = poly1[0].buffer(0.1, cap_style=1, join_style=2)
gf.output(buf, name="buffer", multiple=True)

hull = poly1[0].convex_hull
gf.output(hull, name="hull", multiple=True)

res = OverlayOp.overlayOp(poly1[0], poly2[0], OverlayOp.opDIFFERENCE)
gf.output(res, name="difference", multiple=True)

res = OverlayOp.overlayOp(poly1[0], poly2[0], OverlayOp.opUNION)
gf.output(res, name="union", multiple=True)

res = OverlayOp.overlayOp(poly1[0], poly2[0], OverlayOp.opINTERSECTION)
gf.output(res, name="intersection", multiple=True)

res = OverlayOp.overlayOp(poly1[0], poly2[0], OverlayOp.opSYMDIFFERENCE)
gf.output(res, name="sym_diff", multiple=True)





import time
import logging
logger = logging.getLogger(__package__)

walls = C.selected_objects
from archipack.archipack_polylines import Polygons
from archipack.pygeos.op_polygonize import PolygonizeOp
from archipack.pygeos.geom import GeometryFactory
from archipack.pygeos.op_linemerge import LineMerger
from archipack.pygeos.op_overlay import OverlayOp
from archipack.archipack_polylib import Io, OutputFactory

t = time.time()
curves = C.selected_objects
extend = 0.02

Polygons.polygonize(C, curves, extend=extend, resolution=12)


p = Polygons(coords)
p.from_curves(walls, 12)
p._split_segs(extend=extend)

t2 = time.time()
lines = [gf.createLineString([seg.c0, seg.c1]) for seg in p.Q_segs._geoms if seg.available and seg.c0 is not seg.c1]
logger.debug("Polygonize input lines :%.4f seconds" , (time.time() - t2))

t2 = time.time()
merged = LineMerger.merge(lines)
logger.debug("LineMerger :%.4f seconds" , (time.time() - t2))

t2 = time.time()
polys, dangles, cuts, invalids = PolygonizeOp.polygonize_full(merged)
logger.debug("PolygonizeOp.polygonize_full(lines) :%.4f seconds" , (time.time() - t2))


logger.debug("Polygonize :%.4f seconds" , (time.time() - t))
gf.output(polys, name="polys", multiple=True)



bpy.app.debug = True
C.object.data.show_extra_indices = True


p.Q_segs._geoms[1413]._intersect_seg(p.Q_segs._geoms[4455])




seg_index = 103
sel = p.Q_segs.intersects_ext(p.Q_segs._geoms[seg_index], extend)
sel = (0, sorted([i for i in sel[1] if p.Q_segs._geoms[i].available]))

def select_edges(context, segs):
    import bmesh
    obj = context.edit_object
    me = obj.data
    bm = bmesh.from_edit_mesh(me)
    for e in bm.edges:
        e.select_set(state=False)
    for e in segs:
        bm.edges[e].select_set(state=True)
    bmesh.update_edit_mesh(me, False)


select_edges(C, [11])




p.polygonize()

for i, shape in enumerate(p.shapes):
    gen = True
    for j, pt in enumerate(p.inside_wall):
        if shape.inside(pt):
            gen = False
            break
    if gen:
        curves = []
        shape.as_curves(C, curves, p.coordsys.world, True, True)
        boundary = curves.pop(0)
        boundary.select_set(state=True)
        C.context.view_layer.objects.active = boundary
        bpy.ops.archipack.floor_from_curve(auto_manipulate=False)
        floor_name = C.active_object.name
        for hole in curves:
            hole.name = "Hole_{}_{}_{}_".format(i, shape.cw, shape.depth)
            bpy.ops.archipack.floor_cutter(parent=floor_name, curve=hole.name, auto_manipulate=False)
        bpy.ops.object.select_all(action='DESELECT')
        boundary.select_set(state=True)
        C.context.view_layer.objects.active = boundary
        for hole in curves:
            hole.select_set(state=True)
        bpy.ops.object.delete(use_global=False)


walls = C.selected_objects
from archipack.archipack_polylines import Polygons, CoordSys, Shape

extend = 0.01
coords = CoordSys(walls)
p = Polygons(coords, extend=extend)
p.from_curves(walls, 12)
p.cascaded_union(extend=extend)


p.Q_segs.intersects_ext(p.Q_segs._geoms[1413], 0.2)

p._reversed_copy()
p._neighboors()

p.polygonize()
p._relationship()


p.as_curves(C, shapes=p.err)

for i, shape in enumerate(p.shapes):
    c = shape.as_curve(C, p.coordsys.world, True, True)
    c.name = "Curve_{}_{}_{}_".format(i, shape.cw, shape.depth)


p.as_curves(C)

"""
