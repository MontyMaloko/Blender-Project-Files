# -*- coding:utf-8 -*-

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------

# noinspection PyUnresolvedReferences
import bpy
from uuid import uuid4
from math import pi, cos, sin
from random import uniform
# noinspection PyUnresolvedReferences
from bpy.types import Operator, PropertyGroup, Mesh, Panel, Object

from bpy.props import (
    FloatProperty, IntProperty, CollectionProperty, IntVectorProperty,
    EnumProperty, BoolProperty, StringProperty, PointerProperty
)
from mathutils import Vector, Matrix
from .bmesh_utils import BmeshEdit as bmed
from .panel import Panel as DoorPanel
from .archipack_autoboolean import ArchipackBoolManager
from .archipack_handle import ArchipackHandle
from .archipack_manipulator import Manipulable
from .archipack_preset import ArchipackPreset, PresetMenuOperator
from .archipack_abstraction import context_override, ensure_select_and_restore, Callbacks
from .archipack_i18n import Archipacki18n
from .archipack_object import (
    ArchipackPanel,
    ArchipackObject,
    ArchipackCreateTool,
    ArchipackDrawTool,
    ArchipackObjectsManager,
    ArchipackArrayTool
)
from .archipack_compound import Compound, CompoundPart
from .archipack_gl import FeedbackPanel
from .archipack_segments2 import OpeningGenerator
from .archipack_keymaps import Keymaps
from .archipack_dimension import DimensionProvider
from .archipack_custom import Customizable, update_user_object
from .archipack_snappable import Snappable
from .archipack_material import build_mat_enum
from .archipack_iconmanager import icons
import logging
import time
logger = logging.getLogger(__package__)

SPACING = 0.001
BOTTOM_HOLE_MARGIN = 0.001
FRONT_HOLE_MARGIN = 0.1


def update(self, context):
    self.update(context)


def update_auto_hole(self, context):
    self.update(context)
    self.update_auto_hole(context)


def update_parent(self, context):
    self.parent_data.update(context)


def update_childs(self, context):
    self.update(context, childs_only=True)


def update_handle(self, context):
    self.update(context, childs_only=True)
    self.cleanup_user_defined_objects(context, bpy.data.objects)


def update_panels(self, context):
    self.update_panels()
    self.update(context)


def random_color():
    return Vector((uniform(0.0, 1.0), uniform(0.0, 1.0), uniform(0.0, 1.0), 1))


MAT_FRAME_INSIDE = 0
MAT_FRAME_OUTSIDE = 1
MAT_DOOR_INSIDE = 2
MAT_DOOR_OUTSIDE = 3
MAT_PANEL_INSIDE = 4
MAT_PANEL_OUTSIDE = 5
MAT_SILL = 6
MAT_HANDLE = 7
MAT_SOIL = 8

# keep a reference to material enums
material_enums = []
mat_enum, mat_index_getter, mat_index_setter = build_mat_enum(
    'idmat', material_enums)


class archipack_door_panel(ArchipackObject, CompoundPart, PropertyGroup):

    handle_side: EnumProperty(
        name="Handle",
        items=(
            ('BOTH', "Both", "Inside and outside"),
            ('INSIDE', "Inside", "Inside only"),
            ('OUTSIDE', "Outside", "Outside only"),
            ('NONE', "None", "Disable handles")
        ),
        default="BOTH",
        update=update_parent
    )

    @property
    def parent_data(self):
        return self.id_data.archipack_door[0]

    @staticmethod
    def symbol_2d(d, y):

        #  __ y0
        # |__ y1
        # x0

        dy = 0
        if d.open == 'OUTSIDE':
            dy = -y
        y0 = y
        y1 = 0
        x0 = 0
        return DoorPanel(
            False,  # profil closed
            [0, 0],  # x index
            [x0],
            [dy + i for i in [y0, y1]],
            [0, 0],  # material index
            closed_path=True,  #
            side_cap_front=1,  # cap index
            side_cap_back=0
        )

    @staticmethod
    def panels(d, y):

        # subdivide side to weld panels
        subdiv_x = d.panels_x - 1

        if d.panels_distrib == 'REGULAR':
            subdiv_y = d.panels_y - 1
        else:
            subdiv_y = 2

        #  __ y0
        # |__ y1
        # x0 x1

        y0 = -y
        y1 = 0
        dy = 0
        if d.open == 'OUTSIDE':
            dy = y

        x0 = 0
        x1 = max(0.001, d.panel_border - 0.5 * d.panel_spacing)
        mi, mo = d.id_mat(MAT_DOOR_INSIDE), d.id_mat(MAT_DOOR_OUTSIDE)
        mpi, mpo = d.id_mat(MAT_PANEL_INSIDE), d.id_mat(MAT_PANEL_OUTSIDE)
        side = DoorPanel(
            False,  # profil closed
            [1, 0, 0, 1],  # x index
            [x0, x1],
            [dy + i for i in [y0, y0, y1, y1]],
            [mo, mi, mi, mi],  # material index
            closed_path=True,  #
            subdiv_x=subdiv_x,
            subdiv_y=subdiv_y
        )

        # on x axis bevel is always positive
        abs_chanfer = max(0.001, abs(d.chanfer))
        # center -> -0.5 * y
        half_y = -0.5 * y
        face = None
        back = None
        if d.model == 1:
            #     /   y2-y3
            #  __/    y1-y0
            #   x2 x3
            x2 = 0.5 * d.panel_spacing
            x3 = x2 + abs_chanfer

            # face  y1 = 0
            y2 = max(half_y + 0.001, y1 - d.chanfer)
            # back   y0 = -d
            y3 = min(half_y - 0.001, y0 + d.chanfer)

            face = DoorPanel(
                False,  # profil closed
                [0, 1, 2],  # x index
                [0, x2, x3],
                [dy + i for i in [y1, y1, y2]],
                [mi, mpi, mpi],  # material index
                side_cap_front=2,  # cap index
                closed_path=True
            )

            back = DoorPanel(
                False,  # profil closed
                [0, 1, 2],  # x index
                [x3, x2, 0],
                [dy + i for i in [y3, y0, y0]],
                [mpo, mo, mo],  # material index
                side_cap_back=0,  # cap index
                closed_path=True
            )

        elif d.model == 2:
            #               /   y2-y3  inner part
            #  ___    _____/    y1-y0
            #     \  /
            #      \/           y4-y5
            # 0 x2 x4 x5 x6 x3

            x2 = 0.5 * d.panel_spacing
            x4 = x2 + abs_chanfer
            x5 = x4 + abs_chanfer
            x6 = x5 + 4 * abs_chanfer
            x3 = x6 + abs_chanfer
            # face  y1 = 0
            y2 = max(half_y + 0.001, y1 - d.chanfer)
            y4 = max(half_y + 0.001, y1 + d.chanfer)
            # back   y0 = -d
            y3 = min(half_y - 0.001, y0 + d.chanfer)
            y5 = min(half_y - 0.001, y0 - d.chanfer)

            face = DoorPanel(
                False,  # profil closed
                [0, 1, 2, 3, 4, 5],  # x index
                [0, x2, x4, x5, x6, x3],
                [dy + i for i in [y1, y1, y4, y1, y1, y2]],
                [mi, mi, mi, mpi, mpi, mpi],  # material index
                side_cap_front=5,  # cap index
                closed_path=True
            )

            back = DoorPanel(
                False,  # profil closed
                [0, 1, 2, 3, 4, 5],  # x index
                [x3, x6, x5, x4, x2, 0],
                [dy + i for i in [y3, y0, y0, y5, y0, y0]],
                [mpo, mpo, mo, mo, mo, mo],  # material index
                side_cap_back=0,  # cap index
                closed_path=True
            )

        elif d.model == 3:
            #      _____      y2-y3
            #     /     \     y4-y5
            #  __/            y1-y0
            # 0 x2 x3 x4 x5
            x2 = 0.5 * d.panel_spacing
            x3 = x2 + abs_chanfer
            x4 = x3 + 4 * abs_chanfer
            x5 = x4 + 2 * abs_chanfer
            # face  y1 = 0
            y2 = max(half_y + 0.001, y1 - d.chanfer)
            y4 = max(half_y + 0.001, y2 + d.chanfer)
            # back   y0 = -d
            y3 = min(half_y - 0.001, y0 + d.chanfer)
            y5 = min(half_y - 0.001, y3 - d.chanfer)

            face = DoorPanel(
                False,  # profil closed
                [0, 1, 2, 3, 4],  # x index
                [0, x2, x3, x4, x5],
                [dy + i for i in [y1, y1, y2, y2, y4]],
                [mi, mi, mpi, mpi, mpi],  # material index
                side_cap_front=4,  # cap index
                closed_path=True
            )

            back = DoorPanel(
                False,  # profil closed
                [0, 1, 2, 3, 4],  # x index
                [x5, x4, x3, x2, 0],
                [dy + i for i in [y5, y3, y3, y0, y0]],
                [mpo, mpo, mo, mo, mo],  # material index
                side_cap_back=0,  # cap index
                closed_path=True
            )

        else:
            side.side_cap_front = 3
            side.side_cap_back = 0

        return side, face, back

    @staticmethod
    def verts(d, side, face, back, x, z, direction):
        if d.panels_distrib == 'REGULAR':
            subdiv_y = d.panels_y - 1
        else:
            subdiv_y = 2

        radius = Vector((0.8, 0.5, 0))
        center = Vector((0, z - radius.x, 0))

        if direction == 0:
            pivot = 1
        else:
            pivot = -1

        path_type = 'RECTANGLE'
        curve_steps = 16

        x1 = max(0.001, d.panel_border - 0.5 * d.panel_spacing)
        bottom_z = d.panel_bottom
        shape_z = [0, bottom_z, bottom_z, 0]
        origin = Vector((-pivot * 0.5 * x, 0, 0))
        offset = Vector((0, 0, 0))
        size = Vector((x, z, 0))
        verts = side.vertices(curve_steps, offset, center, origin,
                              size, radius, 0, pivot, shape_z=shape_z, path_type=path_type)
        if face is not None:
            p_radius = radius.copy()
            p_radius.x -= x1
            p_radius.y -= x1
            if d.panels_distrib == 'REGULAR':
                p_size = Vector(((x - 2 * x1) / d.panels_x,
                                 (z - 2 * x1 - bottom_z) / d.panels_y, 0))
                for i in range(d.panels_x):
                    for j in range(d.panels_y):
                        if j < subdiv_y:
                            shape = 'RECTANGLE'
                        else:
                            shape = path_type
                        offset = Vector(((pivot * 0.5 * x) + p_size.x * (i + 0.5) - 0.5 * size.x + x1,
                                         bottom_z + p_size.y * j + x1, 0))
                        origin = Vector((p_size.x * (i + 0.5) - 0.5 * size.x + x1, bottom_z + p_size.y * j + x1, 0))
                        verts += face.vertices(curve_steps, offset, center, origin,
                                               p_size, p_radius, 0, 0, shape_z=None, path_type=shape)
                        if back is not None:
                            verts += back.vertices(curve_steps, offset, center, origin,
                                                   p_size, p_radius, 0, 0, shape_z=None, path_type=shape)
            else:
                ####################################
                # Ratio vertical panels 1/3 - 2/3
                ####################################
                p_size = Vector(((x - 2 * x1) / d.panels_x, (z - 2 * x1 - bottom_z) / 3, 0))
                p_size_2x = Vector((p_size.x, p_size.y * 2, 0))
                for i in range(d.panels_x):
                    j = 0
                    offset = Vector(((pivot * 0.5 * x) + p_size.x * (i + 0.5) - 0.5 * size.x + x1,
                                     bottom_z + p_size.y * j + x1, 0))
                    origin = Vector((p_size.x * (i + 0.5) - 0.5 * size.x + x1, bottom_z + p_size.y * j + x1, 0))
                    shape = 'RECTANGLE'
                    face.subdiv_y = 0
                    verts += face.vertices(curve_steps, offset, center, origin,
                                           p_size, p_radius, 0, 0, shape_z=None, path_type=shape)
                    if back is not None:
                        back.subdiv_y = 0
                        verts += back.vertices(curve_steps, offset, center, origin,
                                               p_size, p_radius, 0, 0, shape_z=None, path_type=shape)
                    j = 1
                    offset = Vector(((pivot * 0.5 * x) + p_size.x * (i + 0.5) - 0.5 * size.x + x1,
                                     bottom_z + p_size.y * j + x1, 0))
                    origin = Vector((p_size.x * (i + 0.5) - 0.5 * size.x + x1,
                                     bottom_z + p_size.y * j + x1, 0))
                    face.subdiv_y = 1
                    verts += face.vertices(curve_steps, offset, center, origin,
                                           p_size_2x, p_radius, 0, 0, shape_z=None, path_type=path_type)
                    if back is not None:
                        back.subdiv_y = 1
                        verts += back.vertices(curve_steps, offset, center, origin,
                                               p_size_2x, p_radius, 0, 0, shape_z=None, path_type=path_type)

        return verts

    @staticmethod
    def faces(d, side, face, back):
        if d.panels_distrib == 'REGULAR':
            subdiv_y = d.panels_y - 1
        else:
            subdiv_y = 2

        path_type = 'RECTANGLE'
        curve_steps = 16

        faces = side.faces(curve_steps, path_type=path_type)
        faces_offset = side.n_verts(curve_steps, path_type=path_type)

        if face is not None:
            if d.panels_distrib == 'REGULAR':
                for i in range(d.panels_x):
                    for j in range(d.panels_y):
                        if j < subdiv_y:
                            shape = 'RECTANGLE'
                        else:
                            shape = path_type
                        faces += face.faces(curve_steps, path_type=shape, offset=faces_offset)
                        faces_offset += face.n_verts(curve_steps, path_type=shape)
                        if back is not None:
                            faces += back.faces(curve_steps, path_type=shape, offset=faces_offset)
                            faces_offset += back.n_verts(curve_steps, path_type=shape)
            else:
                ####################################
                # Ratio vertical panels 1/3 - 2/3
                ####################################
                for i in range(d.panels_x):
                    shape = 'RECTANGLE'
                    face.subdiv_y = 0
                    faces += face.faces(curve_steps, path_type=shape, offset=faces_offset)
                    faces_offset += face.n_verts(curve_steps, path_type=shape)
                    if back is not None:
                        back.subdiv_y = 0
                        faces += back.faces(curve_steps, path_type=shape, offset=faces_offset)
                        faces_offset += back.n_verts(curve_steps, path_type=shape)
                    face.subdiv_y = 1
                    faces += face.faces(curve_steps, path_type=path_type, offset=faces_offset)
                    faces_offset += face.n_verts(curve_steps, path_type=path_type)
                    if back is not None:
                        back.subdiv_y = 1
                        faces += back.faces(curve_steps, path_type=path_type, offset=faces_offset)
                        faces_offset += back.n_verts(curve_steps, path_type=path_type)

        return faces

    @staticmethod
    def uvs(d, side, face, back, x, z, direction):
        if d.panels_distrib == 'REGULAR':
            subdiv_y = d.panels_y - 1
        else:
            subdiv_y = 2

        radius = Vector((0.8, 0.5, 0))
        center = Vector((0, z - radius.x, 0))

        if direction == 0:
            pivot = 1
        else:
            pivot = -1

        path_type = 'RECTANGLE'
        curve_steps = 16

        x1 = max(0.001, d.panel_border - 0.5 * d.panel_spacing)
        bottom_z = d.panel_bottom
        origin = Vector((-pivot * 0.5 * x, 0, 0))
        size = Vector((x, z, 0))
        uvs = side.uv(curve_steps, center, origin, size, radius, 0, pivot, 0, d.panel_border, path_type=path_type)
        if face is not None:
            p_radius = radius.copy()
            p_radius.x -= x1
            p_radius.y -= x1
            if d.panels_distrib == 'REGULAR':
                p_size = Vector(((x - 2 * x1) / d.panels_x, (z - 2 * x1 - bottom_z) / d.panels_y, 0))
                for i in range(d.panels_x):
                    for j in range(d.panels_y):
                        if j < subdiv_y:
                            shape = 'RECTANGLE'
                        else:
                            shape = path_type
                        origin = Vector((p_size.x * (i + 0.5) - 0.5 * size.x + x1, bottom_z + p_size.y * j + x1, 0))
                        uvs += face.uv(curve_steps, center, origin, p_size, p_radius, 0, 0, 0, 0, path_type=shape)
                        if back is not None:
                            uvs += back.uv(curve_steps, center, origin,
                                           p_size, p_radius, 0, 0, 0, 0, path_type=shape)
            else:
                ####################################
                # Ratio vertical panels 1/3 - 2/3
                ####################################
                p_size = Vector(((x - 2 * x1) / d.panels_x, (z - 2 * x1 - bottom_z) / 3, 0))
                p_size_2x = Vector((p_size.x, p_size.y * 2, 0))
                for i in range(d.panels_x):
                    j = 0
                    origin = Vector((p_size.x * (i + 0.5) - 0.5 * size.x + x1, bottom_z + p_size.y * j + x1, 0))
                    shape = 'RECTANGLE'
                    face.subdiv_y = 0
                    uvs += face.uv(curve_steps, center, origin, p_size, p_radius, 0, 0, 0, 0, path_type=shape)
                    if back is not None:
                        back.subdiv_y = 0
                        uvs += back.uv(curve_steps, center, origin, p_size, p_radius, 0, 0, 0, 0, path_type=shape)
                    j = 1
                    origin = Vector((p_size.x * (i + 0.5) - 0.5 * size.x + x1, bottom_z + p_size.y * j + x1, 0))
                    face.subdiv_y = 1
                    uvs += face.uv(curve_steps, center, origin, p_size_2x, p_radius, 0, 0, 0, 0, path_type=path_type)
                    if back is not None:
                        back.subdiv_y = 1
                        uvs += back.uv(curve_steps, center, origin,
                                       p_size_2x, p_radius, 0, 0, 0, 0, path_type=path_type)
        return uvs

    @staticmethod
    def matids(d, side, face, back):
        if d.panels_distrib == 'REGULAR':
            subdiv_y = d.panels_y - 1
        else:
            subdiv_y = 2

        path_type = 'RECTANGLE'
        curve_steps = 16
        mi, mo = d.id_mat(MAT_DOOR_INSIDE), d.id_mat(MAT_DOOR_OUTSIDE)
        mat = side.mat(curve_steps, mi, mo, path_type=path_type)

        if face is not None:
            mi, mo = d.id_mat(MAT_PANEL_INSIDE), d.id_mat(MAT_PANEL_OUTSIDE)
            if d.panels_distrib == 'REGULAR':
                for i in range(d.panels_x):
                    for j in range(d.panels_y):
                        if j < subdiv_y:
                            shape = 'RECTANGLE'
                        else:
                            shape = path_type
                        mat.extend(
                            face.mat(curve_steps, mi, mi, path_type=shape)
                        )
                        if back is not None:
                            mat.extend(
                                back.mat(curve_steps, mo, mo, path_type=shape)
                            )
            else:
                ####################################
                # Ratio vertical panels 1/3 - 2/3
                ####################################
                for i in range(d.panels_x):
                    shape = 'RECTANGLE'
                    face.subdiv_y = 0
                    mat.extend(
                        face.mat(curve_steps, mi, mi, path_type=shape)
                    )
                    if back is not None:
                        back.subdiv_y = 0
                        mat.extend(
                            back.mat(curve_steps, mo, mo, path_type=shape)
                        )
                    shape = path_type
                    face.subdiv_y = 1
                    mat.extend(
                        face.mat(curve_steps, mi, mi, path_type=shape)
                    )
                    if back is not None:
                        back.subdiv_y = 1
                        mat.extend(
                            back.mat(curve_steps, mo, mo, path_type=shape)
                        )
        return mat

    @staticmethod
    def vcolors(d, side, face, back):
        if d.panels_distrib == 'REGULAR':
            subdiv_y = d.panels_y - 1
        else:
            subdiv_y = 2

        path_type = 'RECTANGLE'
        curve_steps = 16

        col = random_color()
        vcolors = side.vcolors(curve_steps, col, path_type=path_type)

        if face is not None:
            if d.panels_distrib == 'REGULAR':
                for i in range(d.panels_x):
                    for j in range(d.panels_y):
                        col = random_color()
                        if j < subdiv_y:
                            shape = 'RECTANGLE'
                        else:
                            shape = path_type
                        vcolors.extend(
                            face.vcolors(curve_steps, col, path_type=shape)
                        )
                        if back is not None:
                            vcolors.extend(
                                back.vcolors(curve_steps, col, path_type=shape)
                            )
            else:
                ####################################
                # Ratio vertical panels 1/3 - 2/3
                ####################################
                for i in range(d.panels_x):
                    col = random_color()
                    shape = 'RECTANGLE'
                    face.subdiv_y = 0
                    vcolors.extend(
                        face.vcolors(curve_steps, col, path_type=shape)
                    )
                    if back is not None:
                        back.subdiv_y = 0
                        vcolors.extend(
                            back.vcolors(curve_steps, col, path_type=shape)
                        )
                    face.subdiv_y = 1
                    vcolors.extend(
                        face.vcolors(curve_steps, col, path_type=path_type)
                    )
                    if back is not None:
                        back.subdiv_y = 1
                        vcolors.extend(
                            back.vcolors(curve_steps, col, path_type=path_type)
                        )
        return vcolors

    def update(self, context, o, d, x, y, z, direction, merge_geometry=False):

        side, face, back = self.panels(d, y)
        verts = self.verts(d, side, face, back, x, z, direction)
        faces = self.faces(d, side, face, back)
        matids = self.matids(d, side, face, back)
        uvs = self.uvs(d, side, face, back, x, z, direction)
        vcolors = self.vcolors(d, side, face, back)
        bm = bmed.buildmesh(o, verts, faces, matids, uvs, vcolors=vcolors, weld=True, temporary=merge_geometry)
        if merge_geometry:
            return bm

        self.shade_smooth(context, o, 0.20944)
        return None


class ARCHIPACK_PT_door_panel(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_door_panel"
    bl_label = "Door leaf"

    @classmethod
    def poll(cls, context):
        return archipack_door_panel.poll(context.active_object)

    def draw(self, context):
        layout = self.layout
        self.draw_op(context, layout, layout, "archipack.select_parent", icon="RESTRICT_SELECT_OFF")


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------

class ARCHIPACK_OT_select(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.select"
    bl_label = "Select"
    bl_description = "Select object"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty(default="")

    def execute(self, context):
        if context.mode == "OBJECT":
            o = self.get_scene_object(context, self.name)
            if o:
                bpy.ops.object.select_all(action='DESELECT')

                # select and make active
                self.select_object(context, o, True)

            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_select_parent(ArchipackObjectsManager, Operator):
    bl_idname = "archipack.select_parent"
    bl_label = "Edit parameters"
    bl_description = "Edit parameters located on parent"
    bl_category = 'Archipack'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode == "OBJECT":
            o = context.active_object
            if o is not None and o.parent is not None:
                bpy.ops.object.select_all(action="DESELECT")
                # select and make active
                self.select_object(context, o.parent, True)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


def get_direction(self):
    return self.direction


def set_direction(self, value):
    self.direction = value
    return None


def get_model(self):
    return self.model


def set_model(self, value):
    self.model = value
    return None


class archipack_door(
    ArchipackObject, ArchipackHandle, Customizable, Compound,
    Snappable, Manipulable, DimensionProvider, PropertyGroup
):
    """
        The frame is the door main object
        parent parametric object
        create/remove/update her own childs
    """
    parts: CollectionProperty(type=archipack_door_panel)

    tabs: EnumProperty(
        options={'SKIP_SAVE'},
        description="Display settings",
        name='Ui tabs',
        items=(
            ('MAIN', 'Main', 'Display main settings', 'NONE', 0),
            ('SUB', 'Parts', 'Display components settings', 'NONE', 2),
            ('MATERIALS', '', 'Display materials settings', 'MATERIAL', 3)
        ),
        default='MAIN',
    )
    x: FloatProperty(
        name='Width',
        min=0.25,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Width', update=update,
    )
    y: FloatProperty(
        name='Depth',
        min=0.03,
        default=0.20, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description="Depth\nBasically the thickness of wall, keep as it", update=update,
    )
    z: FloatProperty(
        name='Height',
        min=0.1,
        default=2.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='height', update=update,
    )
    frame_x: FloatProperty(
        name='Face',
        min=0,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Face width', update=update,
    )
    frame_y: FloatProperty(
        name='Backbend',
        default=0.01, min=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Face thickness', update=update,
    )
    jamb_depth: FloatProperty(
        name="Jamb depth",
        default=0.1, min=0.0001, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Jamb depth', update=update,
    )
    direction: IntProperty(
        name="Direction",
        min=0,
        max=1,
        description="open direction",
    )
    direction_ui: EnumProperty(
        options={'SKIP_SAVE'},
        name="Direction",
        items=(
            ("RIGHT", "Right", "Right"),
            ("LEFT", "Left", "Left")
        ),
        update=update,
        get=get_direction,
        set=set_direction
    )
    door_y: FloatProperty(
        name='Depth',
        min=0.001,
        default=0.02, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Door thickness', update=update,
    )
    rabbet: FloatProperty(
        name='Rabbet',
        default=0.03, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Size of rabbet', update=update,
    )
    door_offset: FloatProperty(
        name='Offset',
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Offset from axis', update=update,
    )
    door_type: EnumProperty(
        name='Type',
        items=(
            ('HINGED', 'Hinged door', '', 0),
            ('USER', 'User defined', '', 1),
            ('USER_PANEL', 'Custom based Panel', '', 2),
        ),
        default='HINGED', update=update,
    )

    stop: FloatProperty(
        name="Stop",
        min=0.0001,
        default=0.02,
        update=update
    )

    # TODO: Missing : Double egress
    frame_shape: EnumProperty(
        name='Shape',
        items=(
            ('SINGLE_RABBET', 'Single rabbet', ' ', icons["frame_single_rabbet"].icon_id, 0),
            ('DOUBLE_RABBET', 'Double rabbet', ' ', icons["frame_double_rabbet"].icon_id, 1),
            ('CASED', 'Cased opening', ' ', icons["frame_cased"].icon_id, 2),
        ),
        description="Shape of the frame",
        default='SINGLE_RABBET', update=update,
    )

    frame_layout: EnumProperty(
        name='Layout',
        items=(
            ('ENCOMPASS', 'Encompass', 'Fit wall thickness, with faces', icons["frame_around"].icon_id, 0),
            ('ADAPT', 'Fit', 'Fit wall exactly', icons["frame_beside"].icon_id, 1),
            ('FIXED', 'Inside', 'Inside wall, use jamb depth', icons["frame_inside"].icon_id, 2),
            ('FACE', 'In front', 'In front of wall', icons["frame_in_front"].icon_id, 3),
        ),
        description="Shape of the frame",
        default='ENCOMPASS', update=update,
    )

    open: EnumProperty(
        name="Open",
        items=(
            ('INSIDE', "Inside", "Inside"),
            ('OUTSIDE', "Outside", "Outside"),
        ),
        default="INSIDE",
        update=update
    )

    model: IntProperty(
        name="Model",
        min=0,
        max=3,
        default=0,
        description="Model",
    )
    model_ui: EnumProperty(
        options={'SKIP_SAVE'},
        name="Direction",
        items=(
            ("FLAT", "Flat", "Flat"),
            ("PANEL", "Panel", "Panel"),
            ("FRAME", "Frame", "Frame"),
            ("BEVEL", "Bevel", "Bevel panel")
        ),
        get=get_model,
        set=set_model,
        default="FLAT",
        update=update
    )
    n_panels: IntProperty(
        name="Door leaf",
        min=1,
        max=64,
        default=1,
        description="number of door leaf", update=update_panels
    )
    chanfer: FloatProperty(
        name='Bevel',
        # min=0.001,
        default=0.005, precision=3, step=0.01,
        unit='LENGTH', subtype='DISTANCE',
        description='Chanfer', update=update_childs,
    )
    panel_spacing: FloatProperty(
        name='Spacing',
        min=0.001,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Distance between panels', update=update_childs,
    )
    panel_bottom: FloatProperty(
        name='Bottom',
        min=0.0,
        default=0.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Distance from bottom', update=update_childs,
    )
    panel_border: FloatProperty(
        name='Border',
        min=0.001,
        default=0.2, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Distance from border', update=update_childs,
    )
    panels_x: IntProperty(
        name="# h",
        min=1,
        max=50,
        default=1,
        description="Panels h", update=update_childs,
    )
    panels_y: IntProperty(
        name="# v",
        min=1,
        max=50,
        default=1,
        description="Panels v", update=update_childs,
    )
    panels_distrib: EnumProperty(
        name='Distribution',
        items=(
            ('REGULAR', 'Regular', '', 0),
            ('ONE_THIRD', '1/3 2/3', '', 1)
        ),
        default='REGULAR', update=update_childs,
    )
    # TODO: handle user defined geometry as handle
    # ('USER', "User defined", "User defined mesh"),
    handle_type: EnumProperty(
        name="Type",
        items=(
            ('DOOR_1', "Default", "Door handle"),
            ('DOOR_15', "Round", "Door handle round"),
            ('DOOR_USER', "User defined", "Door handle user defined")
        ),
        default="DOOR_1", update=update_childs
    )
    handle_altitude: FloatProperty(
        name="Altitude",
        min=0,
        default=1.0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='handle altitude', update=update_childs,
    )

    sill_enable: BoolProperty(
        name="Sill",
        default=False, update=update,
    )
    frame_enable: BoolProperty(
        name="Frame",
        default=True, update=update,
    )
    sill_x: FloatProperty(
        name='Width',
        min=0.0,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet width', update=update,
    )
    sill_y: FloatProperty(
        name='Depth',
        min=0.001,
        default=0.04, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet depth', update=update,
    )
    sill_z: FloatProperty(
        name='Height',
        min=0.001,
        default=0.03, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='tablet height', update=update,
    )
    soil_enable: BoolProperty(
        name="Step",
        default=True, update=update,
    )
    soil_z: FloatProperty(
        name='Height',
        min=0.001,
        default=0.001, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Soil height', update=update,
    )
    soil_y: FloatProperty(
        name='Width',
        min=0.001,
        default=0.02, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Soil width', update=update,
    )
    hole_margin: FloatProperty(
        name='Hole margin',
        min=0.001,
        default=0.1, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='how much hole surround wall',
        update=update
    )
    automatic_hole: BoolProperty(
        name="Automatic hole",
        default=True,
        description="Provide automatic hole geometry",
        update=update_auto_hole
    )
    finishing_out: FloatProperty(
        name='Finishing thickness',
        min=0,
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Thickness of outside wall finishing'
    )
    finishing_int: FloatProperty(
        name='Finishing thickness',
        min=0,
        default=0, precision=5, step=1,
        unit='LENGTH', subtype='DISTANCE',
        description='Thickness of outside wall finishing'
    )
    flip: BoolProperty(
        default=False,
        # update=update,
        description='flip outside and outside material of hole'
    )
    z_offset: FloatProperty(
        name="Hole depth z",
        unit='LENGTH', subtype='DISTANCE',
        description='Depth of hole under the door',
        default=0.1, precision=5, step=1,
        update=update
    )

    auto_update: BoolProperty(
        options={'SKIP_SAVE'},
        default=True,
        update=update
    )

    mat_panel_inside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Panel in",
        description="Material index of door panel inside",
        items=mat_enum,
        get=mat_index_getter(MAT_PANEL_INSIDE),
        set=mat_index_setter(MAT_PANEL_INSIDE),
        update=update
    )

    mat_panel_outside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Panel out",
        description="Material index of door panel outside",
        items=mat_enum,
        get=mat_index_getter(MAT_PANEL_OUTSIDE),
        set=mat_index_setter(MAT_PANEL_OUTSIDE),
        update=update
    )

    mat_door_inside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Door in",
        description="Material index of door inside",
        items=mat_enum,
        get=mat_index_getter(MAT_DOOR_INSIDE),
        set=mat_index_setter(MAT_DOOR_INSIDE),
        update=update
    )

    mat_door_outside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Door out",
        description="Material index of door outside",
        items=mat_enum,
        get=mat_index_getter(MAT_DOOR_OUTSIDE),
        set=mat_index_setter(MAT_DOOR_OUTSIDE),
        update=update
    )

    mat_frame_inside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Frame in",
        description="Material index of frame inside",
        items=mat_enum,
        get=mat_index_getter(MAT_FRAME_INSIDE),
        set=mat_index_setter(MAT_FRAME_INSIDE),
        update=update
    )

    mat_frame_outside: EnumProperty(
        options={'SKIP_SAVE'},
        name="Frame out",
        description="Material index of frame outside",
        items=mat_enum,
        get=mat_index_getter(MAT_FRAME_OUTSIDE),
        set=mat_index_setter(MAT_FRAME_OUTSIDE),
        update=update
    )

    mat_handle: EnumProperty(
        options={'SKIP_SAVE'},
        name="Handle",
        description="Material index of handle",
        items=mat_enum,
        get=mat_index_getter(MAT_HANDLE),
        set=mat_index_setter(MAT_HANDLE),
        update=update
    )

    mat_sill: EnumProperty(
        options={'SKIP_SAVE'},
        name="Sill",
        description="Material index of sill",
        items=mat_enum,
        get=mat_index_getter(MAT_SILL),
        set=mat_index_setter(MAT_SILL),
        update=update
    )

    mat_soil: EnumProperty(
        options={'SKIP_SAVE'},
        name="Step",
        description="Material index of step",
        items=mat_enum,
        get=mat_index_getter(MAT_SOIL),
        set=mat_index_setter(MAT_SOIL),
        update=update
    )
    mat_hole_outside: IntProperty(
        name="Outside",
        description="Material index of wall for outside part of the hole",
        min=0,
        max=128,
        default=1, update=update,
    )
    mat_hole_inside: IntProperty(
        name="Inside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0, update=update,
    )
    mat_finish_inside: IntProperty(
        name="Finish Inside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )
    mat_finish_outside: IntProperty(
        name="Finish Outside",
        description="Material index of wall for inside part of the hole",
        min=0,
        max=128,
        default=0
    )

    idmat: IntVectorProperty(
        default=[
            1, 0,
            1, 0,
            1, 0,
            4, 5,
            3
        ],
        size=9
    )
    auto_mat: BoolProperty(
        name="Auto materials",
        default=True
    )

    user_defined_hole: PointerProperty(
        name="Hole",
        type=Object,
        update=update_user_object
    )

    # Required to synch custom's altitude, and snappable
    altitude = 0

    def get_member_datablock(self, o):
        return archipack_door_panel.datablock(o)

    @property
    def frame(self):
        finishing_out = self.finishing_out
        finishing_int = self.finishing_int

        if self.flip:
            finishing_out, finishing_int = finishing_int, finishing_out

        x0 = 0
        # Stop depends on frame shape
        x1 = -self._stop
        # frame_x is Face
        x2 = x1 - self.frame_x

        # in "adaptive" modes thickness depends on wall, half absolute outside of frame
        y0 = self._jamb_depth
        y2 = -y0
        y3 = 0

        if self.frame_layout in {'ENCOMPASS', 'ADAPT'}:
            y0 += finishing_int
            y2 -= finishing_out

        # rabbet is rabbet, keep positive distance between both sides
        y1 = max(0.001, y0 - self.rabbet)
        y6 = min(-0.001, y2 + self.rabbet)

        mo, mi = self.id_mat(MAT_FRAME_INSIDE), self.id_mat(MAT_FRAME_OUTSIDE)

        if self.frame_layout == 'ENCOMPASS':
            #    _____      y0
            #   |___  |_    y1
            #       |   |   y5
            #   x   x   |   y3
            #    ___|   |   y4   T y6
            #   |_______|   y2
            #
            #   x2 x3 x1  x0
            y4 = y2 + self.frame_y
            y5 = y0 - self.frame_y
            x3 = x1 - self.frame_y
            if self.frame_shape == "DOUBLE_RABBET":

                return DoorPanel(
                    True,  # closed
                    [0, 0, 3, 3, 0, 0, 1, 1, 2, 2, 1, 1],  # x index
                    [x2, x1, x0, x3],
                    [y2, y4, y4, y5, y5, y0, y0, y1, y1, y6, y6, y2],
                    [mi, mi, mo, mo, mo, mo, mo, mo, mi, mi, mi, mi],  # material index
                    closed_path=False
                )
            elif self.frame_shape == "SINGLE_RABBET":
                # L shaped
                if self.open == 'OUTSIDE':
                    return DoorPanel(
                        True,  # closed
                        [ 0,  0,  3,  3,  0,  0,  2,  2,  1,  1],  # x index
                        [x2, x1, x0, x3],
                        [y2, y4, y4, y5, y5, y0, y0, y6, y6, y2],
                        [mi, mi, mo, mo, mo, mo, mo, mo, mi, mi],  # material index
                        closed_path=False
                    )
                else:
                    return DoorPanel(
                        True,  # closed
                        [0, 0, 3, 3, 0, 0, 1, 1, 2, 2],  # x index
                        [x2, x1, x0, x3],
                        [y2, y4, y4, y5, y5, y0, y0, y1, y1, y2],
                        [mi, mi, mo, mo, mo, mo, mo, mo, mi, mi],  # material index
                        closed_path=False
                    )
            else:
                # without stops
                return DoorPanel(
                    True,  # closed
                    [0, 0, 2, 2, 0, 0, 1, 1],  # x index
                    [x2, x0, x3],
                    [y2, y4, y4, y5, y5, y0, y0, y2],
                    [mi, mi, mo, mo, mo, mo, mo, mi],  # material index
                    closed_path=False
                )
        elif self.frame_layout == 'FACE':
            #   Frames inside wall
            #
            #    _____        y0
            #   |     |___    y1
            #   |_________|   y2
            #
            #   x2    x1  x0
            y2 = y0 - self.frame_y

            if self.frame_shape == "SINGLE_RABBET":
                if self.open == 'OUTSIDE':
                    y1 = y2 + max(0.001, self.rabbet)
                    return DoorPanel(
                        True,  # closed
                        [0, 0, 2, 2, 1, 1],  # x index
                        [x2, x1, x0],
                        [y2, y0, y0, y1, y1, y2],
                        [mi, mi, mi, mi, mi, mi],  # material index
                        closed_path=False
                    )
                else:
                    y1 = max(y2 + 0.001, y0 - self.rabbet)
                    return DoorPanel(
                        True,  # closed
                        [0, 0, 1, 1, 2, 2],  # x index
                        [x2, x1, x0],
                        [y2, y0, y0, y1, y1, y2],
                        [mi, mi, mi, mi, mi, mi],  # material index
                        closed_path=False
                    )
            else:
                # No double rabbet, default to flat
                return DoorPanel(
                    True,  # closed
                    [0, 0, 1, 1],  # x index
                    [x2, x0],
                    [y2, y0, y0, y2],
                    [mi, mi, mi, mi],  # material index
                    closed_path=False
                )
        else:
            # 'ADAPT' and 'FIXED'
            #   Frames inside wall
            #    _____        y0
            #   |     |___    y1
            #   x         |   y3
            #   |         |   T  y6
            #   |_________|   y2
            #   x2    x1  x0
            if self.frame_shape == "DOUBLE_RABBET":

                return DoorPanel(
                    True,  # closed
                    [0, 0, 0, 1, 1, 2, 2, 1, 1],  # x index
                    [x2, x1, x0],
                    [y2, y3, y0, y0, y1, y1, y6, y6, y2],
                    [mi, mo, mo, mo, mo, mi, mi, mi, mi],  # material index
                    closed_path=False
                )
            elif self.frame_shape == "SINGLE_RABBET":
                if self.open == 'OUTSIDE':
                    return DoorPanel(
                        True,  # closed
                        [0, 0, 0, 2, 2, 1, 1],  # x index
                        [x2, x1, x0],
                        [y2, y3, y0, y0, y6, y6, y2],
                        [mi, mo, mo, mo, mo, mi, mi],  # material index
                        closed_path=False
                    )
                else:
                    return DoorPanel(
                        True,  # closed
                        [0, 0, 0, 1, 1, 2, 2],  # x index
                        [x2, x1, x0],
                        [y2, y3, y0, y0, y1, y1, y2],
                        [mi, mo, mo, mo, mo, mi, mi],  # material index
                        closed_path=False
                    )
            else:
                # simple without rabbet
                return DoorPanel(
                    True,  # closed
                    [0, 0, 0, 1, 1],  # x index
                    [x2, x0],
                    [y2, y3, y0, y0, y2],
                    [mi, mo, mo, mo, mi],  # material index
                    closed_path=False
                )

    @property
    def sill_in(self):
        # profil tablette
        #  __  y0
        # |  |
        # |  |
        # |__| y1
        # x0  x1
        y0 = -0.5 * self.y - self.sill_y
        y1 = self.hole_center_y
        x0 = -self.sill_z
        x1 = 0
        return DoorPanel(
            True,  # closed profil
            [0, 0, 1, 1],  # x index
            [x0, x1],
            [y1, y0, y0, y1],
            [self.id_mat(MAT_SILL)] * 4,  # material index
            closed_path=False  # closed path
        )

    @property
    def soil(self):
        #  __  y0
        # |  |
        # |  |
        # |__| y1
        # x0  x1
        y1 = self.hole_center_y
        y0 = y1 - self.soil_y
        y2 = y1 + self.soil_y
        x0 = 0
        x1 = self.soil_z
        return DoorPanel(
            False,  # closed profil
            [0, 1, 0],  # x index
            [x0, x1],
            [y0, y1, y2],
            [self.id_mat(MAT_SOIL)] * 2,  # material index
            closed_path=False  # closed path
        )

    @property
    def hole(self):
        #
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        x0 = - self._stop
        gap = 0.0001

        if self.frame_layout in {'ENCOMPASS'}:
            # frame_y is thickness  0.5 *  +
            x0 -= self.frame_y
        if self.frame_layout in {'ADAPT', 'FIXED'}:
            # frame_x is Face
            x0 -= self.frame_x

        y = 0.5 * self.y + gap + self.hole_margin
        y2 = 0

        outside_mat = self.mat_hole_outside
        inside_mat = self.mat_hole_inside
        in_finish_mat = self.mat_finish_inside
        out_finish_mat = self.mat_finish_outside
        finishing_int = self.finishing_int
        finishing_out = self.finishing_out

        if self.flip:
            outside_mat, inside_mat = inside_mat, outside_mat
            out_finish_mat, in_finish_mat = in_finish_mat, out_finish_mat
            finishing_int, finishing_out = finishing_out, finishing_int

        y0 = y + finishing_int
        y1 = -(y + finishing_out)

        return DoorPanel(
            False,  # closed
            [0, 0, 0, 0, 0],  # x index
            [x0],
            [y1, -y, y2, y, y0],
            [out_finish_mat, outside_mat, inside_mat, in_finish_mat, in_finish_mat],  # material index
            closed_path=True,
            side_cap_front=4,
            side_cap_back=0  # cap index
        )

    @property
    def hole_symbol(self):
        #   Provide hole for moldings
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        #   x0
        x0 = 0
        y2 = 0
        y0 = self.y / 2 + max(0.001, self.frame_y)
        y1 = -y0
        # size = Vector((self.x + 2 * self.frame_y, self.z + self.frame_y + 0.001, self.y))
        if self.frame_layout in {'ENCOMPASS'}:
            # frame_y is thickness
            x0 -= self.stop #self.frame_y - self.stop

        elif self.frame_layout in {'ADAPT', 'FIXED'}:
            # frame_x is Face
            x0 -= self.stop # self.frame_x
        else:
            # Face frame layout is a mix where on opening side there is a frame and nothing on other side
            x0 -= self.stop
            x1 = x0 + self.frame_x

            return DoorPanel(
                False,  # closed
                [0, 0, 1, 1],  # x index
                [x0, x1],
                [y1, y2, y2, y0],
                [0, 0, 0, 0],  # material index
                closed_path=True,
                side_cap_front=3,
                side_cap_back=0  # cap index
            )

        return DoorPanel(
            False,  # closed
            [0, 0, 0],  # x index
            [x0],
            [y1, y2, y0],
            [0, 0, 0],  # material index
            closed_path=True,
            side_cap_front=2,
            side_cap_back=0  # cap index
        )

    @property
    def _stop(self):
        if self.frame_shape == 'CASED':
            return 0
        return self.stop

    @property
    def hole_center_y(self):
        """
        Hole center on y axis - this is the location of ground
        :return:
        """
        # y is location of panel
        y = self._jamb_depth - self.rabbet + 0.5 * self.door_y

        if self.open == 'OUTSIDE':
            if self.frame_layout == 'FACE':
                y = 0.5 * self.y + self.rabbet - 0.5 * self.door_y
            else:
                y = -y

        # y = max(0.25 * self.door_y, self.y / 2 + self.frame_y)
        # return max(y - 0.5 * self.door_y - self.rabbet, -y)

        return y # max(y - self.door_y - self.rabbet, -y)

    @property
    def inside_hole(self):
        #
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        #   x0
        x0 = 0
        y2 = self.hole_center_y
        y0 = self.y / 2 + self.hole_margin
        outside_mat = 0
        inside_mat = 1
        if self.flip:
            outside_mat, inside_mat = inside_mat, outside_mat

        if self.frame_layout in {'ENCOMPASS'}:
            # frame_y is thickness
            x0 -= self.stop

        elif self.frame_layout in {'ADAPT', 'FIXED'}:
            # frame_x is Face
            x0 -= self.frame_x - 0.5 * self._stop
        else:  #, 'FIXED'
            # Face frame layout is a mix where on opening side there is a frame and nothing on other side
            x0 += 0.5 * self.stop

        return DoorPanel(
            False,  # closed
            [0, 0],  # x index
            [x0],
            [y2, y0],
            [inside_mat, inside_mat],  # material index
            closed_path=True,
            side_cap_front=0,
            side_cap_back=1  # cap index
        )

    @property
    def outside_hole(self):
        #
        #    _____   y0
        #   |
        #   x        y2
        #   |
        #   |_____   y1
        #
        #   x0
        x0 = 0
        y2 = self.hole_center_y
        y1 = -(self.y / 2 + self.hole_margin)
        outside_mat = 0
        inside_mat = 1
        if self.flip:
            outside_mat, inside_mat = inside_mat, outside_mat

        if self.frame_layout in {'ENCOMPASS'}:
            # frame_y is thickness
            x0 -= self.stop

        elif self.frame_layout in {'ADAPT', 'FIXED'}:
            # frame_x is Face
            x0 -= self.frame_x - 0.5 * self._stop

        else:  # , 'FIXED'
            # Face frame layout is a mix where on opening side there is a frame and nothing on other side
            x0 += 0.5 * self.stop

        return DoorPanel(
            False,  # closed
            [0, 0],  # x index
            [x0],
            [y1, y2],
            [outside_mat, outside_mat],  # material index
            closed_path=True,
            side_cap_front=0,
            side_cap_back=1  # cap index
        )

    @property
    def _jamb_depth(self):
        """
        half of depth of jamb, depends on adaptive mode
        either it is the wall + face thickness
        or jamb_depth
        """
        if self.frame_layout in {'ENCOMPASS', 'FACE'}:
            # frame y is thickness
            return 0.5 * self.y + self.frame_y
        elif self.frame_layout in {'ADAPT'}:
            return 0.5 * self.y
        return 0.5 * self.jamb_depth

    def get_generator(self, o=None, typ="DOOR"):
        return OpeningGenerator(self, o, typ)

    def get_snap_generator(self, tM):
        return self.get_generator(tM, typ="SNAP_DOOR")

    def setup_manipulators(self):
        n_manips = len(self.manipulators)
        if n_manips < 1:
            s = self.manipulators.add()
            s.prop1_name = "x"
            s.prop2_name = "x"
        else:
            s = self.manipulators[0]
        if self.has_user_defined_object:
            s.type_key = "DUMB_SIZE"
        else:
            s.type_key = "SNAP_SIZE_LOC"

        if n_manips < 2:
            s = self.manipulators.add()
            s.prop1_name = "y"
            s.prop2_name = "y"
        else:
            s = self.manipulators[1]
        if self.has_user_defined_object:
            s.type_key = "DUMB_SIZE"
        else:
            s.type_key = "SNAP_SIZE_LOC"

        if n_manips < 3:
            s = self.manipulators.add()
            s.prop1_name = "z"
            s.normal = Vector((0, 1, 0))
        else:
            s = self.manipulators[2]

        if self.has_user_defined_object:
            s.type_key = "DUMB_SIZE"
        else:
            s.type_key = "SIZE"

    def add_panel(self):
        p = self.parts.add()
        p.part_uid = str(uuid4())
        return p

    def _synch_childs(self, context, o, linked, childs):
        """
            sub synch childs nodes of linked object
        """
        # remove childs not found on source
        members = [c for c in linked.children if archipack_door_panel.filter(c)]

        for panel in members:
            if panel.data.users < 2:
                self.delete_object(context, panel)

        members = self._members(linked)

        # add missing childs and update other ones
        for uid, panel in childs.items():
            if uid not in members:
                p = bpy.data.objects.new("Door Panel", panel.data)
                # Link object into scene
                self.link_object_to_scene(context, p)
                self.link_collections(linked, p)
                p.color = (0, 1, 0, 1)

                p.show_transparent = True
                p.lock_location = (False, True, True)
                p.lock_rotation = (False, True, False)
                p.lock_scale = (True, True, True)
                p.parent = linked
                p.matrix_world = linked.matrix_world.copy()

            else:
                p = members[uid]

            p.location = panel.location.copy()

            # update handle
            handle, handle_outside = self.find_handle(panel)
            h, h_outside = self.find_handle(p)
            if handle is not None:
                if h is None:
                    h = self.duplicate_object(context, handle, linked=True)
                    self.link_collections(linked, h)
                    h.parent = p
                    h.matrix_world = p.matrix_world.copy()

                h.location = handle.location.copy()
            else:
                self.delete_object(context, h)
            if handle_outside is not None:
                if h_outside is None:
                    h_outside = self.duplicate_object(context, handle_outside, linked=True)
                    self.link_collections(linked, h_outside)
                    h_outside.parent = p
                    h_outside.matrix_world = p.matrix_world.copy()

                h_outside.location = handle_outside.location.copy()
            else:
                self.delete_object(context, h_outside)

    def _synch_hole(self, context, linked, hole):
        l_hole = self.find_hole(linked)
        if hole is None:
            if l_hole is not None:
                # user defined hole
                self.delete_object(context, l_hole)
        elif l_hole is None:
            l_hole = bpy.data.objects.new("hole", hole.data)
            l_hole['archipack_hole'] = True
            self.link_object_to_scene(context, l_hole)
            l_hole.parent = linked
            l_hole.matrix_world = linked.matrix_world.copy()
            l_hole.location = hole.location.copy()
            ArchipackBoolManager.prepare_hole(context, l_hole)
        else:
            l_hole.data = hole.data

    def synch_childs(self, context, o):
        """
            synch childs nodes of linked objects
        """
        childs = self._members(o)
        hole = self.find_hole(o)
        linked_objects = self.get_linked_objects(context, o)
        for linked in linked_objects:
            if linked != o:
                self._synch_childs(context, o, linked, childs)
                self._synch_hole(context, linked, hole)

    def update_panels(self):
        n_parts = len(self.parts)
        for i in range(n_parts, self.n_panels, -1):
            self.parts.remove(i - 1)
        for i in range(n_parts, self.n_panels):
            self.add_panel()

    def update_childs(self, context, o, base_bmesh=None):
        """
            pass params to childrens
        """
        def _filter(c):
            return not self.has_flag(c, 'hole')

        members = self.cleanup_members(context, o, _filter)

        bm = None

        # door offset is rabbet
        location_y = self._jamb_depth - self.rabbet + self.door_y + 0.001

        handle_x = 0.05 + self._stop
        handle_y = 0

        if self.open == 'OUTSIDE':
            if self.frame_layout == 'FACE':
                location_y = 0.5 * self.y + self.rabbet - self.door_y
            else:
                location_y = -location_y

            handle_y = self.door_y

        if self.frame_enable:
            grow = self._stop
        else:
            grow = 0

        x = (self.x + 2 * grow) / self.n_panels - (2 * SPACING)
        y = self.door_y
        z = self.z + grow - SPACING

        for i, panel in enumerate(self.parts):

            if self.n_panels < 2:
                direction = self.direction
            else:
                direction = i % 2

            if panel.part_uid not in members:
                p, m = self.create_mesh("Door Panel")
                d = m.archipack_door_panel.add()
                d.part_uid = panel.part_uid
                # Link object into scene
                self.link_object_to_scene(context, p)
                self.link_collections(o, p)
                p.color = (0, 1, 0, 1)

                p.show_transparent = True
                p.lock_location = (False, True, True)
                p.lock_rotation = (False, True, False)
                p.lock_scale = (True, True, True)
                # parenting at 0, 0, 0 before set object matrix_world
                # so location remains local from frame
                p.parent = o
                p.matrix_world = o.matrix_world.copy()
            else:
                p = members[panel.part_uid]
                # select and make active
                d = archipack_door_panel.datablock(p)

            if d is not None:
                self.link_materials(context, o, p)
                bm = d.update(context, p, self, x, y, z, direction)

            handle_sides = {
                'NONE': 0,
                'INSIDE': 1,
                'OUTSIDE': 2,
                'BOTH': 3
            }[panel.handle_side]

            handle_location = ((1 - direction * 2) * (x - handle_x), handle_y, self.handle_altitude)

            self.update_handle(
                context, p, self.handle_type,
                handle_location, self.id_mat(MAT_HANDLE), handle_sides, direction, y
            )

            location_x = -(0.5 * self.x + grow) + (2 * i + 1) * SPACING + (i + direction) * x
            p.location = Vector((location_x, location_y, 0))

    def upgrade(self):
        old = tuple(self.version)
        if old < (2, 4, 0):
            self.version[:] = (2, 4, 0)
            self.migrate_to_24()

    def migrate_to_24(self):
        """
        Migrate data-model from < 2.4 version
        """
        if not self.parts:
            self.auto_update = False
            for i in range(self.n_panels):
                p = self.parts.add()
                p.part_uid = str(uuid4())
            # Rough shape
            self.handle_altitude = 0.5 * self.z
            self.rabbet = self.door_offset
            self.door_offset = 0
            self.frame_shape = "SINGLE_RABBET"
            if self.frame_y > 0:
                self.frame_layout = "ENCOMPASS"
            else:
                self.frame_layout = "FIXED"
                self.jamb_depth = self.y / 2 + self.frame_y
                self.frame_y = 0.02
            self.auto_update = True

    def update(self, context, childs_only=False):

        # support for "copy to selected"
        o = self.find_in_selection(context, self.auto_update)

        if o is None:
            return

        # update data model to 2.4
        self.upgrade()

        self.setup_manipulators()

        bm = None

        # is user defined geometry based door
        # only full door is supported
        is_user_object_door = (
            self.door_type == 'USER' and self.has_user_defined_object
        )

        is_custom = self.has_user_defined_custom and "USER" in self.door_type

        is_custom_door = (
            self.door_type == "USER" and
            is_custom
        )
        is_custom_panel = (
            self.door_type == "USER_PANEL" and
            is_custom
        )

        is_regular_door = (
            'USER' not in self.door_type or not (is_user_object_door or is_custom)
        )

        if is_user_object_door or is_custom_door:
            # both regular and custom panels are members based
            members = self._members(o)
            for c in members.values():
                self.delete_object(context, c)

        if is_regular_door or is_custom_panel:
            # use_object and custom door use "custom_door" tag
            for c in o.children:
                if self.has_flag(c, "custom_door"):
                    self.delete_object(context, c)

        if is_custom:

            # either whole door or panel(s) only
            if is_custom_panel:
                # use source y as frame_y, x and z, use overflow
                if self.frame_enable:
                    grow = self._stop
                else:
                    grow = 0

                x = (self.x + 2 * grow) / self.n_panels - (2 * SPACING)
                override = {'x': x, 'y': self.door_y, 'z': self.z + grow}
                members = self.cleanup_members(context, o)
                for i, panel in enumerate(self.parts):

                    translate = Vector((0.5 * x, -0.5 * self.door_y, 0))
                    if panel.part_uid not in members:
                        dst, me = self.create_mesh("Panel")
                        p = me.archipack_door_panel.add()
                        p.uid = panel.uid
                        dst.parent = o
                        self.link_object_to_scene(context, dst, layer_name="Openings")
                        self.link_collections(o, dst)
                        dst.matrix_world = o.matrix_world.copy()
                        members[panel.part_uid] = dst
                    else:
                        dst = members[panel.part_uid]

                    self.custom_datablock_update(context, self.user_defined_object, dst, translate, override)

                    if self.n_panels < 2:
                        direction = self.direction
                    else:
                        direction = i % 2

                    location_y = self._jamb_depth - self.rabbet + self.door_y
                    if self.open == 'OUTSIDE':
                        location_y = - location_y + self.door_y

                    location_x = -(0.5 * self.x + grow) + (2 * i + 1) * SPACING + (i + direction) * x
                    dst.location = Vector((
                        location_x,
                        location_y,
                        0
                    ))
                    self.set_flag(dst.data, "nested_custom", True)
                    self.set_flag(dst, "custom_door", False)
                    # as we reset mesh every time, must also reset mirror state
                    self.set_flag(dst.data, "mirror", False)
                    self._mirror_custom_object(dst, direction != 0)

            elif is_custom_door:

                translate = Vector((0, self.rabbet, 0))
                override = None
                self.custom_datablock_update(
                    context, self.user_defined_object, o, translate, override
                )

                self.copy_modifier_stack(self.user_defined_object, o)

                self.set_flag(o.data, "nested_custom", False)
                for c in o.children:
                    if not self.has_flag(c, ('hole', 'custom_hole')):
                        self.set_flag(c, "custom_door", True)

        elif is_user_object_door:
            self.custom_geometry_update(
                context, self.user_defined_object, o, translation=Vector((0, self.rabbet, 0))
            )
            self.copy_modifier_stack(self.user_defined_object, o)

            for c in o.children:
                if not self.has_flag(c, ('hole', 'custom_hole')):
                    self.set_flag(c, "custom_door", True)

        # Generate frame for custom panel and any invalid user object
        if is_custom_panel or is_regular_door:

            if childs_only is False :

                v = Vector((0, 0, 0))
                size = Vector((self.x, self.z, self.y))
                if self.frame_enable:
                    frame = self.frame
                    verts = frame.vertices(16, v, v, v, size, v, 0, 0, shape_z=None, path_type='RECTANGLE')
                    faces = frame.faces(16, path_type='RECTANGLE')
                    matids = frame.mat(16, 0, 0, path_type='RECTANGLE')
                    uvs = frame.uv(16, v, v, size, v, 0, 0, 0, 0, path_type='RECTANGLE')
                    col = random_color()
                    vcolors = frame.vcolors(16, col, path_type='RECTANGLE')
                else:
                    verts, faces, matids, uvs, vcolors = [], [], [], [], []

                if self.sill_enable:
                    sill_in = self.sill_in

                    size = Vector((self.x + 2 * (self.frame_x + self.sill_x), self.y, self.z))
                    faces.extend(
                        sill_in.faces(16, path_type='HORIZONTAL', offset=len(verts))
                    )
                    verts.extend(
                        sill_in.vertices(16, v, v, v, size, v, 0, 0, shape_z=None, path_type='HORIZONTAL')
                    )
                    matids.extend(
                        sill_in.mat(16, 0, 0, path_type='HORIZONTAL')
                    )
                    uvs.extend(
                        sill_in.uv(16, v, v, size, v, 0, 0, 0, 0, path_type='HORIZONTAL')
                    )
                    col = random_color()
                    vcolors.extend(
                        sill_in.vcolors(16, col, path_type='HORIZONTAL')
                    )
                if self.soil_enable:
                    soil = self.soil

                    size = Vector((self.x + 2 * self._stop, self.y, self.z))
                    faces.extend(
                        soil.faces(16, path_type='HORIZONTAL', offset=len(verts))
                    )
                    verts.extend(
                        soil.vertices(16, v, v, v, size, v, 0, 0, shape_z=None, path_type='HORIZONTAL')
                    )
                    matids.extend(
                        soil.mat(16, 0, 0, path_type='HORIZONTAL')
                    )
                    uvs.extend(
                        soil.uv(16, v, v, size, v, 0, 0, 0, 0, path_type='HORIZONTAL')
                    )
                    col = random_color()
                    vcolors.extend(
                        soil.vcolors(16, col, path_type='HORIZONTAL')
                    )

                if len(verts) == 0:
                    verts.append(Vector())

                bmed.buildmesh(o, verts, faces, matids, uvs, vcolors=vcolors)

                if len(verts) > 1:
                    self.shade_smooth(context, o, 0.20944)

        # door of any non user type and invalid user object
        if is_regular_door:
            self.update_childs(context, o, base_bmesh=bm)

        if childs_only is False:
            self.interactive_hole(context, o)

        if self.has_flag(o, "standalone"):
            # snap does update "extremes", so opening generator are able to properly close spaces
            self.snap(o, 0.3 * self.x)

        # setup 3d points for gl manipulators
        _dir = 1
        if self.has_flag(o, "flip"):
            _dir = -1

        # x, y = dir * 0.5 * self.x, dir * 0.5 * self.y
        x, y = 0.5 * self.x, _dir * 0.5 * self.y

        self.manipulators[0].set_pts([(-x, -y, 0), (x, -y, 0), (0.5, 0, 0)])
        self.manipulators[1].set_pts([(-x, -y, 0), (-x, y, 0), (-1, 0, 0)])
        self.manipulators[2].set_pts([(x, -y, 0), (x, -y, self.z), (-_dir, 0, 0)])

        # support for instances childs, update at object level
        # self.update_dimension(context, o)
        dx = x + _dir * self.frame_y
        self.add_dimension_point(0, Vector((-x, -y, 0)))
        self.add_dimension_point(1, Vector((x, -y, 0)))
        self.add_dimension_point(2, Vector((-dx, -y, 0)))
        self.add_dimension_point(3, Vector((dx, -y, 0)))
        self.add_dimension_point(4, Vector((-x, y, 0)))
        self.add_dimension_point(5, Vector((x, y, 0)))
        self.add_dimension_point(6, Vector((-dx, y, 0)))
        self.add_dimension_point(7, Vector((dx, y, 0)))

        # childs are updated through custom when required
        if is_regular_door:
            self.synch_childs(context, o)

        # synch wall dimensions when apply
        self.update_dimensions(context, o)

        # restore context
        self.restore_context(context)

    def find_hole(self, o):
        return self.find_one_by_flag(o, ('hole', 'custom_hole'))

    def update_auto_hole(self, context):
        """ Handle automatic_hole state changes
        :param context:
        :return:
        """
        o = self.find_in_selection(context, True)
        if o is None:
            return

        linked_objects = self.get_linked_objects(context, o)
        for linked in linked_objects:
            hole_obj = self.find_hole(linked)
            if hole_obj is not None:
                manager = ArchipackBoolManager()
                manager.automatic_hole(context, linked, hole_obj, self.automatic_hole)

        self.restore_context(context)

    def interactive_hole(self, context, o):

        if not self.automatic_hole:
            return None

        if self.has_flag(o, "standalone"):
            # standalone door do not require hole at all
            # print("interactive_hole is standalone !")
            return None

        hole_obj = self.find_hole(o)

        # print("interactive_hole found hole ?", hole_obj is not None)

        if self.user_defined_hole is None and (self.has_user_defined_object or self.has_user_defined_custom):
            # use hole copy found with user_defined object
            # print("interactive_hole return", hole_obj)
            return hole_obj

        if hole_obj is None:
            hole_obj, m = self.create_mesh("hole")
            # Link object into scene
            self.set_flag(hole_obj, "hole", True)
            self.set_flag(hole_obj, "skip_material", True)
            self.link_object_to_scene(context, hole_obj)
            hole_obj.parent = o
            hole_obj.matrix_world = o.matrix_world.copy()

            self.hide_for_render_engines(hole_obj)
            Callbacks.call("create", context, hole_obj, None)

        if self.user_defined_hole is not None:
            # print("interactive_hole, using user_defined_hole hole")
            vcolors = None
            verts, faces, uvs, matids = \
                bmed.mesh_data_from_obj(self.user_defined_hole)

        else:
            # print("interactive_hole, using automatic hole")
            hole = self.hole
            v = Vector((0, 0, 0))
            offset = Vector((0, -self.z_offset - 0.001, 0))

            # if self.frame_enable:
            #    # frame is bigger than wall
            #    if self.frame_y > 0:
            #        x = self.frame_y
            #    else:
            #        # when smaller than wall cut the wall
            #        x = self.frame_x
            # else:
            x = 0

            size = Vector((
                self.x + 2 * x,
                self.z + x + self.z_offset + 0.001,
                self.y))

            verts = hole.vertices(16, offset, v, v, size, v, 0, 0, shape_z=None, path_type='RECTANGLE')
            faces = hole.faces(16, path_type='RECTANGLE')
            matids = hole.mat(16, 0, 1, path_type='RECTANGLE')
            uvs = hole.uv(16, v, v, size, v, 0, 0, 0, 0, path_type='RECTANGLE')
            col = random_color()
            # without vcolors boolean wont transfer vcolors to result mesh
            vcolors = hole.vcolors(16, col, path_type='RECTANGLE')

        bmed.buildmesh(hole_obj, verts, faces, matids, uvs, vcolors=vcolors)

        Callbacks.call("update", context, hole_obj, None)
        return hole_obj

    @staticmethod
    def _add_spline(curve, coords):
        spline = curve.splines.new('POLY')
        spline.use_endpoint_u = False
        spline.use_cyclic_u = coords[-1] == coords[0]
        if coords[-1] == coords[0]:
            coords.pop()
        spline.points.add(len(coords) - 1)
        for i, coord in enumerate(coords):
            x, y, z = coord
            spline.points[i].co = (x, y, z, 1)

    def _to_curve(self, context, coords, name: str, dimensions: str = '3D'):
        curve = bpy.data.curves.new(name, type='CURVE')
        curve.dimensions = dimensions
        for co in coords:
            self._add_spline(curve, co)
        curve_obj = bpy.data.objects.new(name, curve)
        self.link_object_to_scene(context, curve_obj)
        self.select_object(context, curve_obj)
        return curve_obj

    def as_2d(self, context, o):

        # TODO: handle custom 2d symbol
        self.upgrade()

        # frame
        v = Vector((0, 0, 0))
        size = Vector((self.x, self.z, self.y))

        coords = self.frame.as_2d(16, v, v, v,
                                  size, v, 0, 0, connect=0)

        if len(o.children) < self.n_panels + 1:
            with context_override(context, o, [o]) as ctx:
                self.update(ctx)

        childs = self._members(o)

        # location_y = max(0.25 * self.door_y + 0.0005, self.y / 2 + self.frame_y)
        # location_y = max(location_y - self.rabbet + 0.5 * self.door_y, -location_y + self.door_y + 0.001)
        # location_y = max(location_y - self.rabbet + self.door_y, -location_y + self.door_y + 0.001)

        location_y = self._jamb_depth - self.rabbet + self.door_y + 0.001

        if self.open == 'OUTSIDE':
            location_y = -location_y

        radius = Vector((0.8, 0.5, 0))
        center = Vector((0, 0, 0))

        if self.direction == 0:
            pivot = 1
        else:
            pivot = -1

        for uid, panel in childs.items():

            d = archipack_door_panel.datablock(panel)
            x = self.x / self.n_panels + (3 - self.n_panels) * (self._stop - SPACING)
            y = self.door_y
            z = self.z + self._stop - SPACING

            origin = Vector((-pivot * 0.5 * x, 0, 0))
            size = Vector((y, z, 0))

            location_x = -pivot * (0.5 * self.x + self._stop - SPACING)

            location = Vector((location_x, location_y, 0))
            coords.extend(
                d.symbol_2d(self, x).as_2d(
                    1, location, center, origin,
                    size, radius, 0, pivot, shape_z=None, path_type='RECTANGLE')
            )
            # arc
            r = x
            steps = 16
            da = pi / (2 * steps)
            arc = [Vector((
                location_x + pivot * r * cos(da * i),
                location_y + r * sin(da * i),
                0))
                for i in range(steps + 1)]
            coords.append(arc)
            pivot = -pivot

        curve = self._to_curve(context, coords, name="{}-2d".format(o.name), dimensions='2D')
        curve.matrix_world = o.matrix_world.copy()

        return curve

    def merge_geometry(self, o):
        def _filter(c):
            return not self.has_flag(c, ("hole", "custom_hole"))

        bm = bmed.bmesh_from_obj(
            o, hierarchy=True, filter_hierarchy=_filter
        )
        me = bpy.data.meshes.new("%s-simple" % o.data.name)
        bm.to_mesh(me)
        bm.free()
        return me

    def ifc_representation(self, context, o, representation_id="FootPrint"):

        if representation_id == "Annotation":
            curve = self.as_2d(context, o)
            curve.matrix_world = Matrix()
            return curve

        elif representation_id == "FootPrint":
            coords = self.hole_2d(mode="BOUND")
            curve = self._to_curve(context, [coords], name="{}-footprint".format(o.name), dimensions='2D')
            curve.matrix_world = Matrix()
            return curve

        elif representation_id == "Body":
            return self.merge_geometry(o)

        return None

    def hole_2d(self, mode='PLAN_2D'):
        """
          return coords of full / inside hole in 2d top ortho view
        """
        if mode == 'BOUND':
            # Boundarys of whole door to detect wall intersection
            x, y = 0.5 * self.x + self.frame_x, 0.5 * self.y + self.hole_margin
            return [(-x, -y, 0), (-x, y, 0), (x, y, 0), (x, -y, 0), (-x, -y, 0)]

        v = Vector((0, 0, 0))

        if self.frame_y > 0 and mode not in {'MOLDINGS', 'FLOOR'}:
            # moldings always depends on frame width
            size = Vector((self.x + 2 * self.frame_y, self.z + self.frame_y + 0.001, self.y))
        else:
            size = Vector((self.x + 2 * self.frame_x, self.z + self.frame_x + 0.001, self.y))

        if mode == 'INSIDE':
            # inside hole for floors
            coords = self.inside_hole.as_2d(16,
                                            v,
                                            v, v, size, v,
                                            0, 0, shape_z=None, path_type='RECTANGLE')
        elif mode == 'OUTSIDE':
            # outside hole for floors
            coords = self.outside_hole.as_2d(16,
                                             v,
                                             v, v, size, v,
                                             0, 0, shape_z=None, path_type='RECTANGLE')
        elif mode == 'MOLDINGS':
            # whole hole for moldings
            coords = self.hole_symbol.as_2d(16,
                                            v,
                                            v, v, size, v,
                                            0, 0, shape_z=None, path_type='RECTANGLE')

        else:
            # whole hole for symbols
            size = Vector((
                self.x,
                self.z,
                self.y))
            coords = self.hole.as_2d(16,
                                            v,
                                            v, v, size, v,
                                            0, 0, shape_z=None, path_type='RECTANGLE')

        # Use only first curve
        return coords[0]

    def remove_hole(self, context, hole, walls):
        ctx = context.copy()
        ctx['object'] = hole
        ctx['selected_objects'] = walls
        self.call_operator(context, ctx, bpy.ops.archipack.remove_hole)

    @property
    def user_defined_objects(self):
        return [
            self.user_defined_object,
            self.user_defined_handle,
            self.user_defined_handle_outside,
            self.user_defined_hole
        ]

    def on_delete(self, context, obj):

        walls = set()
        wall2 = {}
        sel = context.selected_objects[:]
        # collect walls
        ref = self.get_reference_point(obj)
        if ref is not None:
            walls = [
                c for c in ref.children
                if (
                        c.data and (
                            "archipack_wall2" in c.data
                            or "archipack_wall" in c.data
                            or self.has_flag(c, "custom_wall")
                        )
                )
            ]
            wall2 = {
                c: c.data.archipack_wall2[0]
                for c in ref.children
                if c.data and "archipack_wall2" in c.data
            }

        for o in sel:
            if archipack_door.filter(o):
                hole = self.find_hole(o)
                if hole is not None:
                    self.remove_hole(context, hole, walls)

                if o.name != obj.name:
                    self.delete_object(context, o)

        for c, d in wall2.items():
            d.setup_childs(context, c, openings_only=True)
            for i, child in enumerate(d.childs):
                if child.child_name == obj.name:
                    d.childs.remove(i)
                    break
            d.synch_dimension(context, c, remove_object=obj.name)

        ArchipackObject.on_delete(self, context, obj)


class ARCHIPACK_PT_door(ArchipackPanel, Archipacki18n, Panel):
    bl_idname = "ARCHIPACK_PT_door"
    bl_label = "Door"

    @classmethod
    def poll(cls, context):
        return archipack_door.poll(context.active_object)

    def draw(self, context):
        o = context.active_object
        d = archipack_door.datablock(o)

        if d is None:
            return

        layout = self.layout

        self.draw_common(context, layout)

        row = layout.row(align=True)
        self.draw_op(context, layout, row, 'archipack.door', icon='FILE_REFRESH', text="Refresh").mode = 'REFRESH'
        if o.data.users > 1:
            self.draw_op(context, layout, row, 'archipack.door', icon='UNLINKED', text="Make unique",
                         postfix="({})".format(o.data.users)).mode = 'UNIQUE'
        self.draw_op(context, layout, layout, "archipack.door_array", icon='MOD_ARRAY', text="Array")

        box = layout.box()
        # self.draw_label(context, layout, box, "Styles")
        row = box.row(align=True)
        self.draw_op(context, layout, row, "archipack.door_preset_menu",
                     text=bpy.types.ARCHIPACK_OT_door_preset_menu.bl_label, icon="PRESET"
                     ).preset_operator = "archipack.preset_loader"
        self.draw_op(context, layout, row, "archipack.door_preset", icon='ADD', text="")
        self.draw_op(context, layout, row, "archipack.door_preset", icon='REMOVE', text="").remove_active = True
        self.draw_op(context, layout, layout, "archipack.door_open")

        self.draw_prop(context, layout, layout, d, 'tabs', expand=True)

        box = layout.box()

        if d.tabs == 'MAIN':
            self.draw_prop(context, layout, box, d, 'door_type')
            if d.door_type != "USER":
                self.draw_prop(context, layout, box, d, 'open')
            self.draw_label(context, layout, box, "Size")
            self.draw_prop(context, layout, box, d, 'x')
            self.draw_prop(context, layout, box, d, 'y')
            self.draw_prop(context, layout, box, d, 'z')

            if d.door_type != "USER":
                box = layout.box()
                self.draw_label(context, layout, box, "Frame")
                self.draw_prop(context, layout, box, d, 'frame_enable')
                self.draw_prop(context, layout, box, d, 'frame_shape')
                self.draw_prop(context, layout, box, d, 'frame_layout')
                self.draw_prop(context, layout, box, d, 'stop')
                self.draw_prop(context, layout, box, d, 'rabbet')
                self.draw_prop(context, layout, box, d, 'frame_x')
                # self.draw_prop(context, layout, box, d, 'frame_adaptive')
                if d.frame_layout in {'ENCOMPASS', 'FACE'}:
                    self.draw_prop(context, layout, box, d, 'frame_y')
                elif d.frame_layout == 'FIXED':
                    self.draw_prop(context, layout, box, d, 'jamb_depth')


            if 'USER' in d.door_type:
                box = layout.box()
                self.draw_label(context, layout, box, "Custom geometry")
                self.draw_prop(context, layout, box, d, 'user_defined_object')
                self.draw_prop(context, layout, box, d, 'user_defined_hole')

            if d.door_type != 'USER':
                box = layout.box()
                row = box.row(align=True)
                self.draw_prop(context, layout, row, d, 'direction_ui', expand=True)
                self.draw_prop(context, layout, box, d, 'n_panels')

            box = layout.box()
            self.draw_prop(context, layout, box, d, 'automatic_hole', icon="BLANK1", emboss=True)

            if d.automatic_hole:
                self.draw_prop(context, layout, box, d, 'z_offset')
                self.draw_prop(context, layout, box, d, "hole_margin")

        elif d.tabs == 'SUB':

            if d.door_type == 'USER':
                return

            self.draw_label(context, layout, box, "Door")
            self.draw_prop(context, layout, box, d, 'door_y')

            box = layout.box()
            self.draw_label(context, layout, box, "Handle")
            self.draw_prop(context, layout, box, d, 'handle_type', text="")
            self.draw_prop(context, layout, box, d, 'handle_altitude')
            if d.handle_type == "DOOR_USER":
                self.draw_prop(context, layout, box, d, 'user_defined_handle')
                self.draw_prop(context, layout, box, d, 'user_defined_handle_outside')

            self.draw_prop(context, layout, box, d, 'soil_enable')
            if d.soil_enable:
                self.draw_prop(context, layout, box, d, 'soil_z')
                self.draw_prop(context, layout, box, d, 'soil_y')
            self.draw_prop(context, layout, box, d, 'sill_enable')
            if d.sill_enable:
                self.draw_prop(context, layout, box, d, 'sill_x')
                self.draw_prop(context, layout, box, d, 'sill_y')
                self.draw_prop(context, layout, box, d, 'sill_z')

            if 'USER' in d.door_type:
                return

            box = layout.box()
            self.draw_label(context, layout, box, "Panels")
            self.draw_prop(context, layout, box, d, 'model_ui', text="Type")
            if d.model > 0:
                self.draw_prop(context, layout, box, d, 'panels_distrib', text="")
                row = box.row(align=True)
                self.draw_prop(context, layout, row, d, 'panels_x')
                if d.panels_distrib == 'REGULAR':
                    self.draw_prop(context, layout, row, d, 'panels_y')
                self.draw_prop(context, layout, box, d, 'panel_bottom')
                self.draw_prop(context, layout, box, d, 'panel_spacing')
                self.draw_prop(context, layout, box, d, 'panel_border')
                self.draw_prop(context, layout, box, d, 'chanfer')

            box = layout.box()
            self.draw_label(context, layout, box, "Panels")
            for i, panel in enumerate(d.parts):
                if i < len(o.children):
                    c = o.children[i]
                    if archipack_door_panel.datablock(c) and hasattr(c, "rotation_euler"):
                        self.draw_prop(context, layout, box, c, "rotation_euler", index=2, text="Open angle")
                self.draw_prop(context, layout, box, panel, 'handle_side', text="Handle", postfix=str(i))

        elif d.tabs == 'MATERIALS':

            if "archipack_material" in o:
                o.archipack_material[0].draw(context, box)

            box = layout.box()
            self.draw_label(context, layout, box, "Apply materials")
            self.draw_prop(context, layout, box, d, 'mat_frame_inside')
            self.draw_prop(context, layout, box, d, 'mat_frame_outside')
            self.draw_prop(context, layout, box, d, 'mat_door_inside')
            self.draw_prop(context, layout, box, d, 'mat_door_outside')

            if d.model > 0:
                self.draw_prop(context, layout, box, d, 'mat_panel_inside')
                self.draw_prop(context, layout, box, d, 'mat_panel_outside')

            self.draw_prop(context, layout, box, d, 'mat_handle')
            self.draw_prop(context, layout, box, d, 'mat_sill')
            self.draw_prop(context, layout, box, d, 'mat_soil')


# ------------------------------------------------------------------
# Define operator class to create object
# ------------------------------------------------------------------


class ARCHIPACK_OT_door(ArchipackCreateTool, Operator):
    bl_idname = "archipack.door"
    bl_label = "Door"
    bl_description = "Door"

    x: FloatProperty(
        name='width',
        min=0.1,
        default=0.80, precision=5,
        unit='LENGTH', subtype='DISTANCE',
        description='Width'
    )
    y: FloatProperty(
        name='depth',
        min=0.1,
        default=0.20, precision=5,
        unit='LENGTH', subtype='DISTANCE',
        description='Depth'
    )
    z: FloatProperty(
        name='height',
        min=0.1,
        default=2.0, precision=5,
        unit='LENGTH', subtype='DISTANCE',
        description='height'
    )
    direction: IntProperty(
        name="direction",
        min=0,
        max=1,
        description="open direction"
    )
    n_panels: IntProperty(
        name="Door leaf",
        min=1,
        max=2,
        default=1,
        description="number of panels"
    )
    chanfer: FloatProperty(
        name='Chanfer',
        min=0.001,
        default=0.005, precision=3,
        unit='LENGTH', subtype='DISTANCE',
        description='chanfer'
    )
    panel_spacing: FloatProperty(
        name='Spacing',
        min=0.001,
        default=0.1, precision=5,
        unit='LENGTH', subtype='DISTANCE',
        description='distance between panels'
    )
    panel_bottom: FloatProperty(
        name='bottom',
        default=0.0, precision=5,
        unit='LENGTH', subtype='DISTANCE',
        description='distance from bottom'
    )
    panel_border: FloatProperty(
        name='border',
        min=0.001,
        default=0.2, precision=5,
        unit='LENGTH', subtype='DISTANCE',
        description='distance from border'
    )
    panels_x: IntProperty(
        name="panels h",
        min=1,
        max=50,
        default=1,
        description="panels h"
    )
    panels_y: IntProperty(
        name="panels v",
        min=1,
        max=50,
        default=1,
        description="panels v"
    )
    panels_distrib: EnumProperty(
        name='distribution',
        items=(
            ('REGULAR', 'Regular', '', 0),
            ('ONE_THIRD', '1/3 2/3', '', 1)
        ),
        default='REGULAR'
    )

    handle_side: EnumProperty(
        name="Side",
        items=(
            ('BOTH', "Both", "Inside and outside"),
            ('INSIDE', "Inside", "Inside only"),
            ('OUTSIDE', "Outside", "Outside only"),
            ('NONE', "None", "Disable handles")
        ),
        default="BOTH",
        update=update_childs
    )

    standalone: BoolProperty(default=True)

    mode: EnumProperty(
        items=(
            ('CREATE', 'Create', '', 0),
            ('REFRESH', 'Refresh', '', 2),
            ('UNIQUE', 'Make unique', '', 3),
        ),
        default='CREATE'
    )

    def create(self, context):
        """
            expose only basic params in operator
            use object property for other params
        """
        o, m = self.create_mesh("Door")
        d = m.archipack_door.add()
        d.x = self.x
        d.y = self.y
        d.z = self.z
        d.direction = self.direction
        d.n_panels = self.n_panels
        d.chanfer = self.chanfer
        d.panel_border = self.panel_border
        d.panel_bottom = self.panel_bottom
        d.panel_spacing = self.panel_spacing
        d.panels_distrib = self.panels_distrib
        d.panels_x = self.panels_x
        d.panels_y = self.panels_y
        d.handle_side = self.handle_side
        # is standalone until boolean state otherwise, but draw tool may override in order to see hole at create time
        self.set_flag(o, "standalone", self.standalone)
        # Link object into scene
        self.link_object_to_scene(context, o)
        o.color = (0, 1, 0, 1)

        # select and make active
        self.select_object(context, o, True)
        self.add_material(context, o, material="DEFAULT", category="door")
        self.load_preset(context, o, d)
        return o

    def update(self, context):
        o = context.active_object
        d = archipack_door.datablock(o)
        if d is not None:
            d.update(context)
        #     bpy.ops.object.select_linked(type='OBDATA')
        #     for linked in context.selected_objects:
        #         if linked != o:
        #             archipack_door.datablock(linked).update(context)
        # bpy.ops.object.select_all(action="DESELECT")
        # # select and make active
        # self.select_object(context, o, True)

    def unique(self, context):
        obj = context.active_object
        sel = context.selected_objects
        uniques = []
        for o in sel:
            if archipack_door.filter(o):
                Callbacks.call("unique", context, o, None)
                uniques.append(o)
                # panel and holes
                uniques.extend(list(o.children))
                for c in o.children:
                    # hole, handles and dimension text
                    uniques.extend(list(c.children))
        if bool(uniques):
            bpy.ops.archipack.disable_manipulate()
            with ensure_select_and_restore(context, uniques[0], uniques):
                bpy.ops.object.make_single_user(
                    type='SELECTED_OBJECTS', object=True, obdata=True, material=False, animation=False
                )
            self.select_object(context, obj, True)

    def execute(self, context):
        if context.mode == "OBJECT":
            if self.mode == 'CREATE':
                bpy.ops.object.select_all(action="DESELECT")
                o = self.create(context)
                o.location = self.get_cursor_location(context)
                # select and make active
                self.select_object(context, o, True)
            elif self.mode == 'REFRESH':
                self.update(context)
            elif self.mode == 'UNIQUE':
                self.unique(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


class ARCHIPACK_OT_door_open(Operator):
    bl_idname = "archipack.door_open"
    bl_label = "Open Door(s)"
    bl_description = "Open selected doors"
    bl_options = {'UNDO', 'REGISTER'}

    angle: FloatProperty(
        name='Angle',
        min=0, max=pi,
        default=pi / 2, precision=5,
        subtype='ANGLE', unit='ROTATION',
        description='Rotation'
    )

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o and archipack_door.filter(o)

    def execute(self, context):
        sel = context.selected_objects
        for o in sel:
            d = archipack_door.datablock(o)
            if d is not None:
                if d.n_panels == 1:
                    for c in o.children:
                        if archipack_door_panel.filter(c):
                            if d.open == 'OUTSIDE':
                                c.rotation_euler = (0, 0, (1 - 2 * d.direction) * -self.angle)
                            else:
                                c.rotation_euler = (0, 0, (1 - 2 * d.direction) * self.angle)
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class ARCHIPACK_OT_door_array(ArchipackArrayTool, Operator):
    bl_idname = "archipack.door_array"
    bl_label = "Door Array"
    bl_description = "Duplicate selected doors"
    bl_options = {'UNDO'}

    # XXX crash on redo when using spinner values ..
    # bl_options = {'REGISTER', 'UNDO'}

    def filter_object(self, o):
        return archipack_door.filter(o)

    def get_object_datablock(self, o):
        return archipack_door.datablock(o)


class ARCHIPACK_OT_door_draw(ArchipackDrawTool, Operator):
    bl_idname = "archipack.door_draw"
    bl_label = "Draw Doors"
    bl_description = "Draw Doors over walls"

    filepath: StringProperty(default="")
    feedback = None
    stack = []
    object_name = ""
    keymap = None
    _handle = None

    @classmethod
    def poll(cls, context):
        return True

    def draw_callback(self, _self, context):
        self.feedback.draw(context)

    def add_object(self, context, event):

        bpy.ops.object.select_all(action="DESELECT")
        o = context.scene.objects.get(self.object_name)
        # print("add_object bpy.ops.archipack.window")

        if self.filepath == '' and archipack_door.filter(o):
            o = self.duplicate_object(context, o, False)
            d = self.archipack_datablock(o)
            self.load_preset(context, o, d)
            self.select_object(context, o, True)
        else:
            bpy.ops.archipack.door(filepath=self.filepath, standalone=False)

            o = context.active_object

        if o is None:
            o = context.object

        self.object_name = o.name
        # print("add_object bpy.ops.archipack.generate_hole")
        # bpy.ops.archipack.generate_hole()
        return o

    def remove_object(self, context, o):
        if archipack_door.filter(o):
            with context_override(context, None, [o]) as ctx:
                self.call_operator(context, ctx, bpy.ops.archipack.delete)

    def exit(self, context, o):
        self.remove_object(context, o)
        self.feedback.disable()
        try:
            context.space_data.show_gizmo = True
        except:
            pass
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

    def modal(self, context, event):

        o = self.get_scene_object(context, self.object_name)

        if o is None or context.area is None:
            self.exit(context, o)
            return {'FINISHED'}

        context.area.tag_redraw()

        d = archipack_door.datablock(o)

        # hide door and hole from ray cast, broken till 28.02 ..
        to_hide = []
        self.rec_get_childrens(o, to_hide)

        for obj in to_hide:
            self.hide_object(obj)

        res, tM, wall, width, y, z_offset = self.mouse_hover_wall(context, event)

        print("mouse hover wall %s" % res)

        for obj in to_hide:
            self.show_object(obj)

        if res and d is not None:
            o.matrix_world = tM
            if abs(d.z_offset - z_offset) > 0.001:
                self.select_object(context, o, True)
                d.z_offset = z_offset
                # print("draw_tool z_offset change", z_offset)
                with context_override(context, o, [o]) as ctx:
                    d.update(ctx)
            if abs(d.y - width) > 0.001:
                self.select_object(context, o, True)
                d.y = width
                # print("draw_tool width change", width)
                with context_override(context, o, [o]) as ctx:
                    d.update(ctx)

        if event.value == 'PRESS':

            if event.type in {'C', 'D'}:
                self.exit(context, o)
                bpy.ops.archipack.door_preset_menu(
                    'INVOKE_DEFAULT',
                    preset_operator="archipack.door_draw")
                self.restore_walls(context)
                return {'FINISHED'}

            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
                if wall is not None:
                    # select and make active
                    ctx = context.copy()
                    ctx['object'] = wall
                    ctx['selected_objects'] = [o]
                    self.call_operator(context, ctx, bpy.ops.archipack.single_boolean)

                    # o must be a door here
                    if d is not None:
                        # make linked object
                        if len(self.stack) > 0 and not event.shift:
                            last = self.stack[-1]
                            d_last = last.data.archipack_door[0]
                            if d_last.y == d.y:
                                # Must disable manipulators before link !!
                                bpy.ops.archipack.disable_manipulate()
                                self.link_object(last, o)

                        if "archipack_wall2" in wall.data:
                            # update dimensions
                            with ensure_select_and_restore(context, wall, [wall]):
                                wd = wall.data.archipack_wall2[0]
                                wg = wd.get_generator()
                                wd.setup_childs(context, wall, g=wg, openings_only=True)
                                wd.relocate_childs(context, wall, g=wg)
                                wd.update_dimension(context, wall, wg)

                        # self.select_object(context, o, True)
                        self.stack.append(o)

                        o = self.add_object(context, event)
                        o.matrix_world = tM

                    return {'RUNNING_MODAL'}

            # prevent selection of other object
            if event.type in {'RIGHTMOUSE'}:
                return {'RUNNING_MODAL'}

        if self.keymap.check(event, self.keymap.undo) or (
                event.type in {'BACK_SPACE'} and event.value == 'RELEASE'
        ):
            if len(self.stack) > 0:
                last = self.stack.pop()
                self.remove_object(context, last)
                # self.select_object(context, o, True)
            return {'RUNNING_MODAL'}

        if event.value == 'RELEASE':

            if event.type in {'ESC', 'RIGHTMOUSE'}:
                self.exit(context, o)
                self.restore_walls(context)

                return {'FINISHED'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):

        if context.mode == "OBJECT":
            o = context.active_object
            self.stack = []
            self.keymap = Keymaps(context)
            # exit manipulate_mode if any
            bpy.ops.archipack.disable_manipulate()

            # Hide manipulators
            context.space_data.show_gizmo = False

            # invoke with alt pressed will use current object as basis for linked copy
            if self.filepath == '' and archipack_door.filter(o):
                self.stack.append(o)
                o = self.duplicate_object(context, o, False)
                self.object_name = o.name
            else:
                o = self.add_object(context, event)

            # select and make active
            bpy.ops.object.select_all(action="DESELECT")
            self.select_object(context, o, True)

            self.feedback = FeedbackPanel()
            self.feedback.instructions(context, "Draw a door", "Click & Drag over a wall", [
                ('LEFTCLICK, RET, SPACE, ENTER', 'Create a door'),
                ('BACKSPACE, CTRL+Z', 'undo last'),
                ('D', 'Draw another door'),
                ('SHIFT', 'Make independant copy'),
                ('RIGHTCLICK or ESC', 'exit')
            ])
            self.feedback.enable()
            args = (self, context)

            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Archipack: Option only valid in Object mode")
            return {'CANCELLED'}


# ------------------------------------------------------------------
# Define operator class to load / save presets
# ------------------------------------------------------------------


class ARCHIPACK_OT_door_preset_draw(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and draw doors over wall"
    bl_idname = "archipack.door_preset_draw"
    bl_label = "Door Presets"
    preset_subdir = "archipack_door"


class ARCHIPACK_OT_door_preset_create(PresetMenuOperator, Operator):
    bl_description = "Choose a preset and create standalone door at cursor location"
    bl_idname = "archipack.door_preset_create"
    bl_label = "Door preset"
    preset_subdir = "archipack_door"


class ARCHIPACK_OT_door_preset_menu(PresetMenuOperator, Operator):
    bl_description = "Show Doors presets"
    bl_idname = "archipack.door_preset_menu"
    bl_label = "Door Presets"
    preset_subdir = "archipack_door"


class ARCHIPACK_OT_door_preset(ArchipackPreset, Operator):
    bl_description = "Add / remove a Door Preset"
    bl_idname = "archipack.door_preset"
    bl_label = "Door Preset"
    preset_menu = "ARCHIPACK_OT_door_preset_menu"

    @property
    def blacklist(self):
        return ['y']


def register():
    bpy.utils.register_class(archipack_door_panel)
    Mesh.archipack_door_panel = CollectionProperty(type=archipack_door_panel)
    bpy.utils.register_class(ARCHIPACK_PT_door_panel)
    bpy.utils.register_class(ARCHIPACK_OT_select_parent)
    bpy.utils.register_class(ARCHIPACK_OT_select)
    bpy.utils.register_class(archipack_door)
    Mesh.archipack_door = CollectionProperty(type=archipack_door)
    bpy.utils.register_class(ARCHIPACK_OT_door_preset_menu)
    bpy.utils.register_class(ARCHIPACK_OT_door_preset_create)
    bpy.utils.register_class(ARCHIPACK_OT_door_preset_draw)
    bpy.utils.register_class(ARCHIPACK_PT_door)
    bpy.utils.register_class(ARCHIPACK_OT_door)
    bpy.utils.register_class(ARCHIPACK_OT_door_array)
    bpy.utils.register_class(ARCHIPACK_OT_door_preset)

    bpy.utils.register_class(ARCHIPACK_OT_door_draw)
    bpy.utils.register_class(ARCHIPACK_OT_door_open)


def unregister():
    bpy.utils.unregister_class(archipack_door_panel)
    del Mesh.archipack_door_panel
    bpy.utils.unregister_class(ARCHIPACK_PT_door_panel)
    bpy.utils.unregister_class(ARCHIPACK_OT_select_parent)
    bpy.utils.unregister_class(ARCHIPACK_OT_select)
    bpy.utils.unregister_class(archipack_door)
    del Mesh.archipack_door
    bpy.utils.unregister_class(ARCHIPACK_OT_door_preset_menu)
    bpy.utils.unregister_class(ARCHIPACK_OT_door_preset_create)
    bpy.utils.unregister_class(ARCHIPACK_OT_door_preset_draw)
    bpy.utils.unregister_class(ARCHIPACK_PT_door)
    bpy.utils.unregister_class(ARCHIPACK_OT_door_array)
    bpy.utils.unregister_class(ARCHIPACK_OT_door)
    bpy.utils.unregister_class(ARCHIPACK_OT_door_preset)
    bpy.utils.unregister_class(ARCHIPACK_OT_door_draw)
    bpy.utils.unregister_class(ARCHIPACK_OT_door_open)
