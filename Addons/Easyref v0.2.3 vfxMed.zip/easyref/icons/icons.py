# -*- coding:utf-8 -*-

# Easyref Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>


import os
import bpy
import bpy.utils.previews
 
epm_icon_collections = {}
epm_icons_loaded = False
 
def load_icons():
    global epm_icon_collections
    global epm_icons_loaded
 
    if epm_icons_loaded: return epm_icon_collections["main"]
 
    custom_icons = bpy.utils.previews.new()
 
    icons_dir = os.path.join(os.path.dirname(__file__))
    

    custom_icons.load("icon_cam_active", os.path.join(icons_dir, "cam_active.png"), 'IMAGE')
    custom_icons.load("icon_dollyzoom", os.path.join(icons_dir, "dollyzoom.png"), 'IMAGE')


    custom_icons.load("icon_market", os.path.join(icons_dir, "market.png"), 'IMAGE')
    custom_icons.load("icon_artstation", os.path.join(icons_dir, "artstation.png"), 'IMAGE')
    custom_icons.load("icon_gumroad", os.path.join(icons_dir, "gumroad.png"), 'IMAGE')
    custom_icons.load("icon_youtube", os.path.join(icons_dir, "youtube.png"), 'IMAGE')
    custom_icons.load("icon_tutocom", os.path.join(icons_dir, "tutocom.png"), 'IMAGE')
    custom_icons.load("icon_discord", os.path.join(icons_dir, "discord.png"), 'IMAGE')
    custom_icons.load("icon_flipped_normals", os.path.join(icons_dir, "flipped_normals.png"), 'IMAGE')
    custom_icons.load("icon_web", os.path.join(icons_dir, "web.png"), 'IMAGE')
    custom_icons.load("icon_twitter", os.path.join(icons_dir, "twitter.png"), 'IMAGE')
    custom_icons.load("icon_facebook", os.path.join(icons_dir, "facebook.png"), 'IMAGE')


    custom_icons.load("icon_1", os.path.join(icons_dir, "1.png"), 'IMAGE')
    custom_icons.load("icon_2", os.path.join(icons_dir, "2.png"), 'IMAGE')
    custom_icons.load("icon_3", os.path.join(icons_dir, "3.png"), 'IMAGE')
    custom_icons.load("icon_4", os.path.join(icons_dir, "4.png"), 'IMAGE')
    custom_icons.load("icon_5", os.path.join(icons_dir, "5.png"), 'IMAGE')
    custom_icons.load("icon_6", os.path.join(icons_dir, "6.png"), 'IMAGE')
    custom_icons.load("icon_7", os.path.join(icons_dir, "7.png"), 'IMAGE')
    custom_icons.load("icon_8", os.path.join(icons_dir, "8.png"), 'IMAGE')
    custom_icons.load("icon_9", os.path.join(icons_dir, "9.png"), 'IMAGE')
    custom_icons.load("icon_0", os.path.join(icons_dir, "0.png"), 'IMAGE')

    custom_icons.load("icon_a", os.path.join(icons_dir, "a.png"), 'IMAGE')
    custom_icons.load("icon_b", os.path.join(icons_dir, "b.png"), 'IMAGE')
    custom_icons.load("icon_c", os.path.join(icons_dir, "c.png"), 'IMAGE')
    custom_icons.load("icon_d", os.path.join(icons_dir, "d.png"), 'IMAGE')
    custom_icons.load("icon_e", os.path.join(icons_dir, "e.png"), 'IMAGE')
    custom_icons.load("icon_f", os.path.join(icons_dir, "f.png"), 'IMAGE')
    custom_icons.load("icon_g", os.path.join(icons_dir, "g.png"), 'IMAGE')
    custom_icons.load("icon_h", os.path.join(icons_dir, "h.png"), 'IMAGE')
    custom_icons.load("icon_i", os.path.join(icons_dir, "i.png"), 'IMAGE')
    custom_icons.load("icon_j", os.path.join(icons_dir, "j.png"), 'IMAGE')
    custom_icons.load("icon_k", os.path.join(icons_dir, "k.png"), 'IMAGE')
    custom_icons.load("icon_l", os.path.join(icons_dir, "l.png"), 'IMAGE')
    custom_icons.load("icon_m", os.path.join(icons_dir, "m.png"), 'IMAGE')
    custom_icons.load("icon_n", os.path.join(icons_dir, "n.png"), 'IMAGE')
    custom_icons.load("icon_o", os.path.join(icons_dir, "o.png"), 'IMAGE')
    custom_icons.load("icon_p", os.path.join(icons_dir, "p.png"), 'IMAGE')
    custom_icons.load("icon_q", os.path.join(icons_dir, "q.png"), 'IMAGE')
    custom_icons.load("icon_r", os.path.join(icons_dir, "r.png"), 'IMAGE')
    custom_icons.load("icon_s", os.path.join(icons_dir, "s.png"), 'IMAGE')
    custom_icons.load("icon_t", os.path.join(icons_dir, "t.png"), 'IMAGE')
    custom_icons.load("icon_u", os.path.join(icons_dir, "u.png"), 'IMAGE')
    custom_icons.load("icon_v", os.path.join(icons_dir, "v.png"), 'IMAGE')
    custom_icons.load("icon_w", os.path.join(icons_dir, "w.png"), 'IMAGE')
    custom_icons.load("icon_x", os.path.join(icons_dir, "x.png"), 'IMAGE')
    custom_icons.load("icon_y", os.path.join(icons_dir, "y.png"), 'IMAGE')
    custom_icons.load("icon_z", os.path.join(icons_dir, "z.png"), 'IMAGE')

    custom_icons.load("icon_ctrl", os.path.join(icons_dir, "ctrl.png"), 'IMAGE')
    custom_icons.load("icon_left", os.path.join(icons_dir, "left.png"), 'IMAGE')
    custom_icons.load("icon_right", os.path.join(icons_dir, "right.png"), 'IMAGE')

    custom_icons.load("icon_easyref", os.path.join(icons_dir, "easyref.png"), 'IMAGE')
    custom_icons.load("icon_easyref_refs", os.path.join(icons_dir, "easyref_refs.png"), 'IMAGE')
    custom_icons.load("icon_easyref_cams", os.path.join(icons_dir, "easyref_cams.png"), 'IMAGE')
    custom_icons.load("icon_easyref_edit", os.path.join(icons_dir, "easyref_edit.png"), 'IMAGE')
    custom_icons.load("icon_set_ref_view", os.path.join(icons_dir, "set_ref_view.png"), 'IMAGE')
    custom_icons.load("icon_add_ref_view", os.path.join(icons_dir, "add_ref_view.png"), 'IMAGE')
    custom_icons.load("icon_options", os.path.join(icons_dir, "options.png"), 'IMAGE')
    custom_icons.load("icon_arrow_up", os.path.join(icons_dir, "arrow_up.png"), 'IMAGE')
    custom_icons.load("icon_remove_ref_view", os.path.join(icons_dir, "remove_ref_view.png"), 'IMAGE')

    epm_icon_collections["main"] = custom_icons
    epm_icons_loaded = True
 
    return epm_icon_collections["main"]
 
def speedflow_clear_icons():
    global epm_icons_loaded
    for icon in epm_icon_collections.values():
        bpy.utils.previews.remove(icon)
    epm_icon_collections.clear()
    epm_icons_loaded = False
