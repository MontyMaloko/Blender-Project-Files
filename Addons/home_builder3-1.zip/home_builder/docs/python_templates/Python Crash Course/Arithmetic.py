#Arithmetic Operators

addition = 1 + 1
subtraction = 3 - 2
multiplication = 3 * 5
division = 10 / 2
