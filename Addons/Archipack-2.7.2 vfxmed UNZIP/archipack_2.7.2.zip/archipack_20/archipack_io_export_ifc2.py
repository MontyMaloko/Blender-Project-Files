# -*- coding:utf-8 -*-

# #
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110- 1301, USA.
#
# 
# <pep8 compliant>

# ----------------------------------------------------------
# Author: Stephen Leger (s-leger)
#
# ----------------------------------------------------------

import bpy
import time
import bmesh
from bpy.types import Operator, Panel
from bpy.props import StringProperty, EnumProperty, BoolProperty, IntProperty
from .archipack_prefs import get_prefs
from .archipack_abstraction import (
    ArchipackObjectsManager,
    context_override,
    Callbacks
)
from .archipack_object import ArchipackCreateTool
from .archipack_logging import logger
from blenderbim.bim.ifc import IfcStore
import blenderbim.bim.operator as blenderbim_exporter
from bpy.app.handlers import persistent, load_pre, load_post
from blenderbim.bim.handler import purge_module_data
from blenderbim.bim.export_ifc import IfcExporter
from ifcopenshell.api.void.data import Data as VoidData
from ifcopenshell.api.context.data import Data as ContextData
from ifcopenshell.api.aggregate.data import Data as AggregateData
from ifcopenshell.api.geometry.data import Data as GeometryData
from ifcopenshell.api.pset.data import Data as PsetData
from ifcopenshell.api.attribute.data import Data as AttributeData

import ifcopenshell
from mathutils import Vector, Matrix
import numpy as np
from ifcopenshell.validate import validate


X_AXIS = Vector((1,0,0))
Y_AXIS = Vector((0,1,0))
Z_AXIS = Vector((0,0,1))


# Switch for "synch" mode full fledged ifc scene management, not mature enough to enable by default
USE_SYNCH = False
USE_LISTENERS = True

DEBUG_VALIDATE = False


IFC_CLASS_MAP = {
    "IFC2X3":{
        # Sunlight provide interface for lat/lon parameters with presets,
        # also allow to define scene origin other than 0,0
        # "archipack_sun": "IfcSite",
        # archipack_building still not exposed in ui
        "archipack_building": "IfcBuilding",
        "archipack_reference_point": "IfcBuildingStorey",
        "archipack_wall": "IfcWall",
        "archipack_wall2": "IfcWall",
        "archipack_custom_wall": "IfcWall",
        "archipack_window": "IfcWindow",
        "archipack_door": "IfcDoor",
        "archipack_slab": "IfcSlab",
        "archipack_stair": "IfcStair",
        # ArchiCad reference
        # Kitchen Cabinets           IfcFurnishingElement
        # Cabinet with Sink          IfcFlowTerminal > IfcSanitaryTerminalType with PredefinedType SINK.
        # Cabinet with Dishwasher    IfcFlowTerminal > IfcElectricApplianceType with PredefinedType DIRECTWATERHEATER.
        "archipack_kitchen": "IfcBuildingElementProxy",
        "archipack_furniture": "IfcBuildingElementProxy",
        "furniture": "IfcBuildingElementProxy",
        # use IfcMember instead ??  as column / beam are direction dependants
        "archipack_beam": "IfcColumn",
        # Moldings                   IfcCovering with PredefinedType as MOLDING on ceiling and SKIRTINGBOARD on floor
        "archipack_molding": "IfcCovering",
        # FLOORING
        "archipack_floor": "IfcCovering",
        "archipack_fence": "IfcRailing",
        "archipack_ceiling": "IfcCovering",
        # ShadingDevice is a 4x2 entity
        "archipack_blind": "IfcBuildingElementProxy",
        "archipack_window_shutter": "IfcBuildingElementProxy",
        "archipack_hole_geometry": "IfcOpeningElement",
        "archipack_custom_hole": "IfcOpeningElement",
        "archipack_roof": "IfcRoof",
        "archipack_terrain": "IfcGeographicElement"
    },
    "IFC4":{
        # Sunlight provide interface for lat/lon parameters with presets,
        # also allow to define scene origin other than 0,0
        # "archipack_sun": "IfcSite",
        # archipack_building still not exposed in ui
        "archipack_building": "IfcBuilding",
        "archipack_reference_point": "IfcBuildingStorey",
        "archipack_wall": "IfcWall",
        "archipack_wall2": "IfcWall",
        "archipack_custom_wall": "IfcWall",
        "archipack_window": "IfcWindow",
        "archipack_door": "IfcDoor",
        "archipack_slab": "IfcSlab",
        "archipack_stair": "IfcStair",
        # ArchiCad reference
        # Kitchen Cabinets           IfcFurnishingElement
        # Cabinet with Sink          IfcFlowTerminal > IfcSanitaryTerminalType with PredefinedType SINK.
        # Cabinet with Dishwasher    IfcFlowTerminal > IfcElectricApplianceType with PredefinedType DIRECTWATERHEATER.
        "archipack_kitchen": "IfcFurniture",
        "archipack_furniture": "IfcFurniture",
        "furniture": "IfcFurniture",
        # use IfcMember instead ??  as column / beam are direction dependants
        "archipack_beam": "IfcColumn",
        # Moldings                   IfcCovering with PredefinedType as MOLDING on ceiling and SKIRTINGBOARD on floor
        "archipack_molding": "IfcCovering",
        # FLOORING
        "archipack_floor": "IfcCovering",
        "archipack_fence": "IfcRailing",
        "archipack_ceiling": "IfcCovering",
        # ShadingDevice is a 4x2 entity
        "archipack_blind": "IfcShadingDevice",
        "archipack_window_shutter": "IfcShadingDevice",
        "archipack_hole_geometry": "IfcOpeningElement",
        "archipack_custom_hole": "IfcOpeningElement",
        "archipack_roof": "IfcRoof",
        "archipack_terrain": "IfcGeographicElement"
    }
}


PREDEFINED_TYPES = {
    "IFC2X3":{
        # Sunlight provide interface for lat/lon parameters with presets,
        # also allow to define scene origin other than 0,0
        # "archipack_sun": "IfcSite",
        # archipack_building still not exposed in ui
        # "archipack_building": "IfcBuilding",
        # "archipack_reference_point": "IfcBuildingStorey",
        # NOTE: wall type depends on location  SOLIDWALL or PARTITIONNING
        "archipack_wall": "SOLIDWALL",
        "archipack_wall2": "SOLIDWALL",
        "archipack_custom_wall": "SOLIDWALL",
        # "archipack_window": "WINDOW",
        # "archipack_window_shutter": "SHUTTER",
        # "archipack_door": "DOOR",
        # "archipack_slab": "FLOOR",
        # Stair type depends on landings, when > than 3 stair is USERDEFINED
        # "archipack_stair": "",
        # ArchiCad reference
        # Kitchen Cabinets           IfcFurnishingElement
        # Cabinet with Sink          IfcFlowTerminal > IfcSanitaryTerminalType with PredefinedType SINK.
        # Cabinet with Dishwasher    IfcFlowTerminal > IfcElectricApplianceType with PredefinedType DIRECTWATERHEATER.
        # "archipack_kitchen": "",
        # use IfcMember instead ??  as column / beam are direction dependants
        "archipack_beam": "COLUMN",
        # Moldings                   IfcCovering with PredefinedType as MOLDING on ceiling and SKIRTINGBOARD on floor
        "archipack_molding": "SKIRTINGBOARD",
        # FLOORING
        "archipack_floor": "FLOORING",
        "archipack_fence": "BALUSTRADE",
        "archipack_ceiling": "CEILING",
        # ShadingDevice is a 4x2 entity
        # "archipack_blind": "SHUTTER",
        "archipack_hole_geometry": "OPENING",
        "archipack_custom_hole": "OPENING",
        # "archipack_roof": "GABLE_ROOF",
        "archipack_terrain": "TERRAIN"
    },
    "IFC4":{
        # Sunlight provide interface for lat/lon parameters with presets,
        # also allow to define scene origin other than 0,0
        # "archipack_sun": "IfcSite",
        # archipack_building still not exposed in ui
        # "archipack_building": "IfcBuilding",
        # "archipack_reference_point": "IfcBuildingStorey",
        # NOTE: wall type depends on location  SOLIDWALL or PARTITIONNING
        "archipack_wall": "SOLIDWALL",
        "archipack_wall2": "SOLIDWALL",
        "archipack_custom_wall": "SOLIDWALL",
        "archipack_window": "WINDOW",
        "archipack_window_shutter": "SHUTTER",
        "archipack_door": "DOOR",
        # "archipack_slab": "FLOOR",
        # Stair type depends on landings, when > than 3 stair is USERDEFINED
        # "archipack_stair": "",
        # ArchiCad reference
        # Kitchen Cabinets           IfcFurnishingElement
        # Cabinet with Sink          IfcFlowTerminal > IfcSanitaryTerminalType with PredefinedType SINK.
        # Cabinet with Dishwasher    IfcFlowTerminal > IfcElectricApplianceType with PredefinedType DIRECTWATERHEATER.
        # "archipack_kitchen": "",
        # use IfcMember instead ??  as column / beam are direction dependants
        "archipack_beam": "COLUMN",
        # Moldings                   IfcCovering with PredefinedType as MOLDING on ceiling and SKIRTINGBOARD on floor
        "archipack_molding": "SKIRTINGBOARD",
        # FLOORING
        "archipack_floor": "FLOORING",
        "archipack_fence": "BALUSTRADE",
        "archipack_ceiling": "CEILING",
        # ShadingDevice is a 4x2 entity
        # "archipack_blind": "SHUTTER",
        "archipack_hole_geometry": "OPENING",
        "archipack_custom_hole": "OPENING",
        "archipack_roof": "GABLE_ROOF",
        "archipack_terrain": "TERRAIN"
    }
}


def get_body_context_id():
    if not ContextData.is_loaded:
        ContextData.load(IfcStore.get_file())
    for context in ContextData.contexts.values():
        for subcontext_id, subcontext in context["HasSubContexts"].items():
            if subcontext["ContextType"] == "Model" and subcontext["ContextIdentifier"] == "Body":
                return subcontext_id


def _filter_component(o):
    """
    :param o: child of main object
    :return: True if child object is not a component
    """
    if o.type != "MESH":
        return True
    d = ArchipackObjectsManager.archipack_datablock(o)
    key = ARCHIPACK_IfcExporter.get_key(o, d)
    if key is not None and (
        "cutter" in key or
        "area" in key or
        "hole" in key or
        "dimension" in key or
        "curtain" in key
    ):
        return True
    return False


def _get_components(o, components):
    for c in o.children:
        _get_components(c, components)
        # filter non components objects
        if _filter_component(c):
            continue
        components.append(c)


class ARCHIPACK_IfcExporterSettings:
    simplify_objects = True
    use_styles = False
    bake_boolean = False


class ARCHIPACK_IfcExporter(IfcExporter, ArchipackObjectsManager):

    def __init__(self, settings):

        IfcExporter.__init__(self, settings)

        self.exportable_objects = set()
        self.preprocessed_objects = set()
        self.preprocessed_alternate_representations = set()
        self.preprocessed_plan_unique_source_objects = set()

    # Class variables : Globally disable all 2d stuff
    # create_2d_representation = False
    # create_2d_axis = False
    # create_2d_footprint = False
    # create_2d_annotation = False  # plan 2d Symbols

    @classmethod
    def get_key(cls, o, d):
        key = None
        if d is not None:
            key = d.__class__.__name__
        elif cls.has_flag(o, ("hole", "custom_hole")):
            key = "archipack_hole_geometry"
        return key

    def get_component_key(self, o):
        d = self.archipack_datablock(o)
        key = self.get_key(o, d)
        return key, d

    def transverse(self, sel, apk):
        """ Transverse selection and filter archipack objects
        :param sel: array blender objects
        :param apk: dict: {archipack_class: {object, datablock}}
        :return: void
        """
        for o in sel:
            key, d = self.get_component_key(o)
            if key:
                if key not in apk:
                    apk[key] = {}
                apk[key][o] = d

    def rec_childs(self, o, ifc_childs, proxys):

        for c in o.children:

            if c.BIMObjectProperties.ifc_definition_id != 0:
                # exclude opening and skip nested storeys - should never happen, but who knows ?
                if c.name.startswith("IfcBuildingStorey") or c.name.startswith("IfcOpeningElement"):
                    continue
                ifc_childs.append(c)

            elif c.type == "MESH" and c in self.exportable_objects:
                proxys.append(c)

            self.rec_childs(c, ifc_childs, proxys)

    def classify(self, sel):

        building = self.find_object_by_name("Building")
        if building is None:
            return

        # find context_id
        body_context_id = get_body_context_id()
        if not body_context_id:
            return

        # assoc {archipack_class: {object: datablock}}
        apk = {}

        self.transverse(sel, apk)

        schema = bpy.context.scene.BIMProperties.export_schema

        # Filter out objects
        if ARCHIPACK_IfcExporterSettings.bake_boolean and "archipack_hole_geometry" in apk:
            del apk["archipack_hole_geometry"]

        if "archipack_hole" in apk:
            del apk["archipack_hole"]

        # remove child "lambris" part of roofs
        if "archipack_roof" in apk:
            to_remove = set()
            for o, d in apk['archipack_roof'].items():
                if d.schrinkwrap_target:
                    to_remove.add(o)
            for o in to_remove:
                del apk['archipack_roof'][o]

        # link in storey collection
        if "archipack_reference_point" in apk:
            to_remove = set()
            main = building.users_collection[0]
            for o, d in apk["archipack_reference_point"].items():

                if len(o.children) < 1:
                    to_remove.add(o)
                else:
                    name = self.cleanup_name(o.name)
                    coll = bpy.data.collections.get("IfcBuildingStorey/%s" % name)
                    if coll is None:
                        coll = bpy.data.collections.new("IfcBuildingStorey/%s" % name)

                    if coll.name not in main.children:
                        main.children.link(coll)

                    # relink
                    if o.name not in coll.objects:
                        coll.objects.link(o)

            # clear empty reference points
            for o in to_remove:
                del apk["archipack_reference_point"][o]

        # add class and representation
        for apk_cls, od in apk.items():
            if apk_cls in IFC_CLASS_MAP[schema]:

                ctx = {"selected_objects": list(od.keys())}
                args = {
                    "ifc_class": IFC_CLASS_MAP[schema][apk_cls],
                    "context_id": body_context_id
                }
                if apk_cls in PREDEFINED_TYPES[schema]:
                    args["predefined_type"] = PREDEFINED_TYPES[schema][apk_cls]

                bpy.ops.archipack.ifc_assign_class(ctx, **args)

        #  rel_void, rel_fill
        if not ARCHIPACK_IfcExporterSettings.bake_boolean:
            for key in ("wall", "wall2", "custom_wall"):
                if "archipack_%s" % key in apk:
                    for o, d in apk["archipack_%s" % key].items():
                        self._add_rel_void_and_fill(o)

        # Relationships rel_aggregate
        if "archipack_reference_point" in apk:

            for o, d in apk["archipack_reference_point"].items():

                # include all childs, recursive
                ifc_childs = []
                proxys = []

                self.rec_childs(o, ifc_childs, proxys)

                # classify furnitures as IfcBuildingProxy
                if len(proxys) > 0:
                    ctx = {"selected_objects": proxys}
                    bpy.ops.archipack.ifc_assign_class(ctx, **{
                        "ifc_class": IFC_CLASS_MAP[schema]["furniture"],
                        "context_id": body_context_id
                    })

                # Make ref point child of building from ifc point of view
                bpy.ops.archipack.ifc_assign_object(related_object=o.name, relating_object=building.name)

                # make childs child of storey from ifc point of view
                ifc_childs.extend(proxys)
                ctx = {'selected_objects': ifc_childs}
                bpy.ops.archipack.ifc_assign_object(ctx, relating_object=o.name)

    def _remove_geometry(self, o, flat, flat_names):
        if o in self.exportable_objects:
            self.exportable_objects.remove(o)
        if o.name in flat:
            del flat[o.name]
        if o.name in flat_names:
            flat_names.remove(o.name)

    def _add_filling(self, void, fill):
        element_id = void.BIMObjectProperties.ifc_definition_id
        ifc_fill = IfcStore.file.by_id(fill.BIMObjectProperties.ifc_definition_id)
        ifc_void = IfcStore.file.by_id(element_id)
        for rel_fill in ifc_void.HasFillings:
            if rel_fill.RelatedBuildingElement == ifc_fill:
                logger.debug("Skip fill %s %s" % (void.name, fill.name))
                return
        logger.debug("Add filling %s %s" % (void.name, fill.name))
        ifcopenshell.api.run(
            "void.add_filling",
            IfcStore.file,
            **{
                "opening": ifc_void,
                "element": ifc_fill,
            },
        )
        bpy.ops.bim.edit_object_placement(obj=fill.name)
        VoidData.load(IfcStore.get_file(), element_id)
        if DEBUG_VALIDATE:
            validate(IfcStore.get_file(), logger)

    def _add_opening(self, void, obj):
        element_id = obj.BIMObjectProperties.ifc_definition_id
        ifc_elem = IfcStore.file.by_id(element_id)
        ifc_void = IfcStore.file.by_id(void.BIMObjectProperties.ifc_definition_id)
        for rel_void in ifc_elem.HasOpenings:
            if rel_void.RelatedOpeningElement == ifc_void:
                # print("Skip hole", void.name, obj.name)
                logger.debug("Skip hole %s %s" % (void.name, obj.name))
                return
        logger.debug("Add opening %s %s" % (void.name, obj.name))
        # print("Add opening", void.name, obj.name)
        ifcopenshell.api.run(
            "void.add_opening",
            IfcStore.file,
            **{
                "opening": ifc_void,
                "element": ifc_elem,
            },
        )
        bpy.ops.bim.edit_object_placement(obj=void.name)
        VoidData.load(IfcStore.get_file(), element_id)
        if DEBUG_VALIDATE:
            validate(IfcStore.get_file(), logger)

    def _add_rel_void_and_fill(self, o):
        holes = []
        m = self.get_archipack_bool_modifier(o)

        if m is None:

            logger.debug("No holes found for %s" % o.name)
            return holes

        if m.type == 'BOOLEAN':
            if m.object and "archipack_hybridhole" in m.object:
                operand = m.object
                for mod in operand.modifiers:
                    if mod.type != 'BOOLEAN' or mod.object is None:
                        continue
                    hole = mod.object
                    self._add_opening(hole, o)
                    if hole.parent:
                        key, d = self.get_component_key(hole.parent)
                        if 'window' in key or 'door' in key:
                            self._add_filling(hole, hole.parent)
                    holes.append(hole)

        elif m.type == "NODES":
            for n in m.node_group.nodes:
                if n.type == "OBJECT_INFO" and n.inputs[0].default_value is not None:
                    hole = n.inputs[0].default_value
                    self._add_opening(hole, o)
                    if hole.parent:
                        key, d = self.get_component_key(hole.parent)
                        if 'window' in key or 'door' in key:
                            self._add_filling(hole, hole.parent)
                    holes.append(hole)

        return holes

    def pre_process_geometry(self, sel):
        # Store object name that require refresh after export

        # join components to match Ifc entity structure
        self.exportable_objects = set([o for o in sel if o.type in {'MESH', 'EMPTY'}])

        flat = {}
        flat_names = set()

        for o in self.exportable_objects:
            key, d = self.get_component_key(o)
            if key:
                flat[o.name] = tuple([o, key])
                flat_names.add(o.name)

        # keep track of processed mesh to prevent re-merge of components
        instances = set()
        schema = bpy.context.scene.BIMProperties.export_schema

        while len(flat_names) > 0:
            n = flat_names.pop()
            o, apk_cls = flat[n]

            # Filter out
            if (
                    apk_cls in {
                        "archipack_area",
                        "archipack_dimension_auto",
                        "archipack_hole",
                    } or
                    "cutter" in apk_cls or
                    ("hole_geometry" in apk_cls and ARCHIPACK_IfcExporterSettings.bake_boolean)
            ):
                # print("remove", o.name, "from exportables")
                self._remove_geometry(o, flat, flat_names)

            elif apk_cls in IFC_CLASS_MAP[schema]:

                # keep archipack containers
                if apk_cls in {'archipack_building'}:
                    continue

                elif apk_cls == 'archipack_reference_point':
                    # skip empty ref points
                    childs = [c for c in o.children if c in self.exportable_objects]
                    if len(childs) < 1:
                        self._remove_geometry(o, flat, flat_names)

                elif apk_cls in {'archipack_window', 'archipack_door', 'archipack_kitchen', 'archipack_roof'}:
                    # components are children of main object (including nested childs)
                    components = []
                    _get_components(o, components)
                    if len(components) > 0:
                        for c in components:
                            # remove merged geometry in list of entity to export
                            self._remove_geometry(c, flat, flat_names)

                        if not USE_LISTENERS and o.data.name not in instances:
                            logger.debug("Pre processing %s %s" % (apk_cls, o.name))
                            self.preprocessed_objects.add(o.name)
                            # Join geometry
                            with context_override(bpy.context, o, components) as ctx:
                                self.call_operator(bpy.context, ctx, bpy.ops.object.join, None, 'INVOKE_DEFAULT')
                                # bpy.ops.object.join(ctx, 'INVOKE_DEFAULT')
                    
                    instances.add(o.data.name)

                else:
                    instances.add(o.data.name)

    @staticmethod
    def find_object_by_name(name, clean_name=False):
        for o in bpy.data.objects:
            if o.name == name:
                return o
            if o.name.startswith("Ifc") and "/" in o.name and name == o.name.split("/")[-1]:
                if clean_name:
                    o.name =  "/".join(o.name.split("/")[1:])
                return o
        return bpy.data.objects.new(name, None)

    @classmethod
    def create_project(cls):
        file = IfcStore.get_file()
        if file:
            logger.debug("Create project skipped as a file is found")
            return file

        IfcStore.file = ifcopenshell.api.run(
            "project.create_file", **{"version": bpy.context.scene.BIMProperties.export_schema}
        )

        file = IfcStore.get_file()

        bpy.ops.bim.add_person()
        bpy.ops.bim.add_organisation()

        project = cls.find_object_by_name("Project", clean_name=True)
        bpy.ops.bim.assign_class(obj=project.name, ifc_class="IfcProject")

        # 4x2 require context for units
        bpy.ops.bim.assign_unit()

        bpy.ops.bim.add_subcontext(context="Model")
        bpy.ops.bim.add_subcontext(context="Model", subcontext="Body", target_view="MODEL_VIEW")
        bpy.ops.bim.add_subcontext(context="Model", subcontext="Box", target_view="MODEL_VIEW")

        bpy.ops.bim.add_subcontext(context="Plan")
        bpy.ops.bim.add_subcontext(context="Plan", subcontext="Axis", target_view="GRAPH_VIEW")
        bpy.ops.bim.add_subcontext(context="Plan", subcontext="FootPrint", target_view="PLAN_VIEW")
        bpy.ops.bim.add_subcontext(context="Plan", subcontext="Annotation", target_view="PLAN_VIEW")

        # subcontext = ifcopenshell.util.representation.get_context(file, "Model", "Body", "MODEL_VIEW")

        for subcontext in file.by_type("IfcGeometricRepresentationSubContext"):
            if subcontext.ContextIdentifier == "Body":
                bpy.context.scene.BIMProperties.contexts = str(subcontext.id())
                break

        site = cls.find_object_by_name("Site", clean_name=True)
        building = cls.find_object_by_name("Building", clean_name=True)

        bpy.ops.bim.assign_class(obj=site.name, ifc_class="IfcSite")
        bpy.ops.bim.assign_class(obj=building.name, ifc_class="IfcBuilding")
        bpy.ops.bim.assign_object(related_object=site.name, relating_object=project.name)
        bpy.ops.bim.assign_object(related_object=building.name, relating_object=site.name)

    def reset_file(self):

        for o in bpy.data.objects:
            if o.type in {'MESH', 'EMPTY'}:
                o.BIMObjectProperties.ifc_definition_id = 0
                if o.data:
                    o.data.BIMMeshProperties.ifc_definition_id = 0

        for m in bpy.data.materials:
            m.BIMMaterialProperties.ifc_style_id = False

        # prevent reload of file from disk !
        bpy.context.scene.BIMProperties.ifc_file = ""

        IfcStore.purge()
        purge_module_data()
        IfcStore.file = None

        # IfcStore.file = IfcStore.file.from_string("")

    def export(self):
        t = time.time()

        # XXX remove here by hand
        ifcopenshell.api.remove_pre_listener(
            "geometry.add_representation", "BlenderBIM.DumbWall.EnsureSolid", None
        )
        ifcopenshell.api.remove_pre_listener(
            "geometry.add_representation", "BlenderBIM.DumbSlab.EnsureSolid", None
        )

        if USE_SYNCH:
            Callbacks.disable()
            # Trigger representation update
            bpy.context.scene.BIMProjectProperties.is_authoring = True

        else:
            self.reset_file()

        self.create_project()

        self.preprocess()
        IfcExporter.export(self)
        self.postprocess()

        # self.reset_file()
        if USE_SYNCH:
            Callbacks.enable()

        # remove file so we are able to select a schema
        IfcStore.file = None

    def preprocess(self):
        # Add missing classes to objects
        sel = bpy.data.objects

        # Join mesh for archipack's objects
        self.pre_process_geometry(sel)

        t = time.time()
        # classify after pre process as it does create representations
        self.classify(sel)
        logger.debug("Classify %.4f" % (time.time() - t))

    def cleanup_name(self, name):
        if name.startswith("Ifc"):
            return "/".join(name.split("/")[1:])
        return name

    def cleanup_names(self):
        # [:] prevent infinite loop..
        for o in bpy.data.objects[:]:
            o.name = self.cleanup_name(o.name)

    def postprocess(self):

        logger.debug("Post process %s objects" % len(self.preprocessed_objects))

        # Disable throttle as object name change in the meantime
        prefs = get_prefs(bpy.context)
        last_state = prefs.throttle_enable
        prefs.throttle_enable = False

        # remove ifc prefix from objects names
        if not USE_SYNCH:
            self.cleanup_names()

        for name in self.preprocessed_objects:
            o = bpy.data.objects.get(name)
            logger.debug("Post processing %s" % name)

            if o is not None:
                d = self.archipack_datablock(o)
                if d is not None:
                    with context_override(bpy.context, o, [o]) as ctx:
                        d.update(ctx)

        for name in self.preprocessed_alternate_representations:
            o = self.get_scene_object(bpy.context, name)
            o.data.use_fake_user = False
            self.delete_object(bpy.context, o)

        prefs.throttle_enable = last_state


# Temporary swap between object data and temp mesh
preprocessed_mesh_assoc = {}
# Temporary bpy.data.mesh
temp_data_assoc = {}

EPSILON = 1e-6


def edit_attributes(obj, attr_value):
    oprops = obj.BIMObjectProperties
    product = IfcStore.get_file().by_id(oprops.ifc_definition_id)
    for attr, value in attr_value.items():
        setattr(product, attr, value)


def should_triangulate_face(face, threshold=EPSILON):
    vz = face.normal
    co = face.verts[0].co
    if vz.length < 0.5:
        return True
    if abs(vz.z) < 0.5:
        vx = vz.cross(Z_AXIS)
    else:
        vx = vz.cross(X_AXIS)
    vy = vx.cross(vz)
    tM = Matrix(
        [[vx.x, vy.x, vz.x, co.x], [vx.y, vy.y, vz.y, co.y], [vx.z, vy.z, vz.z, co.z], [0, 0, 0, 1]]
    ).inverted()
    return any([abs((tM @ v.co).z) > threshold for v in face.verts])


def evaluate_geometry(settings):
    # pre-evaluate geometry as blenderbim disable boolean modifiers
    # so we are able to bake booleans
    o = settings["blender_object"]

    if not ARCHIPACK_IfcExporterSettings.bake_boolean:
        m = ArchipackObjectsManager.get_archipack_bool_modifier(o)
        if m is not None:
            m.show_viewport = False

    # evaluate remaining modifiers
    mesh = o.evaluated_get(bpy.context.evaluated_depsgraph_get()).to_mesh()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    if settings["should_force_triangulation"]:
        faces = bm.faces
    else:
        faces = [f for f in bm.faces if should_triangulate_face(f)]
    if len(faces) > 0:
        bmesh.ops.triangulate(bm, faces=faces)
    bm.to_mesh(mesh)
    bm.free()
    del bm

    if not ARCHIPACK_IfcExporterSettings.bake_boolean:
        m = ArchipackObjectsManager.get_archipack_bool_modifier(o)
        if m is not None:
            m.show_viewport = True

    temp_data_assoc[o] = mesh.name
    settings["geometry"] = mesh


def preprocess_body_representation(usecase_path, ifc_file, settings):
    context = settings['context']
    if (context.ContextType == "Model"
            and context.ContextIdentifier
            and context.ContextIdentifier == "Body"
    ):
        o = settings['blender_object']
        prefs = get_prefs(bpy.context)
        last_state = prefs.throttle_enable, prefs.auto_synch
        prefs.throttle_enable = False
        prefs.auto_synch = False

        d = ArchipackObjectsManager.archipack_datablock(o)
        if d is not None:
            key = ARCHIPACK_IfcExporter.get_key(o, d)

            if ARCHIPACK_IfcExporterSettings.simplify_objects:
                if key in {"archipack_wall2", "archipack_floor"} or (
                        key == "archipack_roof" and not d.schrinkwrap_target
                ):
                    # preprocessed_mesh_assoc[o] = o.data.name
                    settings["ifc_representation_class"] = None

                    # May use extruded area solid for walls
                    # if key == "archipack_wall2" and not ARCHIPACK_IfcExporterSettings.bake_booleans:
                    #    if all([s.z == 0 for p in d.parts for s in p.slices]):
                    #        settings["ifc_representation_class"] = "IfcExtrudedAreaSolid/IfcArbitraryClosedProfileDef"

                    with context_override(bpy.context, o, [o]) as ctx:
                        tmp = o.data
                        o.data = d.ifc_representation(ctx, o, representation_id="Body")
                        evaluate_geometry(settings)
                        o.data = tmp

            elif key == "archipack_wall2":
                settings["ifc_representation_class"] = None
                evaluate_geometry(settings)

            if key in {"archipack_window", "archipack_door", "archipack_kitchen"}:
                # preprocessed_mesh_assoc[o] = o.data.name
                settings["ifc_representation_class"] = None

                with context_override(bpy.context, o, [o]) as ctx:
                    tmp = o.data
                    o.data = d.ifc_representation(ctx, o, representation_id="Body")
                    evaluate_geometry(settings)
                    o.data = tmp
            elif (
                key == "archipack_roof" and
                (not d.schrinkwrap_target) and
                (not ARCHIPACK_IfcExporterSettings.simplify_objects)
            ):
                components = []
                _get_components(o, components)
                if len(components) > 0:
                    t = time.time()
                    with context_override(bpy.context, o, components) as ctx:
                        if bpy.app.version[0] > 3:
                            with bpy.context.temp_override(**ctx):
                                bpy.ops.object.join('INVOKE_DEFAULT')
                        else:
                            bpy.ops.object.join(ctx, 'INVOKE_DEFAULT')
                    logger.debug("Join geometry of %s %.4f sec" % (o.name, time.time() - t))

            # Keep objects attributes in synch
            if key in {"archipack_window", "archipack_door"}:
                attrs = {
                    "OverallHeight": round(d.z, 4),
                    "OverallWidth": round(d.x, 4)
                }

                if key == "archipack_door":
                    if d.n_panels > 1:
                        attrs["OperationType"] = "DOUBLE_DOOR_SINGLE_SWING"
                    elif d.direction == 0:
                        attrs["OperationType"] = "SINGLE_SWING_LEFT"
                    else:
                        attrs["OperationType"] = "SINGLE_SWING_RIGHT"

                edit_attributes(o, attrs)

        prefs.throttle_enable, prefs.auto_synch = last_state


def postprocess_body_representation(usecase_path, ifc_file, settings):
    context = settings['context']
    if (context.ContextType == "Model"
            and context.ContextIdentifier
            and context.ContextIdentifier == "Body"
    ):
        o = settings['blender_object']
        prefs = get_prefs(bpy.context)
        last_state = prefs.throttle_enable, prefs.auto_synch
        prefs.throttle_enable = False
        prefs.auto_synch = False

        d = ArchipackObjectsManager.archipack_datablock(o)
        if d is not None:
            key = ARCHIPACK_IfcExporter.get_key(o, d)

            if o in preprocessed_mesh_assoc:
                o.data = bpy.data.meshes.get(preprocessed_mesh_assoc[o])
                del preprocessed_mesh_assoc[o]

            if o in temp_data_assoc:
                tmp = bpy.data.meshes.get(temp_data_assoc[o])
                bpy.data.meshes.remove(tmp)
                del temp_data_assoc[o]

            if (
                key == "archipack_roof" and
                (not d.schrinkwrap_target) and
                (not ARCHIPACK_IfcExporterSettings.simplify_objects)
                ):
                t = time.time()
                with context_override(bpy.context, o, [o]) as ctx:
                    d.update(ctx)
                logger.debug("Restore %s %.4f sec" % (o.name, time.time() - t))

        prefs.throttle_enable, prefs.auto_synch = last_state


def eval_georeference(ifc_file, matrix):
    mat = np.array(matrix)
    props = bpy.context.scene.BIMGeoreferenceProperties
    if props.has_blender_offset and props.blender_offset_type == "OBJECT_PLACEMENT":
        unit_scale = ifcopenshell.util.unit.calculate_unit_scale(ifc_file)
        return np.array(
            ifcopenshell.util.geolocation.local2global(
                mat,
                float(props.blender_eastings) * unit_scale,
                float(props.blender_northings) * unit_scale,
                float(props.blender_orthogonal_height) * unit_scale,
                float(props.blender_x_axis_abscissa),
                float(props.blender_x_axis_ordinate),
            )
        )
    return mat


def preprocess_object_placement(usecase_path, ifc_file, settings):
    # "product": self.file.by_id(obj.BIMObjectProperties.ifc_definition_id),
    product = settings['product']
    if product.GlobalId in IfcStore.guid_map:
        o = IfcStore.guid_map[product.GlobalId]
        d = ARCHIPACK_IfcExporter.archipack_datablock(o)
        if d is not None:
            key = ARCHIPACK_IfcExporter.get_key(o, d)
            if key in {'archipack_window', 'archipack_door'}:
                if key == "archipack_door":
                    # translate origin to wall's and door limit
                    offset = Matrix.Translation(-0.5 * Vector((d.x, d.y, 0)))
                else:   # key == "archipack_window":
                    offset = Matrix.Translation(-0.5 * Vector((0, d.y, 0)))
                settings['matrix'] = eval_georeference(ifc_file, o.matrix_world @ offset)


def generate_axis(usecase_path, ifc_file, settings):
    context = settings['context']
    if (context.ContextType == "Model"
            and context.ContextIdentifier
            and context.ContextIdentifier == "Axis"
        ):

        axis_context = ifcopenshell.util.representation.get_context(ifc_file, "Model", "Axis", "GRAPH_VIEW")
        if not axis_context:
            return
        o = settings["blender_object"]

        d = ArchipackObjectsManager.archipack_datablock(o)
        if d is not None:
            key = ARCHIPACK_IfcExporter.get_key(o, d)
            if key in {'archipack_wall2'}:

                logger.debug("generate_axis for %s" % o.name)

                product = ifc_file.by_id(o.BIMObjectProperties.ifc_definition_id)

                old_axis = ifcopenshell.util.representation.get_representation(product, "Model", "Axis", "GRAPH_VIEW")

                if old_axis:
                    bpy.ops.bim.remove_representation(representation_id=old_axis.id(), obj=o.name)

                new_settings = settings.copy()
                new_settings["context"] = axis_context
                curve =  d.ifc_representation(bpy.context, o, representation_id ="Axis")
                new_settings["geometry"] = curve

                new_axis = ifcopenshell.api.run(
                    "geometry.add_representation", ifc_file, should_run_listeners=False, **new_settings
                )
                ifcopenshell.api.run(
                    "geometry.assign_representation",
                    ifc_file,
                    should_run_listeners=False,
                    **{"product": product, "representation": new_axis}
                )
                man = ArchipackObjectsManager()
                man.delete_object(bpy.context, curve)


def generate_footprint(usecase_path, ifc_file, settings):
    context = settings['context']
    if (context.ContextType == "Model"
            and context.ContextIdentifier
            and context.ContextIdentifier == "FootPrint"
        ):

        footprint_context = ifcopenshell.util.representation.get_context(ifc_file, "Model", "FootPrint", "PLAN_VIEW")
        if not footprint_context:
            return
        o = settings["blender_object"]

        d = ArchipackObjectsManager.archipack_datablock(o)
        if d is not None:
            key = ARCHIPACK_IfcExporter.get_key(o, d)
            if key in {'archipack_wall2'}:

                logger.debug("generate_footprint for %s" % o.name)

                product = ifc_file.by_id(o.BIMObjectProperties.ifc_definition_id)

                old_footprint = ifcopenshell.util.representation.get_representation(
                    product, "Model", "FootPrint", "PLAN_VIEW"
                )

                if old_footprint:
                    bpy.ops.bim.remove_representation(representation_id=old_footprint.id(), obj=o.name)

                new_settings = settings.copy()
                new_settings["context"] = footprint_context
                curve =  d.ifc_representation(bpy.context, o, representation_id ="FootPrint")
                new_settings["geometry"] = curve

                new_footprint = ifcopenshell.api.run(
                    "geometry.add_representation", ifc_file, should_run_listeners=False, **new_settings
                )
                ifcopenshell.api.run(
                    "geometry.assign_representation",
                    ifc_file,
                    should_run_listeners=False,
                    **{"product": product, "representation": new_footprint}
                )
                man = ArchipackObjectsManager()
                man.delete_object(bpy.context, curve)


def calculate_quantities(usecase_path, ifc_file, settings):

    o = settings["blender_object"]
    d = ArchipackObjectsManager.archipack_datablock(o)
    if d is not None:
        key = ARCHIPACK_IfcExporter.get_key(o, d)
        if key in {'archipack_wall2'}:

            unit_scale = ifcopenshell.util.unit.calculate_unit_scale(ifc_file)
            product = ifc_file.by_id(o.BIMObjectProperties.ifc_definition_id)

            qto = ifcopenshell.api.run(
                "pset.add_qto", ifc_file, should_run_listeners=False, product=product, name="Qto_WallBaseQuantities"
            )
            g = d.get_generator()
            length = g.axis.length / unit_scale
            width = d.width / unit_scale
            height = d.z / unit_scale

            gross_volume = g.volume(d)
            if product.HasOpenings:
                net_volume = 0
            else:
                net_volume = gross_volume

            ifcopenshell.api.run(
                "pset.edit_qto",
                ifc_file,
                should_run_listeners=False,
                qto=qto,
                properties={
                    "Length": round(length, 2),
                    "Width": round(width, 2),
                    "Height": round(height, 2),
                    "GrossVolume": round(gross_volume, 2),
                    "NetVolume": round(net_volume, 2),
                },
            )
            PsetData.load(ifc_file, o.BIMObjectProperties.ifc_definition_id)

        # Area object's qto
        # g = d.get_generator()
        # perimeter = g.length
        # floor_area = g.area
        # volume = d.height * floor_area
        # wall_area = d.height * perimeter
        # return {
        #     "Length": round(perimeter, 2),
        #     "Height": round(d.height, 2),
        #     "Volume": round(volume, 2),
        #     "Wall": round(wall_area, 2),
        #     "Floor": round(floor_area, 2)
        # }


if USE_LISTENERS:

    @persistent
    def remove_listeners(dummy=None):
        ifcopenshell.api.remove_pre_listener(
            "geometry.add_representation",
            "Archipack.preprocess_body_representation",
            preprocess_body_representation
        )
        ifcopenshell.api.remove_post_listener(
            "geometry.add_representation",
            "Archipack.postprocess_body_representation",
            postprocess_body_representation
        )
        ifcopenshell.api.remove_post_listener(
            "geometry.add_representation",
            "Archipack.generate_axis",
            generate_axis
        )
        ifcopenshell.api.remove_post_listener(
            "geometry.add_representation",
            "Archipack.generate_footprint",
            generate_footprint
        )
        ifcopenshell.api.remove_post_listener(
            "geometry.add_representation",
            "Archipack.calculate_quantities",
            calculate_quantities
        )
        ifcopenshell.api.remove_pre_listener(
            "geometry.edit_object_placement",
            "Archipack.preprocess_object_placement",
            preprocess_object_placement
        )

    @persistent
    def add_listeners(dummy=None):
        ifcopenshell.api.add_pre_listener(
            "geometry.add_representation",
            "Archipack.preprocess_body_representation",
            preprocess_body_representation
        )
        ifcopenshell.api.add_post_listener(
            "geometry.add_representation",
            "Archipack.postprocess_body_representation",
            postprocess_body_representation
        )
        ifcopenshell.api.add_post_listener(
            "geometry.add_representation",
            "Archipack.generate_footprint",
            generate_footprint
        )
        ifcopenshell.api.add_post_listener(
            "geometry.add_representation",
            "Archipack.generate_axis",
            generate_axis
        )
        ifcopenshell.api.add_post_listener(
            "geometry.add_representation",
            "Archipack.calculate_quantities",
            calculate_quantities
        )
        ifcopenshell.api.add_pre_listener(
            "geometry.edit_object_placement",
            "Archipack.preprocess_object_placement",
            preprocess_object_placement
        )


class ARCHIPACK_OT_IfcAddRepresentation(Operator):
    bl_idname = "archipack.ifc_add_representation"
    bl_label = "Add Representation"
    obj: StringProperty()
    context_id: IntProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.obj) if self.obj else bpy.context.active_object
        self.file = IfcStore.get_file()

        bpy.ops.bim.edit_object_placement(obj=obj.name)

        if obj.data:
            product = self.file.by_id(obj.BIMObjectProperties.ifc_definition_id)
            context_id = self.context_id or int(bpy.context.scene.BIMProperties.contexts)
            context_of_items = self.file.by_id(context_id)

            gprop = context.scene.BIMGeoreferenceProperties
            coordinate_offset = None
            if gprop.has_blender_offset and gprop.blender_offset_type == "CARTESIAN_POINT":
                coordinate_offset = Vector(
                    (
                        float(gprop.blender_eastings),
                        float(gprop.blender_northings),
                        float(gprop.blender_orthogonal_height),
                    )
                )

            should_force_triangulation = context.scene.BIMGeometryProperties.should_force_triangulation

            representation_data = {
                "context": context_of_items,
                "blender_object": obj,
                "geometry": obj.data,
                "coordinate_offset": coordinate_offset,
                "total_items": max(1, len(obj.material_slots)),
                "should_force_faceted_brep": context.scene.BIMGeometryProperties.should_force_faceted_brep,
                "should_force_triangulation":should_force_triangulation,
            }

            if not ARCHIPACK_IfcExporterSettings.use_styles:
                representation_data["total_items"] = 1
            
            result = ifcopenshell.api.run("geometry.add_representation", self.file, **representation_data)

            if not result:
                logger.debug("Failed to write shape representation")
                return {"FINISHED"}

            if ARCHIPACK_IfcExporterSettings.use_styles:
                [
                    bpy.ops.bim.add_style(material=s.material.name)
                    for s in obj.material_slots
                    if not s.material.BIMMaterialProperties.ifc_style_id
                ]

                ifcopenshell.api.run(
                    "geometry.assign_styles",
                    self.file,
                    **{
                        "shape_representation": result,
                        "styles": [
                            self.file.by_id(s.material.BIMMaterialProperties.ifc_style_id)
                            for s in obj.material_slots
                            if s.material
                        ],
                        "should_use_presentation_style_assignment": context.scene.BIMGeometryProperties.should_use_presentation_style_assignment,
                    },
                )

            ifcopenshell.api.run(
                "geometry.assign_representation", self.file, **{"product": product, "representation": result}
            )

            # does make sense only in dynamic export mode
            if USE_SYNCH:
                mesh = obj.data.copy()
                mesh.name = "{}/{}".format(context_id, result.id())
                mesh.BIMMeshProperties.ifc_definition_id = int(result.id())
                obj.data = mesh

        GeometryData.load(IfcStore.get_file(), obj.BIMObjectProperties.ifc_definition_id)
        return {"FINISHED"}


class ARCHIPACK_OT_IfcRemoveProduct(Operator, ArchipackObjectsManager):
    bl_idname = "archipack.ifc_remove_product"
    bl_label = "Remove IFC Product"
    bl_options = {'REGISTER', 'UNDO'}
    obj: StringProperty()

    def execute(self, context):
        objects = [bpy.data.objects.get(self.obj)] if self.obj else context.selected_objects

        for o in objects:
            element_id = o.BIMObjectProperties.ifc_definition_id

            if element_id != 0:

                o.BIMObjectProperties.ifc_definition_id = 0

                file = IfcStore.get_file()
                product = file.by_id(element_id)

                IfcStore.unlink_element(product)

                d = self.archipack_datablock(o)
                key = ARCHIPACK_IfcExporter.get_key(o, d)

                ref = self.get_reference_point(o)

                if ref and ref.BIMObjectProperties.ifc_definition_id:
                    logger.debug("aggregate.unassign_object")
                    relating_object = file.by_id(ref.BIMObjectProperties.ifc_definition_id)
                    ifcopenshell.api.run("aggregate.unassign_object", file,
                        **{"product": product, "relating_object":relating_object}
                    )
                    del AggregateData.products[element_id]

                if key == "archipack_reference_point":
                    logger.debug("spatial.remove_container")
                    ifcopenshell.api.run("spatial.remove_container", file, **{"product": product})

                elif key == "archipack_hole":
                    # opening cant exists without relationship, so this will also remove the product
                    logger.debug("remove opening")
                    if element_id in VoidData.openings:
                        del VoidData.openings[element_id]

                    for rel in file.by_type("IfcRelVoidsElement"):
                        opening = rel.RelatedOpeningElement
                        if opening != product:
                            continue
                        building_element = rel.RelatingBuildingElement
                        building_element_id = int(building_element.id())
                        opening_id = int(opening.id())
                        if opening_id in VoidData.products[building_element_id]:
                            VoidData.products[building_element_id].remove(opening_id)

                    for rel in file.by_type("IfcRelFillsElement"):
                        opening = rel.RelatingOpeningElement
                        opening_id = int(opening.id())
                        if opening_id != element_id:
                            continue

                        filling = rel.RelatedBuildingElement
                        filling_id = int(filling.id())

                        if filling_id in VoidData.fillings:
                            del VoidData.fillings[filling_id]

                    ifcopenshell.api.run("void.remove_opening", file, **{"opening": product})

                else:

                    # takes care of all representations
                    # but no other relationships / object placement
                    logger.debug("root.remove_product")
                    # SEGMENTATION_ERROR
                    ifcopenshell.api.run("root.remove_product", file, **{"product": product})
                    logger.debug("done")

                # Note: you can't access to product after this point.

        return {'FINISHED'}


class ARCHIPACK_OT_IfcAssignClass(Operator, ArchipackObjectsManager):
    bl_idname = "archipack.ifc_assign_class"
    bl_label = "Assign IFC Class"
    bl_options = {'REGISTER', 'UNDO'}
    obj: StringProperty()
    ifc_class: StringProperty()
    predefined_type: StringProperty()
    userdefined_type: StringProperty()
    context_id: IntProperty()

    def execute(self, context):
        objects = [bpy.data.objects.get(self.obj)] if self.obj else context.selected_objects
        logger.debug("Assign class %s to %s objects" % (self.ifc_class, len(objects)))
        self.file = IfcStore.get_file()
        self.declaration = IfcStore.get_schema().declaration_by_name(self.ifc_class)
        if self.predefined_type == "USERDEFINED":
            self.predefined_type = self.ifc_userdefined_type
        elif self.predefined_type == "":
            predefined_type = None

        for obj in objects:
            if hasattr(obj, "material_slots"):
                for slot in obj.material_slots:
                    if slot.material is not None and not slot.material.BIMMaterialProperties.ifc_style_id:
                        bpy.ops.bim.add_style(material=slot.material.name)
            self.assign_class(context, obj)
        return {"FINISHED"}

    def assign_class(self, context, obj):
        t = time.time()
        if "/" in obj.name and obj.name[0:3] == "Ifc":
            name = "/".join(obj.name.split("/")[1:])
        else:
            name = obj.name

        if obj.BIMObjectProperties.ifc_definition_id:
            logger.debug("Assign class skip %s to %s" % (self.ifc_class, name))
            return

        product = ifcopenshell.api.run(
            "root.create_entity",
            self.file,
            **{
                "ifc_class": self.ifc_class,
                "predefined_type": self.predefined_type,
                "name": name,
            },
        )

        obj.name = "{}/{}".format(product.is_a(), name)

        IfcStore.link_element(product, obj)

        if not ARCHIPACK_IfcExporterSettings.bake_boolean:
            m = self.get_archipack_bool_modifier(obj)
            if m is not None:
                # Disable so wall representation is evaluated without holes
                m.show_viewport = False

        if obj.type != "MESH" or (obj.data and len(obj.data.polygons) > 0):
            bpy.ops.archipack.ifc_add_representation(
                obj=obj.name,
                context_id=self.context_id
            )

        if not ARCHIPACK_IfcExporterSettings.bake_boolean:
            m = self.get_archipack_bool_modifier(obj)
            if m is not None:
                # Re-Enable boolean modifier
                m.show_viewport = True

        logger.debug("Assign class %s to %s %.4f sec" % (self.ifc_class, name, time.time() - t))

        if product.is_a("IfcElementType"):
            self.place_in_types_collection(obj)
        elif (
            product.is_a("IfcSpatialElement")
            or product.is_a("IfcSpatialStructureElement")
            or product.is_a("IfcProject")
            or product.is_a("IfcContext")
        ):
            self.place_in_spatial_collection(obj)
        else:
            self.assign_potential_spatial_container(obj)
        # context.view_layer.objects.active = obj

    def place_in_types_collection(self, obj):

        for project in [c for c in bpy.context.view_layer.layer_collection.children if "IfcProject" in c.name]:
            if not [c for c in project.children if "Types" in c.name]:
                types = bpy.data.collections.new("Types")
                project.collection.children.link(types)
            for collection in [c for c in project.children if "Types" in c.name]:
                for user_collection in obj.users_collection:
                    user_collection.objects.unlink(obj)
                collection.collection.objects.link(obj)
                break
            break

    def place_in_spatial_collection(self, obj):

        for collection in obj.users_collection:
            if obj.name in collection.name:
                return

        parent_collection = None
        for collection in obj.users_collection:
            if "Ifc" in collection.name:
                # Only unlink from Ifc collections
                collection.objects.unlink(obj)
                parent_collection = collection

        collection = bpy.data.collections.new(obj.name)
        collection.objects.link(obj)

        if parent_collection:
            parent_collection.children.link(collection)
            bpy.ops.archipack.ifc_assign_object(related_object=obj.name, relating_object=parent_collection.name)
        else:
            bpy.context.scene.collection.children.link(collection)

    def assign_potential_spatial_container(self, obj):
        for collection in obj.users_collection:
            if "Ifc" not in collection.name or collection.name == obj.name:
                continue

            spatial_obj = bpy.data.objects.get(collection.name)
            if spatial_obj and spatial_obj.BIMObjectProperties.ifc_definition_id:
                logger.debug("Assign container %s %s" % (spatial_obj.name, obj.name))
                bpy.ops.bim.assign_container(
                    relating_structure=spatial_obj.BIMObjectProperties.ifc_definition_id, related_element=obj.name
                )
                break


class ARCHIPACK_OT_IfcAssignObject(Operator):
    bl_idname = "archipack.ifc_assign_object"
    bl_label = "Assign Object"
    relating_object: StringProperty()
    related_object: StringProperty()

    def rel_exists(self, product, ifc_relating):
        for rel in product.Decomposes:
            if rel.RelatingObject == ifc_relating:
                return True
        return False

    def execute(self, context):

        related_objects = (
            [bpy.data.objects.get(self.related_object)] if self.related_object else context.selected_objects
        )
        relating_object = bpy.data.objects.get(self.relating_object)

        if not relating_object or not relating_object.BIMObjectProperties.ifc_definition_id:
            return {"CANCELLED"}

        file = IfcStore.get_file()

        ifc_relating = file.by_id(relating_object.BIMObjectProperties.ifc_definition_id)

        for related_object in related_objects:

            oprops = related_object.BIMObjectProperties
            product = file.by_id(oprops.ifc_definition_id)

            if self.rel_exists(product, ifc_relating):
                logger.debug("rel_exists: skip %s %s" % (self.relating_object, related_object.name))
                continue

            logger.debug("aggregate.assign_object %s %s" % (self.relating_object, related_object.name))

            ifcopenshell.api.run(
                "aggregate.assign_object",
                file,
                **{
                    "product": product,
                    "relating_object": ifc_relating,
                },
            )
            bpy.ops.bim.edit_object_placement(obj=related_object.name)

            AggregateData.load(IfcStore.get_file(), oprops.ifc_definition_id)

        # self.edit_object_placement(file, relating_object, related_objects)

        return {"FINISHED"}


def delete_cb(context, o, d):
    if d is None:
        d = ArchipackObjectsManager.archipack_datablock(o)
    key = ARCHIPACK_IfcExporter.get_key(o, d)
    schema = bpy.context.scene.BIMProperties.export_schema
    if key in IFC_CLASS_MAP[schema]:
        bpy.ops.archipack.ifc_remove_product(obj=o.name)


def create_cb(context, o, d):
    ARCHIPACK_IfcExporter.create_project()
    # add_listeners()
    if d is None:
        d = ArchipackObjectsManager.archipack_datablock(o)
    key = ARCHIPACK_IfcExporter.get_key(o, d)
    schema = bpy.context.scene.BIMProperties.export_schema
    if o.BIMObjectProperties.ifc_definition_id == 0 and key in IFC_CLASS_MAP[schema]:
        body_context_id = get_body_context_id()
        if not body_context_id:
            return
        args = {
            "obj": o.name,
            "ifc_class": IFC_CLASS_MAP[schema][key],
            "context_id": body_context_id
        }
        if key in PREDEFINED_TYPES[schema]:
            args["predefined_type"] = PREDEFINED_TYPES[schema][key]
        bpy.ops.archipack.ifc_assign_class(**args)


def copy_cb(context, o, d):
    # @TODO: implement direct blenderbim copy operator here once available
    if d is None:
        d = ArchipackObjectsManager.archipack_datablock(o)
    schema = bpy.context.scene.BIMProperties.export_schema
    key = ARCHIPACK_IfcExporter.get_key(o, d)
    if key in IFC_CLASS_MAP[schema]:
        o.BIMObjectProperties.ifc_definition_id = 0
        create_cb(context, o, d)


def update_cb(context, o, d):
    if d is None:
        d = ArchipackObjectsManager.archipack_datablock(o)
    schema = bpy.context.scene.BIMProperties.export_schema
    key = ARCHIPACK_IfcExporter.get_key(o, d)
    if key in IFC_CLASS_MAP[schema]:
        IfcStore.edited_objs.add(o.name)


def unique_cb(context, o, d):
    if not o.BIMObjectProperties.ifc_definition_id:
        return
    bpy.ops.archipack.ifc_remove_product(obj=o.name)
    if "/" in o.name and o.name[0:3] == "Ifc":
        o.name = "/".join(o.name.split("/")[1:])
    create_cb(context, o, d)


def setup_handlers():
    Callbacks.add("create", create_cb)
    Callbacks.add("copy",   copy_cb)
    Callbacks.add("update", update_cb)
    Callbacks.add("unique", unique_cb)
    Callbacks.add("delete", delete_cb)
    # Temporary disable callbacks until remove elements stabilize
    if not USE_SYNCH:
        Callbacks.disable()


def get_force_triangulation(self):
    return bpy.context.scene.BIMGeometryProperties.should_force_triangulation


def set_force_triangulation(self, value):
    bpy.context.scene.BIMGeometryProperties.should_force_triangulation = value


def get_bake_boolean(self):
    return ARCHIPACK_IfcExporterSettings.bake_boolean


def set_bake_boolean(self, value):
    ARCHIPACK_IfcExporterSettings.bake_boolean = value


def get_use_styles(self):
    return ARCHIPACK_IfcExporterSettings.use_styles


def set_use_styles(self, value):
    ARCHIPACK_IfcExporterSettings.use_styles = value


def get_simplify_objects(self):
    return ARCHIPACK_IfcExporterSettings.simplify_objects


def set_simplify_objects(self, value):
    ARCHIPACK_IfcExporterSettings.simplify_objects = value


class ARCHIPACK_OT_IfcBuildRepresentation(ArchipackCreateTool, Operator):
    bl_idname = "archipack.ifc_build_representation"
    bl_label = "Create Ifc representation"
    bl_description = "Create and display ifc body representation for current object(s)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def build_representation(self, context, o):
        d = self.archipack_datablock(o)
        if d is not None and hasattr(d, "ifc_representation"):
            key = ARCHIPACK_IfcExporter.get_key(o, d)
            me = d.ifc_representation(context, o, representation_id="Body")
            new_o, me = self.create_mesh("%s/%s" % (IFC_CLASS_MAP['IFC4'][key], o.name), mesh=me)
            new_o.matrix_world = o.matrix_world.copy()
            self.link_object_to_scene(context, new_o, layer_name="Ifc_Body")

    def execute(self, context):
        o = context.active_object
        for o in context.selected_objects:
            self.build_representation(context, o)
        return {'FINISHED'}


class ARCHIPACK_IO_ExportIfc(Operator):
    bl_idname = "archipack.export_ifc"
    bl_label = "Industry Foundation Classes (archipack) (.ifc)"
    bl_description = "Industry Foundation Classes ASCII"
    filename_ext = ".ifc"
    filter_glob: StringProperty(default="*.ifc;*.ifczip;*.ifcxml;*.ifcjson", options={"HIDDEN"})
    filepath: StringProperty(subtype="FILE_PATH")
    json_version: EnumProperty(items=[("4", "4", ""), ("5a", "5a", "")], name="IFC JSON Version")
    json_compact: BoolProperty(name="Export Compact IFCJSON", default=False)


    force_triangulation: BoolProperty(
        name="Force triangulation",
        description="Force triangulation of representations\n"\
            "This is a vendor workaround, when enabled it does create bigger files.",
        default=False,
        get=get_force_triangulation,
        set=set_force_triangulation,
    )

    bake_boolean: BoolProperty(
        name="Bake booleans",
        get=get_bake_boolean,
        set=set_bake_boolean,
        default=False,
        description="Apply Voids to walls and remove IfcOpeningElement.\n"\
            "This is a vendor workaround, should remain disabled by default.",
    )
    use_styles: BoolProperty(
        name="Use styles",
        get=get_use_styles,
        set=set_use_styles,
        default=False,
        description="Export surface styles as IfcStyledItems.\n"\
            "This is a blenderbim experimental feature, not supported everywhere, so off by default"
    )

    simplify_objects: BoolProperty(
        name="Simplify objects",
        get=get_simplify_objects,
        set=set_simplify_objects,
        description="Simplify complex objects representations",
        default=False
    )

    # create_2d_representation: BoolProperty(
    #     name="Create 2d representation",
    #     description="Export 2d axis / footprint / annotations",
    #     default=False
    # )
    # create_2d_axis: BoolProperty(default=False)
    # create_2d_footprint: BoolProperty(default=False)
    # create_2d_annotation: BoolProperty(default=False)

    def invoke(self, context, event):
        if context.scene.BIMProperties.ifc_file:
            self.filepath = context.scene.BIMProperties.ifc_file
        if not self.filepath:
            self.filepath = bpy.path.ensure_ext(bpy.data.filepath, ".ifc")
        WindowManager = context.window_manager
        WindowManager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        context.window.cursor_set("WAIT")
        start = time.time()
        # logger = logging.getLogger("ExportIFC")
        # logging.basicConfig(
        #     filename=context.scene.BIMProperties.data_dir + "process.log", filemode="a", level=logging.DEBUG
        # )

        extension = self.filepath.split(".")[-1]
        if extension == "ifczip":
            output_file = bpy.path.ensure_ext(self.filepath, ".ifczip")
        elif extension == "ifcjson":
            output_file = bpy.path.ensure_ext(self.filepath, ".ifcjson")
        else:
            output_file = bpy.path.ensure_ext(self.filepath, ".ifc")

        settings = blenderbim_exporter.export_ifc.IfcExportSettings.factory(context, output_file, logger)
        settings.json_version = self.json_version
        settings.json_compact = self.json_compact

        ifc_exporter = ARCHIPACK_IfcExporter(settings)

        # Experimental
        # ifc_exporter.create_2d_representation = self.create_2d_representation
        # ifc_exporter.create_2d_axis = self.create_2d_representation
        # ifc_exporter.create_2d_footprint = self.create_2d_representation
        # ifc_exporter.create_2d_annotation = self.create_2d_representation  # plan 2d Symbols

        logger.info("Starting export")
        ifc_exporter.export()
        logger.info("Export finished in {:.2f} seconds".format(time.time() - start))

        print("Export finished in {:.2f} seconds\n\n".format(time.time() - start))

        self.report({"INFO"}, "Export finished in {:.2f} seconds".format(time.time() - start))
        # if not context.scene.DocProperties.ifc_files:
        #     new = context.scene.DocProperties.ifc_files.add()
        #     new.name = output_file
        #
        # if not context.scene.BIMProperties.ifc_file:
        #     context.scene.BIMProperties.ifc_file = output_file

        # if bpy.data.is_saved and bpy.data.is_dirty and bpy.data.filepath:
        #    bpy.ops.wm.save_mainfile(filepath=bpy.data.filepath)
        context.window.cursor_set("DEFAULT")

        return {"FINISHED"}


def menu_func_export(self, context):
    self.layout.operator(ARCHIPACK_IO_ExportIfc.bl_idname, text=ARCHIPACK_IO_ExportIfc.bl_label)


def register():
    bpy.utils.register_class(ARCHIPACK_OT_IfcAssignClass)
    bpy.utils.register_class(ARCHIPACK_OT_IfcAssignObject)
    bpy.utils.register_class(ARCHIPACK_OT_IfcRemoveProduct)
    bpy.utils.register_class(ARCHIPACK_OT_IfcAddRepresentation)
    bpy.utils.register_class(ARCHIPACK_IO_ExportIfc)
    bpy.utils.register_class(ARCHIPACK_OT_IfcBuildRepresentation)

    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    if USE_LISTENERS:
        load_post.append(add_listeners)
        load_pre.append(remove_listeners)
    if USE_SYNCH:
        setup_handlers()


def unregister():
    import bpy
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(ARCHIPACK_OT_IfcAssignClass)
    bpy.utils.unregister_class(ARCHIPACK_OT_IfcAssignObject)
    bpy.utils.unregister_class(ARCHIPACK_OT_IfcRemoveProduct)
    bpy.utils.unregister_class(ARCHIPACK_OT_IfcAddRepresentation)
    bpy.utils.unregister_class(ARCHIPACK_IO_ExportIfc)
    bpy.utils.unregister_class(ARCHIPACK_OT_IfcBuildRepresentation)
    if USE_LISTENERS:
        load_post.remove(add_listeners)
        load_pre.remove(remove_listeners)