'''-*- coding:utf-8 -*-

Easyref Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

import bpy

# Freeze / Unfreeze - Selection set and select ------------------------------------------------
class Freezer:

# Freeze ---------------------------------------------------------------------------------------------------------
    freeze_list = []

    # Freeze
    def freeze(self, context):
        _freeze = [o for o in context.visible_objects if not o.hide_select and not o.type == 'CAMERA']
        for o in _freeze:
            o.hide_select = True
            Freezer.freeze_list = _freeze


    def unfreeze(self):
        _freeze = Freezer.freeze_list
        for o in _freeze:
            o.hide_select = False
        _freeze.clear()

    # set_selection
    def save_selection(self, context):
        Freezer.act = getattr(context, 'active_object')
        Freezer.selection = [o.name for o in context.selected_objects]

        if Freezer.act:
            Freezer.mode = context.object.mode
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')

    # Restore_selection
    def restore_selection(self, context):

        bpy.ops.object.select_all(action='DESELECT')

        for name in Freezer.selection:
            o = context.scene.objects.get(name)
            o.select_set(state=True)

        context.view_layer.objects.active = Freezer.act

        if context.object is not None and Freezer.mode is not None:
            bpy.ops.object.mode_set(mode=Freezer.mode)

        # print('---------------------------------------------->')
        Freezer.act = None
        Freezer.mode = None
        Freezer.selection.clear()

    def get_rv(self, cam_prop, cam):
        for rv in cam_prop.ref_visibility:
            if rv.name == cam.name:
                return rv
            return None

    # Cleanup
    def cleanup(self):
        Freezer.freeze_list.clear()